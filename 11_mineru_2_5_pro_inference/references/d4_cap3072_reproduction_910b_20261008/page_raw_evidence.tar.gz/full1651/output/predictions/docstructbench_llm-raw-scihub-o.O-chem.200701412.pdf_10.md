Octahedral Pyridine Adducts of Dichlorosilane

FULL PAPER

lar effect has already been discussed for antimony, tin and silicon complexes.\(^{[5,8,31]}\) The negative charge on the pyridine nitrogen atom also increases upon complex formation. Furthermore, the chlorine and hydrogen atoms also bear higher negative charges in complex 1b than in H\(_2\)SiCl\(_2\). These changes in the charge distribution are evidence for a bonding situation in the complex that involves generally more polar bonds than in the starting molecule H\(_2\)SiCl\(_2\). This assumption is confirmed by the bond polarities shown in Table 6. The Si–Cl bond has 26.71 % Si character in H\(_2\)SiCl\(_2\), and this value decreases to 15.86 % and 16.92 % for the valence structures A and B, respectively. A similar effect is observed for the Si–H bond.

Conclusion

Hexacoordinate dichlorosilane/pyridine adducts have been synthesised in various aprotic solvents by the direct reaction of  \( H_{2}SiCl_{2} \)  with pyridine. The first example of an  \( H_{2}SiCl_{2}\cdot2Rpy \)  compound bearing non-coplanar pyridine rings has been found, although a coplanar arrangement of the pyridine ligands seems to be the most typical conformation in the solid state. Quantum chemical analysis demonstrates that both coordination modes may be favourable. Some of these pyridine adducts (those bearing 4-methyl- and 4-ethylpyridine) have been shown to undergo ligand redistribution when extracted with hot chloroform to yield the hexacoordinate siliconium salts  \( [H_{2}Si(RPy)_{4}]Cl_{2} \) , the anion of which is stabilised by chloroform molecules.

The \(^{29}\mathrm{Si}\) CP/MAS NMR spectra of the adducts \(\mathrm{H}_2\mathrm{SiCl}_2\cdot 2\mathrm{Rpy}\) reveal large spans for the shielding tensors of their octahedrally coordinated silicon nuclei, and GIAO calculations have provided an insight into the directions of the principal components [(11), (22) and (33)] of the shielding tensors, which point almost along the Cl-Si-Cl, H-Si-H and N-Si-N axes, respectively. The highest shielding is observed in the direction of the Si-H and Si-N bonds, and the shielding is considerably lower in the direction of the Si-Cl bonds. Quantitative descriptions of those shielding tensors, however, are difficult due to general problems with the modelling of H-Si bond influences on \(^{29}\mathrm{Si}\) NMR properties, which have not yet been overcome.

Four possible valence structures A–D have been investigated with the NBO method, with the valence structures B, C and D being equally good descriptions of the bonding situation. The NBO analysis reveals that these structures contain polar covalent Si–H bonds, strong polar Si–Cl bonds, and that the highest bond polarisation is observed for the Si–N interaction, which therefore has to be considered as a donor–acceptor interaction. Analysis of the topological properties of the electron density distribution (AIM) suggests that the Lewis structure C is the best description for the bonding situation in molecules of the type  \( H_{2}SiCl_{2}\cdot2Rpy \) .

Experimental Section

Caution: Handling of dichlorosilane is not trivial due to its low boiling point of  \( 8.4^{\circ} \) C and oxidative and hydrolytic sensitivity. All reactions were carried out under dry argon using Schlenk techniques. Solvents were dried and purified by standard methods. CP/MAS NMR spectra were recorded with a Bruker Avance 400 MHz WB spectrometer by using a 7-mm probehead with zirconia rotors and KelF inserts operating at 400.23, 100.61 and 79.51 MHz for  \( {}^{1} \) H,  \( {}^{13} \) C and  \( {}^{29} \) Si, respectively. Chemical shifts are reported in ppm relative to TMS. Raman spectra were recorded with a Bruker RFS 100/S instrument equipped with an Nd/YAG Laser. X-ray single crystal structure analyses were carried out with a Bruker Nonius X8 APEX2 CCD diffractometer. Elemental analysis (determination of the chlorine content of product 1c) was performed by hydrolysis of 0.15 g of 1c in 100 mL of dilute sodium hydroxide solution followed by chloride quantification by ion chromatography (Dionex, ICS-2000; eluent: 22 mM KOH; column: AS11 HC, electrical conductivity measurement).

The structures were solved by direct methods and refined by full-matrix least-squares methods. All non-hydrogen atoms were refined anisotropically. Carbon-bonded hydrogen atoms were placed in idealised positions and refined isotropically (riding model). Si-bonded hydrogen atoms were found by analysis of the residual electron density and refined without bond length restraints. Structure solution and refinement of  \( F^{2} \)  against all reflections were carried out with the software SHELXS-97 and SHELXL-97 (G. M. Sheldrick, Universität Göttingen (1986–1997)). Structure determination and refinement data for the crystal structures presented in this paper are summarised in Tables 8, 9 and 10. CCDC 621840 (1a), 621841 (1b), 621839 (1c), 634403 (1d), 621844 (1e), 621843 (1f), 621845 (2), 621846 (3d) and 621842 (3e) contain the supplementary crystallographic data for this paper. These data can be obtained free of charge from the Cambridge Crystallographic Data Centre via www.ccdc.cam.ac.uk/data_request/cif.

The Quantum chemical calculations were carried out using the GAUSSIAN 03 program suite.\(^{[32]}\) The solid-state geometries obtained from X-ray structure analyses were used for the calculations without further optimisation. The calculations were performed at the density functional theory level (DFT), using Becke's three-parameter hybrid exchange functional and the correlation functional of Lee, Yang and Parr (B3LYP),\(^{[33,34]}\) with the 6-311 + G(2d,p) basis set for all atoms.\(^{[35-37]}\)

The AIM analyses \( ^{[22]} \) were performed at the B3LYP/6-311+G(2d,p) level with the geometries obtained from the X-ray structure analyses.

The wavefunction files for the AIM analysis were generated in Cartesian coordinates with a basis set containing 6d functions (option “6D 10F” in Gaussian 03). The electron-density topology was analysed by using the programs AIM2000 \( ^{[38]} \) and Xaim. \( ^{[39]} \)

The NBO analyses were performed with NBO 3.0. \( ^{[28]} \)  The different valence structures A–D were generated with the “CHOOSE” option in the NBO programme.

Relaxed potential energy surface (PES) scans were performed with the Opt=ModRedundant utility in Gaussian 03 with B3LYP/6-31G(d). This option includes the specification of redundant internal coordinates. In these cases, a specific torsion angle was changed in  \( 5^{\circ} \)  steps. The geometry of the molecule was completely optimised in every step whilst restricting only the torsion angle to the specified value. This method allows access to a defined section of the potential energy surface.

The principal components of the NMR shielding tensor were extracted from the spectra using the HB-MAS program (D. Fenzke, Universität Leipzig 1989).

NMR shielding tensors were calculated by the Gauge-Independent Atomic Orbital method (GIAO) \( ^{[40]} \) at the B3LYP/6-311+G(2d,p) level of theory with the geometries obtained from the X-ray structure analyses. Calculated absolute shielding values were converted to relative shifts ( \( \delta \) ) by calculating the shielding of tetramethylsilane at the same level of theory.

\( H_{2}SiCl_{2} \)  (Degussa), 4-methylpyridine (Alfa Aesar), 4-ethylpyridine (Merck), 3-bromopyridine (ABCR), 4-tert-butylpyridine (Fluka), 4-vinyl-

Chem. Eur. J. 2008, 14, 3164–3176

© 2008 Wiley-VCH Verlag GmbH & Co. KGaA, Weinheim

www.chemeurj.org

3173