www.cheminform.wiley-vch.de

ChemInform®

Germanium I 4700
25-015

DOI: 10.1002/chin.201025015

Mixed Cations and Structural Complexity in  \( (\mathrm{Eu}_{1-x}\mathrm{Ca}_{x})_{4}\mathrm{In}_{3}\mathrm{Ge}_{4} \)  and  \( (\mathrm{Eu}_{1-x}\mathrm{Ca}_{x})_{3}\mathrm{In}_{2}\mathrm{Ge}_{3} \)  — The First Two Members of the Homologous Series  \( A_{2[n+m]}In_{2n+m}Ge_{2[n+m]} \)  (n, m = 1, 2,  \( \cdots\infty \) ; A: Ca, Sr, Ba, Eu, or Yb). —  \( Eu_{1.23}Ca_{2.77}In_{3}Ge_{4} \)  (I),  \( Eu_{2.60}Ca_{1.40}In_{3}Ge_{4} \)  (II),  \( Eu_{0.30}Ca_{2.70}In_{2}Ge_{3} \)  (III), and  \( Eu_{0.66}Ca_{2.34}In_{2}Ge_{3} \)  (IV) are synthesized from the elements in a molten In metal flux (960 °C, 20 h). The compounds are characterized by single crystal XRD, magnetic susceptibility measurements, and TB-LMTO band structure calculations. (I) and (II) crystallize in the space group C2/m with Z = 2, and (III) and (IV) in the space group Pnma with Z = 4. The polyanionic substructures of the compounds are based on  \( InGe_{4} \)  edge-sharing tetrahedra,  \( Ge_{2} \)  dimers, and bridging In atoms in a nearly square planar environment. — (YOU, T.-S.; TOBASH, P. H.; BOBEV*, S.; Inorg. Chem. 49 (2010) 4, 1773-1783; Dep. Chem. Biochem., Univ. Del., Newark, DE 19716, USA; Eng.) — W. Pewestorf

ChemInform 2010, 41, issue 25

© 2010 Wiley-VCH Verlag GmbH & Co. KGaA, Weinheim