TREATMENT ADHERENCE BY BIPOLAR DISORDER PATIENTS

99

of patient-reported nonadherence equivalent to major defaulting on 20–30% of days would be needed to accord with comparable nonadherence estimates of 6% of patients made by their physicians (Table 2).

These self-reports of incomplete adherence with prescribed treatments for BPD in one-third of patients are unverified, but the risk of under-reporting may be limited by the very sensitive standard applied in an effort to detect the “worst case” for incomplete treatment-adherence. In addition to the self-reported, recent incomplete treatment-adherence just noted, 32.9% [137/417] of patients also reported having discontinued all recommended medications for BPD at some point in the past, without informing their physicians. Leading reasons given for such patient-initiated discontinuation of treatment, among 130 patients providing such information, ranked: (a) not needing it any longer (22.3%) > (b) no longer wanting to take it (18.5%) > (c) side effects (13.1%]) > (d) feeling better at the time (10.8%).

The rate of reported major defaulting in the past (32.9%) and the rate of missing recent single doses (33.8%) is similar, and many cases of previous and current nonadherence (45.0%) involved the same persons. Both rates represent about one-third of all treated patients with BPD sampled, indicating that some degree of treatment-nonadherence may be quite prevalent among contemporary American BPD patients. The apparently large disparity between physicians' impressions and patient self-reports is noteworthy, but may reflect differences in definitions of “nonadherence,” such that physicians self-defined nonadherence was likely to reflect clinically important levels of missed dosing over undefined periods of risk, whereas patients were asked about even single missed doses within 10 recent days.

Patient assessments of illness and its treatment

When asked a general question about major frustrations of having BPD, patients cited factors related to the illness as well as its treatment (Table 3). Most commonly cited major burdens involving  \( \geq \) 40% of 423 patients providing such data were: mood swings (66.4%) > depression (56.3%) > need for daily self-medication (51.1%) > stigma of being considered mentally ill (43.5%) > uncertain interpersonal relationships (40.4%)  \( \geq \)  medication side-effects (40.2%). Prominent adverse effects associated with treatment-nonadherence, as identified by the 145 patients with self-reported nonadherence, ranked: weight-gain (58.5%)  \( \geq \)  excessive sedation (54.2%) > physical awkwardness or tremor (33.1%).

Table 3. Major frustrations reported by BPD patients

<table><tr><td>Characteristic</td><td>n (%)</td></tr><tr><td colspan="2">Illness-related factors</td></tr><tr><td>Mood swings</td><td>281 (66.4)</td></tr><tr><td>Depressions</td><td>238 (56.3)</td></tr><tr><td>Others&#x27; perceptions/stigma</td><td>184 (43.5)</td></tr><tr><td>Problems with trust/relationships/social interactions</td><td>171 (40.4)</td></tr><tr><td>Holding down a job</td><td>152 (35.9)</td></tr><tr><td>Hospitalization</td><td>118 (27.9)</td></tr><tr><td>Highs of mood</td><td>115 (27.2)</td></tr><tr><td>Lack of information</td><td>26 (6.15)</td></tr><tr><td colspan="2">Treatment-related factors</td></tr><tr><td>Taking medication every day</td><td>216 (51.1)</td></tr><tr><td>Medication side-effects</td><td>170 (40.2)</td></tr><tr><td>Cost of treatment</td><td>3 (0.71)</td></tr><tr><td colspan="2">Miscellaneous factors</td></tr><tr><td>Other</td><td>34 (8.04)</td></tr></table>

Responding patients \((N = 423; 98.6\%)\) cited four major frustrations/person (1708/423).

Physician assessments of treatment

When psychiatrists were asked to report improvements in treatments for BPD patients needed to increase acceptance and adherence to treatment, the most common response was the need for better mood-stabilization in 48.0% of their 429 patients. In addition, they identified freedom from weight-gain as important for treatment-acceptance among 29.1% of their patients, and improvement of treatment-unresponsive depression in 30.8%. They also estimated that at least 59.0% of their BPD patients had experienced adverse effects of psychotropic medications at some time in the past, that adverse effects were of current concern to 14.0% of patients (60/429), and were considered by their physicians to be severe in 15.0% (9/60) of that subgroup. Psychiatrists reported further that 30.5% of their 429 BPD patients had experienced weight-gain in association with current treatment, with substantial prevalence of hyperlipidemia (19.1%) and diabetes (8.62%) and identified these as problems of particular clinical concern.

Univariate analyses of factors associated with treatment-nonadherence

Copyright © 2007 John Wiley & Sons, Ltd.

We compared treatment-nonadherent with treatment-adherent patients on a list of factors identified in the PSF and PRF questionnaires, which yielded a total of 59 variables tentatively related to treatment adherence, based on initial univariate comparisons \((p\leq 0.10)\), and 43 significantly \((p < 0.05)\) associated

Hum. Psychopharmacol Clin Exp 2008; 23: 95–105. DOI: 10.1002/hup