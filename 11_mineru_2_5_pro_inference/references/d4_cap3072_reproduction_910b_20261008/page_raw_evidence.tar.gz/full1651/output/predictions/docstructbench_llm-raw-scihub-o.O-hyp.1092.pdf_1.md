HYDROLOGICAL PROCESSES
Hydrol. Process. 16, 3131–3150 (2002)
Published online 7 August 2002 in Wiley InterScience (www.interscience.wiley.com). DOI: 10.1002/hyp.1092

Daily streamflow modelling and assessment based on the curve-number technique

Jin-Yong Choi,\(^{1*}\) Bernard A. Engel\(^{1}\) and Ha Woo Chung\(^{2}\)

\(^{1}\) Department of Agricultural and Biological Engineering, Purdue University, West Lafayette, IN 47907-1146, USA.  
\(^{2}\) Division of Biological Resources and Material Engineering, Seoul National University, Suwon, Kyounggi 441-744, South Korea

Abstract:

A cell-based long-term hydrological model (CELTHYM) that can be integrated with a geographical information system (GIS) was developed to predict continuous stream flow from small agricultural watersheds. The CELTHYM uses a cell-by-cell soil moisture balance approach. For surface runoff estimation, the curve number technique considering soil moisture on a daily basis was used, and release rate was used to estimate baseflow. Evapotranspiration was computed using the FAO modified Penman equation that considered land-use-based crop coefficients, soil moisture and the influence of topography on radiation. A rice paddy field water budget model was also adapted for the specific application of the model to East Asia. Model sensitivity analysis was conducted to obtain operational information about the model calibration parameters. The CELTHYM was calibrated and verified with measured runoff data from the WS#1 and WS#3 watersheds of the Seoul National University, Department of Agricultural Engineering, in Hwaseong County, Kyounggi Province, South Korea. The WS#1 watershed is comprised of about 35·4% rice paddy fields and 42·3% forest, whereas the WS#3 watershed is about 85·0% forest and 11·5% rice paddy fields. The CELTHYM was calibrated for the parameter release rate, K, and soil moisture storage coefficient, STC, and results were compared with the measured runoff data for 1986. The validation results for WS#1 considering all daily stream flow were poor with  \( R^{2} \) ,  \( E^{2} \)  and RMSE having values of 0·40, -6·63 and 9·69 (mm), respectively, but validation results for days without rainfall were statistically significant ( \( R^{2}=0·66 \) ). Results for WS#3 showed good agreement with observed data for all days, and  \( R^{2} \) ,  \( E^{2} \)  and RMSE were 0·92, 0·91 and 2·23 (mm), respectively, suggesting potential for CELTHYM application to other watersheds. The direct runoff and water balance components for watershed WS#1 with significant areas of paddy fields did not perform well, suggesting that additional study of these components is needed. Copyright © 2002 John Wiley & Sons, Ltd.

KEY WORDS watershed modelling; GIS; soil moisture balance; grid-based modelling, paddy field water balance; model calibration; sensitivity analysis; model assessment

INTRODUCTION

Water resources development and watershed management require an understanding of hydrological variations owing to changes in watershed characteristics over long-term periods (Bhaduri et al., 2000), and spatial variability of watershed characteristics that affect hydrological phenomenon also must be evaluated in heterogeneous land-use watersheds. However, hydrological model operations that reflect long-term watershed changes often have limitations owing to difficulties obtaining measured hydrological data and data quantifying land use and soil characteristics. Therefore, simulation of stream flow on a daily basis using a long-term hydrological model that is simple to operate with readily available data is needed.

Continuous models, also called long-term hydrological models or continuous stream flow models, typically are focused on estimating water yield from a watershed. Owing to complications and difficulties related to data preparation and operation, however, these hydrological models largely have been used for daily, 10-day and

* Correspondence to: Jin-Yong Choi, Department of Agricultural and Biological Engineering, Purdue University, West Lafayette, IN 47907-1146, USA. E-mail: jychoi@ecn.purdue.edu

Copyright © 2002 John Wiley & Sons, Ltd.

Received 22 February 2001  
Accepted 30 November 2001