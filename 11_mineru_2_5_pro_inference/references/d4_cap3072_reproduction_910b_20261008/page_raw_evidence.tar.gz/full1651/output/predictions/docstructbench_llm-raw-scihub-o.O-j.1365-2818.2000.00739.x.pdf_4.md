62

K. BAHLMANN AND S. W. HELL

Fig. 5. Measured integral fluorescence \(\Phi\) (dots) for a low semi-aperture angle \((14.3^{\circ})\) as a function of the orientation of the transition dipoles to the polarization of the illuminating field. The line is fitted by a cosine squared function. The measured modulation contrast in this measurement is 1: 277.

10  \( \mu \) m pinhole it flattened out the beam profile across the entrance pupil of the objective lens. The frequency doubled beam was polarized by a Glan–Thomson prism with a polarization ratio of  \( 10^{-6} \) . A zero-order  \( \lambda/2 \) -plate mounted on a stepping motor precisely rotated the orientation of the incoming field with respect to the layer.

We placed a mount in front of the objective lens that allowed us to insert various beam shaping elements, such as beam stops of various size. The objective lens was a NA = 1.4 oil immersion lens (Leica 100×, Planapo, Wetzlar, Germany). It is connected with a semiaperture angle of 67.3°, which is the highest for immersion lenses. Annuli were produced by obstructing the central part of the beam with a black circular foil attached to a plane parallel glass plate, as indicated in Figs 1 and 4. The diameters of the circular obstructions were 3.7, 4.5 and 5.0 mm, so that they amounted to 66, 80 and 89% of the diameter of the aperture, respectively. The obstruction was aligned in the beam by observing the transmitted excitation light as a guide. Figure 4 reveals that we also employed a cross-like

Fig. 6. Measured integral depolarization \(\Pi\) in high aperture focusing. The fluorescence \(\Phi\) of the polydiacetylene layer is measured as a function of the angle \(\varphi\) between the orientation of the transition dipoles and the incoming electric field. Angles of \(90^{\circ}\) and \(270^{\circ}\) represent perpendicular orientation, thus allowing for the direct observation of the perpendicularly orientated field in the focal region of the lens for various aperture conditions. The depolarization is strongest, \(5.49\%\), for the narrowest annulus. For the commonly used full aperture of 1.4 oil, \(\Pi\) amounts to \(1.59\%\).

© 2000 The Royal Microscopical Society, Journal of Microscopy, 200, 59–67