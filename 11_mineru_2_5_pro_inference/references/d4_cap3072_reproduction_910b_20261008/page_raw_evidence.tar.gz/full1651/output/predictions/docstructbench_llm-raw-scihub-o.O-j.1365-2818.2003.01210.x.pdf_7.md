STATISTICAL ANALYSIS OF FREEZE FRACTURE SPECIMENS 143

(a)

(c)

(d)

Estimating mean  \( G(r) \)  as ratio of means as in Baddeley et al. (1993) and using the variance estimator for ratio estimators

Fig. 5. Summary statistics (continuous curves) with envelopes (dotted) for rotenone1, given in the same order as in Fig. 3 for untreated1.

Mean G-curves

intervals are so narrow that they are nearly indistinguishable from the mean curve. Therefore the plot is omitted.

leads to the mean curves and confidence bands shown in Fig. 11. Figure 12 shows that the assumption of a linear relation between numerator and denominator in the reduced sample estimator \(\hat{G}_{rs}\) is realistic. The EM algorithm yielded overall mean and variances from the ratio estimators. Figure 13 also shows the overall sample mean with confidence bands estimated from the sample variance.

© 2003 The Royal Microscopical Society, Journal of Microscopy, 211, 137–153