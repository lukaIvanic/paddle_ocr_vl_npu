Section

语气的概述

语气可以分为陈述语气、祈使语气和虚拟语气。虚拟语气又有七种基本结构。

陈述语气

祈使语气

语气

动词原形

动词的过去式

had + 过去分词

虚拟语气

should + 动词原形

should(第一人称)和 would(第二、三人称) + 动词原形

should(第一人称)和 would(第二、三人称) + have + 过去

分词

should + 动词原形

一 陈述语气

陈述语气表示所说的话是陈述事实、提出想法。

陈述语气可以用于各种时态,多用于陈述句、疑问句及部分感叹句中。She went to the office this morning.

她今天早上去了办公室。

How nice a man he is!

他是多好的一个人啊！

252