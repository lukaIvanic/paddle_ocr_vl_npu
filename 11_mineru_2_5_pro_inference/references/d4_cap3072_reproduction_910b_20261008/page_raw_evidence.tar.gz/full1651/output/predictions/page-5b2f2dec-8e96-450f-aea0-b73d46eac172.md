For \(\beta_1'\), with (S.17) we have with probability at least \(1 - O(n^{-10})\)

\[
\begin{array}{r l} & {\beta_ {1} ^ {\prime} = \left\| \mathbf {R} ^ {* ^ {\top}} \left(\mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {U} ^ {*}\right) \right\| _ {2, \infty}} \\ & {\quad \leq \sigma_ {1} ^ {*} \left\| \mathbf {V} ^ {*} \right\| _ {2, \infty} \left\| \mathbf {U} ^ {* ^ {\top}} \mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {I} _ {K} \right\| \lesssim \frac {\kappa^ {*} \sigma^ {2} (M N + J)}{\sigma_ {K} ^ {*}} \left\| \mathbf {V} ^ {*} \right\| _ {2, \infty}.} \end{array}
\]

(S.33)

For \(\beta_2'\), introducing the "leave-one-block-out" alternative \(\mathbf{U}^{(j)}\) yields that

\[
\begin{array}{l} \beta_ {2} ^ {\prime} = \max _ {j \in [ J ]} \left\| \mathbf {E} _ {:, j} ^ {\top} \left(\mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {U} ^ {*}\right) \right\| _ {2} \\ \leq \underbrace {\max _ {j \in [ J ]} \left\| \mathbf {E} _ {: , j} ^ {\top} \left(\mathbf {U} ^ {(j)} \mathbf {U} ^ {(j) ^ {\top}} \mathbf {U} ^ {*} - \mathbf {U} ^ {*}\right) \right\|} _ {\gamma_ {1} ^ {\prime}} + \underbrace {\max _ {j \in [ J ]} \left\| \mathbf {E} _ {: , j} ^ {\top} \left(\mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {U} ^ {(j)} \mathbf {U} ^ {(j) ^ {\top}} \mathbf {U} ^ {*}\right) \right\|} _ {\gamma_ {2} ^ {\prime}}. \end{array}
\]

(S.34)

Upper bounding \(\gamma_1'\) in (S.34). Utilizing Lemma S.4, one has at least \(1 - O(d^{-11})\) that,

\[
\begin{array}{l} \gamma_ {1} ^ {\prime} \leq \sigma \sqrt {\log d} \underset {j \in [ J ]} {\max} \left\| \mathbf {U} ^ {(j)} \mathbf {U} ^ {(\top)} \mathbf {U} ^ {*} - \mathbf {U} ^ {*} \right\| _ {F} + B \log d \underset {j \in [ J ]} {\max} \left\| \mathbf {U} ^ {(j)} \mathbf {U} ^ {(\top)} \mathbf {U} ^ {*} - \mathbf {U} ^ {*} \right\| _ {2, \infty} \\ \leq \sigma \sqrt {\log d} \| \mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {U} ^ {*} \| _ {F} + \sigma \sqrt {\log d} \underset {j \in [ J ]} {\max} \| \mathbf {U} ^ {(j)} \mathbf {U} ^ {(\top)} \mathbf {U} ^ {*} - \mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} \| _ {F} \\ \quad + B \log d \| \mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {U} ^ {*} \| _ {2, \infty} + B \log d \underset {j \in [ J ]} {\max} \| \mathbf {U} ^ {(j)} \mathbf {U} ^ {(\top)} \mathbf {U} ^ {*} - \mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} \| _ {2, \infty} \\ \leq \sigma \sqrt {\log d} \left\| \mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {U} ^ {*} \right\| _ {F} + B \log d \left\| \mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {U} ^ {*} \right\| _ {2, \infty} \\ \quad + \left(\sigma \sqrt {\log d} + B \log d\right) \underset {j \in [ J ]} {\max} \left\| \mathbf {U} ^ {(j)} \mathbf {U} ^ {(\top)} - \mathbf {U} \mathbf {U} ^ {\top} \right\| _ {F} \\ \lesssim \sigma \sqrt {\log d} \left\| \mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {U} ^ {*} \right\| _ {F} + B \log d \left\| \mathbf {U} \mathbf {U} ^ {\top} \mathbf {U} ^ {*} - \mathbf {U} ^ {*} \right\| _ {2, \infty} \\ \quad + B \log d \left\| \mathbf {U} ^ {(j)} \mathbf {U} ^ {(\top)} - \mathbf {U} \mathbf {U} ^ {\top} \right\| _ {F}, \end{array}
\]

(S.35)

where the last line holds since \(\sigma \sqrt{\log d} \ll B \log d\).

To bound \(\max_{j\in [J]}\left\| \mathbf{U}^{(j)}\mathbf{U}^{(j)} - \mathbf{U}\mathbf{U}^{\top}\right\|_{F}\) in the RHS above, we apply Wedin's theorem with (S.31) and obtain

\[
\begin{array}{r l} & {\max \left\{\left\| \mathbf {U} \mathbf {U} ^ {\top} - \mathbf {U} ^ {(j)} \mathbf {U} ^ {(j) ^ {\top}} \right\| _ {F}, \left\| \mathbf {V} \mathbf {V} ^ {\top} - \mathbf {V} ^ {(j)} \mathbf {V} ^ {(j) ^ {\top}} \right\| _ {F} \right\}} \\ & {\lesssim \frac {\max \left\{\left\| \mathcal {P} _ {: , S _ {l _ {j}}} (\mathbf {E}) ^ {\top} \mathbf {U} ^ {(j)} \right\| _ {F} , \left\| \mathcal {P} _ {: , S _ {l _ {j}}} (\mathbf {E}) \mathbf {V} ^ {(j)} \right\| _ {F} \right\}}{\sigma_ {K} ^ {*}}.} \end{array}
\]

(S.36)

51