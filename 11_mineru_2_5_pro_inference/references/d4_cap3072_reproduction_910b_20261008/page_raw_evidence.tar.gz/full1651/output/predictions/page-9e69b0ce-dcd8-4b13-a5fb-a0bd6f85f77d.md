【571】设 \(f(x)\) 与 \(g(x)\) 在 \((-\infty, +\infty)\) 内连续，且 \(f(x) < g(x)\)，则当 \(x \neq 0\) 时必有  
(A) \(\int_{0}^{x} f(t) \mathrm{d}t < \int_{0}^{x} g(t) \mathrm{d}t.\) (B) \(\int_{0}^{x^2} f(t) \mathrm{d}t < \int_{0}^{x^2} g(t) \mathrm{d}t.\)  
(C) \(\int_{0}^{+\infty} f(x) \mathrm{d}x < \int_{0}^{+\infty} g(x) \mathrm{d}x.\) (D) \(\int_{0}^{x^2} |f(t)| \mathrm{d}t < \int_{0}^{x^2} |g(t)| \mathrm{d}t.\)

【572】设 a 与 b 是两个常数, 且  \( \lim_{x\to+\infty}\mathrm{e}^{x}\left(\int_{0}^{\sqrt{x}}\mathrm{e}^{-t^{2}}\mathrm{d}t+a\right)=b \) , 则
(A) a 为任意常数, b = 0.
(B)  \( a = -\frac{\sqrt{\pi}}{2}, b = 0. \) 
(C) a = 0, b = 1.
(D)  \( a = -\sqrt{\pi}, b = 0. \)

第85页/共133页