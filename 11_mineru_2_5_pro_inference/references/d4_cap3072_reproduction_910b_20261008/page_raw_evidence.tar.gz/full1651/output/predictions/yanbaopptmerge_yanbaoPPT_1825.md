教学活动 2

已知三角形的两边及其夹角，求作三角形

已知: 线段 \(a\), \(b\), \(\angle a\), 求作: \(\triangle ABC\), 使 \(BC = a\),

\( {AB} = c,\;\angle {ABC} = \angle a \)

作法与示范

作法

(1) 作 \(\angle MBN = \angle \alpha\)

(2) 在射线 B M 上截取 BC = a，在射线 B N 上截取 BA =

(3) 连接 AC

则 \( \triangle ABC \) 为所求作的三角形