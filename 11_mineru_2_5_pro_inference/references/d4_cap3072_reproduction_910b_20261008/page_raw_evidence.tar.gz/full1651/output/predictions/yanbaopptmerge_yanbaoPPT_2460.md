奇点分类（III）

- \(\Delta = 0 \mathrm{~A}\), 有两个相同的特征值

\[
2
\]

\[
\begin{array}{l} \mathbf {P} \xi \xi \left( \begin{array}{c c c} & & \\ & 1 & & 2 \end{array} \right) \\ d u \end{array} \quad \mathbf {P} ^ {- 1} \mathbf {A} \mathbf {P} = \left( \begin{array}{c c} \lambda & \\ & \lambda \end{array} \right)
\]

数学建模

\[
\left\{ \begin{array}{l l} \frac {d u}{d t} = \lambda u & \left\{ \begin{array}{l l} u = u _ {0} e ^ {\lambda t} & \frac {u}{v} = \frac {u _ {0}}{v _ {0}} \\ v = v _ {0} e ^ {\lambda t} & \end{array} \right. \\ \frac {d v}{d t} = \lambda v & \end{array} \right.
\]

\[
\alpha <   0, \lambda <   0
\]

\[
\alpha > 0, \lambda > 0
\]

\[
\frac {d \mathbf {u}}{d t} = \mathbf {P} ^ {- 1} \mathbf {A} \mathbf {P} \mathbf {u}
\]

\[
\alpha = \operatorname{tr} (\mathbf {A}) = \lambda_ {1} + \lambda_ {2}
\]

\[
\beta = | \mathbf {A} | = \lambda_ {1} \lambda_ {2}
\]