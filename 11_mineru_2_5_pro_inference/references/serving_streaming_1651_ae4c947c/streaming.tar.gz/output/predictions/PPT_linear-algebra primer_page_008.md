Bases & Orthonormal Bases

Basis (or axes): frame of reference

Basis: a space is totally defined by a set of vectors – any point is a linear combination of the basis

Ortho-Normal: orthogonal + normal

[Sneak peek:

Orthogonal: dot product is zero

Normal: magnitude is one ]

Rensselaer Polytechnic Institute

\[
x = \left[ \begin{array}{c c c} 1 & 0 & 0 \end{array} \right] ^ {T} \quad x \cdot y = 0
\]

\[
y = \left[ \begin{array}{c c c} 0 & 1 & 0 \end{array} \right] ^ {T} \qquad \quad x \cdot z = 0
\]

\[
z = \left[ \begin{array}{c c c} 0 & 0 & 1 \end{array} \right] ^ {T} \quad \quad \quad y \cdot z = 0
\]

Shivkumar Kalyanaraman

8

Google": "shiv rpi"