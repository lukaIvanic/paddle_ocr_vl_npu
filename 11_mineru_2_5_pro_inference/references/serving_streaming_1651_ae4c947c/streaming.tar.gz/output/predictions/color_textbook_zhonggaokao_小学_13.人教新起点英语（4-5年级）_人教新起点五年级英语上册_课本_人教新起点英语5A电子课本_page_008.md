3. Now read and tick.

<table><tr><td>make model ships( )</td><td>make model planes( )</td><td>cute( )</td><td>clever( )</td></tr><tr><td>helpful( )</td><td>polite( )</td><td>popular( )</td><td>active( )</td></tr></table>

<table><tr><td>quiet</td><td>careless</td></tr><tr><td>( )</td><td>( )</td></tr></table>

B Let's play a guessing game.

Talk about our friends.

© Let's write.

What is Peter like?

5