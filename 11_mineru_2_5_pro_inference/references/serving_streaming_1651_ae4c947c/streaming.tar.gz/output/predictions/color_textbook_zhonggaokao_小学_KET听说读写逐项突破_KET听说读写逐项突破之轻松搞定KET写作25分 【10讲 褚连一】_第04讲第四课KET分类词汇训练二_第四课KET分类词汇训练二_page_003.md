KET分类词汇训练

<table><tr><td>painter</td><td>painter n. 画家</td></tr><tr><td>photography</td><td>photography n. 摄影</td></tr><tr><td>pratice/pratise</td><td>pratice/pratise n./v. 练习,实践</td></tr><tr><td>prize</td><td>prize n. 奖品</td></tr><tr><td>programme</td><td>programme n. 节目</td></tr><tr><td>project</td><td>Project n. 工程、项目</td></tr><tr><td>website</td><td>website n. 网站</td></tr><tr><td>present</td><td>present n. 礼物</td></tr><tr><td>actor</td><td>actor n. 男演员</td></tr><tr><td>artist</td><td>artist n. 艺术家</td></tr><tr><td>businessman</td><td>businessman n. 商人</td></tr></table>

KET 分类词汇训练

<table><tr><td>chemist</td><td>chemist n. 化学家,药剂师</td></tr><tr><td>cleaner</td><td>cleaner n,清洁工</td></tr><tr><td>colleague</td><td>colleague n.同事</td></tr><tr><td>company</td><td>company n.公司</td></tr><tr><td>computer</td><td>computer n.电脑</td></tr><tr><td>customer</td><td>customer n.顾客</td></tr><tr><td>dentist</td><td>dentist n.牙医</td></tr><tr><td>diploma</td><td>diploma n.文凭</td></tr><tr><td>doctor</td><td>doctor n.医生</td></tr><tr><td>driver</td><td>driver n.司机</td></tr><tr><td>earn</td><td>earn v.赚得,获得</td></tr></table>

KET 分类词汇训练

<table><tr><td>engineer</td><td>engineer n. 工程师</td></tr><tr><td>guest</td><td>guest n. 客人</td></tr><tr><td>guide</td><td>guide n. 引导者、指南</td></tr><tr><td>hairdresser</td><td>hairdresser n. 理发师</td></tr><tr><td>instructions</td><td>instructions n. 说明书</td></tr><tr><td>nurse</td><td>nurse n. 护士</td></tr><tr><td>occupation</td><td>occupation n. 职业</td></tr><tr><td>pharmacy</td><td>pharmacy n. 药房</td></tr><tr><td>photographer</td><td>photographer n. 摄影师</td></tr><tr><td>receptionist</td><td>receptionist n. 接待员</td></tr><tr><td>secretary</td><td>secretary n. 秘书</td></tr></table>

KET 分类词汇训练

<table><tr><td>shop assistant</td><td>shop assistant n. 店员</td></tr><tr><td>staff</td><td>staff n. 全体人员,同事</td></tr><tr><td>uniform</td><td>uniform n. 制服</td></tr><tr><td>accident</td><td>accident n. 事故、意外</td></tr><tr><td>appointment</td><td>appointment n. 约会、预约</td></tr><tr><td>arm</td><td>arm n. 手臂</td></tr><tr><td>body</td><td>body n. 身体</td></tr><tr><td>back</td><td>back n. 后背,脊背</td></tr><tr><td>check</td><td>check n./v. 检查</td></tr><tr><td>dangerous</td><td>dangerous a. 危险的</td></tr><tr><td>dentist</td><td>dentist n. 牙医</td></tr></table>

3