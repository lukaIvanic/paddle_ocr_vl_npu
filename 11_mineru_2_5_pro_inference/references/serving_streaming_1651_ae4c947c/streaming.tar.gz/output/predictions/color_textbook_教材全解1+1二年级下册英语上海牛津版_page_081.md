Module 3 Things around us

have...意为“我有……”。如果主语是第三人称单数，则have要变为第三人称单数形式has。

2. Summer is hot. 夏天很热。

Spring/Summer/Autumn/Winter is...可以用来形容四个季节不同的气候特征。

交际实例

(李欣和澳大利亚的小朋友 Lisa 在视频聊天。)

Li Xin: It's summer. Summer is hot.

Lisa: It's winter now in Australia(澳大利亚).

Li Xin: Is winter cold there?

Lisa: No, winter is hot.

Li Xin: What do you have for winter?

Lisa: I have a T-shirt. I have shorts.

Li Xin: What do you have for summer?

Lisa: I have a sweater. I have trousers.

Li Xin: Wow, so cool. I want to go to Australia.

Lisa: Welcome to Australia!

拓宽视野

- 我们在本单元学习了一些有关服装的单词，除了trousers, sweater, shirt, coat外，下面的有关服装的单词你认识吗？来读一读，学一学吧！

uniform 校服

pants 长裤

jeans 牛仔裤

pajamas 睡衣

jacket 夹克衫

swimsuit 泳衣

underwear 内衣裤

socks 袜子

家长帮一帮

请按照下表所列内容与具体要求,复习本单元重点知识,不积跬步,无以至千里,小朋友加油哦!

<table><tr><td colspan="2">项目与要求</td><td>内容</td><td>复习方式</td></tr><tr><td rowspan="2">词汇</td><td>三会(听说读)</td><td>trousers(长裤),sweater(毛衣),shirt(衬衫),coat(外套)</td><td>★熟读熟记★学会运用</td></tr><tr><td>二会(听说)</td><td>listen(听),woof(狗叫声),too(也),school(学校),together(在一起),ring(铃响),time(时间)</td><td>★指读</td></tr><tr><td colspan="2">句子(听说读)</td><td>Summer is hot.What do you have for...?I have...</td><td>★大声朗读★熟读熟记★学会运用</td></tr><tr><td colspan="2">口语(听说)</td><td>Time for class. /I&#x27;m sorry. /That&#x27;s all right.</td><td>★指读★对话</td></tr><tr><td colspan="2">语音(听读)</td><td>字母l、r的发音(见教材P37)</td><td>★大声朗读★熟读熟记</td></tr></table>

77

关注微信公众号“教辅资料站”获取更多学习资料