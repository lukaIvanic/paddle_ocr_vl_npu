Vol. 17: Cumulative Index

Feeding ecology

New World, 12:252–253, 12:257–263, 12:264t–265t

shrew, 12:268, 12:270

Otariidae, 14:397–398, 14:402–406

pacaranas, 16:387

pacas, 16:418–419, 16:423–424

pangolins, 16:112–113, 16:115–120

peccaries, 15:294–295, 15:298–300

Perissodactyla, 15:219–220

Petauridae, 13:127–128, 13:131–133, 13:133t

Phalangeridae, 13:60, 13:63–66t

pigs, 15:278–279, 15:284–288, 15:289t–290t

pikas, 16:493–494, 16:497–501, 16:501t–502t

pocket gophers, 16:189–190, 16:192–195t, 16:196t–197t

porcupines

New World, 16:368, 16:371–373, 16:374t

Old World, 16:353, 16:357–364

possums

feather-tailed, 13:141, 13:144

honey, 13:137

pygmy, 13:107, 13:110–111

primates, 14:8–9

Procyonidae, 14:310, 14:313–315, 14:315t–316t

pronghorns, 15:414

Pseudocheiridae, 13:116, 13:119–123, 13:122t–123t

rat-kangaroos, 13:75, 13:78–81

rats

African mole-rats, 16:343–344, 16:347–349, 16:349t–350t

cane, 16:334, 16:337–338

chinchilla, 16:445, 16:447–448

dassie, 16:331

spiny, 16:450, 16:453–457, 16:458t

rhinoceroses, 15:253, 15:257–261

rodents, 16:125

sengis, 16:521, 16:524–530, 16:531t

shrews

red-toothed, 13:250–251, 13:255–263, 13:263t

West Indian s, 13:244

white-toothed, 13:267, 13:271–275, 13:276t–277t

Sirenia, 15:193

solenodons, 13:239, 13:241

springhares, 16:309

squirrels

flying, 16:136, 16:139–140, 16:141t–142t

ground, 16:145, 16:147, 16:151–158, 16:158t–160t

scaly-tailed, 16:300, 16:302–305

tree, 16:166, 16:169–174t, 16:175t

Talpidae, 13:281–282, 13:284–287, 13:287t–288t

tapirs, 15:240–241, 15:245–247

tarsiers, 14:94–95, 14:97–99

tenrecs, 13:228–229, 13:232–234, 13:234t

three-toed tree sloths, 13:164–165, 13:167–169

tree shrews, 13:291–292, 13:294–296, 13:297t–298t

true seals, 14:260, 14:261, 14:419–420, 14:427–434, 14:435t

tuco-tucos, 16:427, 16:429–430, 16:430t–431t

ungulates, 15:141–142

Viverridae, 14:337, 14:340–343, 14:344t–345t

walruses, 14:260, 14:414

wombats, 13:52–53, 13:55–56

Xenartha, 13:151–152

protostomes, 2:29, 2:36–37

amphionids, 2:196

amphipods, 2:29, 2:261, 2:265–271

anaspidaceans, 2:182, 2:183

aplacophorans, 2:380, 2:382–385

Arachnida, 2:335, 2:339–352

articulate lampshells, 2:522–523, 2:525–527

bathynellaceans, 2:178, 2:179

beard worms, 2:86, 2:88

bivalves, 2:452–453, 2:457–466

caenogastropods, 2:446, 2:449

centipedes, 2:353, 2:355, 2:358–362

cephalocarids, 2:132, 2:133

Cephalopoda, 2:478, 2:483–489

chitons, 2:395, 2:397, 2:399–401

clam shrimps, 2:148, 2:150–151

copepods, 2:36, 2:300, 2:304–310

cumaceans, 2:230, 2:232

Decapoda, 2:200, 2:204–214

deep-sea limpets, 2:436, 2:437

earthworms, 2:36, 2:66, 2:70–73

echiurans, 2:104, 2:106–107

fairy shrimps, 2:137, 2:139

fish lice, 2:290, 2:292–293

freshwater bryozoans, 2:497, 2:500–502

horseshoe crabs, 2:328, 2:331–332

Isopoda, 2:29, 2:251–252, 2:254–259

krill, 2:186–187, 2:189–192

lampshells, 2:29

leeches, 2:29, 2:76, 2:80–82

leptostracans, 2:162, 2:164–165

lophogastrids, 2:226, 2:227

mantis shrimps, 2:170, 2:173–175

marine bryozoans, 2:504, 2:506–508, 2:510, 2:513–514

mictaceans, 2:241, 2:242

millipedes, 2:365, 2:367–370

monoplacophorans, 2:388

mussel shrimps, 2:312, 2:314–315

mysids, 2:216–217, 2:219–222

mystacocarids, 2:295, 2:297

myzostomids, 2:60, 2:62

Neritopsina, 2:440–441, 2:442–443

nonarticulate lampshells, 2:516, 2:518–519

Onychophora, 2:110, 2:113–114

pauropods, 2:376, 2:377

peanut worms, 2:98, 2:100–101

phoronids, 2:492, 2:494

Polychaeta, 2:36, 2:46–47, 2:50–56

Pulmonata, 2:414, 2:417–421

remipedes, 2:126, 2:128

sea slugs, 2:404–405, 2:407–409

sea spiders, 2:322, 2:324–325

spelaeogriphaceans, 2:243, 2:244

symphylans, 2:372, 2:373

tadpole shrimps, 2:142, 2:145–146

tanaids, 2:236, 2:238–239

tantulocaridans, 2:284, 2:286

Thecostraca, 2:275, 2:278–281

thermosbaenaceans, 2:245, 2:247

tongue worms, 2:320

true limpets, 2:424, 2:426–427