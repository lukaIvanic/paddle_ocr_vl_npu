286

M. Yoshikawa et al./Sensors and Actuators B 104 (2005) 282–288

Fig. 5. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-D-Trp imprinted ODMAAN-533.  \( [(Ac-D-Trp)/(ODMA) = 0.17, K_{S,app} = 5.5 \times 10^{3} \, mol^{-1} \, dm^{3}] \) .

Fig. 6. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-L-Trp imprinted ODMAN-533.  \( [(Ac-L-Trp)/(ODMA) = 0.17, K_{S,app} = 5.5 \times 10^{3} \, mol^{-1} \, dm^{3}] \) .

Fig. 7. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-D-Trp imprinted ODMAAN-533.  \( [(Ac-D-Trp)/(ODMA) = 0.21, K_{S,app} = 1.20 \times 10^{4} \, mol^{-1} \, dm^{3}] \) .

Fig. 8. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-L-Trp imprinted ODMAN-533.  \( [(Ac-L-Trp)/(ODMA) = 0.21, K_{S,app} = 1.16 \times 10^{4} \, mol^{-1} \, dm^{3}] \) .

\[
\Delta \theta = f [ \mathrm{Ac-D-Trp} ] _ {\mathrm{m}} = f k _ {\mathrm{A,app}} [ \mathrm{Ac-D-Trp} ]
\]

and those for the L-isomer can be represented by the following equation:

\[
\begin{array}{l} \Delta \theta = f [ \mathrm{Ac-L-Trp} ] _ {\mathrm{m}} \\ = f \left\{P e _ {\mathrm{A,app}} [ \mathrm{Ac-L-Trp} ] + \frac {K _ {\mathrm{S,app}} [ \mathrm{Site} ] _ {0} [ \mathrm{Ac-L-Trp} ]}{1 + K _ {\mathrm{S,app}} [ \mathrm{Ac-L-Trp} ]} \right\} \\ \end{array}
\]

The apparent affinity constant between Ac-i-Trp and the formed chiral recognition site, which was constructed by the presence of i-isomer during the molecular imprinting process, was determined by the following procedure: the difference in the shift  \( (\Delta\theta)_{S} \) , between that for Ac-i-Trp, which was adsorbed not only on the chiral recognition site toward i-isomer but also on the non-specific region, and that for Ac-j-Trp, which was non-specifically adsorbed, was