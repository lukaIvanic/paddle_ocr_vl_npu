LibreTexts™

We will explore a more detailed analysis of these orbital interactions in the next chapter. For now, we can summarize the most common outcomes in the table below. We should note that there is one important cycloaddition, the \([2 + 2]\) thermal reaction of ketenes that does not conform to this generalized analysis.

Generalized Statement of Woodward-Hoffmann Rules for Cycloadditions

<table><tr><td>Number of Electrons</td><td>Thermal</td><td>Photochemical</td></tr><tr><td>4n + 2</td><td>Allowed</td><td>Forbidden</td></tr><tr><td>4n</td><td>Forbidden</td><td>Allowed</td></tr></table>

Electrocyclic Reactions

Electrocyclic reactions are intramolecular reactions that are ring closing (form a sigma bond) or ring opening (break a sigma bond). The key sigma bond, either formed or broken, must be at the terminus of a pi system so that either the product or reactant must be a fully conjugated diene, triene, etc. These reactions are often reversible and are classified by the number of pi electrons involved. Thus, 4 pi reactions involve the forming/breaking of 4 membered rings, 6 pi reactions involve the forming/breaking of 6 membered rings, and so on. The 4 pi and 6 pi variants are by far the most common and are illustrated below with the key sigma bond highlighted in magenta.

Electrocyclic reactions happen from the HOMO of the molecule and differ in their outcomes based on orbital rotation for the forming/breaking sigma bond. If the orbitals involved rotate in the same direction (both counterclockwise or both clockwise), the process is called conrotatory. If the orbitals involved rotate in opposite directions (one clockwise and one counterclockwise), the process is called disrotatory. These differences in rotation are critically important when stereocenters are formed or broken.

As illustrated below, treatment of the substituted hexatriene shown yields the cis product when heated but the trans product when treated with light. This can be explained by looking at the pi HOMO for each case. For the thermal reaction, the HOMO is psi 3 which rotates in a disrotatory fashion to yield the cis product while the trans product is formed under irradiation due to the conrotatory motion of the HOMO psi 4.

We will delve deeper into this analysis in a subsequent chapter. In general, electrocyclic reactions behave according the generalized rules outlined below.

Generalized Statement of Woodward-Hoffmann Rules for Electrocyclic Reactions

<table><tr><td>Number of Electrons</td><td>Thermal</td><td>Photochemical</td></tr><tr><td>4n + 2</td><td>Disrotatory</td><td>Conrotatory</td></tr><tr><td>4n</td><td>Conrotatory</td><td>Disrotatory</td></tr></table>

Chapter 1.1.2

https://chem.libretexts.org/@go/page/355137