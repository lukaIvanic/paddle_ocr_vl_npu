[单词拓展] \(4\mathrm{th} =\) fourth \(5\mathrm{th} =\) fifth

Unit 4

( B )4. Friday

A. on

B. Monday

( )5.maths

A. English

B. school

六、选择正确的答案，将其序号填入题前括号里。

( )1. May Day is on ____.

A. May 1st

B. March 1st

C. April 1st

( )2. My mother's birthday is on ____.

A. July 3st

B. July 2nd

C. July 1rd

( )3. The eleventh day of the first month in a year is ____.

A. January 11th

B. November 11th

C. November 1st

七、看图,写出合适的单词(简写形式)补全句子。

1. —When is Miss Chen's birthday?

—Her birthday is on August ____.

2. —When is Youth Day(青年节)?

—It's on May ____.

3. —When is the singing contest?

—It's on January ____ .

4. —When is Mr Black's birthday?

—His birthday is on October ____.

5. —When is New Year's Day?

—It's on January ____ .

八、选择正确的句子补全对话，将其序号填在横线上。

Amy: When is the sports meet?

Lisa: 1.

Amy: 2.

Lisa: It's on June 10th.

Amy: Tomorrow is June 10th.

Lisa: Oh! Really? 3.

九、任务型阅读。

下面是 Sarah 的时间安排表。

<table><tr><td>Month</td><td>Activity</td><td>Date</td></tr><tr><td rowspan="2">May</td><td>singing contest</td><td>May 4th</td></tr><tr><td>brother&#x27;s birthday</td><td>May 10th</td></tr><tr><td rowspan="3">June</td><td>Children&#x27;s Day party</td><td>June 1st</td></tr><tr><td>Chinese test</td><td>June 29th</td></tr><tr><td>English test maths test</td><td>June 30th</td></tr></table>

任务一:阅读表格,判断下列句子正误,正确的写“T”,错误的写“F”。

( )1. The singing contest is in May.

( )2. Sarah's brother's birthday is on May 4th.

( )3. Sarah will have a party on Children's Day.

( )4. The maths test is on June 29th.

任务二:仿照例子,写句子。

例: The English test is on June 30th.

5. The Chinese test ____

6. My father's birthday ____ (根据实际情况回答问题)

评一评

五年级英语(下) RP

4 1

关注微信公众号“教辅资料站”获取更多学习资料