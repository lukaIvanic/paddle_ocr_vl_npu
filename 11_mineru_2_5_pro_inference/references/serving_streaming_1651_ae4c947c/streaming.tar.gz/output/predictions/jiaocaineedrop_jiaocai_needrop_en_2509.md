扬帆天天练

思维拓展

四、情景安排。

( )1.你想让别人和你一起擦窗户,你应该说:

A. Let me clean the classroom.

B. Let's clean the windows.

C. Let me clean the windows.

( )2.你想自己擦桌子,你应该说:

A. Let me clean the chair.

B. Let's clean the windows.

C. Let me clean the desk.

( )3. 当你想帮助别人时,你应该说:

A. Let you help me.

B. Please help me.

C. Let me help you.

( )4. 当别人帮助你时,你应该说:

A. Excuse me.

B. Thank you.

C. I'm sorry.

1. Let's clean the ____ . (chairs,desks)

2. My picture is near the ____ . (door, window)

3. ____ the window. (Open,Close)

4. Let me clean the ____ . (teacher's desk, teachers' office)

5. ____ (让我们) clean the classroom. (Let me, Let's)

9

关注微信公众号“教辅资料站”获取更多学习资料