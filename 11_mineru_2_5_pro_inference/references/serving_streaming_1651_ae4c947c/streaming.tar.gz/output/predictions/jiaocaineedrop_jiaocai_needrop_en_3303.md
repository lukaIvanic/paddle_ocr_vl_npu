数学二年级（下）63QD

第 2 课时 用竖式计算有余数的除法

基础练兵坊

一、括号里最大能填几？

\[
\square \div 8 = \square \dots\dots (\quad) \quad \square \div 5 = \square \dots\dots (\quad)
\]

\[
\square \div 3 = \square \dots\dots (\quad) \quad \square \div 6 = \square \dots\dots (\quad)
\]

\[
\square \div 9 = \square \dots\dots (\quad) \quad \square \div 7 = \square \dots\dots (\quad)
\]

二、想一想，填一填。

48个苹果,平均分给9个同学,每人分几个?

\( 48\div9=\square \)  (个)……□(个)

读作：____

\[
9 \times \square <   4 8
\]

三、数学诊断。（对的打“√”，错的打“×”，并改正）

\[
\begin{array}{r} 4 \\ 3 \overline {{) 1 \quad 7}} \\ \underline {{1 \quad 2}} \\ 5 \end{array}
\]

( )

改正：

\[
\begin{array}{r} 5 \\ 3 \overline {{) 1 \quad 8}} \\ \underline {{1 \quad 5}} \\ 3 \end{array}
\]

( )

改正：

四、我是涂色小高手。（把余数是2的涂成红色）

五、竖式计算属我强。

\[
9 \sqrt {7 4}
\]

\[
2 \sqrt {1 7}
\]

\[
8 \sqrt {6 0}
\]

例题讲解

徐老师去商店买笔,每支3元,他带了20元,可以买几支?还剩几元?

思路分析: 这是一道有余数的除法题, 可以买的支数就是所得的商, 所剩余的钱数就是余数。

自我解答：

温馨提示:在除法竖式中试商的方法和除法横式中试商的方法完全一样,都是去想括号里最大能填几。

计算有余数的除法时,要想哪个数与除数相乘最接近被除数,同时要牢记余数比除数小。

3

关注微信公众号“教辅资料站”获取更多学习资料