WEDNESDAY, JANUARY 8, 2025 | THE GLOBE AND MAIL O

REPORT ON BUSINESS

B11

The provided image is completely blank and contains no text or visible content. Therefore, there is no OCR result to output.

SPORTS

Former Alouettes player gives AI a chance to chat on new talk show ■ B13

Burgess set for debut with four-time Scotties winner Einarson ■ B14

LEAFS VS. FLYERS

Sticking to it

Maple Leafs forward Bobby McMann falls to one knee in a competition for a loose puck with Flyers centre Ryan Poehling during Tuesday night's game at Wells Fargo Center in Philadelphia. Read the game story at ■ GLOBESPORTS.COM

EMILEE CHINN/GETTY IMAGES

Vancouver PWHL showcase stirs up fond feelings for Victoire star Poulin

GEMMA KARSTENS-SMITH

VANCOUVER

Marie-Philip Poulin still gets a little emotional as she stands at centre ice in a packed arena, hearing O Canada.

The hockey legend knows her eyes may get misty on Wednesday before her Montreal Victoire line up to face the Toronto Sceptres in Vancouver.

"I think I'm getting old. I think I'm getting a little softer," Poulin said with a grin. "No, I think it's always very awesome. It's always such a privilege to be able to be in these buildings and big crowds. So I don't take it for granted."

Rogers Arena is where Poulin

played her first Olympic hockey game back in 2010, helping Canada to a gold medal on home ice.

Now it will be the setting for another first as her league-leading Victoire (3-2-1-1) and the Sceptres (2-0-1-4) battle in the first Canadian stop of the PWHL's “Takeover Tour.”

The nine-game expedition began at Climate Pledge Arena in Seattle, where the Victoire fell 3-2 to the Boston Fleet in a shootout on Sunday.

More than 12,000 fans took in the game. Merchandise was so popular it had to be stripped off mannequins before employees put up a “sold out” sign.

"The demand is real," said

Honestly, seeing kids wearing different jerseys with our names on with different logos, for us, that's what it's all about.

MARIE-PHILIP POULIN
MONTREAL VICTOIRE FORWARD

Jayna Hefford, the league's senior vice-president of hockey operations. "I think we thought it was, and now we get to see it and feel it."

Fans in both Victoire and Sceptres jerseys milled around the gates at Rogers Arena on Tuesday afternoon, hoping to catch a glimpse of their favourite players. The fact that people living thousands of kilometres away from Montreal own Victoire gear shows the PWHL is a movement, Poulin said.

"Honestly, seeing kids wearing different jerseys with our names on with different logos, for us, that's what it's all about," she said. "We want to grow the league. We're doing this by playing our

best. We're just putting our best product on the ice, and it's been amazing to see."

Currently in its second season, the six-team league is already looking to the future and could expand as soon as the 2025-26 campaign.

Visiting cities across North America this year gives the league a chance to test out future markets, Hefford said.

Each stop will be evaluated on a number of factors, including economic potential, partnerships and facilities. Travel logistics will also be weighed, she said, as teams currently use commercial flights to get from one game to another.

PWHL, B12

Scott balancing full calendar with playing and LIV Golf negotiations on his schedule

DOUG FERGUSON HONOLULU

Adam Scott made it back to Kapalua and returned to the top 20 in the world ranking, and it's a wonder how he managed with so much on his plate. This coincided with his first full year on the PGA Tour board, and it was a lot.

The new PGA Tour Enterprises received US\$1.5-billion in funding from Strategic Sports Group and created a plan for players to receive equity shares. The first big change in eligibility in more than 40 years led to only 100 players from the FedEx Cup keeping cards this year, and field sizes will shrink in 2026.

All the while, the affable Australian is part of the PGA Tour Enterprises transaction subcommittee with Tiger Woods and Rory McIlroy that is negotiating with the Saudi backers of LIV Golf to become a minority investor.

And how's that going?

“Same as always. It sucks,” Scott said in a hallway below the clubhouse at Kapalua, more matter-of-fact than showing any level of irritation. “It’s not worth talking about. Obviously, it’s so complex and when the government department is involved, I think we sit and just wait for them.”

He laughed when he added, "If the PGA Tour is their priority, we've got problems."

Adam Scott says there should soon be some progress on how, or if, the PGA Tour will integrate its competitions with the Saudi-backed LIV Golf. MATT YORK/THE ASSOCIATED PRESS

By all accounts, the PGA Tour and the Public Investment Fund are closer than ever to an agreement and it would not be surprising if a deal was announced by The Players Championship in March. But much

depends on the U.S. Justice Department, with which the tour has been in touch every step of the way in negotiations.

Further muddling the issue is a change in power at the White House in two weeks.

Beyond that is the perhaps the biggest question for golf fans: Even if the PGA Tour strikes a deal with PIF, what does that mean for the great divide in golf? What becomes of LIV?

"Soon there should be more movement," Scott said. "But it's very difficult to bring all of this together, certainly from a competitions layout. It's a lot. Someone has to compromise their product. I don't like the sound of that generally. Who's going to do it? Everyone a little bit? That's not good. Someone a lot? That person is not going to be happy.

"It's really a tricky one."

LIV starts its fourth season next month in Saudi Arabia. It filled out its 14-tournament schedule on Tuesday by adding stops at Trump Doral near Miami, the Robert Trent Jones Golf Club in Virginia, Chapultepec in Mexico City and a course in Michigan that opened only last year.

Sports Business Journal and most recently The Daily Telegraph have reported on advanced negotiations for LIV to get a TV deal with Fox, although the network might need more than 14 tournaments to make it worthwhile. IMG owns the international media rights to the Asian Tour, in which LIV has invested heavily, creating the International Series. Bryson DeChambeau will be among those playing in India later this month.

GOLF, B14