Text needs consistent contrast

177

Too light

Too dark

To solve this problem, you need to reduce the dynamics in the image to make the contrast between the text and the background more consistent.

Add an overlay

One way to increase the overall text contrast is to add a semi-transparent overlay to the background image.

Roommate

Sign in

Schedule a Demo

background-color: hsla(0, 0%, 0%, .55);