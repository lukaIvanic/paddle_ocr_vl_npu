Index

935

marginal cost, 174, 185, 214, 256

marginal cost curve, 276

marginal cost curves, 271

Marginal profit, 216

marginal profit, 221

marginal propensity to consume (MPC), 844

marginal propensity to import (MPI), 849

marginal propensity to save (MPS), 844

marginal rate of substitution, 826

marginal revenue, 183, 200, 214

marginal tax rates, 694, 709

marginal utility, 132, 153, 826

Marginal utility per dollar, 134

marginal utility per dollar, 153

market, 18, 23, 251, 367

market economy, 18, 23, 37, 291, 486, 514

market failure, 269, 280

market price, 227

market share, 248, 260

market structure, 180, 200

marketable permit program, 272, 280

maturity date, 386, 400

maximizing utility, 135

median, 812

median voter theory, 412, 416

Medicaid, 310, 317, 329

Medicare, 409

medium of exchange, 617, 630

menu costs, 583, 591

merchandise trade balance, 527, 544

merged currency, 681, 684

merger, 246, 260

Michael S. Clune, 351

Microeconomics, 14

microeconomics, 23

middle-income country, 750

Midpoint Formula, 109

Midpoint Method, 107, 110

Milton Friedman, 606, 653, 678

minimum resale price

maintenance agreement, 252, 260

minimum wage, 89, 101, 482, 512, 787

model, 16, 23

modern economic growth, 448, 467

Mollie Orshansky, 308

Monetary policy, 15

monetary policy, 23, 636, 642, 679, 690

money, 617, 630

money market fund, 630

money market funds, 619

money multiplier, 655

money multiplier formula, 627, 631

money-back guarantee, 361, 372

monopolistic competition, 226, 240

monopoly, 206, 221, 253

monopoly firm, 340

Moody's, 387

Moral hazard, 366

moral hazard, 372

multiplier effect, 857

municipal bond, 380

municipal bonds, 400

mutual funds, 390, 400

N

Nasdaq, 654

National Academy of Engineers, 297

National Academy of Scientists, 297

National Association of Insurance Commissioners, 369

National Bureau of Economic Research, 746

National Bureau of Economic Research (NBER), 436

National Credit Union

Administration (NCUA), 640

national debt, 696, 709

National Education Association, 342

national income, 428, 442, 843

National Institutes of Health, 297

national interest argument, 794, 801

National Labor-Management Relations Act, 343

national saving and investment identity, 535

national savings and investment identity, 544

National Venture Capital Association, 379

natural monopoly, 207, 221, 234, 254

natural rate of unemployment, 485, 493, 565, 606

near-poor, 315, 329

negative externalities, 409

negative externality, 267, 280

negative slope, 809

neoclassical determinants of growth, 738

neoclassical economists, 551, 570

neoclassical model, 653

neoclassical perspective, 597, 611

neoclassical zone, 568, 570

Net national product (NNP), 428

net national product (NNP), 442

net worth, 622, 631, 639

nominal GDP, 433, 652

nominal interest rate, 512, 652

nominal value, 429, 442

nondurable good, 442

nondurable goods, 425

nonexcludable, 298, 302

nonrivalrous, 298, 302

Nontariff barriers, 779

nontariff barriers, 801

normal good, 54, 74

normal goods, 121, 138

normative statement, 42

normative statements, 39

North American Free Trade

Agreement (NAFTA), 745, 785, 796

0

occupational license, 372

Occupational licenses, 362

oligopoly, 226, 240

Oligopoly, 234

open market operations, 642, 657

opportunity cost, 29, 42, 472, 680, 757, 765, 785