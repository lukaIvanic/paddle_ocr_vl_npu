TABLE 4. Uncorrected p-distances (percentage) of mitochondrial H1 fragment (ca. 2400 bp) among species and lineages of Paratelmatobius. Intraspecific or intra-lineage distances are highlighted in gray (in diagonal). Interspecific or inter-lineage distances are shown under the diagonal. Data are shown as range (mean) where appropriate. N/C = not calculated, because there was only one individual. Lin = Lineage.

Uncorrected p-distances

<table><tr><td></td><td>P. cardosoi</td><td>P. cf. cardosoi</td><td>P. gaigeae</td><td>P. poecilogaster Lin A</td><td>P. poecilogaster Lin B</td><td>P. cf. segallai</td><td>P. segallai</td></tr><tr><td>P. cardosoi</td><td>0.0 (n = 3)</td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>P. cf. cardosoi</td><td>2.5</td><td>0.0 (n = 3)</td><td></td><td></td><td></td><td></td><td></td></tr><tr><td>P. gaigeae</td><td>10.7</td><td>11.1</td><td>N/C</td><td></td><td></td><td></td><td></td></tr><tr><td>P. poecilogaster Lin A</td><td>11.2–11.3 (11.3)</td><td>11.5–11.7 (11.6)</td><td>6.4</td><td>0.0–0.1 (0.1, n = 3)</td><td></td><td></td><td></td></tr><tr><td>P. poecilogaster Lin B</td><td>11.0</td><td>11.3</td><td>6.7</td><td>4.0</td><td>N/C</td><td></td><td></td></tr><tr><td>P. cf. segallai</td><td>7.8–8.0 (7.9)</td><td>7.7–7.9 (7.8)</td><td>11.5–11.8 (11.6)</td><td>12.0–12.4 (12.2)</td><td>11.5–11.9 (11.6)</td><td>0.0–1.3 (0.6, n = 7)</td><td></td></tr><tr><td>P. segallai</td><td>7.5</td><td>7.5–7.6 (7.6)</td><td>11.2</td><td>11.7–11.9 (11.8)</td><td>11.7–11.8 (11.8)</td><td>2.9–3.1 (3.0)</td><td>0.0 (n = 9)</td></tr></table>

488

Zootaxa 4648 (3) © 2019 Magnolia Press

SANTOS ET AL.