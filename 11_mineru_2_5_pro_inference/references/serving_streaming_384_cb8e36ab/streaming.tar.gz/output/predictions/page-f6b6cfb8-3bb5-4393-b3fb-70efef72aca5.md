第三章 公司治理

3.21 检讨及监察董事、监事及高级管理人员的培训及持续专业发展的情况

本行董事会坚持敦促董事及高级管理人员参加相关业务培训，促进专业发展，促进董事及相关高级管理人员提高综合素质和履职能力。报告期内，董事会、监事会按照中国证监会、香港证券及期货事务监察委员会、香港联交所和中国银保监会的有关规定，组织有关董事、监事参加了相关培训，起到了较好的效果。

本行报告期内任职的董事、监事及董事会秘书接受培训的情况如下：

<table><tr><td>姓名</td><td>职务</td><td>培训方</td><td>培训方式</td><td>培训时间(天)</td></tr><tr><td rowspan="2">朱鹤新</td><td>董事长</td><td rowspan="2">北京证监局</td><td rowspan="2">网络培训</td><td rowspan="2">1</td></tr><tr><td>非执行董事</td></tr><tr><td rowspan="2">方合英</td><td>副董事长</td><td rowspan="2">北京证监局</td><td rowspan="2">网络培训</td><td rowspan="2">1</td></tr><tr><td>执行董事、行长</td></tr><tr><td>曹国强</td><td>非执行董事</td><td>北京证监局</td><td>网络培训</td><td>1</td></tr><tr><td rowspan="2">刘成</td><td>执行董事</td><td>北京证监局</td><td rowspan="2">网络培训</td><td rowspan="2">3.5</td></tr><tr><td>常务副行长</td><td>上海证券交易所</td></tr><tr><td>黄芳</td><td>非执行董事</td><td>北京证监局</td><td>网络培训</td><td>1</td></tr><tr><td>廖子彬</td><td>独立非执行董事</td><td>上海证券交易所</td><td>网络培训</td><td>4.5</td></tr><tr><td rowspan="3">魏国斌</td><td rowspan="3">外部监事</td><td>北京证监局</td><td rowspan="3">网络培训</td><td rowspan="3">5</td></tr><tr><td>中信集团</td></tr><tr><td>中信银行</td></tr><tr><td rowspan="3">孙祁祥</td><td rowspan="3">外部监事</td><td>北京证监局</td><td rowspan="3">网络培训</td><td rowspan="3">5</td></tr><tr><td>中信集团</td></tr><tr><td>中信银行</td></tr><tr><td rowspan="3">刘国岭</td><td rowspan="3">外部监事</td><td>北京证监局</td><td rowspan="3">网络培训</td><td rowspan="3">5</td></tr><tr><td>中信集团</td></tr><tr><td>中信银行</td></tr><tr><td rowspan="3">李蓉</td><td rowspan="3">股东代表监事</td><td>北京证监局</td><td rowspan="3">网络培训</td><td rowspan="3">5</td></tr><tr><td>中信集团</td></tr><tr><td>中信银行</td></tr><tr><td rowspan="4">程普升</td><td rowspan="4">职工代表监事</td><td>北京证监局</td><td rowspan="4">网络培训</td><td rowspan="4">8</td></tr><tr><td>上海证券交易所</td></tr><tr><td>中信集团</td></tr><tr><td>中信银行</td></tr><tr><td rowspan="3">陈潘武</td><td rowspan="3">职工代表监事</td><td>北京证监局</td><td rowspan="3">网络培训</td><td rowspan="3">5</td></tr><tr><td>中信集团</td></tr><tr><td>中信银行</td></tr><tr><td rowspan="3">曾玉芳</td><td rowspan="3">职工代表监事</td><td>北京证监局</td><td rowspan="3">网络培训</td><td rowspan="3">5</td></tr><tr><td>中信集团</td></tr><tr><td>中信银行</td></tr><tr><td rowspan="2">张青</td><td rowspan="2">董事会秘书</td><td>北京证监局</td><td rowspan="2">网络培训</td><td rowspan="2">2.5</td></tr><tr><td>上海证券交易所</td></tr></table>

122

中信银行股份有限公司