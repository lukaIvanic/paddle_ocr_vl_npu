教学活动 2

已知三角形的两边及其夹角，求作三角形

(1) 作 \( \angle {MBN} = \angle \alpha \)

(2) 在射线 B M 上截取 BC =

a, 在射线 B N 上截取 BA =

b

(3) 连接 AC

则\(\triangle ABC\)为所求作的三角形