3

一个铅锤高 6cm ，底面半径 4cm ，这个铅锤的体积是多少立方厘米？

\[
\begin{array}{l} \frac {1}{3} \times 3. 1 4 \times 4 ^ {2} \times 6 \\ = 3. 1 4 \times 1 6 \times 2 \\ = 1 0 0. 4 8 \mathrm{cm} ^ {3} \\ \end{array}
\]

先求铅锤的底面积用 \( 3.14\times4^{2} \) 。

答: 这个铅锤的体积是 100.48 立方厘米。