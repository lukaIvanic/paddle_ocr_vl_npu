# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/baseline_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/baseline_crop_0_bucket_768/profile/liteserver-c001-4_80337_20261007120132240_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `16987.613 us`
- `Free`: `663.939 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `717.500 us`
- `Stage`: `17651.500 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 13611.969 |
| `PromptFlashAttention` | 96 | 7975.579 |
| `StridedSliceD` | 384 | 5016.302 |
| `Mul` | 576 | 4057.938 |
| `Transpose` | 384 | 3676.078 |
| `Add` | 384 | 3404.669 |
| `AutomaticBufferFusionOp` | 480 | 3155.225 |
| `ReduceMeanD` | 384 | 2594.591 |
| `Sub` | 192 | 1843.216 |
| `Cast` | 195 | 1543.470 |
| `ConcatV2D` | 192 | 1484.152 |
| `Neg` | 192 | 1462.168 |
| `Unpack` | 96 | 845.618 |
| `Data` | 1 | 6.580 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_14` | 3 | 289.286 |
| `PromptFlashAttention` | 3 | 285.666 |
| `PromptFlashAttention_24` | 3 | 279.126 |
| `PromptFlashAttention_13` | 3 | 259.066 |
| `PromptFlashAttention_7` | 3 | 258.065 |
| `PromptFlashAttention_4` | 3 | 257.904 |
| `PromptFlashAttention_9` | 3 | 257.126 |
| `PromptFlashAttention_5` | 3 | 256.366 |
| `PromptFlashAttention_19` | 3 | 256.286 |
| `PromptFlashAttention_25` | 3 | 255.024 |
| `PromptFlashAttention_27` | 3 | 254.764 |
| `PromptFlashAttention_12` | 3 | 253.685 |
| `PromptFlashAttention_22` | 3 | 251.586 |
| `PromptFlashAttention_8` | 3 | 250.125 |
| `PromptFlashAttention_15` | 3 | 247.644 |
| `PromptFlashAttention_16` | 3 | 247.125 |
| `PromptFlashAttention_28` | 3 | 246.645 |
| `PromptFlashAttention_6` | 3 | 244.545 |
| `PromptFlashAttention_3` | 3 | 242.165 |
| `PromptFlashAttention_17` | 3 | 242.145 |
| `PromptFlashAttention_23` | 3 | 239.985 |
| `PromptFlashAttention_10` | 3 | 239.544 |
| `PromptFlashAttention_26` | 3 | 238.845 |
| `PromptFlashAttention_29` | 3 | 238.485 |
| `PromptFlashAttention_30` | 3 | 238.084 |
| `PromptFlashAttention_2` | 3 | 237.765 |
| `PromptFlashAttention_21` | 3 | 236.203 |
| `PromptFlashAttention_11` | 3 | 235.645 |
| `PromptFlashAttention_1` | 3 | 234.664 |
| `PromptFlashAttention_20` | 3 | 234.246 |
| `PromptFlashAttention_31` | 3 | 234.145 |
| `PromptFlashAttention_18` | 3 | 233.624 |
| `MatMulV2_15` | 3 | 149.983 |
| `MatMulV2_11` | 3 | 140.363 |
| `MatMulV2_7` | 3 | 139.543 |
| `MatMulV2_23` | 3 | 139.103 |
| `MatMulV2_19` | 3 | 138.603 |
| `MatMulV2_3` | 3 | 138.322 |
| `MatMulV2_31` | 3 | 138.283 |
| `MatMulV2_123` | 3 | 138.083 |
| `MatMulV2_87` | 3 | 138.043 |
| `MatMulV2_39` | 3 | 138.002 |
| `MatMulV2_51` | 3 | 137.963 |
| `MatMulV2_27` | 3 | 137.943 |
| `MatMulV2_79` | 3 | 137.883 |
| `MatMulV2_119` | 3 | 137.883 |
| `MatMulV2_59` | 3 | 137.822 |
| `MatMulV2_63` | 3 | 137.603 |
| `MatMulV2_83` | 3 | 137.603 |
| `MatMulV2_111` | 3 | 137.383 |
| `MatMulV2_71` | 3 | 137.342 |
| `MatMulV2_103` | 3 | 137.303 |
| `MatMulV2_67` | 3 | 137.182 |
| `MatMulV2_47` | 3 | 136.962 |
| `MatMulV2_99` | 3 | 136.623 |
| `MatMulV2_43` | 3 | 136.483 |
| `MatMulV2_95` | 3 | 136.182 |
| `MatMulV2_115` | 3 | 136.162 |
| `MatMulV2_107` | 3 | 135.902 |
| `MatMulV2_127` | 3 | 135.563 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_15` | 3 | 149.983 |
| `MatMulV2_11` | 3 | 140.363 |
| `MatMulV2_7` | 3 | 139.543 |
| `MatMulV2_23` | 3 | 139.103 |
| `MatMulV2_19` | 3 | 138.603 |
| `MatMulV2_3` | 3 | 138.322 |
| `MatMulV2_31` | 3 | 138.283 |
| `MatMulV2_123` | 3 | 138.083 |
| `MatMulV2_87` | 3 | 138.043 |
| `MatMulV2_39` | 3 | 138.002 |
| `MatMulV2_51` | 3 | 137.963 |
| `MatMulV2_27` | 3 | 137.943 |
| `MatMulV2_79` | 3 | 137.883 |
| `MatMulV2_119` | 3 | 137.883 |
| `MatMulV2_59` | 3 | 137.822 |
| `MatMulV2_63` | 3 | 137.603 |
| `MatMulV2_83` | 3 | 137.603 |
| `MatMulV2_111` | 3 | 137.383 |
| `MatMulV2_71` | 3 | 137.342 |
| `MatMulV2_103` | 3 | 137.303 |
| `MatMulV2_67` | 3 | 137.182 |
| `MatMulV2_47` | 3 | 136.962 |
| `MatMulV2_99` | 3 | 136.623 |
| `MatMulV2_43` | 3 | 136.483 |
| `MatMulV2_95` | 3 | 136.182 |
| `MatMulV2_115` | 3 | 136.162 |
| `MatMulV2_107` | 3 | 135.902 |
| `MatMulV2_127` | 3 | 135.563 |
| `MatMulV2_35` | 3 | 135.362 |
| `MatMulV2_91` | 3 | 135.163 |
| `MatMulV2_55` | 3 | 134.922 |
| `MatMulV2_75` | 3 | 134.703 |
| `MatMulV2_86` | 3 | 130.023 |
| `MatMulV2_82` | 3 | 129.422 |
| `MatMulV2_50` | 3 | 129.202 |
| `MatMulV2_14` | 3 | 126.043 |
| `MatMulV2_18` | 3 | 124.302 |
| `MatMulV2_26` | 3 | 123.802 |
| `MatMulV2_102` | 3 | 123.722 |
| `MatMulV2_38` | 3 | 123.663 |
| `MatMulV2_54` | 3 | 123.523 |
| `MatMulV2_2` | 3 | 123.503 |
| `MatMulV2_30` | 3 | 123.303 |
| `MatMulV2_42` | 3 | 123.302 |
| `MatMulV2_94` | 3 | 123.102 |
| `MatMulV2_46` | 3 | 123.003 |
| `MatMulV2_10` | 3 | 122.821 |
| `MatMulV2_62` | 3 | 122.703 |
| `MatMulV2_114` | 3 | 122.582 |
| `MatMulV2_58` | 3 | 122.523 |
| `MatMulV2_118` | 3 | 122.522 |
| `MatMulV2_66` | 3 | 122.383 |
| `MatMulV2_126` | 3 | 122.383 |
| `MatMulV2_110` | 3 | 122.322 |
| `MatMulV2_74` | 3 | 122.303 |
| `MatMulV2_98` | 3 | 122.243 |
| `MatMulV2_78` | 3 | 122.141 |
| `MatMulV2_34` | 3 | 122.063 |
| `MatMulV2_6` | 3 | 122.063 |
| `MatMulV2_90` | 3 | 121.602 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4406.265 |
| `MatMulV2 | "768,1280;5120,1280;5120" -> "768,5120" | ND;ND;ND -> ND` | 96 | 3946.997 |
| `MatMulV2 | "768,1280;3840,1280;3840" -> "768,3840" | ND;ND;ND -> ND` | 96 | 3304.328 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 1954.379 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_14` | 1 | 105.162 |
| `PromptFlashAttention` | 1 | 97.542 |
| `PromptFlashAttention_24` | 1 | 95.122 |
| `PromptFlashAttention` | 1 | 94.382 |
| `PromptFlashAttention` | 1 | 93.742 |
| `PromptFlashAttention_14` | 1 | 92.302 |
| `PromptFlashAttention_24` | 1 | 92.222 |
| `PromptFlashAttention_14` | 1 | 91.822 |
| `PromptFlashAttention_24` | 1 | 91.782 |
| `PromptFlashAttention_19` | 1 | 91.562 |
| `PromptFlashAttention_9` | 1 | 91.502 |
| `PromptFlashAttention_7` | 1 | 89.821 |
| `PromptFlashAttention_22` | 1 | 88.002 |
| `PromptFlashAttention_13` | 1 | 87.542 |
| `PromptFlashAttention_25` | 1 | 87.301 |
| `PromptFlashAttention_5` | 1 | 86.722 |
| `PromptFlashAttention_4` | 1 | 86.282 |
| `PromptFlashAttention_12` | 1 | 86.101 |
| `PromptFlashAttention_13` | 1 | 86.022 |
| `PromptFlashAttention_4` | 1 | 85.921 |
| `PromptFlashAttention_4` | 1 | 85.701 |
| `PromptFlashAttention_13` | 1 | 85.502 |
| `PromptFlashAttention_5` | 1 | 85.302 |
| `PromptFlashAttention_8` | 1 | 85.301 |
| `PromptFlashAttention_27` | 1 | 85.062 |
| `PromptFlashAttention_27` | 1 | 85.021 |
| `PromptFlashAttention_7` | 1 | 84.782 |
| `PromptFlashAttention_27` | 1 | 84.681 |
| `PromptFlashAttention_10` | 1 | 84.421 |
| `PromptFlashAttention_5` | 1 | 84.342 |
| `PromptFlashAttention_16` | 1 | 84.161 |
| `PromptFlashAttention_9` | 1 | 84.142 |
| `PromptFlashAttention_25` | 1 | 84.021 |
| `PromptFlashAttention_12` | 1 | 83.862 |
| `PromptFlashAttention_12` | 1 | 83.722 |
| `PromptFlashAttention_25` | 1 | 83.702 |
| `PromptFlashAttention_26` | 1 | 83.601 |
| `PromptFlashAttention_7` | 1 | 83.462 |
| `PromptFlashAttention_2` | 1 | 83.242 |
| `PromptFlashAttention_15` | 1 | 83.101 |
| `PromptFlashAttention_19` | 1 | 82.922 |
| `PromptFlashAttention_8` | 1 | 82.642 |
| `PromptFlashAttention_28` | 1 | 82.562 |
| `PromptFlashAttention_3` | 1 | 82.321 |
| `PromptFlashAttention_15` | 1 | 82.321 |
| `PromptFlashAttention_15` | 1 | 82.222 |
| `PromptFlashAttention_8` | 1 | 82.182 |
| `PromptFlashAttention_28` | 1 | 82.181 |
| `PromptFlashAttention_22` | 1 | 82.042 |
| `PromptFlashAttention_23` | 1 | 82.021 |
| `PromptFlashAttention_28` | 1 | 81.902 |
| `PromptFlashAttention_6` | 1 | 81.841 |
| `PromptFlashAttention_19` | 1 | 81.802 |
| `PromptFlashAttention_17` | 1 | 81.761 |
| `PromptFlashAttention_6` | 1 | 81.702 |
| `PromptFlashAttention_22` | 1 | 81.542 |
| `PromptFlashAttention_16` | 1 | 81.522 |
| `PromptFlashAttention_9` | 1 | 81.482 |
| `PromptFlashAttention_16` | 1 | 81.442 |
| `PromptFlashAttention_6` | 1 | 81.002 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 17709.099 |
| `TorchNpuGraphBase::Run` | 3 | 17324.589 |
| `AssembleInputs` | 3 | 17043.079 |
| `ExecuteGraph` | 3 | 283.270 |
| `RefreshAtTensorFromGeTensor` | 3 | 191.390 |
| `aten::empty` | 3 | 92.820 |
| `empty_tensor` | 3 | 48.770 |
| `AssembleOutputs` | 3 | 47.800 |
| `aten::set_` | 3 | 44.100 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 257950.480 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 50468.600 |
| `launch` | 1314 | 17972.940 |
| `InputCopy` | 3 | 139.420 |
| `ModelExecute` | 3 | 87.310 |
| `step_info` | 6 | 45.140 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 26.330 |
| `OutputCopy` | 3 | 1.950 |

