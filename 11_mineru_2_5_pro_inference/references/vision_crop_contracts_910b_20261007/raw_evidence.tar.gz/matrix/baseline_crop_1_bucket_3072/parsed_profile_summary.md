# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/baseline_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/baseline_crop_1_bucket_3072/profile/liteserver-c001-4_81365_20261007120223094_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `48239.679 us`
- `Free`: `617.157 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `660.750 us`
- `Stage`: `48857.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50342.818 |
| `MatMulV3` | 288 | 34567.008 |
| `StridedSliceD` | 384 | 13096.080 |
| `Mul` | 576 | 7245.892 |
| `MatMulV2` | 96 | 6350.911 |
| `AutomaticBufferFusionOp` | 480 | 6311.087 |
| `Transpose` | 384 | 5195.432 |
| `Add` | 384 | 5107.177 |
| `ReduceMeanD` | 384 | 4813.909 |
| `Sub` | 192 | 3191.168 |
| `ConcatV2D` | 192 | 2371.070 |
| `Cast` | 195 | 2126.038 |
| `Unpack` | 96 | 2060.077 |
| `Neg` | 192 | 1785.921 |
| `Data` | 1 | 6.780 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_12` | 3 | 1611.853 |
| `PromptFlashAttention_25` | 3 | 1602.812 |
| `PromptFlashAttention_22` | 3 | 1599.792 |
| `PromptFlashAttention` | 3 | 1597.291 |
| `PromptFlashAttention_23` | 3 | 1596.113 |
| `PromptFlashAttention_15` | 3 | 1594.592 |
| `PromptFlashAttention_8` | 3 | 1593.550 |
| `PromptFlashAttention_14` | 3 | 1588.432 |
| `PromptFlashAttention_26` | 3 | 1588.372 |
| `PromptFlashAttention_13` | 3 | 1584.871 |
| `PromptFlashAttention_6` | 3 | 1579.671 |
| `PromptFlashAttention_7` | 3 | 1573.510 |
| `PromptFlashAttention_20` | 3 | 1571.111 |
| `PromptFlashAttention_30` | 3 | 1570.791 |
| `PromptFlashAttention_21` | 3 | 1567.311 |
| `PromptFlashAttention_28` | 3 | 1566.252 |
| `PromptFlashAttention_24` | 3 | 1566.031 |
| `PromptFlashAttention_3` | 3 | 1564.611 |
| `PromptFlashAttention_11` | 3 | 1564.531 |
| `PromptFlashAttention_4` | 3 | 1563.751 |
| `PromptFlashAttention_2` | 3 | 1563.651 |
| `PromptFlashAttention_31` | 3 | 1561.491 |
| `PromptFlashAttention_17` | 3 | 1560.551 |
| `PromptFlashAttention_1` | 3 | 1560.410 |
| `PromptFlashAttention_10` | 3 | 1560.292 |
| `PromptFlashAttention_16` | 3 | 1559.930 |
| `PromptFlashAttention_19` | 3 | 1557.291 |
| `PromptFlashAttention_18` | 3 | 1556.111 |
| `PromptFlashAttention_27` | 3 | 1556.031 |
| `PromptFlashAttention_5` | 3 | 1554.851 |
| `PromptFlashAttention_29` | 3 | 1554.591 |
| `PromptFlashAttention_9` | 3 | 1552.370 |
| `MatMulV2_6_to_v3` | 3 | 407.908 |
| `MatMulV2_2_to_v3` | 3 | 399.948 |
| `MatMulV2_18_to_v3` | 3 | 395.369 |
| `MatMulV2_54_to_v3` | 3 | 395.327 |
| `MatMulV2_78_to_v3` | 3 | 393.988 |
| `MatMulV2_106_to_v3` | 3 | 392.548 |
| `MatMulV2_10_to_v3` | 3 | 392.387 |
| `MatMulV2_98_to_v3` | 3 | 392.288 |
| `MatMulV2_86_to_v3` | 3 | 392.127 |
| `MatMulV2_118_to_v3` | 3 | 392.007 |
| `MatMulV2_94_to_v3` | 3 | 391.368 |
| `MatMulV2_66_to_v3` | 3 | 391.188 |
| `MatMulV2_74_to_v3` | 3 | 391.069 |
| `MatMulV2_126_to_v3` | 3 | 391.067 |
| `MatMulV2_23_to_v3` | 3 | 390.767 |
| `MatMulV2_43_to_v3` | 3 | 390.609 |
| `MatMulV2_87_to_v3` | 3 | 390.248 |
| `MatMulV2_59_to_v3` | 3 | 390.148 |
| `MatMulV2_83_to_v3` | 3 | 390.027 |
| `MatMulV2_30_to_v3` | 3 | 389.829 |
| `MatMulV2_107_to_v3` | 3 | 389.568 |
| `MatMulV2_62_to_v3` | 3 | 389.449 |
| `MatMulV2_46_to_v3` | 3 | 389.368 |
| `MatMulV2_123_to_v3` | 3 | 389.308 |
| `MatMulV2_122_to_v3` | 3 | 389.188 |
| `MatMulV2_26_to_v3` | 3 | 388.989 |
| `MatMulV2_55_to_v3` | 3 | 388.788 |
| `MatMulV2_3_to_v3` | 3 | 388.728 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_6_to_v3` | 3 | 407.908 |
| `MatMulV2_2_to_v3` | 3 | 399.948 |
| `MatMulV2_18_to_v3` | 3 | 395.369 |
| `MatMulV2_54_to_v3` | 3 | 395.327 |
| `MatMulV2_78_to_v3` | 3 | 393.988 |
| `MatMulV2_106_to_v3` | 3 | 392.548 |
| `MatMulV2_10_to_v3` | 3 | 392.387 |
| `MatMulV2_98_to_v3` | 3 | 392.288 |
| `MatMulV2_86_to_v3` | 3 | 392.127 |
| `MatMulV2_118_to_v3` | 3 | 392.007 |
| `MatMulV2_94_to_v3` | 3 | 391.368 |
| `MatMulV2_66_to_v3` | 3 | 391.188 |
| `MatMulV2_74_to_v3` | 3 | 391.069 |
| `MatMulV2_126_to_v3` | 3 | 391.067 |
| `MatMulV2_23_to_v3` | 3 | 390.767 |
| `MatMulV2_43_to_v3` | 3 | 390.609 |
| `MatMulV2_87_to_v3` | 3 | 390.248 |
| `MatMulV2_59_to_v3` | 3 | 390.148 |
| `MatMulV2_83_to_v3` | 3 | 390.027 |
| `MatMulV2_30_to_v3` | 3 | 389.829 |
| `MatMulV2_107_to_v3` | 3 | 389.568 |
| `MatMulV2_62_to_v3` | 3 | 389.449 |
| `MatMulV2_46_to_v3` | 3 | 389.368 |
| `MatMulV2_123_to_v3` | 3 | 389.308 |
| `MatMulV2_122_to_v3` | 3 | 389.188 |
| `MatMulV2_26_to_v3` | 3 | 388.989 |
| `MatMulV2_55_to_v3` | 3 | 388.788 |
| `MatMulV2_3_to_v3` | 3 | 388.728 |
| `MatMulV2_79_to_v3` | 3 | 388.667 |
| `MatMulV2_102_to_v3` | 3 | 388.647 |
| `MatMulV2_22_to_v3` | 3 | 388.609 |
| `MatMulV2_11_to_v3` | 3 | 388.449 |
| `MatMulV2_103_to_v3` | 3 | 388.388 |
| `MatMulV2_7_to_v3` | 3 | 388.367 |
| `MatMulV2_71_to_v3` | 3 | 388.327 |
| `MatMulV2_95_to_v3` | 3 | 388.247 |
| `MatMulV2_82_to_v3` | 3 | 388.208 |
| `MatMulV2_19_to_v3` | 3 | 388.187 |
| `MatMulV2_110_to_v3` | 3 | 388.168 |
| `MatMulV2_115_to_v3` | 3 | 388.088 |
| `MatMulV2_90_to_v3` | 3 | 388.007 |
| `MatMulV2_15_to_v3` | 3 | 387.749 |
| `MatMulV2_50_to_v3` | 3 | 387.649 |
| `MatMulV2_99_to_v3` | 3 | 387.507 |
| `MatMulV2_42_to_v3` | 3 | 387.448 |
| `MatMulV2_70_to_v3` | 3 | 387.428 |
| `MatMulV2_14_to_v3` | 3 | 387.386 |
| `MatMulV2_31_to_v3` | 3 | 387.106 |
| `MatMulV2_58_to_v3` | 3 | 387.087 |
| `MatMulV2_111_to_v3` | 3 | 386.948 |
| `MatMulV2_34_to_v3` | 3 | 386.908 |
| `MatMulV2_27_to_v3` | 3 | 386.726 |
| `MatMulV2_38_to_v3` | 3 | 386.388 |
| `MatMulV2_75_to_v3` | 3 | 386.087 |
| `MatMulV2_35_to_v3` | 3 | 386.027 |
| `MatMulV2_91_to_v3` | 3 | 385.888 |
| `MatMulV2_47_to_v3` | 3 | 385.848 |
| `MatMulV2_114_to_v3` | 3 | 385.808 |
| `MatMulV2_63_to_v3` | 3 | 385.548 |
| `MatMulV2_67_to_v3` | 3 | 385.487 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;5120,1280;5120" -> "3072,5120" | ND;ND;ND -> ND` | 96 | 12503.153 |
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12404.621 |
| `MatMulV3 | "3072,1280;3840,1280;3840" -> "3072,3840" | ND;ND;ND -> ND` | 96 | 9659.234 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6350.911 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_12` | 1 | 538.331 |
| `PromptFlashAttention_12` | 1 | 537.731 |
| `PromptFlashAttention` | 1 | 536.270 |
| `PromptFlashAttention_22` | 1 | 535.950 |
| `PromptFlashAttention_12` | 1 | 535.791 |
| `PromptFlashAttention_25` | 1 | 535.510 |
| `PromptFlashAttention_25` | 1 | 534.571 |
| `PromptFlashAttention_23` | 1 | 532.911 |
| `PromptFlashAttention_22` | 1 | 532.811 |
| `PromptFlashAttention_25` | 1 | 532.731 |
| `PromptFlashAttention_23` | 1 | 532.051 |
| `PromptFlashAttention_15` | 1 | 531.991 |
| `PromptFlashAttention_15` | 1 | 531.731 |
| `PromptFlashAttention` | 1 | 531.670 |
| `PromptFlashAttention_8` | 1 | 531.510 |
| `PromptFlashAttention_8` | 1 | 531.470 |
| `PromptFlashAttention_23` | 1 | 531.151 |
| `PromptFlashAttention_22` | 1 | 531.031 |
| `PromptFlashAttention_15` | 1 | 530.870 |
| `PromptFlashAttention_8` | 1 | 530.570 |
| `PromptFlashAttention_26` | 1 | 530.371 |
| `PromptFlashAttention_14` | 1 | 529.710 |
| `PromptFlashAttention_26` | 1 | 529.690 |
| `PromptFlashAttention_13` | 1 | 529.690 |
| `PromptFlashAttention_14` | 1 | 529.631 |
| `PromptFlashAttention` | 1 | 529.351 |
| `PromptFlashAttention_14` | 1 | 529.091 |
| `PromptFlashAttention_6` | 1 | 528.631 |
| `PromptFlashAttention_26` | 1 | 528.311 |
| `PromptFlashAttention_13` | 1 | 527.811 |
| `PromptFlashAttention_13` | 1 | 527.370 |
| `PromptFlashAttention_6` | 1 | 526.710 |
| `PromptFlashAttention_7` | 1 | 525.990 |
| `PromptFlashAttention_30` | 1 | 525.251 |
| `PromptFlashAttention_20` | 1 | 524.970 |
| `PromptFlashAttention_6` | 1 | 524.330 |
| `PromptFlashAttention_7` | 1 | 524.250 |
| `PromptFlashAttention_20` | 1 | 523.810 |
| `PromptFlashAttention_2` | 1 | 523.471 |
| `PromptFlashAttention_21` | 1 | 523.470 |
| `PromptFlashAttention_7` | 1 | 523.270 |
| `PromptFlashAttention_30` | 1 | 523.170 |
| `PromptFlashAttention_24` | 1 | 522.891 |
| `PromptFlashAttention_30` | 1 | 522.370 |
| `PromptFlashAttention_20` | 1 | 522.331 |
| `PromptFlashAttention_3` | 1 | 522.270 |
| `PromptFlashAttention_21` | 1 | 522.191 |
| `PromptFlashAttention_4` | 1 | 522.171 |
| `PromptFlashAttention_28` | 1 | 522.151 |
| `PromptFlashAttention_28` | 1 | 522.071 |
| `PromptFlashAttention_28` | 1 | 522.030 |
| `PromptFlashAttention_11` | 1 | 522.010 |
| `PromptFlashAttention_3` | 1 | 521.791 |
| `PromptFlashAttention_21` | 1 | 521.650 |
| `PromptFlashAttention_24` | 1 | 521.590 |
| `PromptFlashAttention_24` | 1 | 521.550 |
| `PromptFlashAttention_11` | 1 | 521.410 |
| `PromptFlashAttention_4` | 1 | 521.350 |
| `PromptFlashAttention_11` | 1 | 521.111 |
| `PromptFlashAttention_31` | 1 | 521.070 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 48935.804 |
| `TorchNpuGraphBase::Run` | 3 | 48544.534 |
| `AssembleInputs` | 3 | 48296.094 |
| `ExecuteGraph` | 3 | 246.650 |
| `RefreshAtTensorFromGeTensor` | 3 | 219.160 |
| `aten::empty` | 3 | 95.030 |
| `aten::set_` | 3 | 72.270 |
| `empty_tensor` | 3 | 55.920 |
| `AssembleOutputs` | 3 | 40.040 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 249640.050 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 144319.670 |
| `launch` | 1314 | 17678.060 |
| `InputCopy` | 3 | 123.400 |
| `ModelExecute` | 3 | 75.750 |
| `step_info` | 6 | 46.290 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 24.290 |
| `OutputCopy` | 3 | 1.600 |

