# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/eager_pfa_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/eager_pfa_crop_0_bucket_768/profile/liteserver-c001-4_86327_20261007120624956_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `76599.489 us`
- `Free`: `155699.033 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `639.500 us`
- `Stage`: `232298.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 14205.163 |
| `Mul` | 960 | 11478.835 |
| `PromptFlashAttention` | 96 | 8469.048 |
| `Transpose` | 384 | 7917.116 |
| `ReduceMean` | 384 | 6291.955 |
| `Slice` | 672 | 5901.529 |
| `Cast` | 768 | 5513.360 |
| `Add` | 768 | 5501.648 |
| `Sub` | 192 | 3495.552 |
| `Pows` | 192 | 3126.958 |
| `ConcatD` | 192 | 1935.758 |
| `Sigmoid` | 96 | 1357.242 |
| `Neg` | 192 | 1158.440 |
| `Rsqrt` | 192 | 248.324 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulCommon_MatMulV2` | 384 | 14205.163 |
| `aclnnMul_MulAiCore_Mul` | 864 | 10524.036 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 96 | 8469.048 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 384 | 7917.116 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 6291.955 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 5513.360 |
| `aclnnAdd_AddAiCore_Add` | 576 | 5225.403 |
| `aclnnSub_SubAiCore_Sub` | 192 | 3495.552 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3126.958 |
| `aclnnNeg_SliceAiCore_Slice` | 192 | 2276.385 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 2233.049 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 1935.758 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 288 | 1392.095 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 1357.242 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1158.440 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 954.799 |
| `aclnnAdds_AddAiCore_Add` | 192 | 276.245 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 248.324 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulCommon_MatMulV2` | 384 | 14205.163 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4667.313 |
| `MatMulV2 | "768,1280;5120,1280;5120" -> "768,5120" | ND;ND;ND -> ND` | 96 | 4217.581 |
| `MatMulV2 | "768,1280;3840,1280;3840" -> "768,3840" | ND;ND;ND -> ND` | 96 | 3295.947 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 2024.322 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 108.662 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 107.082 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 102.042 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 99.922 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 99.342 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 99.202 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 98.942 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 97.222 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 96.802 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 96.582 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 96.242 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 95.682 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 95.342 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 95.162 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.642 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.362 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.322 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.142 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.102 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.042 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.022 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.022 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.982 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.962 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.802 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.622 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.602 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.602 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.602 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.362 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.342 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.342 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.322 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.261 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.182 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.022 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.942 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.922 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.642 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.302 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.281 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.001 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.742 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.661 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.641 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.621 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.202 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 89.522 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 89.042 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.301 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.002 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.541 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.242 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 86.902 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 85.961 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 82.462 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 81.841 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 81.462 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 81.361 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 81.322 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `aten::to` | 1056 | 26972.830 |
| `npu::npu_prompt_flash_attention` | 96 | 26422.150 |
| `aten::_to_copy` | 768 | 23876.990 |
| `empty_tensor` | 4896 | 23057.650 |
| `aten::copy_` | 1152 | 22035.381 |
| `aten::mul` | 960 | 20264.484 |
| `aten::linear` | 384 | 19157.489 |
| `aten::add` | 768 | 18344.350 |
| `aclnnInplaceCopy` | 1152 | 15129.007 |
| `aten::addmm` | 384 | 14999.362 |
| `aclnnAddmm` | 384 | 14205.164 |
| `aten::contiguous` | 384 | 12535.170 |
| `aten::clone` | 384 | 11398.795 |
| `aclnnMul` | 864 | 10529.369 |
| `aten::mean` | 384 | 9642.473 |
| `aclnnPromptFlashAttentionV3` | 96 | 8769.608 |
| `aten::as_strided` | 1632 | 6573.320 |
| `aten::transpose` | 768 | 6566.290 |
| `aclnnMean` | 384 | 6291.966 |
| `aten::empty` | 768 | 6098.900 |
| `aten::square` | 192 | 5512.420 |
| `aclnnAdd` | 576 | 5363.765 |
| `aten::cat` | 192 | 5059.987 |
| `aten::pow` | 192 | 4936.530 |
| `aten::neg` | 192 | 4671.730 |
| `aten::sub` | 192 | 4280.890 |
| `aclnnCat` | 192 | 4168.803 |
| `aten::view` | 960 | 3543.630 |
| `aten::rsqrt` | 192 | 3528.230 |
| `aclnnSub` | 192 | 3495.550 |
| `aclnnNeg` | 192 | 3434.829 |
| `aten::t` | 384 | 3345.950 |
| `aclnnPowTensorScalar` | 192 | 3126.963 |
| `aten::slice` | 384 | 2956.800 |
| `aten::unbind` | 96 | 2817.370 |
| `aten::select` | 288 | 2338.030 |
| `aten::sigmoid` | 96 | 1815.240 |
| `aten::unsqueeze` | 192 | 1432.200 |
| `aclnnSigmoid` | 96 | 1357.247 |
| `aclnnAdds` | 192 | 1257.460 |
| `aclnnRsqrt` | 192 | 1224.390 |
| `aten::item` | 288 | 1085.490 |
| `aclnnMuls` | 96 | 956.349 |
| `aten::_local_scalar_dense` | 288 | 463.030 |
| `aten::result_type` | 192 | 364.420 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 5472 | 32074.950 |
| `aclrtLaunchKernelWithHostArgs` | 5472 | 25496.230 |
| `InnerPromptFlashAttentionGetWorkspaceSize` | 96 | 19061.870 |
| `PromptFlashAttention_Tiling` | 192 | 13544.220 |
| `aclnnInplaceCopy` | 1152 | 11835.990 |
| `aclnnMul` | 864 | 7362.900 |
| `InnerPromptFlashAttention` | 96 | 4924.340 |
| `aclnnAdd` | 576 | 4894.250 |
| `aclnnMean` | 384 | 4282.370 |
| `aclnnAddmm` | 384 | 3365.710 |
| `aclnnNeg` | 192 | 2522.400 |
| `aclnnCat` | 192 | 2513.370 |
| `aclrtGetStreamAttribute` | 4800 | 2008.990 |
| `aclnnPowTensorScalar` | 192 | 1663.560 |
| `aclnnSub` | 192 | 1655.750 |
| `aclnnAdds` | 192 | 1639.360 |
| `aclnnRsqrt` | 192 | 1627.430 |
| `aclnnSigmoid` | 96 | 865.640 |
| `aclnnMuls` | 96 | 828.930 |
| `aclrtGetHardwareSyncAddr` | 480 | 357.060 |
| `aclrtGetResInCurrentThread` | 192 | 130.010 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 69.450 |

