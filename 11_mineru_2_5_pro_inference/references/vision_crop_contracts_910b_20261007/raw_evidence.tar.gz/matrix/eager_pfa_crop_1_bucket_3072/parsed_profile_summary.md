# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/eager_pfa_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/eager_pfa_crop_1_bucket_3072/profile/liteserver-c001-4_86682_20261007120710775_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `174153.732 us`
- `Free`: `53285.992 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `674.000 us`
- `Stage`: `227439.500 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50515.509 |
| `MatMulV3` | 288 | 36616.333 |
| `Mul` | 960 | 18951.410 |
| `Transpose` | 384 | 9496.092 |
| `ReduceMean` | 384 | 9157.443 |
| `Add` | 768 | 8303.862 |
| `Cast` | 768 | 7549.186 |
| `Slice` | 480 | 7276.607 |
| `MatMulV2` | 96 | 6651.913 |
| `Sub` | 192 | 4706.920 |
| `Pows` | 192 | 4216.765 |
| `Sigmoid` | 96 | 3239.581 |
| `ConcatD` | 192 | 3216.784 |
| `SliceV2` | 192 | 2230.851 |
| `Neg` | 192 | 1709.054 |
| `Rsqrt` | 192 | 317.302 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 96 | 50515.509 |
| `aclnnAddmm_MatMulV3Common_MatMulV3` | 288 | 36616.333 |
| `aclnnMul_MulAiCore_Mul` | 864 | 16914.289 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 384 | 9496.092 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 9157.443 |
| `aclnnAdd_AddAiCore_Add` | 576 | 7962.376 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 7549.186 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 96 | 6651.913 |
| `aclnnSub_SubAiCore_Sub` | 192 | 4706.920 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 4216.765 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 3953.454 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 288 | 3323.153 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 3239.581 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 3216.784 |
| `aclnnNeg_SliceV2AiCore_SliceV2` | 192 | 2230.851 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 2037.121 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1709.054 |
| `aclnnAdds_AddAiCore_Add` | 192 | 341.486 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 317.302 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulV3Common_MatMulV3` | 288 | 36616.333 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 96 | 6651.913 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;5120,1280;5120" -> "3072,5120" | ND;ND;ND -> ND` | 96 | 13873.661 |
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12750.332 |
| `MatMulV3 | "3072,1280;3840,1280;3840" -> "3072,3840" | ND;ND;ND -> ND` | 96 | 9992.340 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6651.913 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 532.050 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 531.611 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 531.531 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 531.190 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 531.091 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.531 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.510 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.430 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.371 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.291 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.050 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.591 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.590 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.250 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.090 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.111 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.910 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.890 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.791 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.731 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.610 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.551 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.451 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.450 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.411 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.251 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.250 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.130 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.931 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.850 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.831 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.751 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.731 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.651 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.551 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.550 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.530 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.450 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.351 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.350 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.330 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.330 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.291 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.270 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.211 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.171 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.131 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.030 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.010 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.991 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.951 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.930 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.810 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.730 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.711 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.691 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.611 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.551 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.430 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.390 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `npu::npu_prompt_flash_attention` | 96 | 50955.188 |
| `aclnnPromptFlashAttentionV3` | 96 | 50515.509 |
| `aten::linear` | 384 | 43268.244 |
| `aten::addmm` | 384 | 43268.244 |
| `aclnnAddmm` | 384 | 43268.244 |
| `aten::to` | 1056 | 27220.410 |
| `aten::copy_` | 1152 | 25472.446 |
| `aten::_to_copy` | 768 | 24392.050 |
| `aten::mul` | 960 | 22103.544 |
| `empty_tensor` | 4896 | 21128.050 |
| `aclnnInplaceCopy` | 1152 | 20536.635 |
| `aten::add` | 768 | 18678.640 |
| `aclnnMul` | 864 | 16920.287 |
| `aten::contiguous` | 384 | 13040.862 |
| `aten::clone` | 384 | 12289.129 |
| `aten::mean` | 384 | 10000.494 |
| `aclnnMean` | 384 | 9157.443 |
| `aclnnAdd` | 576 | 7975.409 |
| `aten::cat` | 192 | 7177.991 |
| `aclnnCat` | 192 | 7170.243 |
| `aten::as_strided` | 1632 | 6164.830 |
| `aten::transpose` | 768 | 5980.530 |
| `aten::square` | 192 | 5637.790 |
| `aten::empty` | 768 | 5524.120 |
| `aten::pow` | 192 | 5132.842 |
| `aten::neg` | 192 | 4781.913 |
| `aten::sub` | 192 | 4749.015 |
| `aclnnSub` | 192 | 4706.914 |
| `aclnnPowTensorScalar` | 192 | 4216.764 |
| `aclnnNeg` | 192 | 3939.899 |
| `aten::view` | 960 | 3333.230 |
| `aten::sigmoid` | 96 | 3239.585 |
| `aclnnSigmoid` | 96 | 3239.585 |
| `aten::rsqrt` | 192 | 2918.780 |
| `aten::t` | 384 | 2852.420 |
| `aten::slice` | 384 | 2584.820 |
| `aten::unbind` | 96 | 2497.690 |
| `aclnnMuls` | 96 | 2037.121 |
| `aten::select` | 288 | 2023.810 |
| `aclnnAdds` | 192 | 1528.250 |
| `aten::unsqueeze` | 192 | 1341.580 |
| `aten::item` | 288 | 890.380 |
| `aclnnRsqrt` | 192 | 717.690 |
| `aten::_local_scalar_dense` | 288 | 381.540 |
| `aten::result_type` | 192 | 335.880 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 5472 | 37673.960 |
| `aclrtLaunchKernelWithHostArgs` | 5472 | 30338.270 |
| `InnerPromptFlashAttentionGetWorkspaceSize` | 96 | 20238.700 |
| `aclnnInplaceCopy` | 1152 | 14866.560 |
| `PromptFlashAttention_Tiling` | 192 | 13797.480 |
| `aclnnMul` | 864 | 9183.000 |
| `InnerPromptFlashAttention` | 96 | 6297.600 |
| `aclnnAdd` | 576 | 6201.450 |
| `aclnnMean` | 384 | 5277.700 |
| `aclnnAddmm` | 384 | 4627.320 |
| `aclnnNeg` | 192 | 3263.460 |
| `aclnnCat` | 192 | 3240.030 |
| `aclnnAdds` | 192 | 2166.130 |
| `aclnnPowTensorScalar` | 192 | 2107.620 |
| `aclrtGetStreamAttribute` | 4800 | 2075.250 |
| `aclnnSub` | 192 | 1995.390 |
| `aclnnRsqrt` | 192 | 1975.720 |
| `aclnnMuls` | 96 | 1086.040 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 1018.520 |
| `aclnnSigmoid` | 96 | 997.570 |
| `aclrtGetHardwareSyncAddr` | 768 | 569.870 |
| `aclrtGetResInCurrentThread` | 192 | 126.650 |

