# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/pfa_nz_weights_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/pfa_nz_weights_crop_0_bucket_768/profile/liteserver-c001-4_82426_20261007120354676_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `18409.634 us`
- `Free`: `709.388 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `922.500 us`
- `Stage`: `19119.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 15751.072 |
| `PromptFlashAttention` | 96 | 8063.939 |
| `StridedSliceD` | 384 | 5754.563 |
| `Mul` | 576 | 4343.184 |
| `Add` | 384 | 3737.499 |
| `AutomaticBufferFusionOp` | 480 | 3138.796 |
| `Transpose` | 288 | 3087.973 |
| `ReduceMeanD` | 384 | 2746.309 |
| `Sub` | 192 | 2051.382 |
| `Cast` | 195 | 1945.857 |
| `Neg` | 192 | 1750.187 |
| `ConcatV2D` | 192 | 1659.252 |
| `Unpack` | 96 | 804.637 |
| `ConfusionTransposeD` | 96 | 526.594 |
| `Data` | 1 | 6.001 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_23` | 3 | 287.345 |
| `PromptFlashAttention` | 3 | 284.586 |
| `PromptFlashAttention_15` | 3 | 284.125 |
| `PromptFlashAttention_5` | 3 | 278.966 |
| `PromptFlashAttention_27` | 3 | 274.366 |
| `PromptFlashAttention_25` | 3 | 268.626 |
| `PromptFlashAttention_16` | 3 | 266.425 |
| `PromptFlashAttention_19` | 3 | 264.866 |
| `PromptFlashAttention_10` | 3 | 256.284 |
| `PromptFlashAttention_8` | 3 | 255.385 |
| `PromptFlashAttention_12` | 3 | 255.105 |
| `PromptFlashAttention_13` | 3 | 254.303 |
| `PromptFlashAttention_26` | 3 | 254.163 |
| `PromptFlashAttention_1` | 3 | 252.525 |
| `PromptFlashAttention_6` | 3 | 252.004 |
| `PromptFlashAttention_30` | 3 | 251.704 |
| `PromptFlashAttention_31` | 3 | 251.586 |
| `PromptFlashAttention_20` | 3 | 250.006 |
| `PromptFlashAttention_11` | 3 | 248.526 |
| `PromptFlashAttention_7` | 3 | 248.306 |
| `PromptFlashAttention_14` | 3 | 240.766 |
| `PromptFlashAttention_28` | 3 | 238.706 |
| `PromptFlashAttention_9` | 3 | 237.646 |
| `PromptFlashAttention_22` | 3 | 237.525 |
| `PromptFlashAttention_2` | 3 | 235.504 |
| `PromptFlashAttention_29` | 3 | 235.405 |
| `PromptFlashAttention_4` | 3 | 234.524 |
| `PromptFlashAttention_17` | 3 | 234.385 |
| `PromptFlashAttention_24` | 3 | 233.464 |
| `PromptFlashAttention_3` | 3 | 232.625 |
| `PromptFlashAttention_18` | 3 | 232.544 |
| `PromptFlashAttention_21` | 3 | 231.643 |
| `MatMulV2_79` | 3 | 153.263 |
| `MatMulV2_47` | 3 | 152.963 |
| `MatMulV2_123` | 3 | 150.863 |
| `MatMulV2_83` | 3 | 150.783 |
| `MatMulV2_87` | 3 | 150.383 |
| `MatMulV2_59` | 3 | 150.303 |
| `MatMulV2_127` | 3 | 150.123 |
| `MatMulV2_67` | 3 | 149.983 |
| `MatMulV2_3` | 3 | 149.843 |
| `MatMulV2_31` | 3 | 149.763 |
| `MatMulV2_63` | 3 | 149.743 |
| `MatMulV2_27` | 3 | 149.402 |
| `MatMulV2_71` | 3 | 149.123 |
| `MatMulV2_115` | 3 | 149.083 |
| `MatMulV2_107` | 3 | 148.963 |
| `MatMulV2_51` | 3 | 148.943 |
| `MatMulV2_43` | 3 | 148.883 |
| `MatMulV2_103` | 3 | 148.883 |
| `MatMulV2_91` | 3 | 148.583 |
| `MatMulV2_95` | 3 | 148.463 |
| `MatMulV2_23` | 3 | 148.083 |
| `MatMulV2_111` | 3 | 147.763 |
| `MatMulV2_11` | 3 | 147.663 |
| `MatMulV2_75` | 3 | 146.943 |
| `MatMulV2_119` | 3 | 146.223 |
| `MatMulV2_99` | 3 | 146.163 |
| `MatMulV2_39` | 3 | 146.043 |
| `MatMulV2_7` | 3 | 145.503 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_79` | 3 | 153.263 |
| `MatMulV2_47` | 3 | 152.963 |
| `MatMulV2_123` | 3 | 150.863 |
| `MatMulV2_83` | 3 | 150.783 |
| `MatMulV2_87` | 3 | 150.383 |
| `MatMulV2_59` | 3 | 150.303 |
| `MatMulV2_127` | 3 | 150.123 |
| `MatMulV2_67` | 3 | 149.983 |
| `MatMulV2_3` | 3 | 149.843 |
| `MatMulV2_31` | 3 | 149.763 |
| `MatMulV2_63` | 3 | 149.743 |
| `MatMulV2_27` | 3 | 149.402 |
| `MatMulV2_71` | 3 | 149.123 |
| `MatMulV2_115` | 3 | 149.083 |
| `MatMulV2_107` | 3 | 148.963 |
| `MatMulV2_51` | 3 | 148.943 |
| `MatMulV2_43` | 3 | 148.883 |
| `MatMulV2_103` | 3 | 148.883 |
| `MatMulV2_91` | 3 | 148.583 |
| `MatMulV2_95` | 3 | 148.463 |
| `MatMulV2_23` | 3 | 148.083 |
| `MatMulV2_111` | 3 | 147.763 |
| `MatMulV2_11` | 3 | 147.663 |
| `MatMulV2_75` | 3 | 146.943 |
| `MatMulV2_119` | 3 | 146.223 |
| `MatMulV2_99` | 3 | 146.163 |
| `MatMulV2_39` | 3 | 146.043 |
| `MatMulV2_7` | 3 | 145.503 |
| `MatMulV2_19` | 3 | 145.143 |
| `MatMulV2_15` | 3 | 144.303 |
| `MatMulV2_55` | 3 | 143.642 |
| `MatMulV2_35` | 3 | 142.483 |
| `MatMulV2_102` | 3 | 141.723 |
| `MatMulV2_106` | 3 | 140.683 |
| `MatMulV2_6` | 3 | 140.463 |
| `MatMulV2_34` | 3 | 140.083 |
| `MatMulV2_70` | 3 | 139.982 |
| `MatMulV2_42` | 3 | 138.603 |
| `MatMulV2_122` | 3 | 138.363 |
| `MatMulV2_30` | 3 | 138.263 |
| `MatMulV2_54` | 3 | 138.063 |
| `MatMulV2_114` | 3 | 137.923 |
| `MatMulV2_50` | 3 | 137.783 |
| `MatMulV2_94` | 3 | 137.783 |
| `MatMulV2_10` | 3 | 137.722 |
| `MatMulV2_110` | 3 | 136.623 |
| `MatMulV2_66` | 3 | 136.483 |
| `MatMulV2_82` | 3 | 136.403 |
| `MatMulV2_62` | 3 | 136.383 |
| `MatMulV2_78` | 3 | 136.343 |
| `MatMulV2_90` | 3 | 136.343 |
| `MatMulV2_22` | 3 | 136.203 |
| `MatMulV2_38` | 3 | 136.163 |
| `MatMulV2_18` | 3 | 136.083 |
| `MatMulV2_98` | 3 | 135.623 |
| `MatMulV2_2` | 3 | 135.443 |
| `MatMulV2_26` | 3 | 134.863 |
| `MatMulV2_14` | 3 | 133.843 |
| `MatMulV2_118` | 3 | 133.763 |
| `MatMulV2_58` | 3 | 133.282 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;320,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4748.294 |
| `MatMulV2 | "768,1280;80,320,16,16;5120" -> "768,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4371.872 |
| `MatMulV2 | "768,1280;80,240,16,16;3840" -> "768,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3583.170 |
| `MatMulV2 | "768,1280;80,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3047.736 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_23` | 1 | 96.902 |
| `PromptFlashAttention_15` | 1 | 96.102 |
| `PromptFlashAttention_23` | 1 | 96.002 |
| `PromptFlashAttention_15` | 1 | 96.001 |
| `PromptFlashAttention` | 1 | 95.562 |
| `PromptFlashAttention_27` | 1 | 94.802 |
| `PromptFlashAttention` | 1 | 94.522 |
| `PromptFlashAttention` | 1 | 94.502 |
| `PromptFlashAttention_23` | 1 | 94.441 |
| `PromptFlashAttention_5` | 1 | 94.162 |
| `PromptFlashAttention_5` | 1 | 92.542 |
| `PromptFlashAttention_5` | 1 | 92.262 |
| `PromptFlashAttention_15` | 1 | 92.022 |
| `PromptFlashAttention_27` | 1 | 90.582 |
| `PromptFlashAttention_25` | 1 | 90.102 |
| `PromptFlashAttention_25` | 1 | 89.842 |
| `PromptFlashAttention_19` | 1 | 89.422 |
| `PromptFlashAttention_16` | 1 | 89.042 |
| `PromptFlashAttention_27` | 1 | 88.982 |
| `PromptFlashAttention_16` | 1 | 88.861 |
| `PromptFlashAttention_25` | 1 | 88.682 |
| `PromptFlashAttention_16` | 1 | 88.522 |
| `PromptFlashAttention_19` | 1 | 88.022 |
| `PromptFlashAttention_19` | 1 | 87.422 |
| `PromptFlashAttention_12` | 1 | 85.922 |
| `PromptFlashAttention_12` | 1 | 85.741 |
| `PromptFlashAttention_10` | 1 | 85.681 |
| `PromptFlashAttention_10` | 1 | 85.462 |
| `PromptFlashAttention_13` | 1 | 85.301 |
| `PromptFlashAttention_13` | 1 | 85.221 |
| `PromptFlashAttention_26` | 1 | 85.161 |
| `PromptFlashAttention_8` | 1 | 85.142 |
| `PromptFlashAttention_10` | 1 | 85.141 |
| `PromptFlashAttention_8` | 1 | 85.122 |
| `PromptFlashAttention_8` | 1 | 85.121 |
| `PromptFlashAttention_26` | 1 | 84.861 |
| `PromptFlashAttention_31` | 1 | 84.362 |
| `PromptFlashAttention_30` | 1 | 84.361 |
| `PromptFlashAttention_1` | 1 | 84.301 |
| `PromptFlashAttention_6` | 1 | 84.222 |
| `PromptFlashAttention_1` | 1 | 84.142 |
| `PromptFlashAttention_26` | 1 | 84.141 |
| `PromptFlashAttention_1` | 1 | 84.082 |
| `PromptFlashAttention_6` | 1 | 84.021 |
| `PromptFlashAttention_31` | 1 | 83.842 |
| `PromptFlashAttention_30` | 1 | 83.782 |
| `PromptFlashAttention_13` | 1 | 83.781 |
| `PromptFlashAttention_6` | 1 | 83.761 |
| `PromptFlashAttention_20` | 1 | 83.702 |
| `PromptFlashAttention_7` | 1 | 83.642 |
| `PromptFlashAttention_30` | 1 | 83.561 |
| `PromptFlashAttention_12` | 1 | 83.442 |
| `PromptFlashAttention_20` | 1 | 83.422 |
| `PromptFlashAttention_31` | 1 | 83.382 |
| `PromptFlashAttention_11` | 1 | 83.162 |
| `PromptFlashAttention_20` | 1 | 82.882 |
| `PromptFlashAttention_11` | 1 | 82.802 |
| `PromptFlashAttention_11` | 1 | 82.562 |
| `PromptFlashAttention_7` | 1 | 82.342 |
| `PromptFlashAttention_7` | 1 | 82.322 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 19369.188 |
| `TorchDynamo Cache Lookup` | 3 | 18492.048 |
| `Torch-Compiled Region: 0/0` | 3 | 1374.040 |
| `TorchNpuGraphBase::Run` | 3 | 756.910 |
| `ExecuteGraph` | 3 | 267.970 |
| `RefreshAtTensorFromGeTensor` | 3 | 169.460 |
| `AssembleInputs` | 3 | 148.020 |
| `aten::empty` | 3 | 79.610 |
| `empty_tensor` | 3 | 44.260 |
| `aten::set_` | 3 | 40.800 |
| `AssembleOutputs` | 3 | 38.770 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 251110.260 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 55092.290 |
| `launch` | 1314 | 18429.590 |
| `InputCopy` | 3 | 130.450 |
| `ModelExecute` | 3 | 86.500 |
| `step_info` | 6 | 46.140 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 27.830 |
| `OutputCopy` | 3 | 1.760 |

