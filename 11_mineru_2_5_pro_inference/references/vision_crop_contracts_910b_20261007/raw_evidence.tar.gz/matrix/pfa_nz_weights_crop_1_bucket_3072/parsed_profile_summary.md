# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/pfa_nz_weights_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/pfa_nz_weights_crop_1_bucket_3072/profile/liteserver-c001-4_84467_20261007120533716_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `50514.133 us`
- `Free`: `703.751 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `867.500 us`
- `Stage`: `51218.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50086.400 |
| `MatMulV2` | 384 | 45899.579 |
| `StridedSliceD` | 384 | 13562.068 |
| `Mul` | 576 | 7435.397 |
| `AutomaticBufferFusionOp` | 480 | 6279.170 |
| `Add` | 384 | 5509.436 |
| `ReduceMeanD` | 384 | 4971.091 |
| `Transpose` | 288 | 4394.484 |
| `Sub` | 192 | 3397.253 |
| `Cast` | 195 | 2568.813 |
| `ConcatV2D` | 192 | 2562.573 |
| `Unpack` | 96 | 2047.060 |
| `Neg` | 192 | 1940.902 |
| `ConfusionTransposeD` | 96 | 1031.647 |
| `Data` | 1 | 5.900 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_1` | 3 | 1584.052 |
| `PromptFlashAttention_15` | 3 | 1579.190 |
| `PromptFlashAttention_26` | 3 | 1578.832 |
| `PromptFlashAttention_8` | 3 | 1577.472 |
| `PromptFlashAttention_10` | 3 | 1576.891 |
| `PromptFlashAttention_6` | 3 | 1576.292 |
| `PromptFlashAttention_12` | 3 | 1573.870 |
| `PromptFlashAttention_31` | 3 | 1572.911 |
| `PromptFlashAttention_30` | 3 | 1572.551 |
| `PromptFlashAttention_25` | 3 | 1571.533 |
| `PromptFlashAttention_18` | 3 | 1569.913 |
| `PromptFlashAttention_19` | 3 | 1569.832 |
| `PromptFlashAttention_13` | 3 | 1565.992 |
| `PromptFlashAttention_16` | 3 | 1565.832 |
| `PromptFlashAttention` | 3 | 1564.411 |
| `PromptFlashAttention_23` | 3 | 1563.790 |
| `PromptFlashAttention_3` | 3 | 1563.213 |
| `PromptFlashAttention_20` | 3 | 1562.191 |
| `PromptFlashAttention_9` | 3 | 1561.451 |
| `PromptFlashAttention_4` | 3 | 1561.110 |
| `PromptFlashAttention_27` | 3 | 1560.290 |
| `PromptFlashAttention_29` | 3 | 1559.613 |
| `PromptFlashAttention_7` | 3 | 1559.271 |
| `PromptFlashAttention_14` | 3 | 1558.650 |
| `PromptFlashAttention_17` | 3 | 1557.430 |
| `PromptFlashAttention_28` | 3 | 1556.813 |
| `PromptFlashAttention_21` | 3 | 1556.351 |
| `PromptFlashAttention_22` | 3 | 1554.751 |
| `PromptFlashAttention_2` | 3 | 1554.450 |
| `PromptFlashAttention_24` | 3 | 1554.370 |
| `PromptFlashAttention_5` | 3 | 1554.171 |
| `PromptFlashAttention_11` | 3 | 1548.911 |
| `MatMulV2_115` | 3 | 463.589 |
| `MatMulV2_7` | 3 | 461.610 |
| `MatMulV2_119` | 3 | 460.889 |
| `MatMulV2_19` | 3 | 460.550 |
| `MatMulV2_103` | 3 | 459.929 |
| `MatMulV2_95` | 3 | 459.689 |
| `MatMulV2_55` | 3 | 459.549 |
| `MatMulV2_15` | 3 | 459.309 |
| `MatMulV2_87` | 3 | 459.209 |
| `MatMulV2_99` | 3 | 458.769 |
| `MatMulV2_43` | 3 | 458.689 |
| `MatMulV2_91` | 3 | 458.671 |
| `MatMulV2_79` | 3 | 458.609 |
| `MatMulV2_75` | 3 | 458.609 |
| `MatMulV2_27` | 3 | 458.531 |
| `MatMulV2_47` | 3 | 458.250 |
| `MatMulV2_35` | 3 | 458.249 |
| `MatMulV2_59` | 3 | 458.209 |
| `MatMulV2_71` | 3 | 456.849 |
| `MatMulV2_127` | 3 | 456.609 |
| `MatMulV2_31` | 3 | 456.349 |
| `MatMulV2_63` | 3 | 456.249 |
| `MatMulV2_83` | 3 | 455.949 |
| `MatMulV2_3` | 3 | 455.489 |
| `MatMulV2_107` | 3 | 455.169 |
| `MatMulV2_11` | 3 | 454.289 |
| `MatMulV2_39` | 3 | 454.249 |
| `MatMulV2_67` | 3 | 454.209 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_115` | 3 | 463.589 |
| `MatMulV2_7` | 3 | 461.610 |
| `MatMulV2_119` | 3 | 460.889 |
| `MatMulV2_19` | 3 | 460.550 |
| `MatMulV2_103` | 3 | 459.929 |
| `MatMulV2_95` | 3 | 459.689 |
| `MatMulV2_55` | 3 | 459.549 |
| `MatMulV2_15` | 3 | 459.309 |
| `MatMulV2_87` | 3 | 459.209 |
| `MatMulV2_99` | 3 | 458.769 |
| `MatMulV2_43` | 3 | 458.689 |
| `MatMulV2_91` | 3 | 458.671 |
| `MatMulV2_79` | 3 | 458.609 |
| `MatMulV2_75` | 3 | 458.609 |
| `MatMulV2_27` | 3 | 458.531 |
| `MatMulV2_47` | 3 | 458.250 |
| `MatMulV2_35` | 3 | 458.249 |
| `MatMulV2_59` | 3 | 458.209 |
| `MatMulV2_71` | 3 | 456.849 |
| `MatMulV2_127` | 3 | 456.609 |
| `MatMulV2_31` | 3 | 456.349 |
| `MatMulV2_63` | 3 | 456.249 |
| `MatMulV2_83` | 3 | 455.949 |
| `MatMulV2_3` | 3 | 455.489 |
| `MatMulV2_107` | 3 | 455.169 |
| `MatMulV2_11` | 3 | 454.289 |
| `MatMulV2_39` | 3 | 454.249 |
| `MatMulV2_67` | 3 | 454.209 |
| `MatMulV2_23` | 3 | 454.029 |
| `MatMulV2_123` | 3 | 452.369 |
| `MatMulV2_51` | 3 | 451.829 |
| `MatMulV2_111` | 3 | 451.329 |
| `MatMulV2_122` | 3 | 434.568 |
| `MatMulV2_42` | 3 | 430.469 |
| `MatMulV2_6` | 3 | 429.849 |
| `MatMulV2_2` | 3 | 429.389 |
| `MatMulV2_50` | 3 | 428.808 |
| `MatMulV2_74` | 3 | 428.749 |
| `MatMulV2_78` | 3 | 428.628 |
| `MatMulV2_90` | 3 | 428.209 |
| `MatMulV2_18` | 3 | 427.389 |
| `MatMulV2_14` | 3 | 426.649 |
| `MatMulV2_114` | 3 | 426.569 |
| `MatMulV2_22` | 3 | 426.309 |
| `MatMulV2_106` | 3 | 426.249 |
| `MatMulV2_62` | 3 | 426.147 |
| `MatMulV2_70` | 3 | 425.847 |
| `MatMulV2_126` | 3 | 425.808 |
| `MatMulV2_94` | 3 | 425.628 |
| `MatMulV2_58` | 3 | 425.369 |
| `MatMulV2_86` | 3 | 425.268 |
| `MatMulV2_34` | 3 | 424.548 |
| `MatMulV2_10` | 3 | 424.488 |
| `MatMulV2_46` | 3 | 423.809 |
| `MatMulV2_118` | 3 | 423.729 |
| `MatMulV2_102` | 3 | 422.429 |
| `MatMulV2_38` | 3 | 422.188 |
| `MatMulV2_30` | 3 | 422.028 |
| `MatMulV2_82` | 3 | 421.967 |
| `MatMulV2_98` | 3 | 421.269 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "3072,5120;320,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 14635.875 |
| `MatMulV2 | "3072,1280;80,320,16,16;5120" -> "3072,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 13613.430 |
| `MatMulV2 | "3072,1280;80,240,16,16;3840" -> "3072,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 10625.158 |
| `MatMulV2 | "3072,1280;80,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 7025.116 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_1` | 1 | 529.191 |
| `PromptFlashAttention_1` | 1 | 527.810 |
| `PromptFlashAttention_26` | 1 | 527.431 |
| `PromptFlashAttention_15` | 1 | 527.350 |
| `PromptFlashAttention_1` | 1 | 527.051 |
| `PromptFlashAttention_10` | 1 | 526.671 |
| `PromptFlashAttention_10` | 1 | 526.670 |
| `PromptFlashAttention_15` | 1 | 526.430 |
| `PromptFlashAttention_26` | 1 | 526.370 |
| `PromptFlashAttention_8` | 1 | 526.031 |
| `PromptFlashAttention_8` | 1 | 525.971 |
| `PromptFlashAttention_18` | 1 | 525.891 |
| `PromptFlashAttention_6` | 1 | 525.571 |
| `PromptFlashAttention_12` | 1 | 525.570 |
| `PromptFlashAttention_12` | 1 | 525.510 |
| `PromptFlashAttention_8` | 1 | 525.470 |
| `PromptFlashAttention_6` | 1 | 525.410 |
| `PromptFlashAttention_15` | 1 | 525.410 |
| `PromptFlashAttention_6` | 1 | 525.311 |
| `PromptFlashAttention` | 1 | 525.271 |
| `PromptFlashAttention_25` | 1 | 525.131 |
| `PromptFlashAttention_26` | 1 | 525.031 |
| `PromptFlashAttention_31` | 1 | 524.451 |
| `PromptFlashAttention_29` | 1 | 524.451 |
| `PromptFlashAttention_31` | 1 | 524.350 |
| `PromptFlashAttention_30` | 1 | 524.310 |
| `PromptFlashAttention_30` | 1 | 524.310 |
| `PromptFlashAttention_31` | 1 | 524.110 |
| `PromptFlashAttention_30` | 1 | 523.931 |
| `PromptFlashAttention_4` | 1 | 523.870 |
| `PromptFlashAttention_10` | 1 | 523.550 |
| `PromptFlashAttention_19` | 1 | 523.511 |
| `PromptFlashAttention_19` | 1 | 523.510 |
| `PromptFlashAttention_25` | 1 | 523.291 |
| `PromptFlashAttention_25` | 1 | 523.111 |
| `PromptFlashAttention_19` | 1 | 522.811 |
| `PromptFlashAttention_12` | 1 | 522.790 |
| `PromptFlashAttention_18` | 1 | 522.551 |
| `PromptFlashAttention_23` | 1 | 522.510 |
| `PromptFlashAttention_13` | 1 | 522.371 |
| `PromptFlashAttention_16` | 1 | 522.211 |
| `PromptFlashAttention_13` | 1 | 521.930 |
| `PromptFlashAttention_16` | 1 | 521.891 |
| `PromptFlashAttention_16` | 1 | 521.730 |
| `PromptFlashAttention_13` | 1 | 521.691 |
| `PromptFlashAttention_3` | 1 | 521.551 |
| `PromptFlashAttention_23` | 1 | 521.530 |
| `PromptFlashAttention_27` | 1 | 521.490 |
| `PromptFlashAttention_18` | 1 | 521.471 |
| `PromptFlashAttention_3` | 1 | 521.391 |
| `PromptFlashAttention_21` | 1 | 521.351 |
| `PromptFlashAttention_9` | 1 | 521.331 |
| `PromptFlashAttention_28` | 1 | 520.971 |
| `PromptFlashAttention_17` | 1 | 520.890 |
| `PromptFlashAttention_20` | 1 | 520.810 |
| `PromptFlashAttention_20` | 1 | 520.771 |
| `PromptFlashAttention_14` | 1 | 520.710 |
| `PromptFlashAttention_7` | 1 | 520.650 |
| `PromptFlashAttention_20` | 1 | 520.610 |
| `PromptFlashAttention_9` | 1 | 520.530 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 51464.919 |
| `TorchDynamo Cache Lookup` | 3 | 50587.299 |
| `Torch-Compiled Region: 0/0` | 3 | 1377.020 |
| `TorchNpuGraphBase::Run` | 3 | 763.530 |
| `ExecuteGraph` | 3 | 263.670 |
| `RefreshAtTensorFromGeTensor` | 3 | 186.240 |
| `AssembleInputs` | 3 | 142.540 |
| `aten::empty` | 3 | 76.870 |
| `aten::set_` | 3 | 60.200 |
| `empty_tensor` | 3 | 45.500 |
| `AssembleOutputs` | 3 | 40.730 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 255788.920 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 151320.190 |
| `launch` | 1314 | 19228.140 |
| `InputCopy` | 3 | 127.170 |
| `ModelExecute` | 3 | 87.580 |
| `step_info` | 6 | 45.360 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 25.530 |
| `OutputCopy` | 3 | 1.740 |

