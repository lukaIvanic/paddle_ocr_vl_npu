# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/unpad_d128_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/unpad_d128_crop_0_bucket_768/profile/liteserver-c001-4_87036_20261007120755219_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `93086.457 us`
- `Free`: `162594.492 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `817.000 us`
- `Stage`: `255681.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `Transpose` | 768 | 17784.879 |
| `MatMulV2` | 384 | 13849.926 |
| `Mul` | 960 | 11654.160 |
| `UnpadFlashAttentionNdKernel` | 96 | 7128.059 |
| `Slice` | 768 | 7112.267 |
| `ReduceMean` | 384 | 5993.008 |
| `Cast` | 768 | 5547.929 |
| `Add` | 768 | 5513.830 |
| `PadV3` | 288 | 4887.589 |
| `Sub` | 192 | 3512.387 |
| `Pows` | 192 | 3127.057 |
| `MemSet` | 288 | 2269.927 |
| `ConcatD` | 192 | 1943.355 |
| `Sigmoid` | 96 | 1356.370 |
| `Neg` | 192 | 1158.039 |
| `Rsqrt` | 192 | 249.426 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 768 | 17784.879 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 384 | 13849.926 |
| `aclnnMul_MulAiCore_Mul` | 864 | 10553.052 |
| `UnpadFlashAttentionNdKernel` | 96 | 7128.059 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 5993.008 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 5547.929 |
| `aclnnAdd_AddAiCore_Add` | 576 | 5237.302 |
| `aclnnConstantPadNd_PadV3AiCore_PadV3` | 288 | 4887.589 |
| `aclnnSub_SubAiCore_Sub` | 192 | 3512.387 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3127.057 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 384 | 2607.874 |
| `aclnnConstantPadNd_PadV3AiCore_MemSet` | 288 | 2269.927 |
| `aclnnNeg_SliceAiCore_Slice` | 192 | 2269.164 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 2235.229 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 1943.355 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 1356.370 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1158.039 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 1101.108 |
| `aclnnAdds_AddAiCore_Add` | 192 | 276.528 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 249.426 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulCommon_MatMulV2` | 384 | 13849.926 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4620.952 |
| `MatMulV2 | "768,1280;5120,1280;5120" -> "768,5120" | ND;ND;ND -> ND` | 96 | 3932.300 |
| `MatMulV2 | "768,1280;3840,1280;3840" -> "768,3840" | ND;ND;ND -> ND` | 96 | 3292.966 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 2003.708 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 1 | 85.841 |
| `UnpadFlashAttentionNdKernel` | 1 | 85.521 |
| `UnpadFlashAttentionNdKernel` | 1 | 85.482 |
| `UnpadFlashAttentionNdKernel` | 1 | 85.382 |
| `UnpadFlashAttentionNdKernel` | 1 | 84.181 |
| `UnpadFlashAttentionNdKernel` | 1 | 84.101 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.642 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.861 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.621 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.621 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.382 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.142 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.042 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.901 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.881 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.702 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.582 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.222 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.021 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.861 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.341 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.222 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.162 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.102 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.022 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.941 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.842 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.742 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.721 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.702 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.681 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.602 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.541 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.521 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.501 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.462 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.461 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.441 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.441 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.421 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.402 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.341 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.341 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.322 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.281 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.281 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.262 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.221 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.221 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.221 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.202 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.162 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.142 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.141 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.122 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.102 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.102 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.102 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.101 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.041 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `aten::copy_` | 1728 | 36071.937 |
| `aten::to` | 960 | 28039.820 |
| `aten::clone` | 960 | 27198.853 |
| `aten::contiguous` | 864 | 27141.059 |
| `aclnnInplaceCopy` | 1632 | 26444.383 |
| `empty_tensor` | 5568 | 25652.240 |
| `aten::_to_copy` | 768 | 25295.920 |
| `aten::mul` | 960 | 21896.481 |
| `aten::linear` | 384 | 19223.948 |
| `aten::add` | 768 | 18985.010 |
| `aten::addmm` | 384 | 14595.254 |
| `aclnnAddmm` | 384 | 13849.916 |
| `aclnnMul` | 864 | 10609.611 |
| `aten::mean` | 384 | 10174.840 |
| `aten::as_strided` | 2496 | 9525.160 |
| `aten::transpose` | 1152 | 8758.520 |
| `aten::pad` | 288 | 8369.306 |
| `aten::constant_pad_nd` | 288 | 7870.434 |
| `atb::_npu_flash_attention_unpad` | 96 | 7313.185 |
| `aclnnConstantPadNd` | 288 | 7157.523 |
| `SelfAttentionOperation` | 96 | 7128.062 |
| `aten::empty` | 768 | 6087.050 |
| `aclnnMean` | 384 | 5994.839 |
| `aten::square` | 192 | 5851.210 |
| `aclnnAdd` | 576 | 5533.916 |
| `aten::pow` | 192 | 5308.260 |
| `aten::cat` | 192 | 5287.593 |
| `aten::neg` | 192 | 5019.000 |
| `aten::select` | 576 | 4607.730 |
| `aten::sub` | 192 | 4329.055 |
| `aclnnCat` | 192 | 4179.493 |
| `aten::slice` | 480 | 3745.890 |
| `aten::view` | 960 | 3531.580 |
| `aclnnSub` | 192 | 3512.370 |
| `aten::rsqrt` | 192 | 3449.750 |
| `aclnnNeg` | 192 | 3427.209 |
| `aten::t` | 384 | 3194.220 |
| `aclnnPowTensorScalar` | 192 | 3127.063 |
| `aten::unbind` | 96 | 2735.990 |
| `aten::unsqueeze` | 288 | 2160.260 |
| `aten::sigmoid` | 96 | 1824.620 |
| `aclnnAdds` | 192 | 1516.780 |
| `aclnnSigmoid` | 96 | 1356.367 |
| `aclnnRsqrt` | 192 | 1158.400 |
| `aclnnMuls` | 96 | 1101.482 |
| `aten::item` | 288 | 986.270 |
| `aten::empty_like` | 96 | 983.440 |
| `aten::empty_strided` | 96 | 588.410 |
| `aten::_local_scalar_dense` | 288 | 430.740 |
| `aten::result_type` | 192 | 375.650 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 6528 | 42721.150 |
| `aclrtLaunchKernelWithHostArgs` | 6432 | 33378.380 |
| `aclnnInplaceCopy` | 1632 | 19753.760 |
| `aclnnMul` | 864 | 8558.280 |
| `aclnnAdd` | 576 | 5803.040 |
| `aclnnConstantPadNd` | 288 | 5133.800 |
| `aclnnMean` | 384 | 5083.000 |
| `SelfAttentionOperation::Setup` | 96 | 4314.060 |
| `SelfAttentionOperation::Execute` | 96 | 4154.990 |
| `aclnnAddmm` | 384 | 4117.220 |
| `aclnnCat` | 192 | 3043.500 |
| `aclnnNeg` | 192 | 2976.370 |
| `aclrtGetStreamAttribute` | 5472 | 2184.390 |
| `aclnnAdds` | 192 | 2013.770 |
| `aclnnPowTensorScalar` | 192 | 1987.920 |
| `aclnnSub` | 192 | 1927.100 |
| `aclnnRsqrt` | 192 | 1825.900 |
| `aclnnMuls` | 96 | 1020.160 |
| `aclnnSigmoid` | 96 | 951.630 |
| `aclrtGetHardwareSyncAddr` | 672 | 448.830 |
| `aclmdlRICaptureGetInfo` | 192 | 161.200 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 81.920 |

