# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/unpad_d128_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/unpad_d128_crop_1_bucket_3072/profile/liteserver-c001-4_87404_20261007120847813_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `208546.196 us`
- `Free`: `53426.638 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `689.500 us`
- `Stage`: `261973.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 96 | 57880.515 |
| `MatMulV3` | 288 | 36539.313 |
| `Transpose` | 768 | 22923.022 |
| `Mul` | 960 | 19536.833 |
| `Slice` | 576 | 9455.465 |
| `ReduceMean` | 384 | 9084.002 |
| `Add` | 768 | 8335.822 |
| `Cast` | 768 | 8025.512 |
| `PadV3` | 288 | 7821.225 |
| `MatMulV2` | 96 | 6601.532 |
| `Sub` | 192 | 4814.381 |
| `Pows` | 192 | 4566.344 |
| `Sigmoid` | 96 | 3244.505 |
| `ConcatD` | 192 | 3155.487 |
| `SliceV2` | 192 | 2272.306 |
| `MemSet` | 288 | 2261.280 |
| `Neg` | 192 | 1714.561 |
| `Rsqrt` | 192 | 316.448 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 96 | 57880.515 |
| `aclnnAddmm_MatMulV3Common_MatMulV3` | 288 | 36539.313 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 768 | 22923.022 |
| `aclnnMul_MulAiCore_Mul` | 864 | 16876.345 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 9084.002 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 8025.512 |
| `aclnnAdd_AddAiCore_Add` | 576 | 8001.137 |
| `aclnnConstantPadNd_PadV3AiCore_PadV3` | 288 | 7821.225 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 96 | 6601.532 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 384 | 5523.877 |
| `aclnnSub_SubAiCore_Sub` | 192 | 4814.381 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 4566.344 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 3931.588 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 3244.505 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 3155.487 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 2660.488 |
| `aclnnNeg_SliceV2AiCore_SliceV2` | 192 | 2272.306 |
| `aclnnConstantPadNd_PadV3AiCore_MemSet` | 288 | 2261.280 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1714.561 |
| `aclnnAdds_AddAiCore_Add` | 192 | 334.685 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 316.448 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulV3Common_MatMulV3` | 288 | 36539.313 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 96 | 6601.532 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;5120,1280;5120" -> "3072,5120" | ND;ND;ND -> ND` | 96 | 13664.258 |
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12911.616 |
| `MatMulV3 | "3072,1280;3840,1280;3840" -> "3072,3840" | ND;ND;ND -> ND` | 96 | 9963.439 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6601.532 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 1 | 610.192 |
| `UnpadFlashAttentionNdKernel` | 1 | 608.252 |
| `UnpadFlashAttentionNdKernel` | 1 | 607.772 |
| `UnpadFlashAttentionNdKernel` | 1 | 607.613 |
| `UnpadFlashAttentionNdKernel` | 1 | 607.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.992 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.972 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.812 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.392 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.292 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.852 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.392 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.392 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.112 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.753 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.572 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.412 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.392 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.352 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.312 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.232 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.112 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.072 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.812 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.692 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.612 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.532 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.472 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.412 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.412 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.352 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.272 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.172 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.112 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.032 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.952 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.892 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.892 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.792 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.732 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.692 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.672 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.612 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.552 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.472 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.432 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.412 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.372 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.372 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.232 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.152 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.133 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.892 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.852 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.832 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `atb::_npu_flash_attention_unpad` | 96 | 57880.516 |
| `SelfAttentionOperation` | 96 | 57880.516 |
| `aten::linear` | 384 | 43146.380 |
| `aten::addmm` | 384 | 43140.842 |
| `aclnnAddmm` | 384 | 43140.842 |
| `aten::copy_` | 1728 | 42200.628 |
| `aclnnInplaceCopy` | 1632 | 36775.775 |
| `aten::clone` | 960 | 30375.862 |
| `aten::contiguous` | 864 | 29445.215 |
| `aten::to` | 960 | 27822.420 |
| `empty_tensor` | 5568 | 27561.920 |
| `aten::_to_copy` | 768 | 24910.220 |
| `aten::mul` | 960 | 22884.580 |
| `aten::add` | 768 | 18560.370 |
| `aclnnMul` | 864 | 16941.033 |
| `aten::pad` | 288 | 13010.335 |
| `aten::constant_pad_nd` | 288 | 12895.553 |
| `aclnnConstantPadNd` | 288 | 11487.241 |
| `aten::mean` | 384 | 10174.330 |
| `aten::as_strided` | 2496 | 9812.440 |
| `aclnnMean` | 384 | 9084.001 |
| `aten::transpose` | 1152 | 8945.320 |
| `aclnnAdd` | 576 | 8030.447 |
| `aten::cat` | 192 | 7217.310 |
| `aclnnCat` | 192 | 7087.082 |
| `aten::empty` | 768 | 6116.900 |
| `aten::square` | 192 | 5547.351 |
| `aten::pow` | 192 | 5093.032 |
| `aten::sub` | 192 | 5075.876 |
| `aten::neg` | 192 | 4921.255 |
| `aclnnSub` | 192 | 4814.376 |
| `aclnnPowTensorScalar` | 192 | 4566.351 |
| `aten::select` | 576 | 4501.020 |
| `aclnnNeg` | 192 | 3996.819 |
| `aten::slice` | 480 | 3888.180 |
| `aten::view` | 960 | 3751.950 |
| `aten::rsqrt` | 192 | 3382.830 |
| `aten::sigmoid` | 96 | 3260.393 |
| `aclnnSigmoid` | 96 | 3244.505 |
| `aten::t` | 384 | 3170.240 |
| `aten::unbind` | 96 | 2727.970 |
| `aclnnMuls` | 96 | 2660.493 |
| `aten::unsqueeze` | 288 | 2246.190 |
| `aclnnAdds` | 192 | 1309.720 |
| `aten::item` | 288 | 1209.190 |
| `aclnnRsqrt` | 192 | 1057.830 |
| `aten::empty_like` | 96 | 1053.830 |
| `aten::empty_strided` | 96 | 543.570 |
| `aten::_local_scalar_dense` | 288 | 434.370 |
| `aten::result_type` | 192 | 337.570 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 6528 | 42209.390 |
| `aclrtLaunchKernelWithHostArgs` | 6432 | 32790.640 |
| `aclnnInplaceCopy` | 1632 | 18657.060 |
| `aclnnMul` | 864 | 7970.170 |
| `aclnnAdd` | 576 | 5299.580 |
| `aclnnConstantPadNd` | 288 | 4824.260 |
| `aclnnMean` | 384 | 4687.320 |
| `SelfAttentionOperation::Setup` | 96 | 4573.790 |
| `aclnnAddmm` | 384 | 4062.120 |
| `SelfAttentionOperation::Execute` | 96 | 4009.510 |
| `aclnnCat` | 192 | 2839.340 |
| `aclnnNeg` | 192 | 2780.010 |
| `aclrtGetStreamAttribute` | 5472 | 2307.060 |
| `aclnnPowTensorScalar` | 192 | 1843.780 |
| `aclnnAdds` | 192 | 1830.260 |
| `aclnnSub` | 192 | 1769.020 |
| `aclnnRsqrt` | 192 | 1721.880 |
| `aclnnMuls` | 96 | 970.330 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 966.310 |
| `aclnnSigmoid` | 96 | 891.880 |
| `aclrtGetHardwareSyncAddr` | 960 | 695.730 |
| `aclmdlRICaptureGetInfo` | 192 | 190.150 |

