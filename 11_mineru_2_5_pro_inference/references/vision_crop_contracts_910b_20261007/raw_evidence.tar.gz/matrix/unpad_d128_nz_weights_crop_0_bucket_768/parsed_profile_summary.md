# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/unpad_d128_nz_weights_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/unpad_d128_nz_weights_crop_0_bucket_768/profile/liteserver-c001-4_87976_20261007120948966_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `92927.656 us`
- `Free`: `150305.624 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `726.250 us`
- `Stage`: `243233.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `Transpose` | 768 | 17910.307 |
| `MatMulV2` | 384 | 13232.927 |
| `Mul` | 960 | 11661.686 |
| `UnpadFlashAttentionNdKernel` | 96 | 7353.000 |
| `Slice` | 768 | 7125.369 |
| `ReduceMean` | 384 | 5991.228 |
| `Add` | 768 | 5488.681 |
| `Cast` | 768 | 5053.893 |
| `PadV3` | 288 | 4985.393 |
| `Sub` | 192 | 4256.072 |
| `Pows` | 192 | 3117.874 |
| `MemSet` | 288 | 2153.335 |
| `ConcatD` | 192 | 2003.204 |
| `Sigmoid` | 96 | 1282.492 |
| `Neg` | 192 | 1061.603 |
| `Rsqrt` | 192 | 252.367 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 768 | 17910.307 |
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 384 | 13232.927 |
| `aclnnMul_MulAiCore_Mul` | 864 | 10560.946 |
| `UnpadFlashAttentionNdKernel` | 96 | 7353.000 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 5991.228 |
| `aclnnAdd_AddAiCore_Add` | 576 | 5212.615 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 5053.893 |
| `aclnnConstantPadNd_PadV3AiCore_PadV3` | 288 | 4985.393 |
| `aclnnSub_SubAiCore_Sub` | 192 | 4256.072 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3117.874 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 384 | 2613.240 |
| `aclnnNeg_SliceAiCore_Slice` | 192 | 2271.422 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 2240.707 |
| `aclnnConstantPadNd_PadV3AiCore_MemSet` | 288 | 2153.335 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 2003.204 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 1282.492 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 1100.740 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1061.603 |
| `aclnnAdds_AddAiCore_Add` | 192 | 276.066 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 252.367 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 384 | 13232.927 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;320,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4401.366 |
| `MatMulV2 | "768,1280;80,320,16,16;5120" -> "768,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3932.104 |
| `MatMulV2 | "768,1280;80,240,16,16;3840" -> "768,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3215.786 |
| `MatMulV2 | "768,1280;80,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 1683.671 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 1 | 82.462 |
| `UnpadFlashAttentionNdKernel` | 1 | 82.102 |
| `UnpadFlashAttentionNdKernel` | 1 | 81.982 |
| `UnpadFlashAttentionNdKernel` | 1 | 81.581 |
| `UnpadFlashAttentionNdKernel` | 1 | 81.482 |
| `UnpadFlashAttentionNdKernel` | 1 | 81.442 |
| `UnpadFlashAttentionNdKernel` | 1 | 81.442 |
| `UnpadFlashAttentionNdKernel` | 1 | 81.421 |
| `UnpadFlashAttentionNdKernel` | 1 | 81.342 |
| `UnpadFlashAttentionNdKernel` | 1 | 81.341 |
| `UnpadFlashAttentionNdKernel` | 1 | 81.121 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.982 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.962 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.862 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.801 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.742 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.742 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.701 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.601 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.582 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.561 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.542 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.541 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.502 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.442 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.421 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.401 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.381 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.341 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.341 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.322 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.282 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.242 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.221 |
| `UnpadFlashAttentionNdKernel` | 1 | 80.081 |
| `UnpadFlashAttentionNdKernel` | 1 | 79.962 |
| `UnpadFlashAttentionNdKernel` | 1 | 79.921 |
| `UnpadFlashAttentionNdKernel` | 1 | 79.841 |
| `UnpadFlashAttentionNdKernel` | 1 | 79.762 |
| `UnpadFlashAttentionNdKernel` | 1 | 79.582 |
| `UnpadFlashAttentionNdKernel` | 1 | 79.561 |
| `UnpadFlashAttentionNdKernel` | 1 | 79.422 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.182 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.581 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.381 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.341 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.201 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.101 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.061 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.041 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.921 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.801 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.662 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.622 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.542 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.421 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.001 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.982 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.722 |
| `UnpadFlashAttentionNdKernel` | 1 | 73.661 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `aten::copy_` | 1728 | 33721.862 |
| `aclnnInplaceCopy` | 1632 | 25840.650 |
| `aten::clone` | 960 | 25606.784 |
| `aten::to` | 960 | 25518.630 |
| `aten::contiguous` | 864 | 25228.875 |
| `empty_tensor` | 5568 | 23874.290 |
| `aten::_to_copy` | 768 | 22762.010 |
| `aten::mul` | 960 | 19402.007 |
| `aten::linear` | 384 | 18784.466 |
| `aten::add` | 768 | 16981.160 |
| `aten::addmm` | 384 | 14094.040 |
| `aclnnAddmmWeightNz` | 384 | 13232.924 |
| `aclnnMul` | 864 | 10561.800 |
| `aten::as_strided` | 2496 | 9235.760 |
| `aten::mean` | 384 | 9109.680 |
| `aten::transpose` | 1152 | 8546.130 |
| `aten::pad` | 288 | 7909.396 |
| `aten::constant_pad_nd` | 288 | 7425.696 |
| `atb::_npu_flash_attention_unpad` | 96 | 7417.166 |
| `SelfAttentionOperation` | 96 | 7353.007 |
| `aclnnConstantPadNd` | 288 | 7138.723 |
| `aclnnMean` | 384 | 5996.379 |
| `aten::empty` | 768 | 5616.620 |
| `aclnnAdd` | 576 | 5318.985 |
| `aten::square` | 192 | 5233.210 |
| `aten::cat` | 192 | 4821.343 |
| `aten::pow` | 192 | 4676.370 |
| `aten::select` | 576 | 4453.220 |
| `aten::sub` | 192 | 4314.623 |
| `aten::neg` | 192 | 4281.800 |
| `aclnnSub` | 192 | 4256.065 |
| `aclnnCat` | 192 | 4243.905 |
| `aten::slice` | 480 | 3607.810 |
| `aten::view` | 960 | 3560.680 |
| `aclnnNeg` | 192 | 3333.026 |
| `aten::rsqrt` | 192 | 3290.490 |
| `aten::t` | 384 | 3145.340 |
| `aclnnPowTensorScalar` | 192 | 3117.882 |
| `aten::unbind` | 96 | 2671.350 |
| `aten::unsqueeze` | 288 | 2082.780 |
| `aten::sigmoid` | 96 | 1705.230 |
| `aclnnSigmoid` | 96 | 1282.486 |
| `aclnnAdds` | 192 | 1152.560 |
| `aclnnMuls` | 96 | 1100.742 |
| `aclnnRsqrt` | 192 | 1043.320 |
| `aten::empty_like` | 96 | 1012.580 |
| `aten::item` | 288 | 992.090 |
| `aten::empty_strided` | 96 | 652.220 |
| `aten::_local_scalar_dense` | 288 | 439.180 |
| `aten::result_type` | 192 | 326.840 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 6528 | 39216.280 |
| `aclrtLaunchKernelWithHostArgs` | 6432 | 30469.090 |
| `aclnnInplaceCopy` | 1632 | 17295.700 |
| `aclnnMul` | 864 | 7301.200 |
| `aclnnAdd` | 576 | 4843.330 |
| `aclnnConstantPadNd` | 288 | 4449.450 |
| `aclnnMean` | 384 | 4352.360 |
| `SelfAttentionOperation::Setup` | 96 | 4103.760 |
| `SelfAttentionOperation::Execute` | 96 | 3811.250 |
| `aclnnAddmmWeightNz` | 384 | 3320.430 |
| `aclnnCat` | 192 | 2552.670 |
| `aclnnNeg` | 192 | 2484.400 |
| `aclrtGetStreamAttribute` | 5472 | 2336.100 |
| `aclnnAdds` | 192 | 1671.880 |
| `aclnnPowTensorScalar` | 192 | 1655.090 |
| `aclnnSub` | 192 | 1645.040 |
| `aclnnRsqrt` | 192 | 1604.540 |
| `aclnnSigmoid` | 96 | 858.960 |
| `aclnnMuls` | 96 | 839.870 |
| `aclrtGetHardwareSyncAddr` | 672 | 446.230 |
| `aclmdlRICaptureGetInfo` | 192 | 227.880 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 89.610 |

