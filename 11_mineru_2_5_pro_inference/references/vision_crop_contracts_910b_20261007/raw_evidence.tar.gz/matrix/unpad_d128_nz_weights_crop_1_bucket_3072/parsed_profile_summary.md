# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/unpad_d128_nz_weights_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/matrix/unpad_d128_nz_weights_crop_1_bucket_3072/profile/liteserver-c001-4_89215_20261007121047282_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `209160.353 us`
- `Free`: `44396.093 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `799.250 us`
- `Stage`: `253556.500 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 96 | 57980.737 |
| `MatMulV3` | 288 | 35621.653 |
| `Transpose` | 768 | 23986.764 |
| `Mul` | 960 | 19407.473 |
| `Slice` | 576 | 9470.089 |
| `ReduceMean` | 384 | 9221.367 |
| `Add` | 768 | 8327.556 |
| `PadV3` | 288 | 8107.207 |
| `Cast` | 768 | 7572.221 |
| `MatMulV2` | 96 | 6892.161 |
| `Sub` | 192 | 5447.841 |
| `Pows` | 192 | 4548.860 |
| `Sigmoid` | 96 | 3177.426 |
| `ConcatD` | 192 | 3164.578 |
| `SliceV2` | 192 | 2226.860 |
| `MemSet` | 288 | 2131.142 |
| `Neg` | 192 | 1564.716 |
| `Rsqrt` | 192 | 314.085 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 96 | 57980.737 |
| `aclnnAddmmWeightNz_MatMulV3Common_MatMulV3` | 288 | 35621.653 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 768 | 23986.764 |
| `aclnnMul_MulAiCore_Mul` | 864 | 16768.501 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 9221.367 |
| `aclnnConstantPadNd_PadV3AiCore_PadV3` | 288 | 8107.207 |
| `aclnnAdd_AddAiCore_Add` | 576 | 7992.149 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 7572.221 |
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 96 | 6892.161 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 384 | 5532.432 |
| `aclnnSub_SubAiCore_Sub` | 192 | 5447.841 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 4548.860 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 3937.657 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 3177.426 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 3164.578 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 2638.972 |
| `aclnnNeg_SliceV2AiCore_SliceV2` | 192 | 2226.860 |
| `aclnnConstantPadNd_PadV3AiCore_MemSet` | 288 | 2131.142 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1564.716 |
| `aclnnAdds_AddAiCore_Add` | 192 | 335.407 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 314.085 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmmWeightNz_MatMulV3Common_MatMulV3` | 288 | 35621.653 |
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 96 | 6892.161 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;80,320,16,16;5120" -> "3072,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 13440.008 |
| `MatMulV3 | "3072,5120;320,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 12397.771 |
| `MatMulV3 | "3072,1280;80,240,16,16;3840" -> "3072,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 9783.874 |
| `MatMulV2 | "3072,1280;80,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 6892.161 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 1 | 610.612 |
| `UnpadFlashAttentionNdKernel` | 1 | 608.232 |
| `UnpadFlashAttentionNdKernel` | 1 | 608.212 |
| `UnpadFlashAttentionNdKernel` | 1 | 607.572 |
| `UnpadFlashAttentionNdKernel` | 1 | 607.533 |
| `UnpadFlashAttentionNdKernel` | 1 | 607.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.812 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.772 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.712 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.352 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.212 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.972 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.952 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.812 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.792 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.592 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.552 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.532 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.512 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.472 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.352 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.312 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.152 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.132 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.033 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.932 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.932 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.892 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.792 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.513 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.472 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.472 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.312 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.272 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.232 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.192 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.072 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.992 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.932 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.932 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.852 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.832 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.773 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.732 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.692 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.592 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.552 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.532 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.392 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.372 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.372 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.333 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.332 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.332 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `atb::_npu_flash_attention_unpad` | 96 | 57980.738 |
| `SelfAttentionOperation` | 96 | 57980.738 |
| `aten::linear` | 384 | 42520.807 |
| `aten::addmm` | 384 | 42513.809 |
| `aclnnAddmmWeightNz` | 384 | 42513.809 |
| `aten::copy_` | 1728 | 42042.280 |
| `aclnnInplaceCopy` | 1632 | 37154.414 |
| `aten::clone` | 960 | 30446.961 |
| `aten::contiguous` | 864 | 29119.707 |
| `aten::to` | 960 | 26505.610 |
| `empty_tensor` | 5568 | 25210.080 |
| `aten::mul` | 960 | 23685.191 |
| `aten::_to_copy` | 768 | 23605.040 |
| `aten::add` | 768 | 17909.240 |
| `aclnnMul` | 864 | 16776.525 |
| `aten::pad` | 288 | 10243.582 |
| `aten::constant_pad_nd` | 288 | 10238.344 |
| `aclnnConstantPadNd` | 288 | 10238.344 |
| `aten::mean` | 384 | 9751.013 |
| `aten::as_strided` | 2496 | 9477.800 |
| `aclnnMean` | 384 | 9221.364 |
| `aten::transpose` | 1152 | 8811.040 |
| `aclnnAdd` | 576 | 7992.140 |
| `aten::cat` | 192 | 7109.771 |
| `aclnnCat` | 192 | 7102.242 |
| `aten::empty` | 768 | 5914.520 |
| `aten::sub` | 192 | 5460.348 |
| `aclnnSub` | 192 | 5447.849 |
| `aten::square` | 192 | 5411.441 |
| `aten::pow` | 192 | 4873.429 |
| `aten::neg` | 192 | 4654.953 |
| `aclnnPowTensorScalar` | 192 | 4548.851 |
| `aten::select` | 576 | 4536.260 |
| `aclnnNeg` | 192 | 3791.576 |
| `aten::slice` | 480 | 3643.380 |
| `aten::view` | 960 | 3581.550 |
| `aten::rsqrt` | 192 | 3432.610 |
| `aten::t` | 384 | 3248.200 |
| `aten::sigmoid` | 96 | 3177.423 |
| `aclnnSigmoid` | 96 | 3177.423 |
| `aten::unbind` | 96 | 2713.900 |
| `aclnnMuls` | 96 | 2638.973 |
| `aten::unsqueeze` | 288 | 2099.250 |
| `aclnnAdds` | 192 | 1267.380 |
| `aclnnRsqrt` | 192 | 1198.030 |
| `aten::item` | 288 | 1019.250 |
| `aten::empty_like` | 96 | 1003.440 |
| `aten::empty_strided` | 96 | 613.980 |
| `aten::_local_scalar_dense` | 288 | 445.000 |
| `aten::result_type` | 192 | 346.460 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 6528 | 39616.840 |
| `aclrtLaunchKernelWithHostArgs` | 6432 | 30120.250 |
| `aclnnInplaceCopy` | 1632 | 17191.420 |
| `aclnnMul` | 864 | 7457.280 |
| `aclnnAdd` | 576 | 4872.630 |
| `aclnnConstantPadNd` | 288 | 4581.360 |
| `aclnnMean` | 384 | 4419.570 |
| `SelfAttentionOperation::Setup` | 96 | 4009.580 |
| `aclnnAddmmWeightNz` | 384 | 3857.900 |
| `SelfAttentionOperation::Execute` | 96 | 3695.330 |
| `aclnnCat` | 192 | 2693.400 |
| `aclnnNeg` | 192 | 2546.400 |
| `aclrtGetStreamAttribute` | 5472 | 2404.780 |
| `aclnnSub` | 192 | 1752.580 |
| `aclnnAdds` | 192 | 1702.240 |
| `aclnnPowTensorScalar` | 192 | 1688.360 |
| `aclnnRsqrt` | 192 | 1652.290 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 1182.730 |
| `aclnnMuls` | 96 | 924.310 |
| `aclnnSigmoid` | 96 | 877.010 |
| `aclrtGetHardwareSyncAddr` | 960 | 596.940 |
| `aclmdlRICaptureGetInfo` | 192 | 170.040 |

