# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/padding_matrix/pfa_d128_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/padding_matrix/pfa_d128_crop_0_bucket_768/profile/liteserver-c001-4_91672_20261007121347736_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `18673.174 us`
- `Free`: `955.658 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `959.750 us`
- `Stage`: `19628.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 13482.303 |
| `PromptFlashAttention` | 96 | 8275.989 |
| `StridedSliceD` | 480 | 6273.819 |
| `PadV3` | 288 | 4247.642 |
| `Mul` | 576 | 4161.655 |
| `Add` | 384 | 3203.787 |
| `AutomaticBufferFusionOp` | 480 | 3043.714 |
| `ReduceMeanD` | 384 | 2571.826 |
| `Transpose` | 288 | 2319.776 |
| `Sub` | 192 | 1849.379 |
| `Cast` | 195 | 1757.659 |
| `ConcatV2D` | 192 | 1488.726 |
| `Neg` | 192 | 1476.790 |
| `Unpack` | 96 | 803.497 |
| `ConfusionTransposeD` | 96 | 512.768 |
| `te_memset_a8b1f5b1b0c44beef84d40753f2a30539fad1ae9efba5fbd957512e0b764e7d9__kernel0` | 288 | 279.806 |
| `Data` | 1 | 6.360 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_24` | 3 | 296.506 |
| `PromptFlashAttention_10` | 3 | 280.126 |
| `te_memset_a8b1f5b1b0c44beef84d40753f2a30539fad1ae9efba5fbd957512e0b764e7d9__kernel0` | 288 | 279.806 |
| `PromptFlashAttention_4` | 3 | 274.646 |
| `PromptFlashAttention_12` | 3 | 270.184 |
| `PromptFlashAttention_23` | 3 | 270.006 |
| `PromptFlashAttention` | 3 | 269.445 |
| `PromptFlashAttention_25` | 3 | 268.806 |
| `PromptFlashAttention_13` | 3 | 268.804 |
| `PromptFlashAttention_28` | 3 | 267.646 |
| `PromptFlashAttention_9` | 3 | 267.286 |
| `PromptFlashAttention_31` | 3 | 267.266 |
| `PromptFlashAttention_11` | 3 | 266.486 |
| `PromptFlashAttention_20` | 3 | 266.465 |
| `PromptFlashAttention_22` | 3 | 264.206 |
| `PromptFlashAttention_19` | 3 | 264.066 |
| `PromptFlashAttention_5` | 3 | 262.226 |
| `PromptFlashAttention_6` | 3 | 257.725 |
| `PromptFlashAttention_21` | 3 | 256.845 |
| `PromptFlashAttention_18` | 3 | 255.065 |
| `PromptFlashAttention_29` | 3 | 250.985 |
| `PromptFlashAttention_30` | 3 | 250.105 |
| `PromptFlashAttention_27` | 3 | 249.106 |
| `PromptFlashAttention_7` | 3 | 247.864 |
| `PromptFlashAttention_3` | 3 | 246.365 |
| `PromptFlashAttention_14` | 3 | 244.844 |
| `PromptFlashAttention_26` | 3 | 244.544 |
| `PromptFlashAttention_15` | 3 | 244.285 |
| `PromptFlashAttention_1` | 3 | 242.865 |
| `PromptFlashAttention_2` | 3 | 241.926 |
| `PromptFlashAttention_16` | 3 | 240.506 |
| `PromptFlashAttention_8` | 3 | 240.305 |
| `PromptFlashAttention_17` | 3 | 238.484 |
| `MatMulV2_15` | 3 | 142.463 |
| `MatMulV2_55` | 3 | 139.943 |
| `MatMulV2_11` | 3 | 139.743 |
| `MatMulV2_7` | 3 | 139.463 |
| `MatMulV2_103` | 3 | 138.522 |
| `MatMulV2_23` | 3 | 138.482 |
| `MatMulV2_31` | 3 | 138.362 |
| `MatMulV2_39` | 3 | 137.923 |
| `MatMulV2_19` | 3 | 137.902 |
| `MatMulV2_27` | 3 | 137.843 |
| `MatMulV2_71` | 3 | 137.703 |
| `MatMulV2_67` | 3 | 137.563 |
| `MatMulV2_59` | 3 | 137.503 |
| `MatMulV2_43` | 3 | 136.843 |
| `MatMulV2_111` | 3 | 136.723 |
| `MatMulV2_63` | 3 | 136.523 |
| `MatMulV2_107` | 3 | 136.403 |
| `MatMulV2_3` | 3 | 136.383 |
| `MatMulV2_35` | 3 | 136.303 |
| `MatMulV2_119` | 3 | 136.263 |
| `MatMulV2_51` | 3 | 136.163 |
| `MatMulV2_99` | 3 | 136.082 |
| `MatMulV2_79` | 3 | 136.003 |
| `MatMulV2_87` | 3 | 135.983 |
| `MatMulV2_47` | 3 | 135.902 |
| `MatMulV2_91` | 3 | 135.863 |
| `MatMulV2_127` | 3 | 135.803 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_15` | 3 | 142.463 |
| `MatMulV2_55` | 3 | 139.943 |
| `MatMulV2_11` | 3 | 139.743 |
| `MatMulV2_7` | 3 | 139.463 |
| `MatMulV2_103` | 3 | 138.522 |
| `MatMulV2_23` | 3 | 138.482 |
| `MatMulV2_31` | 3 | 138.362 |
| `MatMulV2_39` | 3 | 137.923 |
| `MatMulV2_19` | 3 | 137.902 |
| `MatMulV2_27` | 3 | 137.843 |
| `MatMulV2_71` | 3 | 137.703 |
| `MatMulV2_67` | 3 | 137.563 |
| `MatMulV2_59` | 3 | 137.503 |
| `MatMulV2_43` | 3 | 136.843 |
| `MatMulV2_111` | 3 | 136.723 |
| `MatMulV2_63` | 3 | 136.523 |
| `MatMulV2_107` | 3 | 136.403 |
| `MatMulV2_3` | 3 | 136.383 |
| `MatMulV2_35` | 3 | 136.303 |
| `MatMulV2_119` | 3 | 136.263 |
| `MatMulV2_51` | 3 | 136.163 |
| `MatMulV2_99` | 3 | 136.082 |
| `MatMulV2_79` | 3 | 136.003 |
| `MatMulV2_87` | 3 | 135.983 |
| `MatMulV2_47` | 3 | 135.902 |
| `MatMulV2_91` | 3 | 135.863 |
| `MatMulV2_127` | 3 | 135.803 |
| `MatMulV2_95` | 3 | 135.681 |
| `MatMulV2_115` | 3 | 135.603 |
| `MatMulV2_83` | 3 | 135.403 |
| `MatMulV2_75` | 3 | 135.223 |
| `MatMulV2_123` | 3 | 134.742 |
| `MatMulV2_14` | 3 | 125.983 |
| `MatMulV2_6` | 3 | 124.723 |
| `MatMulV2_38` | 3 | 124.222 |
| `MatMulV2_2` | 3 | 123.943 |
| `MatMulV2_94` | 3 | 123.862 |
| `MatMulV2_78` | 3 | 123.703 |
| `MatMulV2_26` | 3 | 123.542 |
| `MatMulV2_18` | 3 | 123.383 |
| `MatMulV2_82` | 3 | 123.303 |
| `MatMulV2_46` | 3 | 123.282 |
| `MatMulV2_34` | 3 | 123.263 |
| `MatMulV2_58` | 3 | 123.083 |
| `MatMulV2_62` | 3 | 123.081 |
| `MatMulV2_30` | 3 | 123.023 |
| `MatMulV2_110` | 3 | 123.022 |
| `MatMulV2_70` | 3 | 122.983 |
| `MatMulV2_90` | 3 | 122.841 |
| `MatMulV2_86` | 3 | 122.742 |
| `MatMulV2_42` | 3 | 122.680 |
| `MatMulV2_126` | 3 | 122.642 |
| `MatMulV2_102` | 3 | 122.581 |
| `MatMulV2_10` | 3 | 122.502 |
| `MatMulV2_54` | 3 | 122.483 |
| `MatMulV2_50` | 3 | 122.443 |
| `MatMulV2_98` | 3 | 121.981 |
| `MatMulV2_118` | 3 | 121.942 |
| `MatMulV2_114` | 3 | 121.923 |
| `MatMulV2_22` | 3 | 121.903 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4387.307 |
| `MatMulV2 | "768,1280;5120,1280;5120" -> "768,5120" | ND;ND;ND -> ND` | 96 | 3933.133 |
| `MatMulV2 | "768,1280;3840,1280;3840" -> "768,3840" | ND;ND;ND -> ND` | 96 | 3263.021 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 1898.842 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_24` | 1 | 101.062 |
| `PromptFlashAttention_24` | 1 | 98.082 |
| `PromptFlashAttention_24` | 1 | 97.362 |
| `PromptFlashAttention_10` | 1 | 95.962 |
| `PromptFlashAttention_4` | 1 | 95.442 |
| `PromptFlashAttention` | 1 | 95.142 |
| `PromptFlashAttention_23` | 1 | 93.222 |
| `PromptFlashAttention_28` | 1 | 93.162 |
| `PromptFlashAttention_10` | 1 | 92.862 |
| `PromptFlashAttention_19` | 1 | 92.602 |
| `PromptFlashAttention_13` | 1 | 92.042 |
| `PromptFlashAttention_11` | 1 | 91.842 |
| `PromptFlashAttention_10` | 1 | 91.302 |
| `PromptFlashAttention_9` | 1 | 90.962 |
| `PromptFlashAttention_12` | 1 | 90.561 |
| `PromptFlashAttention_11` | 1 | 90.302 |
| `PromptFlashAttention_22` | 1 | 90.162 |
| `PromptFlashAttention_12` | 1 | 90.141 |
| `PromptFlashAttention_25` | 1 | 89.882 |
| `PromptFlashAttention_4` | 1 | 89.842 |
| `PromptFlashAttention_23` | 1 | 89.842 |
| `PromptFlashAttention_25` | 1 | 89.702 |
| `PromptFlashAttention_12` | 1 | 89.482 |
| `PromptFlashAttention_31` | 1 | 89.422 |
| `PromptFlashAttention_4` | 1 | 89.362 |
| `PromptFlashAttention_25` | 1 | 89.222 |
| `PromptFlashAttention_20` | 1 | 89.201 |
| `PromptFlashAttention_9` | 1 | 89.002 |
| `PromptFlashAttention_31` | 1 | 88.942 |
| `PromptFlashAttention_31` | 1 | 88.902 |
| `PromptFlashAttention_20` | 1 | 88.682 |
| `PromptFlashAttention_13` | 1 | 88.621 |
| `PromptFlashAttention_20` | 1 | 88.582 |
| `PromptFlashAttention_5` | 1 | 88.522 |
| `PromptFlashAttention_28` | 1 | 88.282 |
| `PromptFlashAttention_13` | 1 | 88.141 |
| `PromptFlashAttention` | 1 | 87.822 |
| `PromptFlashAttention_21` | 1 | 87.721 |
| `PromptFlashAttention_9` | 1 | 87.322 |
| `PromptFlashAttention_5` | 1 | 87.162 |
| `PromptFlashAttention_22` | 1 | 87.142 |
| `PromptFlashAttention_23` | 1 | 86.942 |
| `PromptFlashAttention_22` | 1 | 86.902 |
| `PromptFlashAttention_18` | 1 | 86.562 |
| `PromptFlashAttention_5` | 1 | 86.542 |
| `PromptFlashAttention` | 1 | 86.481 |
| `PromptFlashAttention_6` | 1 | 86.342 |
| `PromptFlashAttention_28` | 1 | 86.202 |
| `PromptFlashAttention_7` | 1 | 86.162 |
| `PromptFlashAttention_21` | 1 | 85.862 |
| `PromptFlashAttention_19` | 1 | 85.782 |
| `PromptFlashAttention_6` | 1 | 85.742 |
| `PromptFlashAttention_19` | 1 | 85.682 |
| `PromptFlashAttention_6` | 1 | 85.641 |
| `PromptFlashAttention_30` | 1 | 85.202 |
| `PromptFlashAttention_27` | 1 | 84.522 |
| `PromptFlashAttention_18` | 1 | 84.522 |
| `PromptFlashAttention_11` | 1 | 84.342 |
| `PromptFlashAttention_29` | 1 | 84.122 |
| `PromptFlashAttention_18` | 1 | 83.981 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 19539.231 |
| `TorchDynamo Cache Lookup` | 3 | 18661.621 |
| `Torch-Compiled Region: 0/0` | 3 | 1428.590 |
| `TorchNpuGraphBase::Run` | 3 | 771.510 |
| `ExecuteGraph` | 3 | 292.660 |
| `RefreshAtTensorFromGeTensor` | 3 | 165.930 |
| `AssembleInputs` | 3 | 135.960 |
| `aten::empty` | 3 | 78.320 |
| `AssembleOutputs` | 3 | 45.410 |
| `empty_tensor` | 3 | 44.730 |
| `aten::set_` | 3 | 40.190 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 291930.990 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 56137.570 |
| `launch` | 1442 | 25318.690 |
| `InputCopy` | 3 | 155.780 |
| `ModelExecute` | 3 | 85.580 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 39.350 |
| `step_info` | 6 | 37.940 |
| `OutputCopy` | 3 | 1.620 |

