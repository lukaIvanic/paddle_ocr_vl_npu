# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/padding_matrix/pfa_d128_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_mineru_kv_probe/tmp/11_mineru_2_5_pro_inference/vision_crop_contracts_910B_20261007T115828Z_82575a91/padding_matrix/pfa_d128_crop_1_bucket_3072/profile/liteserver-c001-4_94091_20261007121518208_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `51349.418 us`
- `Free`: `1003.828 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `902.250 us`
- `Stage`: `52353.500 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50411.329 |
| `MatMulV3` | 288 | 34652.632 |
| `StridedSliceD` | 480 | 14917.411 |
| `PadV3` | 288 | 7462.300 |
| `Mul` | 576 | 7238.259 |
| `MatMulV2` | 96 | 6342.488 |
| `AutomaticBufferFusionOp` | 480 | 6158.706 |
| `Add` | 384 | 4968.410 |
| `ReduceMeanD` | 384 | 4795.620 |
| `Transpose` | 288 | 3907.120 |
| `Sub` | 192 | 3184.505 |
| `ConcatV2D` | 192 | 2383.125 |
| `Cast` | 195 | 2345.910 |
| `Unpack` | 96 | 2062.281 |
| `Neg` | 192 | 1879.838 |
| `ConfusionTransposeD` | 96 | 957.021 |
| `te_memset_a8b1f5b1b0c44beef84d40753f2a30539fad1ae9efba5fbd957512e0b764e7d9__kernel0` | 288 | 278.805 |
| `Data` | 1 | 5.220 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_20` | 3 | 1615.792 |
| `PromptFlashAttention_13` | 3 | 1614.013 |
| `PromptFlashAttention_11` | 3 | 1612.333 |
| `PromptFlashAttention_24` | 3 | 1604.433 |
| `PromptFlashAttention_5` | 3 | 1603.453 |
| `PromptFlashAttention_22` | 3 | 1590.652 |
| `PromptFlashAttention_23` | 3 | 1588.652 |
| `PromptFlashAttention_31` | 3 | 1586.951 |
| `PromptFlashAttention_21` | 3 | 1582.732 |
| `PromptFlashAttention_10` | 3 | 1582.592 |
| `PromptFlashAttention_26` | 3 | 1582.071 |
| `PromptFlashAttention_18` | 3 | 1580.331 |
| `PromptFlashAttention_30` | 3 | 1579.712 |
| `PromptFlashAttention_29` | 3 | 1577.552 |
| `PromptFlashAttention_15` | 3 | 1575.993 |
| `PromptFlashAttention_4` | 3 | 1575.392 |
| `PromptFlashAttention` | 3 | 1571.951 |
| `PromptFlashAttention_9` | 3 | 1571.251 |
| `PromptFlashAttention_7` | 3 | 1569.011 |
| `PromptFlashAttention_2` | 3 | 1563.891 |
| `PromptFlashAttention_16` | 3 | 1562.671 |
| `PromptFlashAttention_14` | 3 | 1561.512 |
| `PromptFlashAttention_3` | 3 | 1560.191 |
| `PromptFlashAttention_1` | 3 | 1558.491 |
| `PromptFlashAttention_25` | 3 | 1558.331 |
| `PromptFlashAttention_6` | 3 | 1557.331 |
| `PromptFlashAttention_12` | 3 | 1556.271 |
| `PromptFlashAttention_17` | 3 | 1554.931 |
| `PromptFlashAttention_8` | 3 | 1554.430 |
| `PromptFlashAttention_27` | 3 | 1553.831 |
| `PromptFlashAttention_19` | 3 | 1552.990 |
| `PromptFlashAttention_28` | 3 | 1551.591 |
| `MatMulV2_122_to_v3` | 3 | 407.209 |
| `MatMulV2_6_to_v3` | 3 | 404.148 |
| `MatMulV2_126_to_v3` | 3 | 401.729 |
| `MatMulV2_78_to_v3` | 3 | 399.868 |
| `MatMulV2_2_to_v3` | 3 | 399.708 |
| `MatMulV2_10_to_v3` | 3 | 398.188 |
| `MatMulV2_90_to_v3` | 3 | 398.028 |
| `MatMulV2_86_to_v3` | 3 | 396.388 |
| `MatMulV2_106_to_v3` | 3 | 394.888 |
| `MatMulV2_98_to_v3` | 3 | 394.348 |
| `MatMulV2_70_to_v3` | 3 | 394.307 |
| `MatMulV2_14_to_v3` | 3 | 394.248 |
| `MatMulV2_26_to_v3` | 3 | 394.068 |
| `MatMulV2_58_to_v3` | 3 | 393.568 |
| `MatMulV2_30_to_v3` | 3 | 393.107 |
| `MatMulV2_46_to_v3` | 3 | 392.367 |
| `MatMulV2_114_to_v3` | 3 | 392.347 |
| `MatMulV2_3_to_v3` | 3 | 392.007 |
| `MatMulV2_82_to_v3` | 3 | 391.988 |
| `MatMulV2_94_to_v3` | 3 | 391.708 |
| `MatMulV2_50_to_v3` | 3 | 391.667 |
| `MatMulV2_38_to_v3` | 3 | 391.508 |
| `MatMulV2_54_to_v3` | 3 | 391.248 |
| `MatMulV2_62_to_v3` | 3 | 390.189 |
| `MatMulV2_18_to_v3` | 3 | 390.088 |
| `MatMulV2_55_to_v3` | 3 | 390.069 |
| `MatMulV2_83_to_v3` | 3 | 389.987 |
| `MatMulV2_118_to_v3` | 3 | 389.648 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_122_to_v3` | 3 | 407.209 |
| `MatMulV2_6_to_v3` | 3 | 404.148 |
| `MatMulV2_126_to_v3` | 3 | 401.729 |
| `MatMulV2_78_to_v3` | 3 | 399.868 |
| `MatMulV2_2_to_v3` | 3 | 399.708 |
| `MatMulV2_10_to_v3` | 3 | 398.188 |
| `MatMulV2_90_to_v3` | 3 | 398.028 |
| `MatMulV2_86_to_v3` | 3 | 396.388 |
| `MatMulV2_106_to_v3` | 3 | 394.888 |
| `MatMulV2_98_to_v3` | 3 | 394.348 |
| `MatMulV2_70_to_v3` | 3 | 394.307 |
| `MatMulV2_14_to_v3` | 3 | 394.248 |
| `MatMulV2_26_to_v3` | 3 | 394.068 |
| `MatMulV2_58_to_v3` | 3 | 393.568 |
| `MatMulV2_30_to_v3` | 3 | 393.107 |
| `MatMulV2_46_to_v3` | 3 | 392.367 |
| `MatMulV2_114_to_v3` | 3 | 392.347 |
| `MatMulV2_3_to_v3` | 3 | 392.007 |
| `MatMulV2_82_to_v3` | 3 | 391.988 |
| `MatMulV2_94_to_v3` | 3 | 391.708 |
| `MatMulV2_50_to_v3` | 3 | 391.667 |
| `MatMulV2_38_to_v3` | 3 | 391.508 |
| `MatMulV2_54_to_v3` | 3 | 391.248 |
| `MatMulV2_62_to_v3` | 3 | 390.189 |
| `MatMulV2_18_to_v3` | 3 | 390.088 |
| `MatMulV2_55_to_v3` | 3 | 390.069 |
| `MatMulV2_83_to_v3` | 3 | 389.987 |
| `MatMulV2_118_to_v3` | 3 | 389.648 |
| `MatMulV2_35_to_v3` | 3 | 389.448 |
| `MatMulV2_66_to_v3` | 3 | 389.369 |
| `MatMulV2_34_to_v3` | 3 | 389.287 |
| `MatMulV2_15_to_v3` | 3 | 389.048 |
| `MatMulV2_47_to_v3` | 3 | 388.689 |
| `MatMulV2_22_to_v3` | 3 | 388.669 |
| `MatMulV2_7_to_v3` | 3 | 388.207 |
| `MatMulV2_103_to_v3` | 3 | 388.088 |
| `MatMulV2_123_to_v3` | 3 | 388.028 |
| `MatMulV2_127_to_v3` | 3 | 387.868 |
| `MatMulV2_79_to_v3` | 3 | 387.648 |
| `MatMulV2_99_to_v3` | 3 | 387.508 |
| `MatMulV2_67_to_v3` | 3 | 387.246 |
| `MatMulV2_91_to_v3` | 3 | 387.187 |
| `MatMulV2_71_to_v3` | 3 | 387.108 |
| `MatMulV2_115_to_v3` | 3 | 387.068 |
| `MatMulV2_31_to_v3` | 3 | 386.948 |
| `MatMulV2_111_to_v3` | 3 | 386.808 |
| `MatMulV2_75_to_v3` | 3 | 386.548 |
| `MatMulV2_27_to_v3` | 3 | 386.547 |
| `MatMulV2_110_to_v3` | 3 | 386.527 |
| `MatMulV2_102_to_v3` | 3 | 386.408 |
| `MatMulV2_119_to_v3` | 3 | 386.367 |
| `MatMulV2_63_to_v3` | 3 | 386.287 |
| `MatMulV2_23_to_v3` | 3 | 386.247 |
| `MatMulV2_87_to_v3` | 3 | 386.047 |
| `MatMulV2_51_to_v3` | 3 | 385.948 |
| `MatMulV2_19_to_v3` | 3 | 385.867 |
| `MatMulV2_74_to_v3` | 3 | 385.767 |
| `MatMulV2_39_to_v3` | 3 | 385.728 |
| `MatMulV2_95_to_v3` | 3 | 385.388 |
| `MatMulV2_59_to_v3` | 3 | 384.748 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;5120,1280;5120" -> "3072,5120" | ND;ND;ND -> ND` | 96 | 12587.113 |
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12388.046 |
| `MatMulV3 | "3072,1280;3840,1280;3840" -> "3072,3840" | ND;ND;ND -> ND` | 96 | 9677.473 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6342.488 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_11` | 1 | 539.951 |
| `PromptFlashAttention_20` | 1 | 539.431 |
| `PromptFlashAttention_13` | 1 | 539.251 |
| `PromptFlashAttention_20` | 1 | 539.131 |
| `PromptFlashAttention_13` | 1 | 538.311 |
| `PromptFlashAttention_20` | 1 | 537.230 |
| `PromptFlashAttention_11` | 1 | 536.551 |
| `PromptFlashAttention_5` | 1 | 536.531 |
| `PromptFlashAttention_13` | 1 | 536.451 |
| `PromptFlashAttention_11` | 1 | 535.831 |
| `PromptFlashAttention_24` | 1 | 534.971 |
| `PromptFlashAttention_24` | 1 | 534.851 |
| `PromptFlashAttention_24` | 1 | 534.611 |
| `PromptFlashAttention_5` | 1 | 533.911 |
| `PromptFlashAttention_5` | 1 | 533.011 |
| `PromptFlashAttention_31` | 1 | 533.010 |
| `PromptFlashAttention_23` | 1 | 531.071 |
| `PromptFlashAttention_22` | 1 | 530.531 |
| `PromptFlashAttention_22` | 1 | 530.351 |
| `PromptFlashAttention` | 1 | 530.111 |
| `PromptFlashAttention_29` | 1 | 529.791 |
| `PromptFlashAttention_22` | 1 | 529.770 |
| `PromptFlashAttention_23` | 1 | 529.290 |
| `PromptFlashAttention_26` | 1 | 529.150 |
| `PromptFlashAttention_23` | 1 | 528.291 |
| `PromptFlashAttention_21` | 1 | 527.771 |
| `PromptFlashAttention_21` | 1 | 527.710 |
| `PromptFlashAttention_10` | 1 | 527.671 |
| `PromptFlashAttention_4` | 1 | 527.570 |
| `PromptFlashAttention_10` | 1 | 527.510 |
| `PromptFlashAttention_10` | 1 | 527.411 |
| `PromptFlashAttention_30` | 1 | 527.371 |
| `PromptFlashAttention_9` | 1 | 527.351 |
| `PromptFlashAttention_18` | 1 | 527.291 |
| `PromptFlashAttention_21` | 1 | 527.251 |
| `PromptFlashAttention_31` | 1 | 527.230 |
| `PromptFlashAttention_18` | 1 | 526.770 |
| `PromptFlashAttention_31` | 1 | 526.711 |
| `PromptFlashAttention_30` | 1 | 526.591 |
| `PromptFlashAttention_26` | 1 | 526.490 |
| `PromptFlashAttention_26` | 1 | 526.431 |
| `PromptFlashAttention_18` | 1 | 526.270 |
| `PromptFlashAttention_15` | 1 | 525.831 |
| `PromptFlashAttention_30` | 1 | 525.750 |
| `PromptFlashAttention_29` | 1 | 525.650 |
| `PromptFlashAttention_15` | 1 | 525.191 |
| `PromptFlashAttention_4` | 1 | 525.031 |
| `PromptFlashAttention_15` | 1 | 524.971 |
| `PromptFlashAttention_2` | 1 | 524.371 |
| `PromptFlashAttention_7` | 1 | 523.970 |
| `PromptFlashAttention_7` | 1 | 523.751 |
| `PromptFlashAttention_4` | 1 | 522.791 |
| `PromptFlashAttention_9` | 1 | 522.590 |
| `PromptFlashAttention_29` | 1 | 522.111 |
| `PromptFlashAttention_3` | 1 | 522.011 |
| `PromptFlashAttention` | 1 | 521.650 |
| `PromptFlashAttention_16` | 1 | 521.590 |
| `PromptFlashAttention_9` | 1 | 521.310 |
| `PromptFlashAttention_7` | 1 | 521.290 |
| `PromptFlashAttention_16` | 1 | 521.011 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 52289.664 |
| `TorchDynamo Cache Lookup` | 3 | 51352.194 |
| `Torch-Compiled Region: 0/0` | 3 | 1429.140 |
| `TorchNpuGraphBase::Run` | 3 | 801.350 |
| `ExecuteGraph` | 3 | 292.770 |
| `RefreshAtTensorFromGeTensor` | 3 | 180.330 |
| `AssembleInputs` | 3 | 139.100 |
| `aten::empty` | 3 | 85.150 |
| `empty_tensor` | 3 | 48.360 |
| `AssembleOutputs` | 3 | 47.790 |
| `aten::set_` | 3 | 42.200 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 294881.660 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 154323.930 |
| `launch` | 1442 | 25867.390 |
| `InputCopy` | 3 | 146.520 |
| `ModelExecute` | 3 | 89.990 |
| `step_info` | 6 | 40.810 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 39.380 |
| `OutputCopy` | 3 | 2.160 |

