#!/usr/bin/env bash
set -e
R="$1"; P="$2"
"$P" -u 11_mineru_2_5_pro_inference/probe_vision_matmul.py suite --internal-format on \
 --output-dir "$R/matmul_compiled_retry" --executions compiled --steps 30 --timeout-s 1800
"$P" -u 11_mineru_2_5_pro_inference/probe_vision_matmul.py suite --internal-format on \
 --output-dir "$R/matmul_eager_768_remaining" --ms 768 --projections proj,fc1,fc2 --executions eager --steps 30 --timeout-s 1800
"$P" -u 11_mineru_2_5_pro_inference/probe_vision_matmul.py suite --internal-format on \
 --output-dir "$R/matmul_eager_large_remaining" --ms 3072,5632 --executions eager --steps 30 --timeout-s 1800
printf '0\n' > "$R/matmul_complete_exit.txt"
