#!/bin/bash
source npu-setup
export ASCEND_RT_VISIBLE_DEVICES=1
export TORCH_DEVICE_BACKEND_AUTOLOAD=0
cd /workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry || exit 1
R=$(cat /tmp/mineru_vision_diagnostics_active_run.txt)
/usr/local/python3.12.13/bin/python3 -u 11_mineru_2_5_pro_inference/probe_vision_matmul.py suite --output-dir "$R/matmul_internal_off_validation" --internal-format off --ms 768 --projections qkv --executions eager,compiled --weight-formats nd,nz --steps 30 --timeout-s 1800
status=$?
echo "$status" > "$R/matmul_off_exit.txt"
exit "$status"
