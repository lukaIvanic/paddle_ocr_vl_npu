#!/usr/bin/env bash
set -e
R="$1"
P="$2"
"$P" -u 11_mineru_2_5_pro_inference/vision_diagnostic_runner.py --output-dir "$R/capture.receipt" --timeout-s 1800 -- \
 "$P" -u 11_mineru_2_5_pro_inference/bench_production_vision_attention.py capture-crops \
 --model /workspace/models/MinerU2.5-Pro-2605-1.2B --config-json "$R/validation_off_config.json" \
 --image crops/hotswap_001_code_txt_p0001_box_id_3.png --image crops/hotswap_002_code_txt_p1474_11.png \
 --cache-root "$R/vision_cache" --output-dir "$R/capture"
"$P" -u 11_mineru_2_5_pro_inference/run_production_attention_matrix.py \
 --capture-dir "$R/capture" --cache-root "$R/vision_cache" --output-dir "$R/vision_matrix" \
 --routes crop_0_bucket_768,crop_1_bucket_3072 \
 --variants baseline,internal_format_opposite,grouped_qkv,grouped_qkv_mlp_fc1 --steps 5 --profile --timeout-s 1800
printf '0\n' > "$R/vision_exit.txt"
