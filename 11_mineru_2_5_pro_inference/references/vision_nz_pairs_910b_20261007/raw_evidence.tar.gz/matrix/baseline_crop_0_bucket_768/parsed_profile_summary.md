# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/baseline_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/baseline_crop_0_bucket_768/profile/liteserver-c001-4_187175_20261007140811254_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `17418.154 us`
- `Free`: `681.788 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `665.000 us`
- `Stage`: `18100.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 13557.319 |
| `PromptFlashAttention` | 96 | 8020.364 |
| `StridedSliceD` | 384 | 5479.881 |
| `Mul` | 576 | 4481.632 |
| `Add` | 384 | 3375.650 |
| `Transpose` | 384 | 3269.040 |
| `AutomaticBufferFusionOp` | 480 | 3151.516 |
| `ReduceMeanD` | 384 | 2730.642 |
| `Sub` | 192 | 2019.280 |
| `Cast` | 195 | 1687.155 |
| `Neg` | 192 | 1658.637 |
| `ConcatV2D` | 192 | 1647.976 |
| `Unpack` | 96 | 849.582 |
| `Data` | 1 | 6.100 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_14` | 3 | 281.866 |
| `PromptFlashAttention` | 3 | 281.586 |
| `PromptFlashAttention_24` | 3 | 276.565 |
| `PromptFlashAttention_12` | 3 | 267.046 |
| `PromptFlashAttention_4` | 3 | 262.786 |
| `PromptFlashAttention_8` | 3 | 260.566 |
| `PromptFlashAttention_16` | 3 | 260.065 |
| `PromptFlashAttention_5` | 3 | 258.246 |
| `PromptFlashAttention_27` | 3 | 257.965 |
| `PromptFlashAttention_7` | 3 | 256.666 |
| `PromptFlashAttention_25` | 3 | 255.446 |
| `PromptFlashAttention_13` | 3 | 253.226 |
| `PromptFlashAttention_15` | 3 | 249.806 |
| `PromptFlashAttention_3` | 3 | 247.265 |
| `PromptFlashAttention_28` | 3 | 247.184 |
| `PromptFlashAttention_26` | 3 | 246.764 |
| `PromptFlashAttention_21` | 3 | 246.105 |
| `PromptFlashAttention_30` | 3 | 245.525 |
| `PromptFlashAttention_1` | 3 | 244.945 |
| `PromptFlashAttention_6` | 3 | 244.386 |
| `PromptFlashAttention_22` | 3 | 243.505 |
| `PromptFlashAttention_23` | 3 | 243.405 |
| `PromptFlashAttention_20` | 3 | 242.445 |
| `PromptFlashAttention_10` | 3 | 242.083 |
| `PromptFlashAttention_29` | 3 | 239.106 |
| `PromptFlashAttention_18` | 3 | 239.004 |
| `PromptFlashAttention_19` | 3 | 238.984 |
| `PromptFlashAttention_11` | 3 | 238.585 |
| `PromptFlashAttention_17` | 3 | 237.984 |
| `PromptFlashAttention_9` | 3 | 237.384 |
| `PromptFlashAttention_31` | 3 | 236.945 |
| `PromptFlashAttention_2` | 3 | 236.925 |
| `MatMulV2_95` | 3 | 148.403 |
| `MatMulV2_127` | 3 | 144.963 |
| `MatMulV2_55` | 3 | 142.123 |
| `MatMulV2_23` | 3 | 141.343 |
| `MatMulV2_15` | 3 | 140.823 |
| `MatMulV2_7` | 3 | 140.263 |
| `MatMulV2_11` | 3 | 140.263 |
| `MatMulV2_27` | 3 | 140.182 |
| `MatMulV2_123` | 3 | 139.781 |
| `MatMulV2_107` | 3 | 139.263 |
| `MatMulV2_115` | 3 | 139.163 |
| `MatMulV2_3` | 3 | 139.023 |
| `MatMulV2_119` | 3 | 138.963 |
| `MatMulV2_43` | 3 | 138.923 |
| `MatMulV2_79` | 3 | 138.903 |
| `MatMulV2_59` | 3 | 138.743 |
| `MatMulV2_75` | 3 | 138.743 |
| `MatMulV2_39` | 3 | 138.683 |
| `MatMulV2_87` | 3 | 138.663 |
| `MatMulV2_31` | 3 | 138.343 |
| `MatMulV2_99` | 3 | 138.282 |
| `MatMulV2_63` | 3 | 138.062 |
| `MatMulV2_103` | 3 | 137.903 |
| `MatMulV2_83` | 3 | 137.863 |
| `MatMulV2_19` | 3 | 137.823 |
| `MatMulV2_35` | 3 | 137.022 |
| `MatMulV2_51` | 3 | 136.903 |
| `MatMulV2_47` | 3 | 136.782 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_95` | 3 | 148.403 |
| `MatMulV2_127` | 3 | 144.963 |
| `MatMulV2_55` | 3 | 142.123 |
| `MatMulV2_23` | 3 | 141.343 |
| `MatMulV2_15` | 3 | 140.823 |
| `MatMulV2_7` | 3 | 140.263 |
| `MatMulV2_11` | 3 | 140.263 |
| `MatMulV2_27` | 3 | 140.182 |
| `MatMulV2_123` | 3 | 139.781 |
| `MatMulV2_107` | 3 | 139.263 |
| `MatMulV2_115` | 3 | 139.163 |
| `MatMulV2_3` | 3 | 139.023 |
| `MatMulV2_119` | 3 | 138.963 |
| `MatMulV2_43` | 3 | 138.923 |
| `MatMulV2_79` | 3 | 138.903 |
| `MatMulV2_59` | 3 | 138.743 |
| `MatMulV2_75` | 3 | 138.743 |
| `MatMulV2_39` | 3 | 138.683 |
| `MatMulV2_87` | 3 | 138.663 |
| `MatMulV2_31` | 3 | 138.343 |
| `MatMulV2_99` | 3 | 138.282 |
| `MatMulV2_63` | 3 | 138.062 |
| `MatMulV2_103` | 3 | 137.903 |
| `MatMulV2_83` | 3 | 137.863 |
| `MatMulV2_19` | 3 | 137.823 |
| `MatMulV2_35` | 3 | 137.022 |
| `MatMulV2_51` | 3 | 136.903 |
| `MatMulV2_47` | 3 | 136.782 |
| `MatMulV2_71` | 3 | 136.623 |
| `MatMulV2_111` | 3 | 135.803 |
| `MatMulV2_67` | 3 | 135.722 |
| `MatMulV2_91` | 3 | 135.143 |
| `MatMulV2_6` | 3 | 127.001 |
| `MatMulV2_54` | 3 | 125.662 |
| `MatMulV2_14` | 3 | 125.342 |
| `MatMulV2_30` | 3 | 125.261 |
| `MatMulV2_86` | 3 | 124.722 |
| `MatMulV2_2` | 3 | 124.522 |
| `MatMulV2_18` | 3 | 124.342 |
| `MatMulV2_118` | 3 | 124.241 |
| `MatMulV2_34` | 3 | 124.103 |
| `MatMulV2_78` | 3 | 124.083 |
| `MatMulV2_22` | 3 | 124.082 |
| `MatMulV2_62` | 3 | 123.983 |
| `MatMulV2_106` | 3 | 123.763 |
| `MatMulV2_82` | 3 | 123.703 |
| `MatMulV2_98` | 3 | 123.683 |
| `MatMulV2_58` | 3 | 123.682 |
| `MatMulV2_66` | 3 | 123.563 |
| `MatMulV2_74` | 3 | 123.562 |
| `MatMulV2_26` | 3 | 123.442 |
| `MatMulV2_10` | 3 | 123.422 |
| `MatMulV2_94` | 3 | 123.363 |
| `MatMulV2_114` | 3 | 123.203 |
| `MatMulV2_110` | 3 | 123.202 |
| `MatMulV2_46` | 3 | 123.162 |
| `MatMulV2_50` | 3 | 123.082 |
| `MatMulV2_38` | 3 | 123.003 |
| `MatMulV2_126` | 3 | 122.782 |
| `MatMulV2_42` | 3 | 122.663 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4449.488 |
| `MatMulV2 | "768,1280;5120,1280;5120" -> "768,5120" | ND;ND;ND -> ND` | 96 | 3959.753 |
| `MatMulV2 | "768,1280;3840,1280;3840" -> "768,3840" | ND;ND;ND -> ND` | 96 | 3253.821 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 1894.257 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 1 | 95.802 |
| `PromptFlashAttention_14` | 1 | 95.762 |
| `PromptFlashAttention` | 1 | 94.902 |
| `PromptFlashAttention_24` | 1 | 93.982 |
| `PromptFlashAttention_14` | 1 | 93.682 |
| `PromptFlashAttention_24` | 1 | 93.102 |
| `PromptFlashAttention_14` | 1 | 92.422 |
| `PromptFlashAttention_12` | 1 | 91.502 |
| `PromptFlashAttention` | 1 | 90.882 |
| `PromptFlashAttention_12` | 1 | 90.322 |
| `PromptFlashAttention_24` | 1 | 89.481 |
| `PromptFlashAttention_16` | 1 | 89.462 |
| `PromptFlashAttention_7` | 1 | 88.522 |
| `PromptFlashAttention_4` | 1 | 88.242 |
| `PromptFlashAttention_27` | 1 | 88.182 |
| `PromptFlashAttention_8` | 1 | 87.962 |
| `PromptFlashAttention_4` | 1 | 87.722 |
| `PromptFlashAttention_8` | 1 | 87.482 |
| `PromptFlashAttention_16` | 1 | 87.342 |
| `PromptFlashAttention_15` | 1 | 87.242 |
| `PromptFlashAttention_4` | 1 | 86.822 |
| `PromptFlashAttention_3` | 1 | 86.622 |
| `PromptFlashAttention_5` | 1 | 86.562 |
| `PromptFlashAttention_25` | 1 | 86.442 |
| `PromptFlashAttention_23` | 1 | 86.381 |
| `PromptFlashAttention_5` | 1 | 86.342 |
| `PromptFlashAttention_20` | 1 | 86.282 |
| `PromptFlashAttention_13` | 1 | 85.362 |
| `PromptFlashAttention_5` | 1 | 85.342 |
| `PromptFlashAttention_7` | 1 | 85.222 |
| `PromptFlashAttention_12` | 1 | 85.222 |
| `PromptFlashAttention_8` | 1 | 85.122 |
| `PromptFlashAttention_28` | 1 | 85.001 |
| `PromptFlashAttention_27` | 1 | 84.941 |
| `PromptFlashAttention_27` | 1 | 84.842 |
| `PromptFlashAttention_10` | 1 | 84.721 |
| `PromptFlashAttention_25` | 1 | 84.622 |
| `PromptFlashAttention_1` | 1 | 84.462 |
| `PromptFlashAttention_13` | 1 | 84.382 |
| `PromptFlashAttention_25` | 1 | 84.382 |
| `PromptFlashAttention_21` | 1 | 83.561 |
| `PromptFlashAttention_13` | 1 | 83.482 |
| `PromptFlashAttention_16` | 1 | 83.261 |
| `PromptFlashAttention_7` | 1 | 82.922 |
| `PromptFlashAttention_26` | 1 | 82.902 |
| `PromptFlashAttention_26` | 1 | 82.721 |
| `PromptFlashAttention_18` | 1 | 82.701 |
| `PromptFlashAttention_22` | 1 | 82.601 |
| `PromptFlashAttention_28` | 1 | 82.542 |
| `PromptFlashAttention_30` | 1 | 82.481 |
| `PromptFlashAttention_6` | 1 | 82.342 |
| `PromptFlashAttention_15` | 1 | 82.342 |
| `PromptFlashAttention_30` | 1 | 82.082 |
| `PromptFlashAttention_2` | 1 | 82.002 |
| `PromptFlashAttention_11` | 1 | 81.841 |
| `PromptFlashAttention_19` | 1 | 81.802 |
| `PromptFlashAttention_1` | 1 | 81.761 |
| `PromptFlashAttention_31` | 1 | 81.702 |
| `PromptFlashAttention_21` | 1 | 81.362 |
| `PromptFlashAttention_6` | 1 | 81.342 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 18287.178 |
| `TorchNpuGraphBase::Run` | 3 | 17851.548 |
| `AssembleInputs` | 3 | 17530.618 |
| `ExecuteGraph` | 3 | 302.790 |
| `RefreshAtTensorFromGeTensor` | 3 | 189.150 |
| `aten::empty` | 3 | 98.090 |
| `AssembleOutputs` | 3 | 60.390 |
| `empty_tensor` | 3 | 50.960 |
| `aten::set_` | 3 | 44.510 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 267551.810 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 51730.890 |
| `launch` | 1314 | 18267.020 |
| `InputCopy` | 3 | 145.090 |
| `ModelExecute` | 3 | 96.190 |
| `step_info` | 6 | 60.660 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 28.720 |
| `OutputCopy` | 3 | 2.030 |

