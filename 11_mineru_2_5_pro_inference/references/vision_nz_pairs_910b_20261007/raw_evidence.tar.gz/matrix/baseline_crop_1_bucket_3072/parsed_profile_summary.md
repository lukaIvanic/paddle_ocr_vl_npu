# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/baseline_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/baseline_crop_1_bucket_3072/profile/liteserver-c001-4_188271_20261007140910777_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `49500.457 us`
- `Free`: `1078.313 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `970.000 us`
- `Stage`: `50578.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50420.264 |
| `MatMulV3` | 288 | 34576.805 |
| `StridedSliceD` | 384 | 13638.118 |
| `Mul` | 576 | 8030.320 |
| `AutomaticBufferFusionOp` | 480 | 6414.703 |
| `MatMulV2` | 96 | 6368.831 |
| `Add` | 384 | 5473.729 |
| `Transpose` | 384 | 5386.292 |
| `ReduceMeanD` | 384 | 5079.304 |
| `Sub` | 192 | 3499.351 |
| `ConcatV2D` | 192 | 2741.331 |
| `Cast` | 195 | 2431.909 |
| `Neg` | 192 | 2157.904 |
| `Unpack` | 96 | 2084.764 |
| `Data` | 1 | 6.860 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_26` | 3 | 1614.012 |
| `PromptFlashAttention_13` | 3 | 1613.133 |
| `PromptFlashAttention_22` | 3 | 1607.012 |
| `PromptFlashAttention_7` | 3 | 1600.112 |
| `PromptFlashAttention` | 3 | 1596.672 |
| `PromptFlashAttention_25` | 3 | 1594.452 |
| `PromptFlashAttention_14` | 3 | 1589.331 |
| `PromptFlashAttention_12` | 3 | 1588.312 |
| `PromptFlashAttention_15` | 3 | 1588.291 |
| `PromptFlashAttention_8` | 3 | 1587.532 |
| `PromptFlashAttention_24` | 3 | 1585.732 |
| `PromptFlashAttention_23` | 3 | 1582.752 |
| `PromptFlashAttention_19` | 3 | 1576.431 |
| `PromptFlashAttention_5` | 3 | 1576.232 |
| `PromptFlashAttention_6` | 3 | 1575.392 |
| `PromptFlashAttention_2` | 3 | 1573.830 |
| `PromptFlashAttention_16` | 3 | 1571.851 |
| `PromptFlashAttention_29` | 3 | 1569.772 |
| `PromptFlashAttention_10` | 3 | 1567.930 |
| `PromptFlashAttention_30` | 3 | 1567.751 |
| `PromptFlashAttention_3` | 3 | 1564.870 |
| `PromptFlashAttention_21` | 3 | 1562.852 |
| `PromptFlashAttention_11` | 3 | 1562.411 |
| `PromptFlashAttention_1` | 3 | 1561.510 |
| `PromptFlashAttention_31` | 3 | 1560.572 |
| `PromptFlashAttention_28` | 3 | 1558.711 |
| `PromptFlashAttention_20` | 3 | 1555.811 |
| `PromptFlashAttention_27` | 3 | 1555.011 |
| `PromptFlashAttention_4` | 3 | 1554.711 |
| `PromptFlashAttention_17` | 3 | 1553.711 |
| `PromptFlashAttention_18` | 3 | 1553.291 |
| `PromptFlashAttention_9` | 3 | 1550.271 |
| `MatMulV2_10_to_v3` | 3 | 405.467 |
| `MatMulV2_2_to_v3` | 3 | 402.448 |
| `MatMulV2_6_to_v3` | 3 | 397.848 |
| `MatMulV2_118_to_v3` | 3 | 395.848 |
| `MatMulV2_26_to_v3` | 3 | 395.028 |
| `MatMulV2_102_to_v3` | 3 | 393.768 |
| `MatMulV2_74_to_v3` | 3 | 393.348 |
| `MatMulV2_86_to_v3` | 3 | 392.588 |
| `MatMulV2_106_to_v3` | 3 | 392.587 |
| `MatMulV2_7_to_v3` | 3 | 392.428 |
| `MatMulV2_98_to_v3` | 3 | 392.388 |
| `MatMulV2_38_to_v3` | 3 | 392.168 |
| `MatMulV2_58_to_v3` | 3 | 391.947 |
| `MatMulV2_62_to_v3` | 3 | 391.627 |
| `MatMulV2_46_to_v3` | 3 | 391.589 |
| `MatMulV2_126_to_v3` | 3 | 391.407 |
| `MatMulV2_90_to_v3` | 3 | 390.788 |
| `MatMulV2_70_to_v3` | 3 | 390.688 |
| `MatMulV2_54_to_v3` | 3 | 390.348 |
| `MatMulV2_66_to_v3` | 3 | 390.269 |
| `MatMulV2_103_to_v3` | 3 | 389.987 |
| `MatMulV2_22_to_v3` | 3 | 389.768 |
| `MatMulV2_11_to_v3` | 3 | 389.749 |
| `MatMulV2_79_to_v3` | 3 | 389.748 |
| `MatMulV2_123_to_v3` | 3 | 389.708 |
| `MatMulV2_67_to_v3` | 3 | 389.667 |
| `MatMulV2_43_to_v3` | 3 | 389.448 |
| `MatMulV2_19_to_v3` | 3 | 389.407 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_10_to_v3` | 3 | 405.467 |
| `MatMulV2_2_to_v3` | 3 | 402.448 |
| `MatMulV2_6_to_v3` | 3 | 397.848 |
| `MatMulV2_118_to_v3` | 3 | 395.848 |
| `MatMulV2_26_to_v3` | 3 | 395.028 |
| `MatMulV2_102_to_v3` | 3 | 393.768 |
| `MatMulV2_74_to_v3` | 3 | 393.348 |
| `MatMulV2_86_to_v3` | 3 | 392.588 |
| `MatMulV2_106_to_v3` | 3 | 392.587 |
| `MatMulV2_7_to_v3` | 3 | 392.428 |
| `MatMulV2_98_to_v3` | 3 | 392.388 |
| `MatMulV2_38_to_v3` | 3 | 392.168 |
| `MatMulV2_58_to_v3` | 3 | 391.947 |
| `MatMulV2_62_to_v3` | 3 | 391.627 |
| `MatMulV2_46_to_v3` | 3 | 391.589 |
| `MatMulV2_126_to_v3` | 3 | 391.407 |
| `MatMulV2_90_to_v3` | 3 | 390.788 |
| `MatMulV2_70_to_v3` | 3 | 390.688 |
| `MatMulV2_54_to_v3` | 3 | 390.348 |
| `MatMulV2_66_to_v3` | 3 | 390.269 |
| `MatMulV2_103_to_v3` | 3 | 389.987 |
| `MatMulV2_22_to_v3` | 3 | 389.768 |
| `MatMulV2_11_to_v3` | 3 | 389.749 |
| `MatMulV2_79_to_v3` | 3 | 389.748 |
| `MatMulV2_123_to_v3` | 3 | 389.708 |
| `MatMulV2_67_to_v3` | 3 | 389.667 |
| `MatMulV2_43_to_v3` | 3 | 389.448 |
| `MatMulV2_19_to_v3` | 3 | 389.407 |
| `MatMulV2_110_to_v3` | 3 | 389.367 |
| `MatMulV2_3_to_v3` | 3 | 389.108 |
| `MatMulV2_115_to_v3` | 3 | 389.088 |
| `MatMulV2_107_to_v3` | 3 | 388.928 |
| `MatMulV2_51_to_v3` | 3 | 388.927 |
| `MatMulV2_78_to_v3` | 3 | 388.888 |
| `MatMulV2_71_to_v3` | 3 | 388.687 |
| `MatMulV2_27_to_v3` | 3 | 388.587 |
| `MatMulV2_59_to_v3` | 3 | 388.428 |
| `MatMulV2_31_to_v3` | 3 | 388.247 |
| `MatMulV2_30_to_v3` | 3 | 387.908 |
| `MatMulV2_55_to_v3` | 3 | 387.867 |
| `MatMulV2_14_to_v3` | 3 | 387.787 |
| `MatMulV2_99_to_v3` | 3 | 387.747 |
| `MatMulV2_63_to_v3` | 3 | 387.708 |
| `MatMulV2_87_to_v3` | 3 | 387.708 |
| `MatMulV2_82_to_v3` | 3 | 387.669 |
| `MatMulV2_127_to_v3` | 3 | 387.527 |
| `MatMulV2_94_to_v3` | 3 | 387.128 |
| `MatMulV2_42_to_v3` | 3 | 387.047 |
| `MatMulV2_91_to_v3` | 3 | 386.867 |
| `MatMulV2_23_to_v3` | 3 | 386.587 |
| `MatMulV2_35_to_v3` | 3 | 386.447 |
| `MatMulV2_95_to_v3` | 3 | 386.387 |
| `MatMulV2_39_to_v3` | 3 | 386.368 |
| `MatMulV2_50_to_v3` | 3 | 386.129 |
| `MatMulV2_47_to_v3` | 3 | 386.086 |
| `MatMulV2_18_to_v3` | 3 | 386.029 |
| `MatMulV2_114_to_v3` | 3 | 386.028 |
| `MatMulV2_111_to_v3` | 3 | 385.768 |
| `MatMulV2_83_to_v3` | 3 | 385.687 |
| `MatMulV2_34_to_v3` | 3 | 385.608 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;5120,1280;5120" -> "3072,5120" | ND;ND;ND -> ND` | 96 | 12516.453 |
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12414.159 |
| `MatMulV3 | "3072,1280;3840,1280;3840" -> "3072,3840" | ND;ND;ND -> ND` | 96 | 9646.193 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6368.831 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_26` | 1 | 540.091 |
| `PromptFlashAttention_13` | 1 | 537.931 |
| `PromptFlashAttention_26` | 1 | 537.890 |
| `PromptFlashAttention_13` | 1 | 537.851 |
| `PromptFlashAttention_13` | 1 | 537.351 |
| `PromptFlashAttention_22` | 1 | 536.650 |
| `PromptFlashAttention_26` | 1 | 536.031 |
| `PromptFlashAttention_22` | 1 | 535.651 |
| `PromptFlashAttention_22` | 1 | 534.711 |
| `PromptFlashAttention_7` | 1 | 534.271 |
| `PromptFlashAttention_7` | 1 | 533.891 |
| `PromptFlashAttention_25` | 1 | 533.531 |
| `PromptFlashAttention` | 1 | 533.271 |
| `PromptFlashAttention` | 1 | 532.570 |
| `PromptFlashAttention_25` | 1 | 532.151 |
| `PromptFlashAttention_7` | 1 | 531.950 |
| `PromptFlashAttention` | 1 | 530.831 |
| `PromptFlashAttention_14` | 1 | 530.590 |
| `PromptFlashAttention_12` | 1 | 530.291 |
| `PromptFlashAttention_15` | 1 | 530.210 |
| `PromptFlashAttention_12` | 1 | 529.931 |
| `PromptFlashAttention_8` | 1 | 529.810 |
| `PromptFlashAttention_14` | 1 | 529.770 |
| `PromptFlashAttention_15` | 1 | 529.710 |
| `PromptFlashAttention_24` | 1 | 529.411 |
| `PromptFlashAttention_8` | 1 | 529.031 |
| `PromptFlashAttention_14` | 1 | 528.971 |
| `PromptFlashAttention_2` | 1 | 528.890 |
| `PromptFlashAttention_23` | 1 | 528.790 |
| `PromptFlashAttention_25` | 1 | 528.770 |
| `PromptFlashAttention_8` | 1 | 528.691 |
| `PromptFlashAttention_24` | 1 | 528.550 |
| `PromptFlashAttention_19` | 1 | 528.471 |
| `PromptFlashAttention_15` | 1 | 528.371 |
| `PromptFlashAttention_12` | 1 | 528.090 |
| `PromptFlashAttention_23` | 1 | 528.031 |
| `PromptFlashAttention_5` | 1 | 527.931 |
| `PromptFlashAttention_24` | 1 | 527.771 |
| `PromptFlashAttention_16` | 1 | 526.710 |
| `PromptFlashAttention_5` | 1 | 526.331 |
| `PromptFlashAttention_23` | 1 | 525.931 |
| `PromptFlashAttention_6` | 1 | 525.591 |
| `PromptFlashAttention_6` | 1 | 525.251 |
| `PromptFlashAttention_19` | 1 | 524.750 |
| `PromptFlashAttention_6` | 1 | 524.550 |
| `PromptFlashAttention_10` | 1 | 523.810 |
| `PromptFlashAttention_29` | 1 | 523.791 |
| `PromptFlashAttention_2` | 1 | 523.590 |
| `PromptFlashAttention_30` | 1 | 523.390 |
| `PromptFlashAttention_29` | 1 | 523.311 |
| `PromptFlashAttention_19` | 1 | 523.210 |
| `PromptFlashAttention_16` | 1 | 523.171 |
| `PromptFlashAttention_29` | 1 | 522.670 |
| `PromptFlashAttention_10` | 1 | 522.310 |
| `PromptFlashAttention_30` | 1 | 522.310 |
| `PromptFlashAttention_3` | 1 | 522.130 |
| `PromptFlashAttention_30` | 1 | 522.051 |
| `PromptFlashAttention_5` | 1 | 521.970 |
| `PromptFlashAttention_16` | 1 | 521.970 |
| `PromptFlashAttention_10` | 1 | 521.810 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 50980.859 |
| `TorchNpuGraphBase::Run` | 3 | 50302.499 |
| `AssembleInputs` | 3 | 49641.859 |
| `ExecuteGraph` | 3 | 469.960 |
| `RefreshAtTensorFromGeTensor` | 3 | 321.820 |
| `aten::empty` | 3 | 174.400 |
| `AssembleOutputs` | 3 | 107.350 |
| `empty_tensor` | 3 | 87.870 |
| `aten::set_` | 3 | 71.540 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 267192.520 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 147684.100 |
| `launch` | 1314 | 18103.190 |
| `InputCopy` | 3 | 201.100 |
| `ModelExecute` | 3 | 130.830 |
| `step_info` | 6 | 70.670 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 26.810 |
| `OutputCopy` | 3 | 3.410 |

