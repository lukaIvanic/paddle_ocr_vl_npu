# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/eager_pfa_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/eager_pfa_crop_0_bucket_768/profile/liteserver-c001-4_211377_20261007143311355_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `75780.553 us`
- `Free`: `152154.421 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `644.250 us`
- `Stage`: `227935.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 14177.304 |
| `Mul` | 960 | 11440.564 |
| `PromptFlashAttention` | 96 | 8516.769 |
| `Transpose` | 384 | 8125.217 |
| `ReduceMean` | 384 | 6108.754 |
| `Slice` | 672 | 5890.188 |
| `Add` | 768 | 5514.957 |
| `Cast` | 768 | 4999.445 |
| `Sub` | 192 | 3444.207 |
| `Pows` | 192 | 3123.165 |
| `ConcatD` | 192 | 1837.198 |
| `Sigmoid` | 96 | 1286.897 |
| `Neg` | 192 | 1070.379 |
| `Rsqrt` | 192 | 246.903 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulCommon_MatMulV2` | 384 | 14177.304 |
| `aclnnMul_MulAiCore_Mul` | 864 | 10500.667 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 96 | 8516.769 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 384 | 8125.217 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 6108.754 |
| `aclnnAdd_AddAiCore_Add` | 576 | 5238.951 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 4999.445 |
| `aclnnSub_SubAiCore_Sub` | 192 | 3444.207 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3123.165 |
| `aclnnNeg_SliceAiCore_Slice` | 192 | 2271.631 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 2243.829 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 1837.198 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 288 | 1374.728 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 1286.897 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1070.379 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 939.897 |
| `aclnnAdds_AddAiCore_Add` | 192 | 276.006 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 246.903 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulCommon_MatMulV2` | 384 | 14177.304 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4680.276 |
| `MatMulV2 | "768,1280;5120,1280;5120" -> "768,5120" | ND;ND;ND -> ND` | 96 | 4207.980 |
| `MatMulV2 | "768,1280;3840,1280;3840" -> "768,3840" | ND;ND;ND -> ND` | 96 | 3266.546 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 2022.502 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 104.162 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 103.302 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 101.502 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 101.502 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 100.122 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 98.982 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 98.382 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 97.762 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 97.202 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 97.162 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 96.002 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 95.922 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 95.782 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 95.362 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 95.142 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.522 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 94.401 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.542 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.462 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.182 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.042 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.541 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.422 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.262 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.941 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.681 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.561 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.402 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.341 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.262 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.042 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.882 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.562 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.442 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.382 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.062 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 89.862 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 89.562 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 89.482 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.842 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.842 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.602 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.602 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.561 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.542 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.462 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.441 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.421 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.241 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.102 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.902 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.841 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.822 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.801 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.521 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.502 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.422 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 86.862 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 86.802 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 86.562 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `aten::to` | 1056 | 26228.060 |
| `npu::npu_prompt_flash_attention` | 96 | 25436.420 |
| `aten::_to_copy` | 768 | 23153.800 |
| `empty_tensor` | 4896 | 22083.570 |
| `aten::copy_` | 1152 | 21489.371 |
| `aten::mul` | 960 | 19427.881 |
| `aten::linear` | 384 | 18757.857 |
| `aten::add` | 768 | 16946.480 |
| `aten::addmm` | 384 | 14820.532 |
| `aclnnInplaceCopy` | 1152 | 14749.837 |
| `aclnnAddmm` | 384 | 14177.303 |
| `aten::contiguous` | 384 | 12181.741 |
| `aten::clone` | 384 | 11097.232 |
| `aclnnMul` | 864 | 10508.878 |
| `aten::mean` | 384 | 9106.390 |
| `aclnnPromptFlashAttentionV3` | 96 | 8516.770 |
| `aten::transpose` | 768 | 6506.140 |
| `aten::as_strided` | 1632 | 6466.830 |
| `aclnnMean` | 384 | 6108.762 |
| `aten::empty` | 768 | 5992.430 |
| `aclnnAdd` | 576 | 5300.179 |
| `aten::square` | 192 | 5210.080 |
| `aten::cat` | 192 | 4764.492 |
| `aten::pow` | 192 | 4633.540 |
| `aten::neg` | 192 | 4344.481 |
| `aclnnCat` | 192 | 4081.022 |
| `aten::sub` | 192 | 4065.620 |
| `aten::view` | 960 | 3486.850 |
| `aclnnSub` | 192 | 3444.209 |
| `aclnnNeg` | 192 | 3342.007 |
| `aten::t` | 384 | 3227.590 |
| `aten::rsqrt` | 192 | 3139.460 |
| `aclnnPowTensorScalar` | 192 | 3123.162 |
| `aten::slice` | 384 | 2857.790 |
| `aten::unbind` | 96 | 2694.210 |
| `aten::select` | 288 | 2213.490 |
| `aten::sigmoid` | 96 | 1685.740 |
| `aten::unsqueeze` | 192 | 1398.400 |
| `aclnnSigmoid` | 96 | 1286.886 |
| `aclnnAdds` | 192 | 1081.290 |
| `aclnnRsqrt` | 192 | 984.010 |
| `aten::item` | 288 | 981.350 |
| `aclnnMuls` | 96 | 939.899 |
| `aten::_local_scalar_dense` | 288 | 410.070 |
| `aten::result_type` | 192 | 346.240 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 5472 | 30936.780 |
| `aclrtLaunchKernelWithHostArgs` | 5472 | 24686.250 |
| `InnerPromptFlashAttentionGetWorkspaceSize` | 96 | 18769.060 |
| `PromptFlashAttention_Tiling` | 192 | 13491.860 |
| `aclnnInplaceCopy` | 1152 | 11108.380 |
| `aclnnMul` | 864 | 6928.490 |
| `InnerPromptFlashAttention` | 96 | 4743.800 |
| `aclnnAdd` | 576 | 4548.780 |
| `aclnnMean` | 384 | 4058.300 |
| `aclnnAddmm` | 384 | 3255.620 |
| `aclnnCat` | 192 | 2453.360 |
| `aclnnNeg` | 192 | 2409.300 |
| `aclrtGetStreamAttribute` | 4800 | 1897.550 |
| `aclnnAdds` | 192 | 1626.830 |
| `aclnnSub` | 192 | 1592.290 |
| `aclnnRsqrt` | 192 | 1536.530 |
| `aclnnPowTensorScalar` | 192 | 1516.040 |
| `aclnnSigmoid` | 96 | 832.190 |
| `aclnnMuls` | 96 | 802.670 |
| `aclrtGetHardwareSyncAddr` | 480 | 323.970 |
| `aclrtGetResInCurrentThread` | 192 | 124.120 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 63.720 |

