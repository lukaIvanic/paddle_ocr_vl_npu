# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/eager_pfa_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/eager_pfa_crop_1_bucket_3072/profile/liteserver-c001-4_212083_20261007143405384_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `174822.892 us`
- `Free`: `47315.127 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `628.500 us`
- `Stage`: `222137.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50155.363 |
| `MatMulV3` | 288 | 36696.024 |
| `Mul` | 960 | 19362.615 |
| `Transpose` | 384 | 9939.616 |
| `ReduceMean` | 384 | 9390.661 |
| `Add` | 768 | 9015.528 |
| `Cast` | 768 | 7643.745 |
| `Slice` | 480 | 7017.428 |
| `MatMulV2` | 96 | 6612.211 |
| `Sub` | 192 | 4829.692 |
| `Pows` | 192 | 3612.340 |
| `Sigmoid` | 96 | 3266.448 |
| `ConcatD` | 192 | 2969.107 |
| `SliceV2` | 192 | 2257.249 |
| `Neg` | 192 | 1720.829 |
| `Rsqrt` | 192 | 335.871 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 96 | 50155.363 |
| `aclnnAddmm_MatMulV3Common_MatMulV3` | 288 | 36696.024 |
| `aclnnMul_MulAiCore_Mul` | 864 | 17328.352 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 384 | 9939.616 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 9390.661 |
| `aclnnAdd_AddAiCore_Add` | 576 | 8681.138 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 7643.745 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 96 | 6612.211 |
| `aclnnSub_SubAiCore_Sub` | 192 | 4829.692 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 3985.014 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3612.340 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 3266.448 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 288 | 3032.414 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 2969.107 |
| `aclnnNeg_SliceV2AiCore_SliceV2` | 192 | 2257.249 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 2034.263 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1720.829 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 335.871 |
| `aclnnAdds_AddAiCore_Add` | 192 | 334.390 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulV3Common_MatMulV3` | 288 | 36696.024 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 96 | 6612.211 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;5120,1280;5120" -> "3072,5120" | ND;ND;ND -> ND` | 96 | 13900.754 |
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12791.511 |
| `MatMulV3 | "3072,1280;3840,1280;3840" -> "3072,3840" | ND;ND;ND -> ND` | 96 | 10003.759 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6612.211 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 532.650 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 532.351 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 531.711 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.850 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.390 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.950 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.050 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.190 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.031 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.811 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.590 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.351 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.150 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.851 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.590 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.491 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.490 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.251 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.131 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.110 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.091 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.071 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.490 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.331 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.331 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.151 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.151 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.030 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.670 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.431 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.350 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.210 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.130 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.971 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.970 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.931 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.890 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.790 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.790 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.650 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.531 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.530 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.451 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.450 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.391 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.370 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.270 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.190 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.150 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.091 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.931 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.871 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.791 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.671 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.671 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.491 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.270 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.171 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.150 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 521.090 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `npu::npu_prompt_flash_attention` | 96 | 50188.832 |
| `aclnnPromptFlashAttentionV3` | 96 | 50155.362 |
| `aten::linear` | 384 | 43308.245 |
| `aten::addmm` | 384 | 43308.245 |
| `aclnnAddmm` | 384 | 43308.245 |
| `aten::to` | 1056 | 25012.110 |
| `aten::copy_` | 1152 | 23437.077 |
| `aten::_to_copy` | 768 | 22145.280 |
| `empty_tensor` | 4896 | 21328.940 |
| `aten::mul` | 960 | 21133.461 |
| `aclnnInplaceCopy` | 1152 | 20630.880 |
| `aclnnMul` | 864 | 17332.376 |
| `aten::add` | 768 | 16362.083 |
| `aten::contiguous` | 384 | 12802.005 |
| `aten::clone` | 384 | 12112.687 |
| `aten::mean` | 384 | 9467.638 |
| `aclnnMean` | 384 | 9390.667 |
| `aclnnAdd` | 576 | 8681.134 |
| `aten::cat` | 192 | 6955.808 |
| `aclnnCat` | 192 | 6954.119 |
| `aten::transpose` | 768 | 6168.660 |
| `aten::as_strided` | 1632 | 6138.620 |
| `aten::empty` | 768 | 5674.370 |
| `aten::square` | 192 | 4982.240 |
| `aten::sub` | 192 | 4840.345 |
| `aclnnSub` | 192 | 4829.676 |
| `aten::pow` | 192 | 4449.621 |
| `aten::neg` | 192 | 4329.429 |
| `aclnnNeg` | 192 | 3978.080 |
| `aclnnPowTensorScalar` | 192 | 3612.352 |
| `aten::view` | 960 | 3348.280 |
| `aten::sigmoid` | 96 | 3266.445 |
| `aclnnSigmoid` | 96 | 3266.445 |
| `aten::t` | 384 | 3067.010 |
| `aten::rsqrt` | 192 | 3033.880 |
| `aten::slice` | 384 | 2655.260 |
| `aten::unbind` | 96 | 2577.460 |
| `aten::select` | 288 | 2113.350 |
| `aclnnMuls` | 96 | 2034.261 |
| `aten::unsqueeze` | 192 | 1328.590 |
| `aclnnAdds` | 192 | 994.410 |
| `aten::item` | 288 | 947.070 |
| `aclnnRsqrt` | 192 | 927.230 |
| `aten::_local_scalar_dense` | 288 | 409.950 |
| `aten::result_type` | 192 | 331.370 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 5472 | 31701.880 |
| `aclrtLaunchKernelWithHostArgs` | 5472 | 25189.520 |
| `InnerPromptFlashAttentionGetWorkspaceSize` | 96 | 18747.940 |
| `PromptFlashAttention_Tiling` | 192 | 13524.920 |
| `aclnnInplaceCopy` | 1152 | 11169.330 |
| `aclnnMul` | 864 | 7085.310 |
| `InnerPromptFlashAttention` | 96 | 4700.490 |
| `aclnnAdd` | 576 | 4624.170 |
| `aclnnMean` | 384 | 4172.730 |
| `aclnnAddmm` | 384 | 3514.920 |
| `aclnnNeg` | 192 | 2449.160 |
| `aclnnCat` | 192 | 2447.500 |
| `aclrtGetStreamAttribute` | 4800 | 1854.210 |
| `aclnnAdds` | 192 | 1634.640 |
| `aclnnPowTensorScalar` | 192 | 1626.290 |
| `aclnnSub` | 192 | 1602.800 |
| `aclnnRsqrt` | 192 | 1555.490 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 983.190 |
| `aclnnSigmoid` | 96 | 831.020 |
| `aclnnMuls` | 96 | 795.240 |
| `aclrtGetHardwareSyncAddr` | 768 | 508.160 |
| `aclrtGetResInCurrentThread` | 192 | 124.450 |

