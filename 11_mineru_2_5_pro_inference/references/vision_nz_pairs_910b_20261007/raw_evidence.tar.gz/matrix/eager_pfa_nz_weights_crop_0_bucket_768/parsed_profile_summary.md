# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/eager_pfa_nz_weights_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/eager_pfa_nz_weights_crop_0_bucket_768/profile/liteserver-c001-4_212598_20261007143512011_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `76769.521 us`
- `Free`: `147512.280 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `699.750 us`
- `Stage`: `224282.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 13716.559 |
| `Mul` | 960 | 11440.029 |
| `PromptFlashAttention` | 96 | 7951.621 |
| `Transpose` | 384 | 7911.660 |
| `ReduceMean` | 384 | 6198.991 |
| `Slice` | 672 | 5894.130 |
| `Add` | 768 | 5504.138 |
| `Cast` | 768 | 5495.502 |
| `Sub` | 192 | 4884.483 |
| `Pows` | 192 | 3123.338 |
| `ConcatD` | 192 | 1878.337 |
| `Sigmoid` | 96 | 1356.470 |
| `Neg` | 192 | 1166.778 |
| `Rsqrt` | 192 | 248.887 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 384 | 13716.559 |
| `aclnnMul_MulAiCore_Mul` | 864 | 10487.027 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 96 | 7951.621 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 384 | 7911.660 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 6198.991 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 5495.502 |
| `aclnnAdd_AddAiCore_Add` | 576 | 5227.332 |
| `aclnnSub_SubAiCore_Sub` | 192 | 4884.483 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3123.338 |
| `aclnnNeg_SliceAiCore_Slice` | 192 | 2276.193 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 2243.768 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 1878.337 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 288 | 1374.169 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 1356.470 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1166.778 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 953.002 |
| `aclnnAdds_AddAiCore_Add` | 192 | 276.806 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 248.887 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 384 | 13716.559 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;320,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4579.953 |
| `MatMulV2 | "768,1280;80,320,16,16;5120" -> "768,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4087.859 |
| `MatMulV2 | "768,1280;80,240,16,16;3840" -> "768,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3182.932 |
| `MatMulV2 | "768,1280;80,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 1865.815 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 99.942 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 98.042 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 96.402 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 96.342 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 95.682 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.762 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.422 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.342 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 93.042 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.942 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.902 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 92.661 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.642 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.402 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.402 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.382 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.262 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 91.001 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.862 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.842 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.522 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.121 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 90.062 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 89.522 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 89.502 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.741 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.722 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 88.422 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.761 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.622 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.502 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 87.401 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 86.642 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 84.102 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 83.702 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 82.981 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 82.802 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 82.701 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 82.421 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 80.662 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 80.642 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 80.602 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 80.582 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.982 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.902 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.822 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.621 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.582 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.342 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.321 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.261 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.201 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 79.041 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 78.862 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 78.722 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 78.682 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 78.582 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 78.502 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 78.501 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 78.282 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `npu::npu_prompt_flash_attention` | 96 | 27619.460 |
| `aten::to` | 1056 | 25071.710 |
| `aten::_to_copy` | 768 | 22174.690 |
| `aten::copy_` | 1152 | 21249.071 |
| `empty_tensor` | 4896 | 20408.500 |
| `aten::mul` | 960 | 18851.953 |
| `aten::linear` | 384 | 18684.422 |
| `aten::add` | 768 | 16557.690 |
| `aclnnInplaceCopy` | 1152 | 15034.197 |
| `aten::addmm` | 384 | 14636.355 |
| `aclnnAddmmWeightNz` | 384 | 13716.574 |
| `aten::contiguous` | 384 | 11872.346 |
| `aten::clone` | 384 | 10880.953 |
| `aclnnMul` | 864 | 10496.059 |
| `aten::mean` | 384 | 8792.740 |
| `aclnnPromptFlashAttentionV3` | 96 | 7951.619 |
| `aten::transpose` | 768 | 6423.670 |
| `aten::as_strided` | 1632 | 6327.610 |
| `aclnnMean` | 384 | 6199.004 |
| `aten::empty` | 768 | 5365.080 |
| `aclnnAdd` | 576 | 5329.428 |
| `aten::square` | 192 | 5126.840 |
| `aten::sub` | 192 | 4922.645 |
| `aclnnSub` | 192 | 4884.478 |
| `aten::cat` | 192 | 4812.850 |
| `aten::pow` | 192 | 4578.280 |
| `aclnnCat` | 192 | 4122.103 |
| `aten::neg` | 192 | 4061.699 |
| `aclnnNeg` | 192 | 3442.989 |
| `aten::view` | 960 | 3377.790 |
| `aten::t` | 384 | 3200.750 |
| `aten::rsqrt` | 192 | 3166.330 |
| `aclnnPowTensorScalar` | 192 | 3123.343 |
| `aten::slice` | 384 | 2725.190 |
| `aten::unbind` | 96 | 2619.440 |
| `aten::select` | 288 | 2146.800 |
| `aten::sigmoid` | 96 | 1649.950 |
| `aclnnSigmoid` | 96 | 1367.627 |
| `aten::unsqueeze` | 192 | 1339.480 |
| `aclnnAdds` | 192 | 1104.640 |
| `aclnnRsqrt` | 192 | 1039.780 |
| `aclnnMuls` | 96 | 953.179 |
| `aten::item` | 288 | 925.770 |
| `aten::_local_scalar_dense` | 288 | 380.330 |
| `aten::result_type` | 192 | 335.730 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 5472 | 32593.940 |
| `aclrtLaunchKernelWithHostArgs` | 5472 | 25930.540 |
| `InnerPromptFlashAttentionGetWorkspaceSize` | 96 | 20498.850 |
| `PromptFlashAttention_Tiling` | 192 | 14812.050 |
| `aclnnInplaceCopy` | 1152 | 11845.490 |
| `aclnnMul` | 864 | 7365.840 |
| `InnerPromptFlashAttention` | 96 | 5024.210 |
| `aclnnAdd` | 576 | 4890.700 |
| `aclnnMean` | 384 | 4348.830 |
| `aclnnAddmmWeightNz` | 384 | 3363.270 |
| `aclnnCat` | 192 | 2532.150 |
| `aclnnNeg` | 192 | 2498.070 |
| `aclrtGetStreamAttribute` | 4800 | 1942.640 |
| `aclnnAdds` | 192 | 1717.090 |
| `aclnnSub` | 192 | 1713.710 |
| `aclnnRsqrt` | 192 | 1671.280 |
| `aclnnPowTensorScalar` | 192 | 1663.100 |
| `aclnnSigmoid` | 96 | 839.130 |
| `aclnnMuls` | 96 | 833.350 |
| `aclrtGetHardwareSyncAddr` | 480 | 356.620 |
| `aclrtGetResInCurrentThread` | 192 | 136.670 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 66.330 |

