# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/eager_pfa_nz_weights_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/eager_pfa_nz_weights_crop_1_bucket_3072/profile/liteserver-c001-4_213859_20261007143616055_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `175953.361 us`
- `Free`: `63701.287 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `743.750 us`
- `Stage`: `239654.500 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50362.070 |
| `MatMulV3` | 288 | 35710.205 |
| `Mul` | 960 | 19319.871 |
| `Transpose` | 384 | 9717.517 |
| `ReduceMean` | 384 | 9394.055 |
| `Add` | 768 | 8898.134 |
| `Cast` | 768 | 8183.493 |
| `Slice` | 480 | 7073.990 |
| `MatMulV2` | 96 | 6883.704 |
| `Sub` | 192 | 6008.875 |
| `Pows` | 192 | 3625.876 |
| `Sigmoid` | 96 | 3330.157 |
| `ConcatD` | 192 | 2976.891 |
| `SliceV2` | 192 | 2269.205 |
| `Neg` | 192 | 1878.092 |
| `Rsqrt` | 192 | 323.109 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 96 | 50362.070 |
| `aclnnAddmmWeightNz_MatMulV3Common_MatMulV3` | 288 | 35710.205 |
| `aclnnMul_MulAiCore_Mul` | 864 | 17311.182 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 384 | 9717.517 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 9394.055 |
| `aclnnAdd_AddAiCore_Add` | 576 | 8570.189 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 8183.493 |
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 96 | 6883.704 |
| `aclnnSub_SubAiCore_Sub` | 192 | 6008.875 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 3994.123 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3625.876 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 3330.157 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 288 | 3079.867 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 2976.891 |
| `aclnnNeg_SliceV2AiCore_SliceV2` | 192 | 2269.205 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 2008.689 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1878.092 |
| `aclnnAdds_AddAiCore_Add` | 192 | 327.945 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 323.109 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmmWeightNz_MatMulV3Common_MatMulV3` | 288 | 35710.205 |
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 96 | 6883.704 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;80,320,16,16;5120" -> "3072,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 13578.677 |
| `MatMulV3 | "3072,5120;320,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 12347.411 |
| `MatMulV3 | "3072,1280;80,240,16,16;3840" -> "3072,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 9784.117 |
| `MatMulV2 | "3072,1280;80,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 6883.704 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 535.110 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 533.631 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 532.570 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 531.871 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 531.630 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 531.351 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.891 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.871 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.131 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 530.071 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.750 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.551 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.251 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.171 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.170 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 529.050 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.811 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.790 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.571 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.530 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.471 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.371 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 528.030 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.910 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.730 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.250 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.191 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.150 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 527.111 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.931 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.891 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.711 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.571 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.550 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.331 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.230 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.210 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 526.191 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.951 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.950 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.510 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.250 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 525.131 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.771 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.650 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.611 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.351 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.291 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 524.150 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.891 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.871 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.511 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.351 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.290 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.271 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.270 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.130 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 523.091 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.971 |
| `InnerPromptFlashAttention_PromptFlashAttention_PromptFlashAttention` | 1 | 522.831 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `npu::npu_prompt_flash_attention` | 96 | 50475.616 |
| `aclnnPromptFlashAttentionV3` | 96 | 50362.066 |
| `aten::linear` | 384 | 42596.989 |
| `aten::addmm` | 384 | 42593.891 |
| `aclnnAddmmWeightNz` | 384 | 42593.891 |
| `aten::to` | 1056 | 26984.530 |
| `aten::copy_` | 1152 | 24292.096 |
| `aten::_to_copy` | 768 | 23817.940 |
| `empty_tensor` | 4896 | 22751.630 |
| `aten::mul` | 960 | 22143.763 |
| `aclnnInplaceCopy` | 1152 | 21038.343 |
| `aten::add` | 768 | 17824.700 |
| `aclnnMul` | 864 | 17315.175 |
| `aten::contiguous` | 384 | 13313.222 |
| `aten::clone` | 384 | 12597.688 |
| `aten::mean` | 384 | 9648.523 |
| `aclnnMean` | 384 | 9394.048 |
| `aclnnAdd` | 576 | 8570.211 |
| `aten::cat` | 192 | 6973.818 |
| `aclnnCat` | 192 | 6971.019 |
| `aten::transpose` | 768 | 6705.220 |
| `aten::as_strided` | 1632 | 6653.380 |
| `aten::sub` | 192 | 6018.938 |
| `aten::empty` | 768 | 6013.740 |
| `aclnnSub` | 192 | 6008.860 |
| `aten::square` | 192 | 5449.240 |
| `aten::pow` | 192 | 4851.720 |
| `aten::neg` | 192 | 4691.867 |
| `aclnnNeg` | 192 | 4156.173 |
| `aclnnPowTensorScalar` | 192 | 3625.892 |
| `aten::view` | 960 | 3545.730 |
| `aten::t` | 384 | 3376.490 |
| `aten::sigmoid` | 96 | 3330.146 |
| `aclnnSigmoid` | 96 | 3330.146 |
| `aten::rsqrt` | 192 | 3284.140 |
| `aten::slice` | 384 | 2835.910 |
| `aten::unbind` | 96 | 2697.990 |
| `aten::select` | 288 | 2217.230 |
| `aclnnMuls` | 96 | 2008.700 |
| `aten::unsqueeze` | 192 | 1369.980 |
| `aclnnAdds` | 192 | 1162.860 |
| `aclnnRsqrt` | 192 | 1071.210 |
| `aten::item` | 288 | 1017.020 |
| `aten::_local_scalar_dense` | 288 | 442.290 |
| `aten::result_type` | 192 | 360.520 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 5472 | 34544.340 |
| `aclrtLaunchKernelWithHostArgs` | 5472 | 27336.620 |
| `InnerPromptFlashAttentionGetWorkspaceSize` | 96 | 21989.610 |
| `PromptFlashAttention_Tiling` | 192 | 16397.660 |
| `aclnnInplaceCopy` | 1152 | 12491.000 |
| `aclnnMul` | 864 | 7801.740 |
| `InnerPromptFlashAttention` | 96 | 5453.700 |
| `aclnnAdd` | 576 | 5187.680 |
| `aclnnMean` | 384 | 4540.740 |
| `aclnnAddmmWeightNz` | 384 | 3904.030 |
| `aclnnNeg` | 192 | 2678.530 |
| `aclnnCat` | 192 | 2619.210 |
| `aclrtGetStreamAttribute` | 4800 | 2205.360 |
| `aclnnSub` | 192 | 1778.920 |
| `aclnnPowTensorScalar` | 192 | 1763.050 |
| `aclnnAdds` | 192 | 1761.600 |
| `aclnnRsqrt` | 192 | 1725.450 |
| `aclnnMuls` | 96 | 880.310 |
| `aclnnSigmoid` | 96 | 870.370 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 816.470 |
| `aclrtGetHardwareSyncAddr` | 768 | 544.280 |
| `aclrtGetResInCurrentThread` | 192 | 135.170 |

