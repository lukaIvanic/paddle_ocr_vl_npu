# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_crop_0_bucket_768/profile/liteserver-c001-4_192563_20261007141400427_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `17604.454 us`
- `Free`: `803.734 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `859.500 us`
- `Stage`: `18408.250 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 288 | 10200.994 |
| `PromptFlashAttention` | 96 | 7993.306 |
| `StridedSliceD` | 384 | 5217.491 |
| `Transpose` | 384 | 5028.820 |
| `Mul` | 576 | 4186.422 |
| `AutomaticBufferFusionOp` | 480 | 3251.261 |
| `Add` | 384 | 3222.467 |
| `GroupedMatmul` | 96 | 2999.485 |
| `ReduceMeanD` | 384 | 2595.595 |
| `Sub` | 192 | 1888.360 |
| `Neg` | 192 | 1647.294 |
| `ConcatV2D` | 192 | 1573.674 |
| `Cast` | 195 | 1523.882 |
| `Unpack` | 96 | 827.929 |
| `ConfusionTransposeD` | 96 | 490.490 |
| `Data` | 1 | 5.160 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_1` | 3 | 270.826 |
| `PromptFlashAttention_20` | 3 | 265.905 |
| `PromptFlashAttention_5` | 3 | 263.365 |
| `PromptFlashAttention_7` | 3 | 262.706 |
| `PromptFlashAttention` | 3 | 258.785 |
| `PromptFlashAttention_15` | 3 | 256.766 |
| `PromptFlashAttention_8` | 3 | 255.706 |
| `PromptFlashAttention_17` | 3 | 255.105 |
| `PromptFlashAttention_23` | 3 | 254.504 |
| `PromptFlashAttention_29` | 3 | 253.865 |
| `PromptFlashAttention_13` | 3 | 253.406 |
| `PromptFlashAttention_18` | 3 | 252.085 |
| `PromptFlashAttention_28` | 3 | 252.006 |
| `PromptFlashAttention_31` | 3 | 251.585 |
| `PromptFlashAttention_9` | 3 | 249.506 |
| `PromptFlashAttention_25` | 3 | 249.405 |
| `PromptFlashAttention_30` | 3 | 247.784 |
| `PromptFlashAttention_27` | 3 | 247.485 |
| `PromptFlashAttention_26` | 3 | 246.685 |
| `PromptFlashAttention_19` | 3 | 246.386 |
| `PromptFlashAttention_10` | 3 | 246.306 |
| `PromptFlashAttention_6` | 3 | 246.145 |
| `PromptFlashAttention_16` | 3 | 243.826 |
| `PromptFlashAttention_24` | 3 | 243.805 |
| `PromptFlashAttention_3` | 3 | 243.005 |
| `PromptFlashAttention_14` | 3 | 242.326 |
| `PromptFlashAttention_21` | 3 | 242.243 |
| `PromptFlashAttention_12` | 3 | 242.006 |
| `PromptFlashAttention_2` | 3 | 241.185 |
| `PromptFlashAttention_11` | 3 | 239.985 |
| `PromptFlashAttention_22` | 3 | 234.583 |
| `PromptFlashAttention_4` | 3 | 234.025 |
| `MatMulV2_47` | 3 | 146.703 |
| `MatMulV2_11` | 3 | 146.342 |
| `MatMulV2_41` | 3 | 140.843 |
| `MatMulV2_5` | 3 | 140.543 |
| `MatMulV2_8` | 3 | 139.702 |
| `MatMulV2_65` | 3 | 139.223 |
| `MatMulV2_83` | 3 | 138.903 |
| `MatMulV2_53` | 3 | 138.623 |
| `MatMulV2_29` | 3 | 138.602 |
| `MatMulV2_68` | 3 | 138.563 |
| `MatMulV2_32` | 3 | 138.523 |
| `MatMulV2_23` | 3 | 138.342 |
| `MatMulV2_89` | 3 | 138.283 |
| `MatMulV2_20` | 3 | 138.283 |
| `MatMulV2_35` | 3 | 138.023 |
| `MatMulV2_77` | 3 | 138.023 |
| `MatMulV2_17` | 3 | 137.862 |
| `MatMulV2_2` | 3 | 137.823 |
| `MatMulV2_50` | 3 | 137.762 |
| `MatMulV2_62` | 3 | 137.663 |
| `MatMulV2_74` | 3 | 137.463 |
| `MatMulV2_71` | 3 | 137.363 |
| `MatMulV2_80` | 3 | 137.343 |
| `MatMulV2_56` | 3 | 137.303 |
| `MatMulV2_38` | 3 | 137.021 |
| `MatMulV2_14` | 3 | 136.982 |
| `MatMulV2_44` | 3 | 136.882 |
| `MatMulV2_95` | 3 | 136.743 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_47` | 3 | 146.703 |
| `MatMulV2_11` | 3 | 146.342 |
| `MatMulV2_41` | 3 | 140.843 |
| `MatMulV2_5` | 3 | 140.543 |
| `MatMulV2_8` | 3 | 139.702 |
| `MatMulV2_65` | 3 | 139.223 |
| `MatMulV2_83` | 3 | 138.903 |
| `MatMulV2_53` | 3 | 138.623 |
| `MatMulV2_29` | 3 | 138.602 |
| `MatMulV2_68` | 3 | 138.563 |
| `MatMulV2_32` | 3 | 138.523 |
| `MatMulV2_23` | 3 | 138.342 |
| `MatMulV2_89` | 3 | 138.283 |
| `MatMulV2_20` | 3 | 138.283 |
| `MatMulV2_35` | 3 | 138.023 |
| `MatMulV2_77` | 3 | 138.023 |
| `MatMulV2_17` | 3 | 137.862 |
| `MatMulV2_2` | 3 | 137.823 |
| `MatMulV2_50` | 3 | 137.762 |
| `MatMulV2_62` | 3 | 137.663 |
| `MatMulV2_74` | 3 | 137.463 |
| `MatMulV2_71` | 3 | 137.363 |
| `MatMulV2_80` | 3 | 137.343 |
| `MatMulV2_56` | 3 | 137.303 |
| `MatMulV2_38` | 3 | 137.021 |
| `MatMulV2_14` | 3 | 136.982 |
| `MatMulV2_44` | 3 | 136.882 |
| `MatMulV2_95` | 3 | 136.743 |
| `MatMulV2_26` | 3 | 136.682 |
| `MatMulV2_59` | 3 | 136.543 |
| `MatMulV2_86` | 3 | 135.803 |
| `MatMulV2_92` | 3 | 135.482 |
| `MatMulV2_67` | 3 | 131.903 |
| `MatMulV2_40` | 3 | 125.683 |
| `MatMulV2_19` | 3 | 125.123 |
| `MatMulV2_85` | 3 | 124.762 |
| `MatMulV2_76` | 3 | 124.583 |
| `MatMulV2_4` | 3 | 124.582 |
| `MatMulV2_73` | 3 | 124.523 |
| `MatMulV2_16` | 3 | 124.483 |
| `MatMulV2_10` | 3 | 124.303 |
| `MatMulV2_94` | 3 | 124.043 |
| `MatMulV2_88` | 3 | 123.902 |
| `MatMulV2_46` | 3 | 123.862 |
| `MatMulV2_28` | 3 | 123.822 |
| `MatMulV2_61` | 3 | 123.783 |
| `MatMulV2_13` | 3 | 123.683 |
| `MatMulV2_58` | 3 | 123.620 |
| `MatMulV2_70` | 3 | 123.602 |
| `MatMulV2_34` | 3 | 123.343 |
| `MatMulV2_7` | 3 | 123.303 |
| `MatMulV2_52` | 3 | 123.282 |
| `MatMulV2_1` | 3 | 123.263 |
| `MatMulV2_37` | 3 | 123.163 |
| `MatMulV2_82` | 3 | 123.083 |
| `MatMulV2_25` | 3 | 123.022 |
| `MatMulV2_31` | 3 | 123.022 |
| `MatMulV2_22` | 3 | 122.983 |
| `MatMulV2_91` | 3 | 122.863 |
| `MatMulV2_43` | 3 | 122.762 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4430.244 |
| `MatMulV2 | "768,1280;5120,1280;5120" -> "768,5120" | ND;ND;ND -> ND` | 96 | 3964.498 |
| `GroupedMatmul | "768,1280;1,1280,3840;1,3840;;;;;1" -> "768,3840" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 2999.485 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 1806.252 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_1` | 1 | 96.042 |
| `PromptFlashAttention_31` | 1 | 93.742 |
| `PromptFlashAttention_25` | 1 | 91.962 |
| `PromptFlashAttention_7` | 1 | 91.722 |
| `PromptFlashAttention_29` | 1 | 89.662 |
| `PromptFlashAttention_23` | 1 | 89.382 |
| `PromptFlashAttention_20` | 1 | 89.202 |
| `PromptFlashAttention_20` | 1 | 88.641 |
| `PromptFlashAttention_5` | 1 | 88.522 |
| `PromptFlashAttention_6` | 1 | 88.401 |
| `PromptFlashAttention_20` | 1 | 88.062 |
| `PromptFlashAttention_28` | 1 | 87.982 |
| `PromptFlashAttention_5` | 1 | 87.901 |
| `PromptFlashAttention` | 1 | 87.802 |
| `PromptFlashAttention_21` | 1 | 87.461 |
| `PromptFlashAttention_1` | 1 | 87.402 |
| `PromptFlashAttention_1` | 1 | 87.382 |
| `PromptFlashAttention_23` | 1 | 87.081 |
| `PromptFlashAttention_5` | 1 | 86.942 |
| `PromptFlashAttention_15` | 1 | 86.862 |
| `PromptFlashAttention_10` | 1 | 86.842 |
| `PromptFlashAttention_8` | 1 | 86.722 |
| `PromptFlashAttention_8` | 1 | 86.322 |
| `PromptFlashAttention_7` | 1 | 85.842 |
| `PromptFlashAttention_15` | 1 | 85.822 |
| `PromptFlashAttention` | 1 | 85.801 |
| `PromptFlashAttention_18` | 1 | 85.762 |
| `PromptFlashAttention_13` | 1 | 85.682 |
| `PromptFlashAttention_16` | 1 | 85.582 |
| `PromptFlashAttention_17` | 1 | 85.202 |
| `PromptFlashAttention` | 1 | 85.182 |
| `PromptFlashAttention_7` | 1 | 85.142 |
| `PromptFlashAttention_17` | 1 | 85.101 |
| `PromptFlashAttention_12` | 1 | 85.022 |
| `PromptFlashAttention_17` | 1 | 84.802 |
| `PromptFlashAttention_3` | 1 | 84.522 |
| `PromptFlashAttention_18` | 1 | 84.462 |
| `PromptFlashAttention_13` | 1 | 84.382 |
| `PromptFlashAttention_28` | 1 | 84.382 |
| `PromptFlashAttention_15` | 1 | 84.082 |
| `PromptFlashAttention_2` | 1 | 83.722 |
| `PromptFlashAttention_26` | 1 | 83.641 |
| `PromptFlashAttention_9` | 1 | 83.622 |
| `PromptFlashAttention_19` | 1 | 83.382 |
| `PromptFlashAttention_13` | 1 | 83.342 |
| `PromptFlashAttention_27` | 1 | 82.962 |
| `PromptFlashAttention_9` | 1 | 82.962 |
| `PromptFlashAttention_9` | 1 | 82.922 |
| `PromptFlashAttention_24` | 1 | 82.901 |
| `PromptFlashAttention_30` | 1 | 82.881 |
| `PromptFlashAttention_19` | 1 | 82.722 |
| `PromptFlashAttention_8` | 1 | 82.662 |
| `PromptFlashAttention_30` | 1 | 82.662 |
| `PromptFlashAttention_27` | 1 | 82.661 |
| `PromptFlashAttention_30` | 1 | 82.241 |
| `PromptFlashAttention_29` | 1 | 82.181 |
| `PromptFlashAttention_14` | 1 | 82.082 |
| `PromptFlashAttention_29` | 1 | 82.022 |
| `PromptFlashAttention_26` | 1 | 81.862 |
| `PromptFlashAttention_27` | 1 | 81.862 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 18547.192 |
| `TorchDynamo Cache Lookup` | 3 | 17690.941 |
| `Torch-Compiled Region: 0/0` | 3 | 1364.290 |
| `TorchNpuGraphBase::Run` | 3 | 745.230 |
| `ExecuteGraph` | 3 | 261.040 |
| `RefreshAtTensorFromGeTensor` | 3 | 156.600 |
| `AssembleInputs` | 3 | 143.170 |
| `aten::empty` | 3 | 71.260 |
| `AssembleOutputs` | 3 | 59.050 |
| `aten::set_` | 3 | 41.530 |
| `empty_tensor` | 3 | 41.180 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 271478.100 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 52616.060 |
| `launch` | 1346 | 22120.840 |
| `InputCopy` | 3 | 132.370 |
| `ModelExecute` | 3 | 76.820 |
| `step_info` | 6 | 46.800 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 26.350 |
| `OutputCopy` | 3 | 1.830 |

