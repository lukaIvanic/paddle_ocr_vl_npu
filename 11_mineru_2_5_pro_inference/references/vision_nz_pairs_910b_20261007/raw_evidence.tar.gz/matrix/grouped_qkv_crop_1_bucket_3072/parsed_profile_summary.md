# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_crop_1_bucket_3072/profile/liteserver-c001-4_193969_20261007141534716_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `49931.095 us`
- `Free`: `814.319 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `837.500 us`
- `Stage`: `50745.250 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50314.267 |
| `MatMulV3` | 192 | 24978.223 |
| `StridedSliceD` | 384 | 13502.114 |
| `GroupedMatmul` | 96 | 9435.891 |
| `Mul` | 576 | 7797.512 |
| `AutomaticBufferFusionOp` | 480 | 6701.845 |
| `Transpose` | 384 | 6504.743 |
| `MatMulV2` | 96 | 6365.243 |
| `Add` | 384 | 5398.051 |
| `ReduceMeanD` | 384 | 5011.228 |
| `Sub` | 192 | 3417.317 |
| `ConcatV2D` | 192 | 2636.807 |
| `Cast` | 195 | 2368.599 |
| `Neg` | 192 | 2139.765 |
| `Unpack` | 96 | 2089.785 |
| `ConfusionTransposeD` | 96 | 988.100 |
| `Data` | 1 | 7.300 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_6` | 3 | 1608.812 |
| `PromptFlashAttention_16` | 3 | 1607.912 |
| `PromptFlashAttention_30` | 3 | 1604.592 |
| `PromptFlashAttention_1` | 3 | 1603.873 |
| `PromptFlashAttention_27` | 3 | 1601.313 |
| `PromptFlashAttention_26` | 3 | 1599.211 |
| `PromptFlashAttention_18` | 3 | 1597.693 |
| `PromptFlashAttention_24` | 3 | 1595.193 |
| `PromptFlashAttention_7` | 3 | 1582.232 |
| `PromptFlashAttention_5` | 3 | 1582.111 |
| `PromptFlashAttention_15` | 3 | 1579.511 |
| `PromptFlashAttention_29` | 3 | 1577.530 |
| `PromptFlashAttention` | 3 | 1576.571 |
| `PromptFlashAttention_22` | 3 | 1572.812 |
| `PromptFlashAttention_8` | 3 | 1572.011 |
| `PromptFlashAttention_3` | 3 | 1571.552 |
| `PromptFlashAttention_19` | 3 | 1569.871 |
| `PromptFlashAttention_12` | 3 | 1567.432 |
| `PromptFlashAttention_14` | 3 | 1565.692 |
| `PromptFlashAttention_9` | 3 | 1564.990 |
| `PromptFlashAttention_28` | 3 | 1558.831 |
| `PromptFlashAttention_31` | 3 | 1558.011 |
| `PromptFlashAttention_4` | 3 | 1557.891 |
| `PromptFlashAttention_20` | 3 | 1553.731 |
| `PromptFlashAttention_11` | 3 | 1553.291 |
| `PromptFlashAttention_25` | 3 | 1551.872 |
| `PromptFlashAttention_21` | 3 | 1549.071 |
| `PromptFlashAttention_13` | 3 | 1547.792 |
| `PromptFlashAttention_10` | 3 | 1547.190 |
| `PromptFlashAttention_2` | 3 | 1546.170 |
| `PromptFlashAttention_17` | 3 | 1545.532 |
| `PromptFlashAttention_23` | 3 | 1543.971 |
| `MatMulV2_4_to_v3` | 3 | 406.869 |
| `MatMulV2_1_to_v3` | 3 | 403.668 |
| `MatMulV2_5_to_v3` | 3 | 401.947 |
| `MatMulV2_95_to_v3` | 3 | 399.928 |
| `MatMulV2_7_to_v3` | 3 | 399.608 |
| `MatMulV2_52_to_v3` | 3 | 395.229 |
| `MatMulV2_2_to_v3` | 3 | 394.127 |
| `MatMulV2_13_to_v3` | 3 | 393.268 |
| `MatMulV2_37_to_v3` | 3 | 393.109 |
| `MatMulV2_61_to_v3` | 3 | 392.948 |
| `MatMulV2_8_to_v3` | 3 | 392.027 |
| `MatMulV2_91_to_v3` | 3 | 391.748 |
| `MatMulV2_79_to_v3` | 3 | 391.487 |
| `MatMulV2_82_to_v3` | 3 | 391.329 |
| `MatMulV2_70_to_v3` | 3 | 391.267 |
| `MatMulV2_19_to_v3` | 3 | 391.149 |
| `MatMulV2_38_to_v3` | 3 | 390.868 |
| `MatMulV2_40_to_v3` | 3 | 390.709 |
| `MatMulV2_73_to_v3` | 3 | 390.689 |
| `MatMulV2_14_to_v3` | 3 | 390.668 |
| `MatMulV2_62_to_v3` | 3 | 390.488 |
| `MatMulV2_50_to_v3` | 3 | 390.308 |
| `MatMulV2_32_to_v3` | 3 | 390.268 |
| `MatMulV2_25_to_v3` | 3 | 390.088 |
| `MatMulV2_89_to_v3` | 3 | 390.068 |
| `MatMulV2_64_to_v3` | 3 | 389.987 |
| `MatMulV2_31_to_v3` | 3 | 389.867 |
| `MatMulV2_49_to_v3` | 3 | 389.727 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_4_to_v3` | 3 | 406.869 |
| `MatMulV2_1_to_v3` | 3 | 403.668 |
| `MatMulV2_5_to_v3` | 3 | 401.947 |
| `MatMulV2_95_to_v3` | 3 | 399.928 |
| `MatMulV2_7_to_v3` | 3 | 399.608 |
| `MatMulV2_52_to_v3` | 3 | 395.229 |
| `MatMulV2_2_to_v3` | 3 | 394.127 |
| `MatMulV2_13_to_v3` | 3 | 393.268 |
| `MatMulV2_37_to_v3` | 3 | 393.109 |
| `MatMulV2_61_to_v3` | 3 | 392.948 |
| `MatMulV2_8_to_v3` | 3 | 392.027 |
| `MatMulV2_91_to_v3` | 3 | 391.748 |
| `MatMulV2_79_to_v3` | 3 | 391.487 |
| `MatMulV2_82_to_v3` | 3 | 391.329 |
| `MatMulV2_70_to_v3` | 3 | 391.267 |
| `MatMulV2_19_to_v3` | 3 | 391.149 |
| `MatMulV2_38_to_v3` | 3 | 390.868 |
| `MatMulV2_40_to_v3` | 3 | 390.709 |
| `MatMulV2_73_to_v3` | 3 | 390.689 |
| `MatMulV2_14_to_v3` | 3 | 390.668 |
| `MatMulV2_62_to_v3` | 3 | 390.488 |
| `MatMulV2_50_to_v3` | 3 | 390.308 |
| `MatMulV2_32_to_v3` | 3 | 390.268 |
| `MatMulV2_25_to_v3` | 3 | 390.088 |
| `MatMulV2_89_to_v3` | 3 | 390.068 |
| `MatMulV2_64_to_v3` | 3 | 389.987 |
| `MatMulV2_31_to_v3` | 3 | 389.867 |
| `MatMulV2_49_to_v3` | 3 | 389.727 |
| `MatMulV2_46_to_v3` | 3 | 389.648 |
| `MatMulV2_28_to_v3` | 3 | 389.527 |
| `MatMulV2_29_to_v3` | 3 | 389.508 |
| `MatMulV2_71_to_v3` | 3 | 389.489 |
| `MatMulV2_55_to_v3` | 3 | 389.468 |
| `MatMulV2_34_to_v3` | 3 | 389.368 |
| `MatMulV2_26_to_v3` | 3 | 389.287 |
| `MatMulV2_85_to_v3` | 3 | 389.269 |
| `MatMulV2_16_to_v3` | 3 | 389.248 |
| `MatMulV2_80_to_v3` | 3 | 389.209 |
| `MatMulV2_74_to_v3` | 3 | 389.107 |
| `MatMulV2_41_to_v3` | 3 | 389.028 |
| `MatMulV2_88_to_v3` | 3 | 389.028 |
| `MatMulV2_10_to_v3` | 3 | 389.008 |
| `MatMulV2_11_to_v3` | 3 | 388.967 |
| `MatMulV2_83_to_v3` | 3 | 388.967 |
| `MatMulV2_56_to_v3` | 3 | 388.567 |
| `MatMulV2_92_to_v3` | 3 | 387.849 |
| `MatMulV2_23_to_v3` | 3 | 387.747 |
| `MatMulV2_47_to_v3` | 3 | 387.607 |
| `MatMulV2_35_to_v3` | 3 | 387.508 |
| `MatMulV2_43_to_v3` | 3 | 387.428 |
| `MatMulV2_53_to_v3` | 3 | 387.428 |
| `MatMulV2_22_to_v3` | 3 | 387.268 |
| `MatMulV2_59_to_v3` | 3 | 387.267 |
| `MatMulV2_65_to_v3` | 3 | 387.248 |
| `MatMulV2_77_to_v3` | 3 | 387.188 |
| `MatMulV2_17_to_v3` | 3 | 386.627 |
| `MatMulV2_20_to_v3` | 3 | 386.588 |
| `MatMulV2_86_to_v3` | 3 | 386.468 |
| `MatMulV2_67_to_v3` | 3 | 386.267 |
| `MatMulV2_68_to_v3` | 3 | 386.188 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;5120,1280;5120" -> "3072,5120" | ND;ND;ND -> ND` | 96 | 12514.277 |
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12463.946 |
| `GroupedMatmul | "3072,1280;1,1280,3840;1,3840;;;;;1" -> "3072,3840" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 9435.891 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6365.243 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_6` | 1 | 537.891 |
| `PromptFlashAttention_16` | 1 | 537.751 |
| `PromptFlashAttention_30` | 1 | 536.390 |
| `PromptFlashAttention_16` | 1 | 536.211 |
| `PromptFlashAttention_1` | 1 | 535.591 |
| `PromptFlashAttention_27` | 1 | 535.511 |
| `PromptFlashAttention_6` | 1 | 535.471 |
| `PromptFlashAttention_6` | 1 | 535.450 |
| `PromptFlashAttention_27` | 1 | 535.111 |
| `PromptFlashAttention_1` | 1 | 535.011 |
| `PromptFlashAttention_18` | 1 | 534.771 |
| `PromptFlashAttention_30` | 1 | 534.431 |
| `PromptFlashAttention_26` | 1 | 534.230 |
| `PromptFlashAttention_16` | 1 | 533.950 |
| `PromptFlashAttention_30` | 1 | 533.771 |
| `PromptFlashAttention_18` | 1 | 533.631 |
| `PromptFlashAttention_26` | 1 | 533.410 |
| `PromptFlashAttention_1` | 1 | 533.271 |
| `PromptFlashAttention_24` | 1 | 532.271 |
| `PromptFlashAttention_24` | 1 | 531.951 |
| `PromptFlashAttention_26` | 1 | 531.571 |
| `PromptFlashAttention_24` | 1 | 530.971 |
| `PromptFlashAttention_27` | 1 | 530.691 |
| `PromptFlashAttention_18` | 1 | 529.291 |
| `PromptFlashAttention_7` | 1 | 528.391 |
| `PromptFlashAttention_5` | 1 | 528.310 |
| `PromptFlashAttention_5` | 1 | 528.211 |
| `PromptFlashAttention` | 1 | 528.110 |
| `PromptFlashAttention_15` | 1 | 528.110 |
| `PromptFlashAttention_7` | 1 | 527.871 |
| `PromptFlashAttention_22` | 1 | 527.110 |
| `PromptFlashAttention_3` | 1 | 526.790 |
| `PromptFlashAttention_19` | 1 | 526.790 |
| `PromptFlashAttention_15` | 1 | 526.531 |
| `PromptFlashAttention_29` | 1 | 526.170 |
| `PromptFlashAttention_29` | 1 | 526.010 |
| `PromptFlashAttention_7` | 1 | 525.970 |
| `PromptFlashAttention_5` | 1 | 525.590 |
| `PromptFlashAttention` | 1 | 525.490 |
| `PromptFlashAttention_29` | 1 | 525.350 |
| `PromptFlashAttention_12` | 1 | 525.071 |
| `PromptFlashAttention_15` | 1 | 524.870 |
| `PromptFlashAttention_8` | 1 | 524.570 |
| `PromptFlashAttention_22` | 1 | 524.311 |
| `PromptFlashAttention_8` | 1 | 524.271 |
| `PromptFlashAttention_8` | 1 | 523.170 |
| `PromptFlashAttention` | 1 | 522.971 |
| `PromptFlashAttention_14` | 1 | 522.810 |
| `PromptFlashAttention_3` | 1 | 522.511 |
| `PromptFlashAttention_9` | 1 | 522.330 |
| `PromptFlashAttention_3` | 1 | 522.251 |
| `PromptFlashAttention_19` | 1 | 522.151 |
| `PromptFlashAttention_9` | 1 | 522.150 |
| `PromptFlashAttention_14` | 1 | 521.811 |
| `PromptFlashAttention_12` | 1 | 521.650 |
| `PromptFlashAttention_22` | 1 | 521.391 |
| `PromptFlashAttention_14` | 1 | 521.071 |
| `PromptFlashAttention_19` | 1 | 520.930 |
| `PromptFlashAttention_12` | 1 | 520.711 |
| `PromptFlashAttention_28` | 1 | 520.570 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 50929.048 |
| `TorchDynamo Cache Lookup` | 3 | 50019.907 |
| `Torch-Compiled Region: 0/0` | 3 | 1412.890 |
| `TorchNpuGraphBase::Run` | 3 | 767.780 |
| `ExecuteGraph` | 3 | 288.290 |
| `RefreshAtTensorFromGeTensor` | 3 | 161.770 |
| `AssembleInputs` | 3 | 148.430 |
| `aten::empty` | 3 | 76.640 |
| `empty_tensor` | 3 | 43.570 |
| `aten::set_` | 3 | 42.480 |
| `AssembleOutputs` | 3 | 42.370 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 272242.620 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 149605.970 |
| `launch` | 1346 | 21401.190 |
| `InputCopy` | 3 | 130.910 |
| `ModelExecute` | 3 | 104.880 |
| `step_info` | 6 | 47.630 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 26.180 |
| `OutputCopy` | 3 | 2.110 |

