# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_mlp_fc1_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_mlp_fc1_crop_0_bucket_768/profile/liteserver-c001-4_198860_20261007142034590_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `18670.813 us`
- `Free`: `862.697 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `882.750 us`
- `Stage`: `19533.500 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 8107.799 |
| `Transpose` | 480 | 7825.635 |
| `GroupedMatmul` | 192 | 6883.756 |
| `MatMulV2` | 192 | 6369.902 |
| `StridedSliceD` | 384 | 5260.514 |
| `Mul` | 576 | 4288.816 |
| `AutomaticBufferFusionOp` | 480 | 3298.354 |
| `Add` | 384 | 3231.802 |
| `ReduceMeanD` | 384 | 2711.268 |
| `Sub` | 192 | 1834.039 |
| `Neg` | 192 | 1661.337 |
| `ConcatV2D` | 192 | 1587.945 |
| `Cast` | 195 | 1529.223 |
| `Unpack` | 96 | 824.253 |
| `ConfusionTransposeD` | 96 | 487.930 |
| `Data` | 1 | 5.100 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_8` | 3 | 282.484 |
| `PromptFlashAttention_24` | 3 | 272.766 |
| `PromptFlashAttention_20` | 3 | 270.986 |
| `PromptFlashAttention_19` | 3 | 269.245 |
| `PromptFlashAttention_12` | 3 | 268.985 |
| `PromptFlashAttention_22` | 3 | 265.945 |
| `PromptFlashAttention_16` | 3 | 264.685 |
| `PromptFlashAttention_2` | 3 | 262.966 |
| `PromptFlashAttention_11` | 3 | 262.745 |
| `PromptFlashAttention_30` | 3 | 262.264 |
| `PromptFlashAttention_3` | 3 | 259.605 |
| `PromptFlashAttention` | 3 | 257.305 |
| `PromptFlashAttention_1` | 3 | 256.945 |
| `PromptFlashAttention_9` | 3 | 255.926 |
| `PromptFlashAttention_7` | 3 | 255.183 |
| `PromptFlashAttention_15` | 3 | 254.505 |
| `PromptFlashAttention_29` | 3 | 253.346 |
| `PromptFlashAttention_31` | 3 | 252.744 |
| `PromptFlashAttention_23` | 3 | 249.765 |
| `PromptFlashAttention_25` | 3 | 245.364 |
| `PromptFlashAttention_17` | 3 | 244.944 |
| `PromptFlashAttention_28` | 3 | 244.365 |
| `PromptFlashAttention_18` | 3 | 243.326 |
| `PromptFlashAttention_26` | 3 | 241.904 |
| `PromptFlashAttention_6` | 3 | 241.486 |
| `PromptFlashAttention_21` | 3 | 240.905 |
| `PromptFlashAttention_13` | 3 | 240.644 |
| `PromptFlashAttention_27` | 3 | 239.406 |
| `PromptFlashAttention_10` | 3 | 238.246 |
| `PromptFlashAttention_14` | 3 | 236.865 |
| `PromptFlashAttention_5` | 3 | 236.846 |
| `PromptFlashAttention_4` | 3 | 235.103 |
| `MatMulV2_7` | 3 | 144.543 |
| `MatMulV2_9` | 3 | 143.022 |
| `MatMulV2_13` | 3 | 142.663 |
| `MatMulV2_5` | 3 | 142.583 |
| `MatMulV2_33` | 3 | 142.143 |
| `MatMulV2_27` | 3 | 140.882 |
| `MatMulV2_59` | 3 | 140.623 |
| `MatMulV2_25` | 3 | 140.223 |
| `MatMulV2_41` | 3 | 140.103 |
| `MatMulV2_15` | 3 | 139.522 |
| `MatMulV2_45` | 3 | 139.463 |
| `MatMulV2_35` | 3 | 139.403 |
| `MatMulV2_61` | 3 | 139.323 |
| `MatMulV2_57` | 3 | 139.303 |
| `MatMulV2_43` | 3 | 139.163 |
| `MatMulV2_23` | 3 | 138.743 |
| `MatMulV2_47` | 3 | 138.682 |
| `MatMulV2_37` | 3 | 138.603 |
| `MatMulV2_19` | 3 | 138.442 |
| `MatMulV2_51` | 3 | 138.343 |
| `MatMulV2_63` | 3 | 138.281 |
| `MatMulV2_55` | 3 | 138.263 |
| `MatMulV2_53` | 3 | 138.122 |
| `MatMulV2_31` | 3 | 137.883 |
| `MatMulV2_17` | 3 | 137.703 |
| `MatMulV2_11` | 3 | 137.663 |
| `MatMulV2_1` | 3 | 137.583 |
| `MatMulV2_3` | 3 | 135.542 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_7` | 3 | 144.543 |
| `MatMulV2_9` | 3 | 143.022 |
| `MatMulV2_13` | 3 | 142.663 |
| `MatMulV2_5` | 3 | 142.583 |
| `MatMulV2_33` | 3 | 142.143 |
| `MatMulV2_27` | 3 | 140.882 |
| `MatMulV2_59` | 3 | 140.623 |
| `MatMulV2_25` | 3 | 140.223 |
| `MatMulV2_41` | 3 | 140.103 |
| `MatMulV2_15` | 3 | 139.522 |
| `MatMulV2_45` | 3 | 139.463 |
| `MatMulV2_35` | 3 | 139.403 |
| `MatMulV2_61` | 3 | 139.323 |
| `MatMulV2_57` | 3 | 139.303 |
| `MatMulV2_43` | 3 | 139.163 |
| `MatMulV2_23` | 3 | 138.743 |
| `MatMulV2_47` | 3 | 138.682 |
| `MatMulV2_37` | 3 | 138.603 |
| `MatMulV2_19` | 3 | 138.442 |
| `MatMulV2_51` | 3 | 138.343 |
| `MatMulV2_63` | 3 | 138.281 |
| `MatMulV2_55` | 3 | 138.263 |
| `MatMulV2_53` | 3 | 138.122 |
| `MatMulV2_31` | 3 | 137.883 |
| `MatMulV2_17` | 3 | 137.703 |
| `MatMulV2_11` | 3 | 137.663 |
| `MatMulV2_1` | 3 | 137.583 |
| `MatMulV2_3` | 3 | 135.542 |
| `MatMulV2_49` | 3 | 135.443 |
| `MatMulV2_29` | 3 | 135.402 |
| `MatMulV2_39` | 3 | 134.882 |
| `MatMulV2_21` | 3 | 133.983 |
| `GroupedMatmul_25` | 3 | 131.262 |
| `GroupedMatmul_21` | 3 | 130.623 |
| `GroupedMatmul_49` | 3 | 129.163 |
| `GroupedMatmul_55` | 3 | 126.942 |
| `GroupedMatmul_11` | 3 | 123.363 |
| `GroupedMatmul_27` | 3 | 122.882 |
| `GroupedMatmul_59` | 3 | 122.563 |
| `GroupedMatmul_13` | 3 | 121.742 |
| `GroupedMatmul_63` | 3 | 121.663 |
| `GroupedMatmul_41` | 3 | 121.543 |
| `GroupedMatmul_39` | 3 | 121.282 |
| `GroupedMatmul_1` | 3 | 121.143 |
| `GroupedMatmul_47` | 3 | 120.982 |
| `GroupedMatmul_37` | 3 | 120.843 |
| `GroupedMatmul_45` | 3 | 120.782 |
| `GroupedMatmul_9` | 3 | 120.741 |
| `GroupedMatmul_29` | 3 | 120.683 |
| `GroupedMatmul_57` | 3 | 120.643 |
| `GroupedMatmul_51` | 3 | 120.642 |
| `GroupedMatmul_33` | 3 | 120.562 |
| `GroupedMatmul_3` | 3 | 120.383 |
| `GroupedMatmul_53` | 3 | 120.262 |
| `GroupedMatmul_35` | 3 | 120.202 |
| `GroupedMatmul_17` | 3 | 120.141 |
| `GroupedMatmul_19` | 3 | 119.643 |
| `GroupedMatmul_7` | 3 | 119.522 |
| `GroupedMatmul_23` | 3 | 119.243 |
| `GroupedMatmul_61` | 3 | 118.661 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4446.525 |
| `GroupedMatmul | "768,1280;1,1280,5120;1,5120;;;;;1" -> "768,5120" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 3887.273 |
| `GroupedMatmul | "768,1280;1,1280,3840;1,3840;;;;;1" -> "768,3840" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 2996.483 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 1923.377 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_8` | 1 | 100.742 |
| `PromptFlashAttention_19` | 1 | 99.642 |
| `PromptFlashAttention_8` | 1 | 96.261 |
| `PromptFlashAttention_11` | 1 | 95.942 |
| `PromptFlashAttention_20` | 1 | 95.282 |
| `PromptFlashAttention_1` | 1 | 94.162 |
| `PromptFlashAttention_12` | 1 | 93.682 |
| `PromptFlashAttention_15` | 1 | 92.962 |
| `PromptFlashAttention_16` | 1 | 92.861 |
| `PromptFlashAttention_2` | 1 | 92.702 |
| `PromptFlashAttention_16` | 1 | 92.542 |
| `PromptFlashAttention_24` | 1 | 92.402 |
| `PromptFlashAttention_20` | 1 | 92.162 |
| `PromptFlashAttention_12` | 1 | 91.721 |
| `PromptFlashAttention_2` | 1 | 91.302 |
| `PromptFlashAttention_24` | 1 | 91.062 |
| `PromptFlashAttention_22` | 1 | 90.022 |
| `PromptFlashAttention_24` | 1 | 89.302 |
| `PromptFlashAttention_30` | 1 | 88.301 |
| `PromptFlashAttention_22` | 1 | 88.201 |
| `PromptFlashAttention_7` | 1 | 87.861 |
| `PromptFlashAttention_9` | 1 | 87.762 |
| `PromptFlashAttention_22` | 1 | 87.722 |
| `PromptFlashAttention_30` | 1 | 87.541 |
| `PromptFlashAttention_3` | 1 | 87.121 |
| `PromptFlashAttention_30` | 1 | 86.422 |
| `PromptFlashAttention_3` | 1 | 86.282 |
| `PromptFlashAttention` | 1 | 86.242 |
| `PromptFlashAttention_3` | 1 | 86.202 |
| `PromptFlashAttention` | 1 | 85.581 |
| `PromptFlashAttention` | 1 | 85.482 |
| `PromptFlashAttention_8` | 1 | 85.481 |
| `PromptFlashAttention_19` | 1 | 84.902 |
| `PromptFlashAttention_9` | 1 | 84.882 |
| `PromptFlashAttention_31` | 1 | 84.841 |
| `PromptFlashAttention_19` | 1 | 84.701 |
| `PromptFlashAttention_29` | 1 | 84.682 |
| `PromptFlashAttention_29` | 1 | 84.682 |
| `PromptFlashAttention_31` | 1 | 84.161 |
| `PromptFlashAttention_29` | 1 | 83.982 |
| `PromptFlashAttention_7` | 1 | 83.921 |
| `PromptFlashAttention_31` | 1 | 83.742 |
| `PromptFlashAttention_11` | 1 | 83.702 |
| `PromptFlashAttention_12` | 1 | 83.582 |
| `PromptFlashAttention_20` | 1 | 83.542 |
| `PromptFlashAttention_23` | 1 | 83.501 |
| `PromptFlashAttention_7` | 1 | 83.401 |
| `PromptFlashAttention_9` | 1 | 83.282 |
| `PromptFlashAttention_28` | 1 | 83.262 |
| `PromptFlashAttention_23` | 1 | 83.142 |
| `PromptFlashAttention_23` | 1 | 83.122 |
| `PromptFlashAttention_11` | 1 | 83.101 |
| `PromptFlashAttention_18` | 1 | 82.742 |
| `PromptFlashAttention_17` | 1 | 82.361 |
| `PromptFlashAttention_15` | 1 | 82.141 |
| `PromptFlashAttention_25` | 1 | 81.901 |
| `PromptFlashAttention_25` | 1 | 81.841 |
| `PromptFlashAttention_25` | 1 | 81.622 |
| `PromptFlashAttention_6` | 1 | 81.562 |
| `PromptFlashAttention_17` | 1 | 81.561 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 19664.683 |
| `TorchDynamo Cache Lookup` | 3 | 18752.023 |
| `Torch-Compiled Region: 0/0` | 3 | 1389.410 |
| `TorchNpuGraphBase::Run` | 3 | 743.320 |
| `ExecuteGraph` | 3 | 271.870 |
| `RefreshAtTensorFromGeTensor` | 3 | 163.500 |
| `AssembleInputs` | 3 | 134.240 |
| `aten::empty` | 3 | 74.710 |
| `empty_tensor` | 3 | 43.140 |
| `aten::set_` | 3 | 41.150 |
| `AssembleOutputs` | 3 | 40.920 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 290667.750 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 55988.790 |
| `launch` | 1378 | 23497.850 |
| `InputCopy` | 3 | 125.920 |
| `ModelExecute` | 3 | 88.280 |
| `step_info` | 6 | 48.960 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 25.430 |
| `OutputCopy` | 3 | 1.760 |

