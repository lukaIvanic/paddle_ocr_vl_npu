# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_mlp_fc1_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_mlp_fc1_crop_1_bucket_3072/profile/liteserver-c001-4_200588_20261007142212293_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `50636.732 us`
- `Free`: `950.499 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `877.250 us`
- `Stage`: `51587.250 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50126.366 |
| `GroupedMatmul` | 192 | 21251.524 |
| `StridedSliceD` | 384 | 13512.153 |
| `MatMulV3` | 96 | 12299.206 |
| `Transpose` | 480 | 9719.209 |
| `Mul` | 576 | 7822.182 |
| `AutomaticBufferFusionOp` | 480 | 6732.467 |
| `MatMulV2` | 96 | 6361.884 |
| `Add` | 384 | 5378.752 |
| `ReduceMeanD` | 384 | 5028.253 |
| `Sub` | 192 | 3417.290 |
| `ConcatV2D` | 192 | 2643.596 |
| `Cast` | 195 | 2288.785 |
| `Neg` | 192 | 2155.141 |
| `Unpack` | 96 | 2082.944 |
| `ConfusionTransposeD` | 96 | 981.780 |
| `Data` | 1 | 5.840 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_21` | 3 | 1595.052 |
| `PromptFlashAttention_8` | 3 | 1591.232 |
| `PromptFlashAttention_9` | 3 | 1589.891 |
| `PromptFlashAttention_23` | 3 | 1585.331 |
| `PromptFlashAttention_31` | 3 | 1581.431 |
| `PromptFlashAttention_18` | 3 | 1579.412 |
| `PromptFlashAttention_12` | 3 | 1576.472 |
| `PromptFlashAttention_1` | 3 | 1576.453 |
| `PromptFlashAttention_29` | 3 | 1576.332 |
| `PromptFlashAttention` | 3 | 1575.433 |
| `PromptFlashAttention_22` | 3 | 1572.772 |
| `PromptFlashAttention_11` | 3 | 1572.752 |
| `PromptFlashAttention_15` | 3 | 1572.332 |
| `PromptFlashAttention_30` | 3 | 1570.730 |
| `PromptFlashAttention_26` | 3 | 1570.412 |
| `PromptFlashAttention_19` | 3 | 1569.350 |
| `PromptFlashAttention_20` | 3 | 1565.691 |
| `PromptFlashAttention_24` | 3 | 1563.991 |
| `PromptFlashAttention_5` | 3 | 1563.551 |
| `PromptFlashAttention_7` | 3 | 1560.812 |
| `PromptFlashAttention_28` | 3 | 1559.151 |
| `PromptFlashAttention_4` | 3 | 1557.592 |
| `PromptFlashAttention_3` | 3 | 1557.311 |
| `PromptFlashAttention_13` | 3 | 1556.251 |
| `PromptFlashAttention_6` | 3 | 1554.951 |
| `PromptFlashAttention_10` | 3 | 1554.631 |
| `PromptFlashAttention_17` | 3 | 1549.511 |
| `PromptFlashAttention_14` | 3 | 1548.471 |
| `PromptFlashAttention_27` | 3 | 1545.331 |
| `PromptFlashAttention_25` | 3 | 1545.292 |
| `PromptFlashAttention_16` | 3 | 1545.151 |
| `PromptFlashAttention_2` | 3 | 1543.291 |
| `MatMulV2_63_to_v3` | 3 | 392.307 |
| `MatMulV2_39_to_v3` | 3 | 392.027 |
| `MatMulV2_1_to_v3` | 3 | 389.129 |
| `MatMulV2_3_to_v3` | 3 | 386.329 |
| `MatMulV2_17_to_v3` | 3 | 385.768 |
| `MatMulV2_45_to_v3` | 3 | 385.707 |
| `MatMulV2_53_to_v3` | 3 | 385.207 |
| `MatMulV2_15_to_v3` | 3 | 385.088 |
| `MatMulV2_49_to_v3` | 3 | 384.408 |
| `MatMulV2_55_to_v3` | 3 | 384.127 |
| `GroupedMatmul_47` | 3 | 384.088 |
| `MatMulV2_19_to_v3` | 3 | 384.048 |
| `MatMulV2_47_to_v3` | 3 | 383.987 |
| `MatMulV2_41_to_v3` | 3 | 383.909 |
| `MatMulV2_59_to_v3` | 3 | 383.907 |
| `MatMulV2_25_to_v3` | 3 | 383.827 |
| `MatMulV2_27_to_v3` | 3 | 383.787 |
| `MatMulV2_51_to_v3` | 3 | 383.768 |
| `MatMulV2_35_to_v3` | 3 | 383.728 |
| `MatMulV2_29_to_v3` | 3 | 383.568 |
| `MatMulV2_11_to_v3` | 3 | 383.548 |
| `MatMulV2_7_to_v3` | 3 | 383.388 |
| `MatMulV2_43_to_v3` | 3 | 383.289 |
| `MatMulV2_23_to_v3` | 3 | 383.028 |
| `MatMulV2_9_to_v3` | 3 | 382.887 |
| `MatMulV2_33_to_v3` | 3 | 382.807 |
| `MatMulV2_37_to_v3` | 3 | 382.747 |
| `MatMulV2_57_to_v3` | 3 | 382.388 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_63_to_v3` | 3 | 392.307 |
| `MatMulV2_39_to_v3` | 3 | 392.027 |
| `MatMulV2_1_to_v3` | 3 | 389.129 |
| `MatMulV2_3_to_v3` | 3 | 386.329 |
| `MatMulV2_17_to_v3` | 3 | 385.768 |
| `MatMulV2_45_to_v3` | 3 | 385.707 |
| `MatMulV2_53_to_v3` | 3 | 385.207 |
| `MatMulV2_15_to_v3` | 3 | 385.088 |
| `MatMulV2_49_to_v3` | 3 | 384.408 |
| `MatMulV2_55_to_v3` | 3 | 384.127 |
| `GroupedMatmul_47` | 3 | 384.088 |
| `MatMulV2_19_to_v3` | 3 | 384.048 |
| `MatMulV2_47_to_v3` | 3 | 383.987 |
| `MatMulV2_41_to_v3` | 3 | 383.909 |
| `MatMulV2_59_to_v3` | 3 | 383.907 |
| `MatMulV2_25_to_v3` | 3 | 383.827 |
| `MatMulV2_27_to_v3` | 3 | 383.787 |
| `MatMulV2_51_to_v3` | 3 | 383.768 |
| `MatMulV2_35_to_v3` | 3 | 383.728 |
| `MatMulV2_29_to_v3` | 3 | 383.568 |
| `MatMulV2_11_to_v3` | 3 | 383.548 |
| `MatMulV2_7_to_v3` | 3 | 383.388 |
| `MatMulV2_43_to_v3` | 3 | 383.289 |
| `MatMulV2_23_to_v3` | 3 | 383.028 |
| `MatMulV2_9_to_v3` | 3 | 382.887 |
| `MatMulV2_33_to_v3` | 3 | 382.807 |
| `MatMulV2_37_to_v3` | 3 | 382.747 |
| `MatMulV2_57_to_v3` | 3 | 382.388 |
| `MatMulV2_31_to_v3` | 3 | 382.308 |
| `MatMulV2_21_to_v3` | 3 | 382.248 |
| `MatMulV2_61_to_v3` | 3 | 382.147 |
| `MatMulV2_13_to_v3` | 3 | 382.068 |
| `MatMulV2_5_to_v3` | 3 | 381.727 |
| `GroupedMatmul_31` | 3 | 377.828 |
| `GroupedMatmul_51` | 3 | 377.627 |
| `GroupedMatmul_61` | 3 | 377.528 |
| `GroupedMatmul_23` | 3 | 377.248 |
| `GroupedMatmul_21` | 3 | 376.248 |
| `GroupedMatmul_43` | 3 | 375.807 |
| `GroupedMatmul_41` | 3 | 375.627 |
| `GroupedMatmul_35` | 3 | 375.587 |
| `GroupedMatmul_5` | 3 | 375.189 |
| `GroupedMatmul_63` | 3 | 375.109 |
| `GroupedMatmul_9` | 3 | 374.808 |
| `GroupedMatmul_37` | 3 | 374.747 |
| `GroupedMatmul_1` | 3 | 374.666 |
| `GroupedMatmul_29` | 3 | 374.568 |
| `GroupedMatmul_13` | 3 | 374.487 |
| `GroupedMatmul_19` | 3 | 374.187 |
| `GroupedMatmul_27` | 3 | 374.127 |
| `GroupedMatmul_17` | 3 | 373.987 |
| `GroupedMatmul_15` | 3 | 373.807 |
| `GroupedMatmul_7` | 3 | 373.747 |
| `GroupedMatmul_49` | 3 | 373.528 |
| `GroupedMatmul_25` | 3 | 373.347 |
| `GroupedMatmul_3` | 3 | 373.287 |
| `GroupedMatmul_39` | 3 | 372.668 |
| `GroupedMatmul_57` | 3 | 372.487 |
| `GroupedMatmul_53` | 3 | 372.289 |
| `GroupedMatmul_55` | 3 | 371.668 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12299.206 |
| `GroupedMatmul | "3072,1280;1,1280,5120;1,5120;;;;;1" -> "3072,5120" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 11981.980 |
| `GroupedMatmul | "3072,1280;1,1280,3840;1,3840;;;;;1" -> "3072,3840" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 9269.544 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6361.884 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_21` | 1 | 533.950 |
| `PromptFlashAttention_9` | 1 | 532.751 |
| `PromptFlashAttention_8` | 1 | 530.931 |
| `PromptFlashAttention_8` | 1 | 530.651 |
| `PromptFlashAttention_21` | 1 | 530.651 |
| `PromptFlashAttention_21` | 1 | 530.451 |
| `PromptFlashAttention_9` | 1 | 530.230 |
| `PromptFlashAttention_18` | 1 | 529.990 |
| `PromptFlashAttention` | 1 | 529.811 |
| `PromptFlashAttention_8` | 1 | 529.650 |
| `PromptFlashAttention_1` | 1 | 528.831 |
| `PromptFlashAttention_23` | 1 | 528.810 |
| `PromptFlashAttention_23` | 1 | 528.570 |
| `PromptFlashAttention_26` | 1 | 528.391 |
| `PromptFlashAttention_31` | 1 | 528.110 |
| `PromptFlashAttention_15` | 1 | 528.051 |
| `PromptFlashAttention_23` | 1 | 527.951 |
| `PromptFlashAttention_12` | 1 | 527.251 |
| `PromptFlashAttention_31` | 1 | 527.110 |
| `PromptFlashAttention_9` | 1 | 526.910 |
| `PromptFlashAttention_29` | 1 | 526.251 |
| `PromptFlashAttention_31` | 1 | 526.211 |
| `PromptFlashAttention_12` | 1 | 526.131 |
| `PromptFlashAttention_29` | 1 | 525.471 |
| `PromptFlashAttention_22` | 1 | 525.011 |
| `PromptFlashAttention_18` | 1 | 524.931 |
| `PromptFlashAttention_22` | 1 | 524.610 |
| `PromptFlashAttention_29` | 1 | 524.610 |
| `PromptFlashAttention_11` | 1 | 524.531 |
| `PromptFlashAttention_18` | 1 | 524.491 |
| `PromptFlashAttention_1` | 1 | 524.491 |
| `PromptFlashAttention_19` | 1 | 524.430 |
| `PromptFlashAttention_11` | 1 | 524.130 |
| `PromptFlashAttention_11` | 1 | 524.091 |
| `PromptFlashAttention_30` | 1 | 523.890 |
| `PromptFlashAttention_30` | 1 | 523.810 |
| `PromptFlashAttention` | 1 | 523.271 |
| `PromptFlashAttention_22` | 1 | 523.151 |
| `PromptFlashAttention_1` | 1 | 523.131 |
| `PromptFlashAttention_12` | 1 | 523.090 |
| `PromptFlashAttention_24` | 1 | 523.071 |
| `PromptFlashAttention_30` | 1 | 523.030 |
| `PromptFlashAttention_20` | 1 | 522.970 |
| `PromptFlashAttention_19` | 1 | 522.810 |
| `PromptFlashAttention_15` | 1 | 522.591 |
| `PromptFlashAttention` | 1 | 522.351 |
| `PromptFlashAttention_5` | 1 | 522.251 |
| `PromptFlashAttention_19` | 1 | 522.110 |
| `PromptFlashAttention_15` | 1 | 521.690 |
| `PromptFlashAttention_26` | 1 | 521.630 |
| `PromptFlashAttention_20` | 1 | 521.611 |
| `PromptFlashAttention_13` | 1 | 521.370 |
| `PromptFlashAttention_28` | 1 | 521.350 |
| `PromptFlashAttention_20` | 1 | 521.110 |
| `PromptFlashAttention_24` | 1 | 520.990 |
| `PromptFlashAttention_7` | 1 | 520.951 |
| `PromptFlashAttention_5` | 1 | 520.910 |
| `PromptFlashAttention_7` | 1 | 520.471 |
| `PromptFlashAttention_26` | 1 | 520.391 |
| `PromptFlashAttention_5` | 1 | 520.390 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 51764.702 |
| `TorchDynamo Cache Lookup` | 3 | 50739.371 |
| `Torch-Compiled Region: 0/0` | 3 | 1481.740 |
| `TorchNpuGraphBase::Run` | 3 | 804.540 |
| `ExecuteGraph` | 3 | 285.320 |
| `RefreshAtTensorFromGeTensor` | 3 | 178.260 |
| `AssembleInputs` | 3 | 147.630 |
| `aten::empty` | 3 | 88.310 |
| `empty_tensor` | 3 | 47.810 |
| `AssembleOutputs` | 3 | 47.710 |
| `aten::set_` | 3 | 41.410 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 291366.630 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 151856.470 |
| `launch` | 1378 | 22940.080 |
| `InputCopy` | 3 | 131.640 |
| `ModelExecute` | 3 | 99.480 |
| `step_info` | 6 | 57.210 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 25.160 |
| `OutputCopy` | 3 | 1.740 |

