# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_mlp_fc1_nz_weights_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_mlp_fc1_nz_weights_crop_0_bucket_768/profile/liteserver-c001-4_202567_20261007142400972_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `20514.540 us`
- `Free`: `859.207 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `814.250 us`
- `Stage`: `21374.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `GroupedMatmul` | 192 | 8391.947 |
| `PromptFlashAttention` | 96 | 8135.841 |
| `MatMulV2` | 192 | 7500.168 |
| `Transpose` | 480 | 6470.115 |
| `StridedSliceD` | 384 | 5467.035 |
| `Mul` | 576 | 4326.647 |
| `TransData` | 192 | 4058.376 |
| `Add` | 384 | 3380.968 |
| `AutomaticBufferFusionOp` | 480 | 3196.179 |
| `ReduceMeanD` | 384 | 2559.854 |
| `Sub` | 192 | 1858.504 |
| `Neg` | 192 | 1576.453 |
| `ConcatV2D` | 192 | 1572.028 |
| `Cast` | 195 | 1543.165 |
| `Unpack` | 96 | 825.737 |
| `ConfusionTransposeD` | 96 | 495.172 |
| `Data` | 1 | 7.360 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_15` | 3 | 288.805 |
| `PromptFlashAttention_5` | 3 | 285.546 |
| `PromptFlashAttention_24` | 3 | 281.646 |
| `PromptFlashAttention_16` | 3 | 278.726 |
| `PromptFlashAttention` | 3 | 277.406 |
| `PromptFlashAttention_6` | 3 | 272.506 |
| `PromptFlashAttention_25` | 3 | 272.185 |
| `PromptFlashAttention_19` | 3 | 268.525 |
| `PromptFlashAttention_23` | 3 | 263.585 |
| `PromptFlashAttention_10` | 3 | 262.565 |
| `PromptFlashAttention_28` | 3 | 262.546 |
| `PromptFlashAttention_27` | 3 | 259.526 |
| `PromptFlashAttention_26` | 3 | 257.284 |
| `PromptFlashAttention_11` | 3 | 256.865 |
| `PromptFlashAttention_2` | 3 | 252.546 |
| `PromptFlashAttention_17` | 3 | 251.266 |
| `PromptFlashAttention_3` | 3 | 249.604 |
| `PromptFlashAttention_8` | 3 | 248.344 |
| `PromptFlashAttention_13` | 3 | 247.386 |
| `PromptFlashAttention_14` | 3 | 246.345 |
| `PromptFlashAttention_12` | 3 | 246.165 |
| `PromptFlashAttention_30` | 3 | 243.064 |
| `PromptFlashAttention_7` | 3 | 242.726 |
| `PromptFlashAttention_22` | 3 | 239.343 |
| `PromptFlashAttention_31` | 3 | 239.163 |
| `PromptFlashAttention_21` | 3 | 237.285 |
| `PromptFlashAttention_29` | 3 | 236.425 |
| `PromptFlashAttention_4` | 3 | 236.125 |
| `PromptFlashAttention_9` | 3 | 235.984 |
| `PromptFlashAttention_18` | 3 | 233.884 |
| `PromptFlashAttention_20` | 3 | 231.584 |
| `PromptFlashAttention_1` | 3 | 230.886 |
| `GroupedMatmul_7` | 3 | 160.563 |
| `MatMulV2_33` | 3 | 156.663 |
| `GroupedMatmul_3` | 3 | 156.103 |
| `GroupedMatmul_57` | 3 | 155.343 |
| `GroupedMatmul_9` | 3 | 154.623 |
| `GroupedMatmul_5` | 3 | 153.763 |
| `MatMulV2_39` | 3 | 152.883 |
| `MatMulV2_23` | 3 | 152.843 |
| `MatMulV2_59` | 3 | 152.723 |
| `MatMulV2_19` | 3 | 152.503 |
| `GroupedMatmul_25` | 3 | 151.623 |
| `MatMulV2_47` | 3 | 151.623 |
| `MatMulV2_57` | 3 | 151.563 |
| `MatMulV2_55` | 3 | 151.483 |
| `MatMulV2_27` | 3 | 151.383 |
| `MatMulV2_7` | 3 | 151.304 |
| `MatMulV2_43` | 3 | 151.243 |
| `MatMulV2_31` | 3 | 151.224 |
| `MatMulV2_29` | 3 | 151.143 |
| `MatMulV2_37` | 3 | 151.063 |
| `MatMulV2_21` | 3 | 150.983 |
| `MatMulV2_51` | 3 | 150.943 |
| `MatMulV2_13` | 3 | 150.884 |
| `MatMulV2_41` | 3 | 150.883 |
| `MatMulV2_61` | 3 | 150.363 |
| `MatMulV2_15` | 3 | 149.963 |
| `GroupedMatmul_21` | 3 | 149.863 |
| `GroupedMatmul_35` | 3 | 149.663 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `GroupedMatmul_7` | 3 | 160.563 |
| `MatMulV2_33` | 3 | 156.663 |
| `GroupedMatmul_3` | 3 | 156.103 |
| `GroupedMatmul_57` | 3 | 155.343 |
| `GroupedMatmul_9` | 3 | 154.623 |
| `GroupedMatmul_5` | 3 | 153.763 |
| `MatMulV2_39` | 3 | 152.883 |
| `MatMulV2_23` | 3 | 152.843 |
| `MatMulV2_59` | 3 | 152.723 |
| `MatMulV2_19` | 3 | 152.503 |
| `GroupedMatmul_25` | 3 | 151.623 |
| `MatMulV2_47` | 3 | 151.623 |
| `MatMulV2_57` | 3 | 151.563 |
| `MatMulV2_55` | 3 | 151.483 |
| `MatMulV2_27` | 3 | 151.383 |
| `MatMulV2_7` | 3 | 151.304 |
| `MatMulV2_43` | 3 | 151.243 |
| `MatMulV2_31` | 3 | 151.224 |
| `MatMulV2_29` | 3 | 151.143 |
| `MatMulV2_37` | 3 | 151.063 |
| `MatMulV2_21` | 3 | 150.983 |
| `MatMulV2_51` | 3 | 150.943 |
| `MatMulV2_13` | 3 | 150.884 |
| `MatMulV2_41` | 3 | 150.883 |
| `MatMulV2_61` | 3 | 150.363 |
| `MatMulV2_15` | 3 | 149.963 |
| `GroupedMatmul_21` | 3 | 149.863 |
| `GroupedMatmul_35` | 3 | 149.663 |
| `MatMulV2_49` | 3 | 149.343 |
| `GroupedMatmul_13` | 3 | 149.283 |
| `GroupedMatmul_11` | 3 | 149.003 |
| `MatMulV2_5` | 3 | 148.943 |
| `MatMulV2_9` | 3 | 148.903 |
| `MatMulV2_17` | 3 | 148.743 |
| `GroupedMatmul_15` | 3 | 148.643 |
| `MatMulV2_25` | 3 | 148.283 |
| `GroupedMatmul_17` | 3 | 148.223 |
| `MatMulV2_45` | 3 | 147.923 |
| `GroupedMatmul_63` | 3 | 147.803 |
| `GroupedMatmul_49` | 3 | 147.783 |
| `MatMulV2_35` | 3 | 147.763 |
| `GroupedMatmul_39` | 3 | 147.763 |
| `GroupedMatmul_55` | 3 | 147.763 |
| `GroupedMatmul_53` | 3 | 147.743 |
| `GroupedMatmul_45` | 3 | 147.643 |
| `GroupedMatmul_27` | 3 | 147.623 |
| `MatMulV2_53` | 3 | 147.543 |
| `GroupedMatmul_59` | 3 | 147.383 |
| `MatMulV2_11` | 3 | 147.343 |
| `GroupedMatmul_29` | 3 | 147.183 |
| `GroupedMatmul_37` | 3 | 147.043 |
| `GroupedMatmul_41` | 3 | 147.003 |
| `GroupedMatmul_61` | 3 | 146.983 |
| `GroupedMatmul_19` | 3 | 146.942 |
| `GroupedMatmul_47` | 3 | 146.903 |
| `MatMulV2_1` | 3 | 146.722 |
| `GroupedMatmul_31` | 3 | 146.683 |
| `MatMulV2_3` | 3 | 146.543 |
| `MatMulV2_63` | 3 | 146.423 |
| `GroupedMatmul_33` | 3 | 144.762 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;320,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4808.138 |
| `GroupedMatmul | "768,1280;1,1280,5120;1,5120;;;;;1" -> "768,5120" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 4726.153 |
| `GroupedMatmul | "768,1280;1,1280,3840;1,3840;;;;;1" -> "768,3840" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 3665.794 |
| `MatMulV2 | "768,1280;80,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 2692.030 |

### TransData Names
| name | count | total_us |
|---|---:|---:|
| `trans_TransData_36` | 3 | 87.482 |
| `trans_TransData_56` | 3 | 83.082 |
| `trans_TransData_39` | 3 | 81.883 |
| `trans_TransData_55` | 3 | 81.183 |
| `trans_TransData_52` | 3 | 80.863 |
| `trans_TransData_63` | 3 | 78.882 |
| `trans_TransData_51` | 3 | 77.802 |
| `trans_TransData_40` | 3 | 76.862 |
| `trans_TransData_43` | 3 | 76.662 |
| `trans_TransData_58` | 3 | 76.203 |
| `trans_TransData_37` | 3 | 75.862 |
| `trans_TransData_47` | 3 | 75.402 |
| `trans_TransData_42` | 3 | 75.262 |
| `trans_TransData_54` | 3 | 75.223 |
| `trans_TransData_65` | 3 | 75.122 |
| `trans_TransData_49` | 3 | 74.102 |
| `trans_TransData_34` | 3 | 74.081 |
| `trans_TransData_53` | 3 | 72.842 |
| `trans_TransData_50` | 3 | 71.662 |
| `trans_TransData_61` | 3 | 71.522 |
| `trans_TransData_62` | 3 | 70.722 |
| `trans_TransData_44` | 3 | 70.381 |
| `trans_TransData_45` | 3 | 68.281 |
| `trans_TransData_60` | 3 | 68.281 |
| `trans_TransData_59` | 3 | 67.942 |
| `trans_TransData_57` | 3 | 67.922 |
| `trans_TransData_46` | 3 | 66.342 |
| `trans_TransData_35` | 3 | 66.181 |
| `trans_TransData_64` | 3 | 66.122 |
| `trans_TransData_41` | 3 | 65.562 |
| `trans_TransData_38` | 3 | 64.022 |
| `trans_TransData_48` | 3 | 63.001 |
| `trans_TransData_10` | 3 | 62.022 |
| `trans_TransData_30` | 3 | 61.761 |
| `trans_TransData_27` | 3 | 60.302 |
| `trans_TransData_25` | 3 | 59.841 |
| `trans_TransData_26` | 3 | 59.621 |
| `trans_TransData_5` | 3 | 57.340 |
| `trans_TransData_14` | 3 | 56.720 |
| `trans_TransData_32` | 3 | 56.381 |
| `trans_TransData_15` | 3 | 56.301 |
| `trans_TransData_31` | 3 | 55.901 |
| `trans_TransData_4` | 3 | 55.621 |
| `trans_TransData_29` | 3 | 55.361 |
| `trans_TransData_3` | 3 | 55.121 |
| `trans_TransData_33` | 3 | 54.602 |
| `trans_TransData_6` | 3 | 54.461 |
| `trans_TransData_17` | 3 | 54.221 |
| `trans_TransData_19` | 3 | 53.801 |
| `trans_TransData_20` | 3 | 53.261 |
| `trans_TransData_18` | 3 | 52.821 |
| `trans_TransData_2` | 3 | 52.400 |
| `trans_TransData_24` | 3 | 52.141 |
| `trans_TransData_7` | 3 | 51.180 |
| `trans_TransData_23` | 3 | 51.141 |
| `trans_TransData_28` | 3 | 50.721 |
| `trans_TransData_22` | 3 | 50.462 |
| `trans_TransData_21` | 3 | 50.362 |
| `trans_TransData_16` | 3 | 50.360 |
| `trans_TransData_13` | 3 | 47.280 |

### TransData Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `TransData | "80,320,16,16" -> "5120,1280" | FRACTAL_NZ -> ND` | 96 | 2346.743 |
| `TransData | "80,240,16,16" -> "3840,1280" | FRACTAL_NZ -> ND` | 96 | 1711.633 |

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_15` | 1 | 98.982 |
| `PromptFlashAttention_15` | 1 | 96.161 |
| `PromptFlashAttention_5` | 1 | 95.342 |
| `PromptFlashAttention_5` | 1 | 95.202 |
| `PromptFlashAttention_5` | 1 | 95.002 |
| `PromptFlashAttention_24` | 1 | 94.182 |
| `PromptFlashAttention_24` | 1 | 93.882 |
| `PromptFlashAttention_16` | 1 | 93.702 |
| `PromptFlashAttention_15` | 1 | 93.662 |
| `PromptFlashAttention_24` | 1 | 93.582 |
| `PromptFlashAttention_16` | 1 | 93.182 |
| `PromptFlashAttention` | 1 | 92.782 |
| `PromptFlashAttention` | 1 | 92.742 |
| `PromptFlashAttention` | 1 | 91.882 |
| `PromptFlashAttention_16` | 1 | 91.842 |
| `PromptFlashAttention_6` | 1 | 91.602 |
| `PromptFlashAttention_25` | 1 | 91.582 |
| `PromptFlashAttention_25` | 1 | 90.942 |
| `PromptFlashAttention_6` | 1 | 90.742 |
| `PromptFlashAttention_19` | 1 | 90.402 |
| `PromptFlashAttention_6` | 1 | 90.162 |
| `PromptFlashAttention_19` | 1 | 89.741 |
| `PromptFlashAttention_25` | 1 | 89.661 |
| `PromptFlashAttention_28` | 1 | 89.642 |
| `PromptFlashAttention_10` | 1 | 88.962 |
| `PromptFlashAttention_23` | 1 | 88.401 |
| `PromptFlashAttention_19` | 1 | 88.382 |
| `PromptFlashAttention_23` | 1 | 87.922 |
| `PromptFlashAttention_10` | 1 | 87.742 |
| `PromptFlashAttention_27` | 1 | 87.562 |
| `PromptFlashAttention_23` | 1 | 87.262 |
| `PromptFlashAttention_27` | 1 | 86.882 |
| `PromptFlashAttention_28` | 1 | 86.522 |
| `PromptFlashAttention_28` | 1 | 86.382 |
| `PromptFlashAttention_26` | 1 | 86.341 |
| `PromptFlashAttention_11` | 1 | 85.962 |
| `PromptFlashAttention_10` | 1 | 85.861 |
| `PromptFlashAttention_26` | 1 | 85.742 |
| `PromptFlashAttention_11` | 1 | 85.582 |
| `PromptFlashAttention_11` | 1 | 85.321 |
| `PromptFlashAttention_26` | 1 | 85.201 |
| `PromptFlashAttention_27` | 1 | 85.082 |
| `PromptFlashAttention_3` | 1 | 84.661 |
| `PromptFlashAttention_2` | 1 | 84.502 |
| `PromptFlashAttention_17` | 1 | 84.482 |
| `PromptFlashAttention_2` | 1 | 84.282 |
| `PromptFlashAttention_2` | 1 | 83.762 |
| `PromptFlashAttention_17` | 1 | 83.522 |
| `PromptFlashAttention_8` | 1 | 83.341 |
| `PromptFlashAttention_17` | 1 | 83.262 |
| `PromptFlashAttention_3` | 1 | 83.041 |
| `PromptFlashAttention_13` | 1 | 82.882 |
| `PromptFlashAttention_8` | 1 | 82.841 |
| `PromptFlashAttention_13` | 1 | 82.702 |
| `PromptFlashAttention_14` | 1 | 82.542 |
| `PromptFlashAttention_12` | 1 | 82.382 |
| `PromptFlashAttention_30` | 1 | 82.181 |
| `PromptFlashAttention_8` | 1 | 82.162 |
| `PromptFlashAttention_14` | 1 | 82.161 |
| `PromptFlashAttention_12` | 1 | 82.061 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 21458.840 |
| `TorchDynamo Cache Lookup` | 3 | 20593.300 |
| `Torch-Compiled Region: 0/0` | 3 | 1289.360 |
| `TorchNpuGraphBase::Run` | 3 | 667.620 |
| `ExecuteGraph` | 3 | 211.960 |
| `RefreshAtTensorFromGeTensor` | 3 | 174.500 |
| `AssembleInputs` | 3 | 150.350 |
| `aten::set_` | 3 | 65.980 |
| `aten::empty` | 3 | 64.030 |
| `empty_tensor` | 3 | 33.910 |
| `AssembleOutputs` | 3 | 26.580 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 293649.840 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 61462.230 |
| `launch` | 1442 | 23292.890 |
| `InputCopy` | 3 | 100.430 |
| `ModelExecute` | 3 | 75.210 |
| `step_info` | 6 | 45.590 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 17.740 |
| `OutputCopy` | 3 | 1.080 |

