# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_mlp_fc1_nz_weights_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_mlp_fc1_nz_weights_crop_1_bucket_3072/profile/liteserver-c001-4_204492_20261007142540586_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `52779.808 us`
- `Free`: `1097.629 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `1481.500 us`
- `Stage`: `53877.500 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50160.676 |
| `GroupedMatmul` | 192 | 22398.005 |
| `MatMulV2` | 192 | 21204.798 |
| `StridedSliceD` | 384 | 13740.399 |
| `Transpose` | 480 | 8199.388 |
| `Mul` | 576 | 7758.524 |
| `AutomaticBufferFusionOp` | 480 | 6557.707 |
| `Add` | 384 | 5427.189 |
| `ReduceMeanD` | 384 | 4946.300 |
| `TransData` | 192 | 4163.394 |
| `Sub` | 192 | 3423.366 |
| `ConcatV2D` | 192 | 2635.868 |
| `Cast` | 195 | 2302.487 |
| `Unpack` | 96 | 2072.147 |
| `Neg` | 192 | 2071.883 |
| `ConfusionTransposeD` | 96 | 972.322 |
| `Data` | 1 | 7.300 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_31` | 3 | 1611.251 |
| `PromptFlashAttention_9` | 3 | 1602.852 |
| `PromptFlashAttention_21` | 3 | 1589.270 |
| `PromptFlashAttention_1` | 3 | 1588.912 |
| `PromptFlashAttention_12` | 3 | 1584.051 |
| `PromptFlashAttention_3` | 3 | 1580.670 |
| `PromptFlashAttention_8` | 3 | 1579.912 |
| `PromptFlashAttention_30` | 3 | 1579.533 |
| `PromptFlashAttention_7` | 3 | 1577.771 |
| `PromptFlashAttention_23` | 3 | 1575.611 |
| `PromptFlashAttention_24` | 3 | 1572.990 |
| `PromptFlashAttention_22` | 3 | 1569.512 |
| `PromptFlashAttention_29` | 3 | 1569.231 |
| `PromptFlashAttention` | 3 | 1568.711 |
| `PromptFlashAttention_11` | 3 | 1568.631 |
| `PromptFlashAttention_26` | 3 | 1567.152 |
| `PromptFlashAttention_18` | 3 | 1565.672 |
| `PromptFlashAttention_6` | 3 | 1565.591 |
| `PromptFlashAttention_20` | 3 | 1561.491 |
| `PromptFlashAttention_27` | 3 | 1559.831 |
| `PromptFlashAttention_14` | 3 | 1557.692 |
| `PromptFlashAttention_5` | 3 | 1557.272 |
| `PromptFlashAttention_19` | 3 | 1556.711 |
| `PromptFlashAttention_4` | 3 | 1556.232 |
| `PromptFlashAttention_10` | 3 | 1554.551 |
| `PromptFlashAttention_16` | 3 | 1554.230 |
| `PromptFlashAttention_28` | 3 | 1551.490 |
| `PromptFlashAttention_15` | 3 | 1550.570 |
| `PromptFlashAttention_13` | 3 | 1547.730 |
| `PromptFlashAttention_2` | 3 | 1546.251 |
| `PromptFlashAttention_25` | 3 | 1544.870 |
| `PromptFlashAttention_17` | 3 | 1544.432 |
| `MatMulV2_29` | 3 | 460.509 |
| `MatMulV2_57` | 3 | 456.469 |
| `MatMulV2_25` | 3 | 452.809 |
| `MatMulV2_19` | 3 | 452.769 |
| `MatMulV2_47` | 3 | 452.749 |
| `MatMulV2_31` | 3 | 452.349 |
| `MatMulV2_63` | 3 | 451.889 |
| `MatMulV2_13` | 3 | 450.709 |
| `MatMulV2_49` | 3 | 450.689 |
| `MatMulV2_61` | 3 | 450.589 |
| `MatMulV2_37` | 3 | 450.009 |
| `MatMulV2_33` | 3 | 449.869 |
| `MatMulV2_17` | 3 | 449.729 |
| `MatMulV2_23` | 3 | 448.869 |
| `MatMulV2_5` | 3 | 448.509 |
| `MatMulV2_7` | 3 | 448.069 |
| `MatMulV2_3` | 3 | 446.989 |
| `MatMulV2_53` | 3 | 446.989 |
| `MatMulV2_43` | 3 | 446.449 |
| `MatMulV2_9` | 3 | 446.309 |
| `MatMulV2_39` | 3 | 446.189 |
| `MatMulV2_41` | 3 | 446.128 |
| `MatMulV2_15` | 3 | 444.789 |
| `MatMulV2_35` | 3 | 444.569 |
| `MatMulV2_11` | 3 | 442.929 |
| `MatMulV2_51` | 3 | 442.589 |
| `MatMulV2_21` | 3 | 442.489 |
| `MatMulV2_55` | 3 | 442.129 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_29` | 3 | 460.509 |
| `MatMulV2_57` | 3 | 456.469 |
| `MatMulV2_25` | 3 | 452.809 |
| `MatMulV2_19` | 3 | 452.769 |
| `MatMulV2_47` | 3 | 452.749 |
| `MatMulV2_31` | 3 | 452.349 |
| `MatMulV2_63` | 3 | 451.889 |
| `MatMulV2_13` | 3 | 450.709 |
| `MatMulV2_49` | 3 | 450.689 |
| `MatMulV2_61` | 3 | 450.589 |
| `MatMulV2_37` | 3 | 450.009 |
| `MatMulV2_33` | 3 | 449.869 |
| `MatMulV2_17` | 3 | 449.729 |
| `MatMulV2_23` | 3 | 448.869 |
| `MatMulV2_5` | 3 | 448.509 |
| `MatMulV2_7` | 3 | 448.069 |
| `MatMulV2_3` | 3 | 446.989 |
| `MatMulV2_53` | 3 | 446.989 |
| `MatMulV2_43` | 3 | 446.449 |
| `MatMulV2_9` | 3 | 446.309 |
| `MatMulV2_39` | 3 | 446.189 |
| `MatMulV2_41` | 3 | 446.128 |
| `MatMulV2_15` | 3 | 444.789 |
| `MatMulV2_35` | 3 | 444.569 |
| `MatMulV2_11` | 3 | 442.929 |
| `MatMulV2_51` | 3 | 442.589 |
| `MatMulV2_21` | 3 | 442.489 |
| `MatMulV2_55` | 3 | 442.129 |
| `MatMulV2_45` | 3 | 441.449 |
| `MatMulV2_59` | 3 | 441.228 |
| `MatMulV2_1` | 3 | 440.609 |
| `MatMulV2_27` | 3 | 439.969 |
| `GroupedMatmul_11` | 3 | 403.269 |
| `GroupedMatmul_1` | 3 | 401.547 |
| `GroupedMatmul_15` | 3 | 398.508 |
| `GroupedMatmul_3` | 3 | 397.868 |
| `GroupedMatmul_7` | 3 | 397.507 |
| `GroupedMatmul_9` | 3 | 394.908 |
| `GroupedMatmul_59` | 3 | 394.887 |
| `GroupedMatmul_5` | 3 | 392.808 |
| `GroupedMatmul_25` | 3 | 391.988 |
| `GroupedMatmul_27` | 3 | 391.628 |
| `GroupedMatmul_57` | 3 | 391.508 |
| `GroupedMatmul_39` | 3 | 391.388 |
| `GroupedMatmul_35` | 3 | 391.089 |
| `GroupedMatmul_55` | 3 | 390.689 |
| `GroupedMatmul_41` | 3 | 390.548 |
| `GroupedMatmul_33` | 3 | 390.507 |
| `GroupedMatmul_51` | 3 | 390.186 |
| `GroupedMatmul_63` | 3 | 389.187 |
| `GroupedMatmul_43` | 3 | 388.967 |
| `GroupedMatmul_23` | 3 | 388.787 |
| `GroupedMatmul_61` | 3 | 388.609 |
| `GroupedMatmul_31` | 3 | 388.547 |
| `GroupedMatmul_13` | 3 | 388.349 |
| `GroupedMatmul_49` | 3 | 388.167 |
| `GroupedMatmul_21` | 3 | 388.147 |
| `GroupedMatmul_17` | 3 | 388.068 |
| `GroupedMatmul_19` | 3 | 387.768 |
| `GroupedMatmul_53` | 3 | 387.749 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "3072,5120;320,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 14328.386 |
| `GroupedMatmul | "3072,1280;1,1280,5120;1,5120;;;;;1" -> "3072,5120" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 12522.349 |
| `GroupedMatmul | "3072,1280;1,1280,3840;1,3840;;;;;1" -> "3072,3840" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 9875.656 |
| `MatMulV2 | "3072,1280;80,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 6876.412 |

### TransData Names
| name | count | total_us |
|---|---:|---:|
| `trans_TransData_36` | 3 | 85.482 |
| `trans_TransData_39` | 3 | 78.780 |
| `trans_TransData_47` | 3 | 77.921 |
| `trans_TransData_65` | 3 | 77.002 |
| `trans_TransData_58` | 3 | 76.902 |
| `trans_TransData_43` | 3 | 76.041 |
| `trans_TransData_59` | 3 | 75.681 |
| `trans_TransData_64` | 3 | 73.742 |
| `trans_TransData_55` | 3 | 73.722 |
| `trans_TransData_56` | 3 | 73.241 |
| `trans_TransData_41` | 3 | 73.101 |
| `trans_TransData_61` | 3 | 72.021 |
| `trans_TransData_45` | 3 | 71.981 |
| `trans_TransData_53` | 3 | 71.383 |
| `trans_TransData_54` | 3 | 71.282 |
| `trans_TransData_38` | 3 | 70.661 |
| `trans_TransData_57` | 3 | 70.101 |
| `trans_TransData_60` | 3 | 70.101 |
| `trans_TransData_46` | 3 | 69.821 |
| `trans_TransData_44` | 3 | 69.621 |
| `trans_TransData_51` | 3 | 69.383 |
| `trans_TransData_37` | 3 | 69.262 |
| `trans_TransData_42` | 3 | 68.581 |
| `trans_TransData_40` | 3 | 68.181 |
| `trans_TransData_34` | 3 | 68.162 |
| `trans_TransData_52` | 3 | 67.183 |
| `trans_TransData_63` | 3 | 66.962 |
| `trans_TransData_48` | 3 | 65.502 |
| `trans_TransData_8` | 3 | 65.022 |
| `trans_TransData_12` | 3 | 65.021 |
| `trans_TransData_50` | 3 | 64.783 |
| `trans_TransData_35` | 3 | 64.662 |
| `trans_TransData_49` | 3 | 64.043 |
| `trans_TransData_16` | 3 | 63.362 |
| `trans_TransData_29` | 3 | 62.862 |
| `trans_TransData_27` | 3 | 62.860 |
| `trans_TransData_14` | 3 | 62.682 |
| `trans_TransData_23` | 3 | 62.020 |
| `trans_TransData_19` | 3 | 61.861 |
| `trans_TransData_7` | 3 | 61.762 |
| `trans_TransData_13` | 3 | 61.682 |
| `trans_TransData_15` | 3 | 61.341 |
| `trans_TransData_20` | 3 | 60.822 |
| `trans_TransData_11` | 3 | 60.440 |
| `trans_TransData_62` | 3 | 60.321 |
| `trans_TransData_9` | 3 | 60.301 |
| `trans_TransData_17` | 3 | 59.962 |
| `trans_TransData_2` | 3 | 59.623 |
| `trans_TransData_24` | 3 | 59.281 |
| `trans_TransData_3` | 3 | 59.202 |
| `trans_TransData_32` | 3 | 59.100 |
| `trans_TransData_6` | 3 | 58.941 |
| `trans_TransData_25` | 3 | 58.203 |
| `trans_TransData_5` | 3 | 57.443 |
| `trans_TransData_30` | 3 | 57.042 |
| `trans_TransData_21` | 3 | 56.721 |
| `trans_TransData_4` | 3 | 56.380 |
| `trans_TransData_28` | 3 | 56.302 |
| `trans_TransData_31` | 3 | 56.083 |
| `trans_TransData_26` | 3 | 54.260 |

### TransData Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `TransData | "80,320,16,16" -> "5120,1280" | FRACTAL_NZ -> ND` | 96 | 2275.612 |
| `TransData | "80,240,16,16" -> "3840,1280" | FRACTAL_NZ -> ND` | 96 | 1887.782 |

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_31` | 1 | 538.610 |
| `PromptFlashAttention_31` | 1 | 537.890 |
| `PromptFlashAttention_9` | 1 | 535.831 |
| `PromptFlashAttention_9` | 1 | 534.791 |
| `PromptFlashAttention_31` | 1 | 534.751 |
| `PromptFlashAttention_9` | 1 | 532.230 |
| `PromptFlashAttention_1` | 1 | 530.650 |
| `PromptFlashAttention_12` | 1 | 530.211 |
| `PromptFlashAttention_21` | 1 | 530.190 |
| `PromptFlashAttention_21` | 1 | 530.130 |
| `PromptFlashAttention_7` | 1 | 530.010 |
| `PromptFlashAttention_1` | 1 | 529.611 |
| `PromptFlashAttention_21` | 1 | 528.950 |
| `PromptFlashAttention_29` | 1 | 528.730 |
| `PromptFlashAttention_1` | 1 | 528.651 |
| `PromptFlashAttention_30` | 1 | 527.851 |
| `PromptFlashAttention_3` | 1 | 527.710 |
| `PromptFlashAttention_8` | 1 | 527.671 |
| `PromptFlashAttention_3` | 1 | 527.390 |
| `PromptFlashAttention_12` | 1 | 527.390 |
| `PromptFlashAttention_8` | 1 | 526.971 |
| `PromptFlashAttention_12` | 1 | 526.450 |
| `PromptFlashAttention_30` | 1 | 526.391 |
| `PromptFlashAttention_3` | 1 | 525.570 |
| `PromptFlashAttention_23` | 1 | 525.430 |
| `PromptFlashAttention_30` | 1 | 525.291 |
| `PromptFlashAttention_8` | 1 | 525.270 |
| `PromptFlashAttention_24` | 1 | 525.250 |
| `PromptFlashAttention_23` | 1 | 525.150 |
| `PromptFlashAttention_26` | 1 | 525.071 |
| `PromptFlashAttention_23` | 1 | 525.031 |
| `PromptFlashAttention_7` | 1 | 524.991 |
| `PromptFlashAttention_24` | 1 | 524.850 |
| `PromptFlashAttention` | 1 | 524.271 |
| `PromptFlashAttention_22` | 1 | 524.270 |
| `PromptFlashAttention_11` | 1 | 523.891 |
| `PromptFlashAttention` | 1 | 523.490 |
| `PromptFlashAttention_22` | 1 | 523.411 |
| `PromptFlashAttention_24` | 1 | 522.890 |
| `PromptFlashAttention_7` | 1 | 522.770 |
| `PromptFlashAttention_26` | 1 | 522.750 |
| `PromptFlashAttention_11` | 1 | 522.450 |
| `PromptFlashAttention_18` | 1 | 522.430 |
| `PromptFlashAttention_18` | 1 | 522.311 |
| `PromptFlashAttention_11` | 1 | 522.290 |
| `PromptFlashAttention_6` | 1 | 521.951 |
| `PromptFlashAttention_22` | 1 | 521.831 |
| `PromptFlashAttention_6` | 1 | 521.830 |
| `PromptFlashAttention_6` | 1 | 521.810 |
| `PromptFlashAttention_29` | 1 | 521.510 |
| `PromptFlashAttention_20` | 1 | 521.111 |
| `PromptFlashAttention` | 1 | 520.950 |
| `PromptFlashAttention_18` | 1 | 520.931 |
| `PromptFlashAttention_27` | 1 | 520.711 |
| `PromptFlashAttention_14` | 1 | 520.510 |
| `PromptFlashAttention_20` | 1 | 520.450 |
| `PromptFlashAttention_5` | 1 | 520.431 |
| `PromptFlashAttention_27` | 1 | 520.170 |
| `PromptFlashAttention_20` | 1 | 519.930 |
| `PromptFlashAttention_19` | 1 | 519.551 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 57256.835 |
| `TorchDynamo Cache Lookup` | 3 | 52936.984 |
| `Torch-Compiled Region: 0/0` | 3 | 2344.630 |
| `TorchNpuGraphBase::Run` | 3 | 1188.600 |
| `ExecuteGraph` | 3 | 376.240 |
| `AssembleInputs` | 3 | 368.940 |
| `RefreshAtTensorFromGeTensor` | 3 | 212.090 |
| `aten::empty` | 3 | 108.110 |
| `empty_tensor` | 3 | 59.190 |
| `AssembleOutputs` | 3 | 52.420 |
| `aten::set_` | 3 | 46.590 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 291838.800 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 155081.510 |
| `launch` | 1442 | 22279.250 |
| `InputCopy` | 3 | 200.640 |
| `ModelExecute` | 3 | 106.490 |
| `step_info` | 6 | 49.840 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 31.760 |
| `OutputCopy` | 3 | 1.760 |

