# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_nz_weights_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_nz_weights_crop_0_bucket_768/profile/liteserver-c001-4_195272_20261007141721073_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `18627.977 us`
- `Free`: `782.811 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `876.000 us`
- `Stage`: `19411.000 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 288 | 12028.664 |
| `PromptFlashAttention` | 96 | 8188.909 |
| `StridedSliceD` | 384 | 5050.579 |
| `Mul` | 576 | 4543.451 |
| `Transpose` | 384 | 4191.240 |
| `GroupedMatmul` | 96 | 3582.958 |
| `Add` | 384 | 3322.765 |
| `AutomaticBufferFusionOp` | 480 | 3062.860 |
| `ReduceMeanD` | 384 | 2575.673 |
| `Sub` | 192 | 1829.995 |
| `TransData` | 96 | 1647.517 |
| `ConcatV2D` | 192 | 1647.490 |
| `Cast` | 195 | 1561.071 |
| `Neg` | 192 | 1444.713 |
| `Unpack` | 96 | 813.334 |
| `ConfusionTransposeD` | 96 | 510.227 |
| `Data` | 1 | 5.240 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_4` | 3 | 302.667 |
| `PromptFlashAttention_13` | 3 | 290.286 |
| `PromptFlashAttention_8` | 3 | 276.566 |
| `PromptFlashAttention_22` | 3 | 273.685 |
| `PromptFlashAttention` | 3 | 273.646 |
| `PromptFlashAttention_31` | 3 | 272.466 |
| `PromptFlashAttention_14` | 3 | 270.306 |
| `PromptFlashAttention_2` | 3 | 268.286 |
| `PromptFlashAttention_24` | 3 | 265.365 |
| `PromptFlashAttention_18` | 3 | 264.405 |
| `PromptFlashAttention_10` | 3 | 263.305 |
| `PromptFlashAttention_21` | 3 | 261.846 |
| `PromptFlashAttention_3` | 3 | 261.506 |
| `PromptFlashAttention_12` | 3 | 260.304 |
| `PromptFlashAttention_25` | 3 | 257.406 |
| `PromptFlashAttention_11` | 3 | 257.366 |
| `PromptFlashAttention_15` | 3 | 251.344 |
| `PromptFlashAttention_23` | 3 | 250.925 |
| `PromptFlashAttention_17` | 3 | 248.284 |
| `PromptFlashAttention_28` | 3 | 248.165 |
| `PromptFlashAttention_27` | 3 | 247.485 |
| `PromptFlashAttention_19` | 3 | 244.985 |
| `PromptFlashAttention_9` | 3 | 244.485 |
| `PromptFlashAttention_30` | 3 | 239.446 |
| `PromptFlashAttention_16` | 3 | 239.424 |
| `PromptFlashAttention_26` | 3 | 239.385 |
| `PromptFlashAttention_7` | 3 | 239.204 |
| `PromptFlashAttention_29` | 3 | 237.986 |
| `PromptFlashAttention_20` | 3 | 236.185 |
| `PromptFlashAttention_1` | 3 | 235.026 |
| `PromptFlashAttention_5` | 3 | 234.065 |
| `PromptFlashAttention_6` | 3 | 233.104 |
| `MatMulV2_26` | 3 | 162.623 |
| `MatMulV2_35` | 3 | 159.003 |
| `MatMulV2_11` | 3 | 158.803 |
| `MatMulV2_59` | 3 | 158.684 |
| `MatMulV2_41` | 3 | 158.383 |
| `MatMulV2_83` | 3 | 158.303 |
| `MatMulV2_77` | 3 | 158.224 |
| `MatMulV2_29` | 3 | 158.103 |
| `MatMulV2_65` | 3 | 157.843 |
| `MatMulV2_95` | 3 | 157.303 |
| `MatMulV2_8` | 3 | 156.283 |
| `MatMulV2_5` | 3 | 156.003 |
| `MatMulV2_47` | 3 | 155.643 |
| `MatMulV2_53` | 3 | 155.603 |
| `MatMulV2_23` | 3 | 155.563 |
| `MatMulV2_71` | 3 | 155.323 |
| `MatMulV2_14` | 3 | 154.743 |
| `MatMulV2_68` | 3 | 153.803 |
| `MatMulV2_50` | 3 | 153.283 |
| `MatMulV2_86` | 3 | 152.803 |
| `MatMulV2_89` | 3 | 152.483 |
| `MatMulV2_38` | 3 | 152.363 |
| `MatMulV2_62` | 3 | 151.583 |
| `MatMulV2_20` | 3 | 151.383 |
| `MatMulV2_17` | 3 | 151.283 |
| `MatMulV2_92` | 3 | 150.663 |
| `MatMulV2_32` | 3 | 150.383 |
| `MatMulV2_56` | 3 | 149.362 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_26` | 3 | 162.623 |
| `MatMulV2_35` | 3 | 159.003 |
| `MatMulV2_11` | 3 | 158.803 |
| `MatMulV2_59` | 3 | 158.684 |
| `MatMulV2_41` | 3 | 158.383 |
| `MatMulV2_83` | 3 | 158.303 |
| `MatMulV2_77` | 3 | 158.224 |
| `MatMulV2_29` | 3 | 158.103 |
| `MatMulV2_65` | 3 | 157.843 |
| `MatMulV2_95` | 3 | 157.303 |
| `MatMulV2_8` | 3 | 156.283 |
| `MatMulV2_5` | 3 | 156.003 |
| `MatMulV2_47` | 3 | 155.643 |
| `MatMulV2_53` | 3 | 155.603 |
| `MatMulV2_23` | 3 | 155.563 |
| `MatMulV2_71` | 3 | 155.323 |
| `MatMulV2_14` | 3 | 154.743 |
| `MatMulV2_68` | 3 | 153.803 |
| `MatMulV2_50` | 3 | 153.283 |
| `MatMulV2_86` | 3 | 152.803 |
| `MatMulV2_89` | 3 | 152.483 |
| `MatMulV2_38` | 3 | 152.363 |
| `MatMulV2_62` | 3 | 151.583 |
| `MatMulV2_20` | 3 | 151.383 |
| `MatMulV2_17` | 3 | 151.283 |
| `MatMulV2_92` | 3 | 150.663 |
| `MatMulV2_32` | 3 | 150.383 |
| `MatMulV2_56` | 3 | 149.362 |
| `MatMulV2_80` | 3 | 148.603 |
| `MatMulV2_2` | 3 | 148.023 |
| `MatMulV2_44` | 3 | 147.243 |
| `MatMulV2_58` | 3 | 147.182 |
| `MatMulV2_19` | 3 | 146.263 |
| `MatMulV2_74` | 3 | 146.063 |
| `MatMulV2_7` | 3 | 146.002 |
| `MatMulV2_79` | 3 | 145.883 |
| `MatMulV2_28` | 3 | 145.782 |
| `MatMulV2_37` | 3 | 145.743 |
| `MatMulV2_64` | 3 | 145.423 |
| `MatMulV2_13` | 3 | 145.043 |
| `MatMulV2_10` | 3 | 145.023 |
| `MatMulV2_22` | 3 | 144.942 |
| `MatMulV2_40` | 3 | 144.823 |
| `MatMulV2_67` | 3 | 144.683 |
| `MatMulV2_34` | 3 | 144.523 |
| `MatMulV2_91` | 3 | 144.482 |
| `MatMulV2_4` | 3 | 144.282 |
| `MatMulV2_25` | 3 | 144.243 |
| `MatMulV2_94` | 3 | 143.503 |
| `MatMulV2_61` | 3 | 143.283 |
| `MatMulV2_82` | 3 | 143.203 |
| `MatMulV2_52` | 3 | 143.003 |
| `MatMulV2_49` | 3 | 142.983 |
| `MatMulV2_46` | 3 | 142.503 |
| `MatMulV2_70` | 3 | 142.403 |
| `MatMulV2_88` | 3 | 141.582 |
| `MatMulV2_31` | 3 | 137.343 |
| `MatMulV2_43` | 3 | 136.743 |
| `MatMulV2_55` | 3 | 136.603 |
| `MatMulV2_76` | 3 | 136.563 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;320,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4935.757 |
| `MatMulV2 | "768,1280;80,320,16,16;5120" -> "768,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4554.948 |
| `GroupedMatmul | "768,1280;1,1280,3840;1,3840;;;;;1" -> "768,3840" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 3582.958 |
| `MatMulV2 | "768,1280;80,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 2537.959 |

### TransData Names
| name | count | total_us |
|---|---:|---:|
| `trans_TransData_27` | 3 | 59.400 |
| `trans_TransData_22` | 3 | 58.462 |
| `trans_TransData_20` | 3 | 58.301 |
| `trans_TransData_30` | 3 | 57.382 |
| `trans_TransData_4` | 3 | 57.221 |
| `trans_TransData_25` | 3 | 56.481 |
| `trans_TransData_29` | 3 | 56.342 |
| `trans_TransData_26` | 3 | 55.921 |
| `trans_TransData_32` | 3 | 55.680 |
| `trans_TransData_10` | 3 | 54.800 |
| `trans_TransData_6` | 3 | 54.661 |
| `trans_TransData_2` | 3 | 54.463 |
| `trans_TransData_23` | 3 | 53.942 |
| `trans_TransData_33` | 3 | 53.640 |
| `trans_TransData_5` | 3 | 53.063 |
| `trans_TransData_15` | 3 | 52.682 |
| `trans_TransData_19` | 3 | 52.261 |
| `trans_TransData_31` | 3 | 52.083 |
| `trans_TransData_16` | 3 | 50.780 |
| `trans_TransData_18` | 3 | 49.842 |
| `trans_TransData_17` | 3 | 49.401 |
| `trans_TransData_3` | 3 | 49.040 |
| `trans_TransData_28` | 3 | 48.701 |
| `trans_TransData_14` | 3 | 48.521 |
| `trans_TransData_21` | 3 | 47.982 |
| `trans_TransData_24` | 3 | 47.220 |
| `trans_TransData_7` | 3 | 45.260 |
| `trans_TransData_11` | 3 | 43.681 |
| `trans_TransData_13` | 3 | 43.660 |
| `trans_TransData_12` | 3 | 43.201 |
| `trans_TransData_8` | 3 | 42.322 |
| `trans_TransData_9` | 3 | 41.121 |

### TransData Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `TransData | "80,240,16,16" -> "3840,1280" | FRACTAL_NZ -> ND` | 96 | 1647.517 |

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_4` | 1 | 102.743 |
| `PromptFlashAttention_4` | 1 | 100.722 |
| `PromptFlashAttention_4` | 1 | 99.202 |
| `PromptFlashAttention_13` | 1 | 97.882 |
| `PromptFlashAttention_13` | 1 | 96.942 |
| `PromptFlashAttention_13` | 1 | 95.462 |
| `PromptFlashAttention_8` | 1 | 93.042 |
| `PromptFlashAttention_22` | 1 | 92.782 |
| `PromptFlashAttention_8` | 1 | 92.322 |
| `PromptFlashAttention` | 1 | 92.262 |
| `PromptFlashAttention_31` | 1 | 91.322 |
| `PromptFlashAttention_8` | 1 | 91.202 |
| `PromptFlashAttention` | 1 | 91.162 |
| `PromptFlashAttention_22` | 1 | 91.121 |
| `PromptFlashAttention_31` | 1 | 90.962 |
| `PromptFlashAttention_18` | 1 | 90.281 |
| `PromptFlashAttention_2` | 1 | 90.222 |
| `PromptFlashAttention` | 1 | 90.222 |
| `PromptFlashAttention_24` | 1 | 90.222 |
| `PromptFlashAttention_14` | 1 | 90.182 |
| `PromptFlashAttention_31` | 1 | 90.182 |
| `PromptFlashAttention_14` | 1 | 90.162 |
| `PromptFlashAttention_14` | 1 | 89.962 |
| `PromptFlashAttention_22` | 1 | 89.782 |
| `PromptFlashAttention_2` | 1 | 89.222 |
| `PromptFlashAttention_2` | 1 | 88.842 |
| `PromptFlashAttention_3` | 1 | 88.282 |
| `PromptFlashAttention_18` | 1 | 88.162 |
| `PromptFlashAttention_10` | 1 | 87.962 |
| `PromptFlashAttention_21` | 1 | 87.942 |
| `PromptFlashAttention_10` | 1 | 87.941 |
| `PromptFlashAttention_24` | 1 | 87.902 |
| `PromptFlashAttention_21` | 1 | 87.462 |
| `PromptFlashAttention_12` | 1 | 87.421 |
| `PromptFlashAttention_10` | 1 | 87.402 |
| `PromptFlashAttention_24` | 1 | 87.241 |
| `PromptFlashAttention_12` | 1 | 87.042 |
| `PromptFlashAttention_3` | 1 | 86.682 |
| `PromptFlashAttention_3` | 1 | 86.542 |
| `PromptFlashAttention_25` | 1 | 86.502 |
| `PromptFlashAttention_21` | 1 | 86.442 |
| `PromptFlashAttention_11` | 1 | 86.122 |
| `PromptFlashAttention_11` | 1 | 86.002 |
| `PromptFlashAttention_18` | 1 | 85.962 |
| `PromptFlashAttention_12` | 1 | 85.841 |
| `PromptFlashAttention_25` | 1 | 85.482 |
| `PromptFlashAttention_25` | 1 | 85.422 |
| `PromptFlashAttention_11` | 1 | 85.242 |
| `PromptFlashAttention_23` | 1 | 84.722 |
| `PromptFlashAttention_15` | 1 | 84.622 |
| `PromptFlashAttention_27` | 1 | 83.761 |
| `PromptFlashAttention_15` | 1 | 83.461 |
| `PromptFlashAttention_23` | 1 | 83.281 |
| `PromptFlashAttention_28` | 1 | 83.281 |
| `PromptFlashAttention_15` | 1 | 83.261 |
| `PromptFlashAttention_17` | 1 | 83.221 |
| `PromptFlashAttention_23` | 1 | 82.922 |
| `PromptFlashAttention_28` | 1 | 82.862 |
| `PromptFlashAttention_17` | 1 | 82.582 |
| `PromptFlashAttention_9` | 1 | 82.502 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 19584.872 |
| `TorchDynamo Cache Lookup` | 3 | 18707.462 |
| `Torch-Compiled Region: 0/0` | 3 | 1360.610 |
| `TorchNpuGraphBase::Run` | 3 | 717.200 |
| `ExecuteGraph` | 3 | 254.130 |
| `RefreshAtTensorFromGeTensor` | 3 | 160.620 |
| `AssembleInputs` | 3 | 139.430 |
| `aten::empty` | 3 | 76.280 |
| `empty_tensor` | 3 | 42.040 |
| `aten::set_` | 3 | 38.180 |
| `AssembleOutputs` | 3 | 34.200 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 275667.000 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 55916.590 |
| `launch` | 1378 | 22094.620 |
| `InputCopy` | 3 | 126.220 |
| `ModelExecute` | 3 | 76.610 |
| `step_info` | 6 | 46.470 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 26.040 |
| `OutputCopy` | 3 | 1.620 |

