# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_nz_weights_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/grouped_qkv_nz_weights_crop_1_bucket_3072/profile/liteserver-c001-4_197077_20261007141859055_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `51721.596 us`
- `Free`: `824.353 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `850.000 us`
- `Stage`: `52545.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50466.229 |
| `MatMulV2` | 288 | 34995.854 |
| `StridedSliceD` | 384 | 13436.032 |
| `GroupedMatmul` | 96 | 9926.697 |
| `Mul` | 576 | 8020.868 |
| `AutomaticBufferFusionOp` | 480 | 6412.724 |
| `Transpose` | 384 | 5941.999 |
| `Add` | 384 | 5662.009 |
| `ReduceMeanD` | 384 | 4944.298 |
| `Sub` | 192 | 3423.051 |
| `ConcatV2D` | 192 | 2666.913 |
| `Cast` | 195 | 2375.770 |
| `Unpack` | 96 | 2061.641 |
| `Neg` | 192 | 1937.756 |
| `TransData` | 96 | 1823.658 |
| `ConfusionTransposeD` | 96 | 1066.323 |
| `Data` | 1 | 5.520 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_12` | 3 | 1612.371 |
| `PromptFlashAttention_3` | 3 | 1608.571 |
| `PromptFlashAttention_21` | 3 | 1600.772 |
| `PromptFlashAttention` | 3 | 1600.111 |
| `PromptFlashAttention_24` | 3 | 1599.251 |
| `PromptFlashAttention_10` | 3 | 1597.133 |
| `PromptFlashAttention_31` | 3 | 1596.132 |
| `PromptFlashAttention_13` | 3 | 1592.252 |
| `PromptFlashAttention_23` | 3 | 1591.852 |
| `PromptFlashAttention_14` | 3 | 1591.393 |
| `PromptFlashAttention_4` | 3 | 1588.150 |
| `PromptFlashAttention_11` | 3 | 1585.051 |
| `PromptFlashAttention_9` | 3 | 1585.033 |
| `PromptFlashAttention_18` | 3 | 1583.073 |
| `PromptFlashAttention_22` | 3 | 1582.752 |
| `PromptFlashAttention_25` | 3 | 1582.071 |
| `PromptFlashAttention_2` | 3 | 1577.172 |
| `PromptFlashAttention_8` | 3 | 1574.030 |
| `PromptFlashAttention_1` | 3 | 1566.112 |
| `PromptFlashAttention_28` | 3 | 1564.091 |
| `PromptFlashAttention_27` | 3 | 1563.831 |
| `PromptFlashAttention_16` | 3 | 1560.712 |
| `PromptFlashAttention_26` | 3 | 1560.173 |
| `PromptFlashAttention_5` | 3 | 1559.312 |
| `PromptFlashAttention_6` | 3 | 1559.151 |
| `PromptFlashAttention_19` | 3 | 1559.012 |
| `PromptFlashAttention_20` | 3 | 1557.651 |
| `PromptFlashAttention_30` | 3 | 1557.432 |
| `PromptFlashAttention_15` | 3 | 1556.210 |
| `PromptFlashAttention_29` | 3 | 1553.751 |
| `PromptFlashAttention_17` | 3 | 1553.710 |
| `PromptFlashAttention_7` | 3 | 1547.911 |
| `MatMulV2_50` | 3 | 458.709 |
| `MatMulV2_32` | 3 | 457.969 |
| `MatMulV2_47` | 3 | 457.069 |
| `MatMulV2_62` | 3 | 456.849 |
| `MatMulV2_56` | 3 | 456.389 |
| `MatMulV2_71` | 3 | 456.089 |
| `MatMulV2_26` | 3 | 455.889 |
| `MatMulV2_89` | 3 | 455.669 |
| `MatMulV2_11` | 3 | 454.089 |
| `MatMulV2_17` | 3 | 453.969 |
| `MatMulV2_86` | 3 | 453.109 |
| `MatMulV2_65` | 3 | 452.829 |
| `MatMulV2_41` | 3 | 452.749 |
| `MatMulV2_23` | 3 | 452.189 |
| `MatMulV2_38` | 3 | 451.729 |
| `MatMulV2_83` | 3 | 451.249 |
| `MatMulV2_95` | 3 | 450.509 |
| `MatMulV2_8` | 3 | 450.089 |
| `MatMulV2_20` | 3 | 449.749 |
| `MatMulV2_80` | 3 | 448.949 |
| `MatMulV2_92` | 3 | 448.449 |
| `MatMulV2_35` | 3 | 447.949 |
| `MatMulV2_68` | 3 | 447.729 |
| `MatMulV2_14` | 3 | 447.309 |
| `MatMulV2_2` | 3 | 446.909 |
| `MatMulV2_77` | 3 | 446.469 |
| `MatMulV2_74` | 3 | 446.309 |
| `MatMulV2_29` | 3 | 446.249 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_50` | 3 | 458.709 |
| `MatMulV2_32` | 3 | 457.969 |
| `MatMulV2_47` | 3 | 457.069 |
| `MatMulV2_62` | 3 | 456.849 |
| `MatMulV2_56` | 3 | 456.389 |
| `MatMulV2_71` | 3 | 456.089 |
| `MatMulV2_26` | 3 | 455.889 |
| `MatMulV2_89` | 3 | 455.669 |
| `MatMulV2_11` | 3 | 454.089 |
| `MatMulV2_17` | 3 | 453.969 |
| `MatMulV2_86` | 3 | 453.109 |
| `MatMulV2_65` | 3 | 452.829 |
| `MatMulV2_41` | 3 | 452.749 |
| `MatMulV2_23` | 3 | 452.189 |
| `MatMulV2_38` | 3 | 451.729 |
| `MatMulV2_83` | 3 | 451.249 |
| `MatMulV2_95` | 3 | 450.509 |
| `MatMulV2_8` | 3 | 450.089 |
| `MatMulV2_20` | 3 | 449.749 |
| `MatMulV2_80` | 3 | 448.949 |
| `MatMulV2_92` | 3 | 448.449 |
| `MatMulV2_35` | 3 | 447.949 |
| `MatMulV2_68` | 3 | 447.729 |
| `MatMulV2_14` | 3 | 447.309 |
| `MatMulV2_2` | 3 | 446.909 |
| `MatMulV2_77` | 3 | 446.469 |
| `MatMulV2_74` | 3 | 446.309 |
| `MatMulV2_29` | 3 | 446.249 |
| `MatMulV2_59` | 3 | 446.189 |
| `MatMulV2_44` | 3 | 445.669 |
| `MatMulV2_53` | 3 | 445.628 |
| `MatMulV2_5` | 3 | 445.529 |
| `MatMulV2_67` | 3 | 438.949 |
| `MatMulV2_79` | 3 | 434.069 |
| `MatMulV2_52` | 3 | 433.069 |
| `MatMulV2_61` | 3 | 432.168 |
| `MatMulV2_28` | 3 | 432.149 |
| `MatMulV2_88` | 3 | 431.948 |
| `MatMulV2_55` | 3 | 431.889 |
| `MatMulV2_31` | 3 | 431.789 |
| `MatMulV2_46` | 3 | 431.569 |
| `MatMulV2_37` | 3 | 430.608 |
| `MatMulV2_70` | 3 | 430.349 |
| `MatMulV2_1` | 3 | 430.168 |
| `MatMulV2_64` | 3 | 430.129 |
| `MatMulV2_76` | 3 | 429.568 |
| `MatMulV2_40` | 3 | 428.948 |
| `MatMulV2_10` | 3 | 428.648 |
| `MatMulV2_16` | 3 | 428.389 |
| `MatMulV2_4` | 3 | 428.208 |
| `MatMulV2_91` | 3 | 427.568 |
| `MatMulV2_82` | 3 | 427.269 |
| `MatMulV2_22` | 3 | 426.569 |
| `MatMulV2_85` | 3 | 424.429 |
| `MatMulV2_43` | 3 | 424.369 |
| `MatMulV2_58` | 3 | 424.348 |
| `MatMulV2_25` | 3 | 424.227 |
| `MatMulV2_19` | 3 | 423.887 |
| `MatMulV2_34` | 3 | 423.848 |
| `MatMulV2_7` | 3 | 423.469 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "3072,5120;320,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 14436.227 |
| `MatMulV2 | "3072,1280;80,320,16,16;5120" -> "3072,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 13704.913 |
| `GroupedMatmul | "3072,1280;1,1280,3840;1,3840;;;;;1" -> "3072,3840" | ND;ND;ND;ND;ND;ND;ND;ND -> ND` | 96 | 9926.697 |
| `MatMulV2 | "3072,1280;80,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 6854.714 |

### TransData Names
| name | count | total_us |
|---|---:|---:|
| `trans_TransData_21` | 3 | 65.222 |
| `trans_TransData_6` | 3 | 64.501 |
| `trans_TransData_20` | 3 | 63.702 |
| `trans_TransData_15` | 3 | 61.982 |
| `trans_TransData_12` | 3 | 61.082 |
| `trans_TransData_33` | 3 | 61.041 |
| `trans_TransData_32` | 3 | 59.681 |
| `trans_TransData_26` | 3 | 59.561 |
| `trans_TransData_16` | 3 | 59.521 |
| `trans_TransData_30` | 3 | 58.882 |
| `trans_TransData_10` | 3 | 58.261 |
| `trans_TransData_11` | 3 | 57.960 |
| `trans_TransData_22` | 3 | 57.901 |
| `trans_TransData_24` | 3 | 57.541 |
| `trans_TransData_5` | 3 | 56.702 |
| `trans_TransData_27` | 3 | 55.961 |
| `trans_TransData_8` | 3 | 55.503 |
| `trans_TransData_29` | 3 | 55.501 |
| `trans_TransData_31` | 3 | 55.360 |
| `trans_TransData_4` | 3 | 55.322 |
| `trans_TransData_2` | 3 | 54.782 |
| `trans_TransData_25` | 3 | 54.701 |
| `trans_TransData_19` | 3 | 54.522 |
| `trans_TransData_14` | 3 | 54.421 |
| `trans_TransData_28` | 3 | 53.840 |
| `trans_TransData_9` | 3 | 53.500 |
| `trans_TransData_3` | 3 | 53.481 |
| `trans_TransData_18` | 3 | 53.401 |
| `trans_TransData_13` | 3 | 53.100 |
| `trans_TransData_17` | 3 | 52.581 |
| `trans_TransData_23` | 3 | 52.141 |
| `trans_TransData_7` | 3 | 52.001 |

### TransData Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `TransData | "80,240,16,16" -> "3840,1280" | FRACTAL_NZ -> ND` | 96 | 1823.658 |

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_12` | 1 | 540.711 |
| `PromptFlashAttention_12` | 1 | 537.090 |
| `PromptFlashAttention_3` | 1 | 537.030 |
| `PromptFlashAttention_3` | 1 | 536.630 |
| `PromptFlashAttention_24` | 1 | 535.111 |
| `PromptFlashAttention_10` | 1 | 535.051 |
| `PromptFlashAttention_3` | 1 | 534.911 |
| `PromptFlashAttention_12` | 1 | 534.570 |
| `PromptFlashAttention_21` | 1 | 534.351 |
| `PromptFlashAttention_24` | 1 | 534.330 |
| `PromptFlashAttention` | 1 | 534.050 |
| `PromptFlashAttention` | 1 | 533.831 |
| `PromptFlashAttention_21` | 1 | 533.410 |
| `PromptFlashAttention_21` | 1 | 533.011 |
| `PromptFlashAttention_31` | 1 | 532.791 |
| `PromptFlashAttention_23` | 1 | 532.730 |
| `PromptFlashAttention` | 1 | 532.230 |
| `PromptFlashAttention_31` | 1 | 531.850 |
| `PromptFlashAttention_23` | 1 | 531.771 |
| `PromptFlashAttention_31` | 1 | 531.491 |
| `PromptFlashAttention_14` | 1 | 531.391 |
| `PromptFlashAttention_13` | 1 | 531.290 |
| `PromptFlashAttention_13` | 1 | 531.171 |
| `PromptFlashAttention_10` | 1 | 531.051 |
| `PromptFlashAttention_10` | 1 | 531.031 |
| `PromptFlashAttention_14` | 1 | 530.751 |
| `PromptFlashAttention_4` | 1 | 530.610 |
| `PromptFlashAttention_24` | 1 | 529.810 |
| `PromptFlashAttention_13` | 1 | 529.791 |
| `PromptFlashAttention_18` | 1 | 529.311 |
| `PromptFlashAttention_14` | 1 | 529.251 |
| `PromptFlashAttention_4` | 1 | 529.090 |
| `PromptFlashAttention_9` | 1 | 528.571 |
| `PromptFlashAttention_11` | 1 | 528.570 |
| `PromptFlashAttention_4` | 1 | 528.450 |
| `PromptFlashAttention_11` | 1 | 528.431 |
| `PromptFlashAttention_9` | 1 | 528.391 |
| `PromptFlashAttention_18` | 1 | 528.371 |
| `PromptFlashAttention_9` | 1 | 528.071 |
| `PromptFlashAttention_11` | 1 | 528.050 |
| `PromptFlashAttention_25` | 1 | 528.031 |
| `PromptFlashAttention_22` | 1 | 527.971 |
| `PromptFlashAttention_22` | 1 | 527.610 |
| `PromptFlashAttention_23` | 1 | 527.351 |
| `PromptFlashAttention_25` | 1 | 527.330 |
| `PromptFlashAttention_22` | 1 | 527.171 |
| `PromptFlashAttention_25` | 1 | 526.710 |
| `PromptFlashAttention_2` | 1 | 526.551 |
| `PromptFlashAttention_2` | 1 | 525.530 |
| `PromptFlashAttention_18` | 1 | 525.391 |
| `PromptFlashAttention_8` | 1 | 525.390 |
| `PromptFlashAttention_2` | 1 | 525.091 |
| `PromptFlashAttention_8` | 1 | 524.930 |
| `PromptFlashAttention_8` | 1 | 523.710 |
| `PromptFlashAttention_1` | 1 | 523.050 |
| `PromptFlashAttention_28` | 1 | 522.030 |
| `PromptFlashAttention_27` | 1 | 521.911 |
| `PromptFlashAttention_26` | 1 | 521.851 |
| `PromptFlashAttention_1` | 1 | 521.551 |
| `PromptFlashAttention_1` | 1 | 521.511 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 52748.293 |
| `TorchDynamo Cache Lookup` | 3 | 51814.853 |
| `Torch-Compiled Region: 0/0` | 3 | 1437.810 |
| `TorchNpuGraphBase::Run` | 3 | 795.610 |
| `ExecuteGraph` | 3 | 273.440 |
| `RefreshAtTensorFromGeTensor` | 3 | 180.910 |
| `AssembleInputs` | 3 | 161.820 |
| `aten::empty` | 3 | 81.930 |
| `AssembleOutputs` | 3 | 46.070 |
| `empty_tensor` | 3 | 44.940 |
| `aten::set_` | 3 | 43.950 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 274241.200 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 155107.910 |
| `launch` | 1378 | 21402.020 |
| `InputCopy` | 3 | 132.160 |
| `ModelExecute` | 3 | 86.970 |
| `step_info` | 6 | 41.270 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 25.690 |
| `OutputCopy` | 3 | 2.080 |

