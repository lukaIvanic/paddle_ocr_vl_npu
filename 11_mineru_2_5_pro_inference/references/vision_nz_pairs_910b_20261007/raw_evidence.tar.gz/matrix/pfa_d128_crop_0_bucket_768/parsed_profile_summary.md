# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_d128_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_d128_crop_0_bucket_768/profile/liteserver-c001-4_206026_20261007142714556_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `18905.714 us`
- `Free`: `965.283 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `840.750 us`
- `Stage`: `19870.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 13512.526 |
| `PromptFlashAttention` | 96 | 8288.834 |
| `StridedSliceD` | 480 | 5871.322 |
| `Mul` | 576 | 4497.153 |
| `PadV3` | 288 | 3853.889 |
| `Add` | 384 | 3529.861 |
| `AutomaticBufferFusionOp` | 480 | 3243.044 |
| `ReduceMeanD` | 384 | 2697.985 |
| `Transpose` | 288 | 2628.955 |
| `Sub` | 192 | 1993.786 |
| `Neg` | 192 | 1645.225 |
| `ConcatV2D` | 192 | 1643.625 |
| `Cast` | 195 | 1573.896 |
| `Unpack` | 96 | 837.058 |
| `ConfusionTransposeD` | 96 | 480.187 |
| `te_memset_a8b1f5b1b0c44beef84d40753f2a30539fad1ae9efba5fbd957512e0b764e7d9__kernel0` | 288 | 281.867 |
| `Data` | 1 | 5.100 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_12` | 3 | 301.766 |
| `PromptFlashAttention_26` | 3 | 292.646 |
| `PromptFlashAttention_21` | 3 | 291.485 |
| `PromptFlashAttention_31` | 3 | 288.545 |
| `te_memset_a8b1f5b1b0c44beef84d40753f2a30539fad1ae9efba5fbd957512e0b764e7d9__kernel0` | 288 | 281.867 |
| `PromptFlashAttention_5` | 3 | 275.826 |
| `PromptFlashAttention_25` | 3 | 270.466 |
| `PromptFlashAttention_17` | 3 | 269.145 |
| `PromptFlashAttention_10` | 3 | 267.406 |
| `PromptFlashAttention_6` | 3 | 265.346 |
| `PromptFlashAttention_24` | 3 | 265.146 |
| `PromptFlashAttention_22` | 3 | 264.926 |
| `PromptFlashAttention_23` | 3 | 263.726 |
| `PromptFlashAttention_4` | 3 | 263.186 |
| `PromptFlashAttention_11` | 3 | 262.306 |
| `PromptFlashAttention_20` | 3 | 259.386 |
| `PromptFlashAttention` | 3 | 257.346 |
| `PromptFlashAttention_18` | 3 | 256.485 |
| `PromptFlashAttention_9` | 3 | 255.126 |
| `PromptFlashAttention_19` | 3 | 253.765 |
| `PromptFlashAttention_13` | 3 | 251.744 |
| `PromptFlashAttention_8` | 3 | 249.106 |
| `PromptFlashAttention_1` | 3 | 245.586 |
| `PromptFlashAttention_14` | 3 | 244.625 |
| `PromptFlashAttention_15` | 3 | 244.426 |
| `PromptFlashAttention_29` | 3 | 243.963 |
| `PromptFlashAttention_27` | 3 | 243.106 |
| `PromptFlashAttention_7` | 3 | 242.226 |
| `PromptFlashAttention_28` | 3 | 241.823 |
| `PromptFlashAttention_30` | 3 | 241.544 |
| `PromptFlashAttention_3` | 3 | 240.426 |
| `PromptFlashAttention_2` | 3 | 238.486 |
| `PromptFlashAttention_16` | 3 | 237.744 |
| `MatMulV2_11` | 3 | 144.123 |
| `MatMulV2_15` | 3 | 143.803 |
| `MatMulV2_19` | 3 | 138.223 |
| `MatMulV2_7` | 3 | 138.202 |
| `MatMulV2_91` | 3 | 138.003 |
| `MatMulV2_103` | 3 | 137.863 |
| `MatMulV2_55` | 3 | 137.003 |
| `MatMulV2_79` | 3 | 136.941 |
| `MatMulV2_63` | 3 | 136.882 |
| `MatMulV2_95` | 3 | 136.443 |
| `MatMulV2_127` | 3 | 136.303 |
| `MatMulV2_39` | 3 | 136.242 |
| `MatMulV2_123` | 3 | 136.123 |
| `MatMulV2_43` | 3 | 135.943 |
| `MatMulV2_71` | 3 | 135.923 |
| `MatMulV2_87` | 3 | 135.883 |
| `MatMulV2_115` | 3 | 135.863 |
| `MatMulV2_99` | 3 | 135.841 |
| `MatMulV2_31` | 3 | 135.763 |
| `MatMulV2_111` | 3 | 135.743 |
| `MatMulV2_23` | 3 | 135.703 |
| `MatMulV2_27` | 3 | 135.562 |
| `MatMulV2_75` | 3 | 135.543 |
| `MatMulV2_59` | 3 | 135.403 |
| `MatMulV2_83` | 3 | 135.323 |
| `MatMulV2_47` | 3 | 135.083 |
| `MatMulV2_67` | 3 | 134.983 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_11` | 3 | 144.123 |
| `MatMulV2_15` | 3 | 143.803 |
| `MatMulV2_19` | 3 | 138.223 |
| `MatMulV2_7` | 3 | 138.202 |
| `MatMulV2_91` | 3 | 138.003 |
| `MatMulV2_103` | 3 | 137.863 |
| `MatMulV2_55` | 3 | 137.003 |
| `MatMulV2_79` | 3 | 136.941 |
| `MatMulV2_63` | 3 | 136.882 |
| `MatMulV2_95` | 3 | 136.443 |
| `MatMulV2_127` | 3 | 136.303 |
| `MatMulV2_39` | 3 | 136.242 |
| `MatMulV2_123` | 3 | 136.123 |
| `MatMulV2_43` | 3 | 135.943 |
| `MatMulV2_71` | 3 | 135.923 |
| `MatMulV2_87` | 3 | 135.883 |
| `MatMulV2_115` | 3 | 135.863 |
| `MatMulV2_99` | 3 | 135.841 |
| `MatMulV2_31` | 3 | 135.763 |
| `MatMulV2_111` | 3 | 135.743 |
| `MatMulV2_23` | 3 | 135.703 |
| `MatMulV2_27` | 3 | 135.562 |
| `MatMulV2_75` | 3 | 135.543 |
| `MatMulV2_59` | 3 | 135.403 |
| `MatMulV2_83` | 3 | 135.323 |
| `MatMulV2_47` | 3 | 135.083 |
| `MatMulV2_67` | 3 | 134.983 |
| `MatMulV2_119` | 3 | 134.983 |
| `MatMulV2_3` | 3 | 134.743 |
| `MatMulV2_35` | 3 | 134.362 |
| `MatMulV2_107` | 3 | 134.300 |
| `MatMulV2_51` | 3 | 134.203 |
| `MatMulV2_118` | 3 | 132.343 |
| `MatMulV2_54` | 3 | 126.382 |
| `MatMulV2_30` | 3 | 125.102 |
| `MatMulV2_18` | 3 | 125.021 |
| `MatMulV2_110` | 3 | 124.843 |
| `MatMulV2_14` | 3 | 124.643 |
| `MatMulV2_102` | 3 | 124.643 |
| `MatMulV2_74` | 3 | 124.581 |
| `MatMulV2_38` | 3 | 124.563 |
| `MatMulV2_10` | 3 | 124.382 |
| `MatMulV2_62` | 3 | 124.323 |
| `MatMulV2_50` | 3 | 124.163 |
| `MatMulV2_58` | 3 | 124.143 |
| `MatMulV2_82` | 3 | 124.103 |
| `MatMulV2_2` | 3 | 124.062 |
| `MatMulV2_42` | 3 | 124.023 |
| `MatMulV2_6` | 3 | 123.982 |
| `MatMulV2_26` | 3 | 123.981 |
| `MatMulV2_78` | 3 | 123.923 |
| `MatMulV2_94` | 3 | 123.841 |
| `MatMulV2_86` | 3 | 123.823 |
| `MatMulV2_46` | 3 | 123.763 |
| `MatMulV2_126` | 3 | 123.743 |
| `MatMulV2_70` | 3 | 123.702 |
| `MatMulV2_22` | 3 | 123.660 |
| `MatMulV2_34` | 3 | 123.622 |
| `MatMulV2_114` | 3 | 123.603 |
| `MatMulV2_90` | 3 | 123.461 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4367.304 |
| `MatMulV2 | "768,1280;5120,1280;5120" -> "768,5120" | ND;ND;ND -> ND` | 96 | 3978.176 |
| `MatMulV2 | "768,1280;3840,1280;3840" -> "768,3840" | ND;ND;ND -> ND` | 96 | 3298.439 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 1868.607 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_12` | 1 | 104.902 |
| `PromptFlashAttention_21` | 1 | 102.522 |
| `PromptFlashAttention_12` | 1 | 100.022 |
| `PromptFlashAttention_21` | 1 | 99.522 |
| `PromptFlashAttention_26` | 1 | 99.302 |
| `PromptFlashAttention_26` | 1 | 98.562 |
| `PromptFlashAttention_12` | 1 | 96.842 |
| `PromptFlashAttention_31` | 1 | 96.522 |
| `PromptFlashAttention_31` | 1 | 96.382 |
| `PromptFlashAttention_17` | 1 | 95.761 |
| `PromptFlashAttention_31` | 1 | 95.641 |
| `PromptFlashAttention_26` | 1 | 94.782 |
| `PromptFlashAttention_5` | 1 | 94.782 |
| `PromptFlashAttention_5` | 1 | 92.942 |
| `PromptFlashAttention_22` | 1 | 92.082 |
| `PromptFlashAttention_4` | 1 | 90.982 |
| `PromptFlashAttention_25` | 1 | 90.742 |
| `PromptFlashAttention_24` | 1 | 90.582 |
| `PromptFlashAttention_17` | 1 | 90.502 |
| `PromptFlashAttention_6` | 1 | 90.482 |
| `PromptFlashAttention_25` | 1 | 90.122 |
| `PromptFlashAttention_10` | 1 | 89.662 |
| `PromptFlashAttention_25` | 1 | 89.602 |
| `PromptFlashAttention_21` | 1 | 89.441 |
| `PromptFlashAttention_10` | 1 | 88.942 |
| `PromptFlashAttention_10` | 1 | 88.802 |
| `PromptFlashAttention_24` | 1 | 88.642 |
| `PromptFlashAttention_11` | 1 | 88.142 |
| `PromptFlashAttention_5` | 1 | 88.102 |
| `PromptFlashAttention_23` | 1 | 88.062 |
| `PromptFlashAttention_23` | 1 | 87.842 |
| `PromptFlashAttention_23` | 1 | 87.822 |
| `PromptFlashAttention_6` | 1 | 87.742 |
| `PromptFlashAttention_11` | 1 | 87.702 |
| `PromptFlashAttention_18` | 1 | 87.181 |
| `PromptFlashAttention_6` | 1 | 87.122 |
| `PromptFlashAttention_4` | 1 | 86.922 |
| `PromptFlashAttention_9` | 1 | 86.802 |
| `PromptFlashAttention_20` | 1 | 86.582 |
| `PromptFlashAttention_22` | 1 | 86.482 |
| `PromptFlashAttention_11` | 1 | 86.462 |
| `PromptFlashAttention_20` | 1 | 86.402 |
| `PromptFlashAttention_20` | 1 | 86.402 |
| `PromptFlashAttention_22` | 1 | 86.362 |
| `PromptFlashAttention` | 1 | 86.302 |
| `PromptFlashAttention` | 1 | 86.262 |
| `PromptFlashAttention_24` | 1 | 85.922 |
| `PromptFlashAttention_4` | 1 | 85.282 |
| `PromptFlashAttention_19` | 1 | 85.142 |
| `PromptFlashAttention_18` | 1 | 84.942 |
| `PromptFlashAttention` | 1 | 84.782 |
| `PromptFlashAttention_9` | 1 | 84.642 |
| `PromptFlashAttention_19` | 1 | 84.561 |
| `PromptFlashAttention_18` | 1 | 84.362 |
| `PromptFlashAttention_13` | 1 | 84.261 |
| `PromptFlashAttention_19` | 1 | 84.062 |
| `PromptFlashAttention_13` | 1 | 83.942 |
| `PromptFlashAttention_8` | 1 | 83.862 |
| `PromptFlashAttention_8` | 1 | 83.742 |
| `PromptFlashAttention_9` | 1 | 83.682 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 19760.646 |
| `TorchDynamo Cache Lookup` | 3 | 18896.736 |
| `Torch-Compiled Region: 0/0` | 3 | 1366.040 |
| `TorchNpuGraphBase::Run` | 3 | 750.340 |
| `ExecuteGraph` | 3 | 269.520 |
| `RefreshAtTensorFromGeTensor` | 3 | 163.840 |
| `AssembleInputs` | 3 | 136.140 |
| `aten::empty` | 3 | 75.740 |
| `AssembleOutputs` | 3 | 54.090 |
| `aten::set_` | 3 | 43.070 |
| `empty_tensor` | 3 | 43.030 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 296605.890 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 57052.050 |
| `launch` | 1442 | 26845.110 |
| `InputCopy` | 3 | 131.970 |
| `ModelExecute` | 3 | 82.460 |
| `step_info` | 6 | 45.330 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 26.520 |
| `OutputCopy` | 3 | 2.360 |

