# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_d128_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_d128_crop_1_bucket_3072/profile/liteserver-c001-4_207281_20261007142856572_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `52687.319 us`
- `Free`: `967.433 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `847.000 us`
- `Stage`: `53654.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50505.004 |
| `MatMulV3` | 288 | 34597.872 |
| `StridedSliceD` | 480 | 14993.960 |
| `Mul` | 576 | 8057.271 |
| `PadV3` | 288 | 7528.379 |
| `AutomaticBufferFusionOp` | 480 | 6681.331 |
| `MatMulV2` | 96 | 6350.445 |
| `Add` | 384 | 5605.929 |
| `ReduceMeanD` | 384 | 5121.312 |
| `Transpose` | 288 | 4625.089 |
| `Sub` | 192 | 3504.022 |
| `ConcatV2D` | 192 | 2714.030 |
| `Cast` | 195 | 2345.059 |
| `Unpack` | 96 | 2104.098 |
| `Neg` | 192 | 1931.938 |
| `ConfusionTransposeD` | 96 | 979.056 |
| `te_memset_a8b1f5b1b0c44beef84d40753f2a30539fad1ae9efba5fbd957512e0b764e7d9__kernel0` | 288 | 286.108 |
| `Data` | 1 | 6.320 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_20` | 3 | 1625.052 |
| `PromptFlashAttention_11` | 3 | 1618.552 |
| `PromptFlashAttention_4` | 3 | 1606.193 |
| `PromptFlashAttention_30` | 3 | 1604.313 |
| `PromptFlashAttention_13` | 3 | 1599.592 |
| `PromptFlashAttention_21` | 3 | 1596.593 |
| `PromptFlashAttention_22` | 3 | 1595.752 |
| `PromptFlashAttention_25` | 3 | 1591.411 |
| `PromptFlashAttention_10` | 3 | 1589.491 |
| `PromptFlashAttention_23` | 3 | 1588.871 |
| `PromptFlashAttention_2` | 3 | 1588.753 |
| `PromptFlashAttention` | 3 | 1588.531 |
| `PromptFlashAttention_28` | 3 | 1587.971 |
| `PromptFlashAttention_24` | 3 | 1582.851 |
| `PromptFlashAttention_16` | 3 | 1579.071 |
| `PromptFlashAttention_6` | 3 | 1577.651 |
| `PromptFlashAttention_18` | 3 | 1577.551 |
| `PromptFlashAttention_5` | 3 | 1575.411 |
| `PromptFlashAttention_7` | 3 | 1566.911 |
| `PromptFlashAttention_8` | 3 | 1564.311 |
| `PromptFlashAttention_14` | 3 | 1563.971 |
| `PromptFlashAttention_9` | 3 | 1563.611 |
| `PromptFlashAttention_17` | 3 | 1559.710 |
| `PromptFlashAttention_27` | 3 | 1559.010 |
| `PromptFlashAttention_12` | 3 | 1558.252 |
| `PromptFlashAttention_3` | 3 | 1557.832 |
| `PromptFlashAttention_15` | 3 | 1557.611 |
| `PromptFlashAttention_19` | 3 | 1557.051 |
| `PromptFlashAttention_26` | 3 | 1556.810 |
| `PromptFlashAttention_29` | 3 | 1556.271 |
| `PromptFlashAttention_1` | 3 | 1555.652 |
| `PromptFlashAttention_31` | 3 | 1554.391 |
| `MatMulV2_122_to_v3` | 3 | 401.667 |
| `MatMulV2_6_to_v3` | 3 | 401.249 |
| `MatMulV2_126_to_v3` | 3 | 398.707 |
| `MatMulV2_2_to_v3` | 3 | 398.169 |
| `MatMulV2_90_to_v3` | 3 | 397.327 |
| `MatMulV2_102_to_v3` | 3 | 394.848 |
| `MatMulV2_66_to_v3` | 3 | 394.808 |
| `MatMulV2_70_to_v3` | 3 | 394.507 |
| `MatMulV2_54_to_v3` | 3 | 393.588 |
| `MatMulV2_114_to_v3` | 3 | 393.468 |
| `MatMulV2_98_to_v3` | 3 | 393.247 |
| `MatMulV2_78_to_v3` | 3 | 392.708 |
| `MatMulV2_22_to_v3` | 3 | 392.508 |
| `MatMulV2_58_to_v3` | 3 | 391.888 |
| `MatMulV2_82_to_v3` | 3 | 391.648 |
| `MatMulV2_127_to_v3` | 3 | 391.489 |
| `MatMulV2_42_to_v3` | 3 | 391.367 |
| `MatMulV2_111_to_v3` | 3 | 390.789 |
| `MatMulV2_79_to_v3` | 3 | 390.728 |
| `MatMulV2_14_to_v3` | 3 | 390.628 |
| `MatMulV2_15_to_v3` | 3 | 390.607 |
| `MatMulV2_110_to_v3` | 3 | 390.547 |
| `MatMulV2_50_to_v3` | 3 | 390.528 |
| `MatMulV2_7_to_v3` | 3 | 390.126 |
| `MatMulV2_119_to_v3` | 3 | 389.967 |
| `MatMulV2_67_to_v3` | 3 | 389.829 |
| `MatMulV2_62_to_v3` | 3 | 389.689 |
| `MatMulV2_23_to_v3` | 3 | 389.549 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_122_to_v3` | 3 | 401.667 |
| `MatMulV2_6_to_v3` | 3 | 401.249 |
| `MatMulV2_126_to_v3` | 3 | 398.707 |
| `MatMulV2_2_to_v3` | 3 | 398.169 |
| `MatMulV2_90_to_v3` | 3 | 397.327 |
| `MatMulV2_102_to_v3` | 3 | 394.848 |
| `MatMulV2_66_to_v3` | 3 | 394.808 |
| `MatMulV2_70_to_v3` | 3 | 394.507 |
| `MatMulV2_54_to_v3` | 3 | 393.588 |
| `MatMulV2_114_to_v3` | 3 | 393.468 |
| `MatMulV2_98_to_v3` | 3 | 393.247 |
| `MatMulV2_78_to_v3` | 3 | 392.708 |
| `MatMulV2_22_to_v3` | 3 | 392.508 |
| `MatMulV2_58_to_v3` | 3 | 391.888 |
| `MatMulV2_82_to_v3` | 3 | 391.648 |
| `MatMulV2_127_to_v3` | 3 | 391.489 |
| `MatMulV2_42_to_v3` | 3 | 391.367 |
| `MatMulV2_111_to_v3` | 3 | 390.789 |
| `MatMulV2_79_to_v3` | 3 | 390.728 |
| `MatMulV2_14_to_v3` | 3 | 390.628 |
| `MatMulV2_15_to_v3` | 3 | 390.607 |
| `MatMulV2_110_to_v3` | 3 | 390.547 |
| `MatMulV2_50_to_v3` | 3 | 390.528 |
| `MatMulV2_7_to_v3` | 3 | 390.126 |
| `MatMulV2_119_to_v3` | 3 | 389.967 |
| `MatMulV2_67_to_v3` | 3 | 389.829 |
| `MatMulV2_62_to_v3` | 3 | 389.689 |
| `MatMulV2_23_to_v3` | 3 | 389.549 |
| `MatMulV2_95_to_v3` | 3 | 389.548 |
| `MatMulV2_63_to_v3` | 3 | 389.308 |
| `MatMulV2_87_to_v3` | 3 | 389.308 |
| `MatMulV2_99_to_v3` | 3 | 388.948 |
| `MatMulV2_19_to_v3` | 3 | 388.928 |
| `MatMulV2_26_to_v3` | 3 | 388.889 |
| `MatMulV2_18_to_v3` | 3 | 388.767 |
| `MatMulV2_3_to_v3` | 3 | 388.746 |
| `MatMulV2_47_to_v3` | 3 | 388.647 |
| `MatMulV2_103_to_v3` | 3 | 388.267 |
| `MatMulV2_34_to_v3` | 3 | 388.207 |
| `MatMulV2_91_to_v3` | 3 | 388.148 |
| `MatMulV2_46_to_v3` | 3 | 388.108 |
| `MatMulV2_35_to_v3` | 3 | 388.088 |
| `MatMulV2_86_to_v3` | 3 | 388.067 |
| `MatMulV2_27_to_v3` | 3 | 387.629 |
| `MatMulV2_115_to_v3` | 3 | 387.567 |
| `MatMulV2_38_to_v3` | 3 | 387.467 |
| `MatMulV2_118_to_v3` | 3 | 387.329 |
| `MatMulV2_30_to_v3` | 3 | 387.268 |
| `MatMulV2_55_to_v3` | 3 | 387.247 |
| `MatMulV2_75_to_v3` | 3 | 387.028 |
| `MatMulV2_94_to_v3` | 3 | 386.547 |
| `MatMulV2_39_to_v3` | 3 | 386.348 |
| `MatMulV2_83_to_v3` | 3 | 386.328 |
| `MatMulV2_31_to_v3` | 3 | 386.288 |
| `MatMulV2_71_to_v3` | 3 | 386.269 |
| `MatMulV2_43_to_v3` | 3 | 385.668 |
| `MatMulV2_123_to_v3` | 3 | 385.468 |
| `MatMulV2_11_to_v3` | 3 | 385.288 |
| `MatMulV2_59_to_v3` | 3 | 385.249 |
| `MatMulV2_107_to_v3` | 3 | 384.748 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;5120,1280;5120" -> "3072,5120" | ND;ND;ND -> ND` | 96 | 12524.026 |
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12415.832 |
| `MatMulV3 | "3072,1280;3840,1280;3840" -> "3072,3840" | ND;ND;ND -> ND` | 96 | 9658.014 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6350.445 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_20` | 1 | 542.591 |
| `PromptFlashAttention_20` | 1 | 541.250 |
| `PromptFlashAttention_20` | 1 | 541.211 |
| `PromptFlashAttention_11` | 1 | 539.811 |
| `PromptFlashAttention_11` | 1 | 539.470 |
| `PromptFlashAttention_11` | 1 | 539.271 |
| `PromptFlashAttention_4` | 1 | 536.071 |
| `PromptFlashAttention_30` | 1 | 535.611 |
| `PromptFlashAttention_30` | 1 | 535.531 |
| `PromptFlashAttention_4` | 1 | 535.371 |
| `PromptFlashAttention_4` | 1 | 534.751 |
| `PromptFlashAttention_13` | 1 | 534.151 |
| `PromptFlashAttention_28` | 1 | 533.931 |
| `PromptFlashAttention_21` | 1 | 533.671 |
| `PromptFlashAttention_13` | 1 | 533.250 |
| `PromptFlashAttention_30` | 1 | 533.171 |
| `PromptFlashAttention_22` | 1 | 532.991 |
| `PromptFlashAttention_21` | 1 | 532.871 |
| `PromptFlashAttention_22` | 1 | 532.331 |
| `PromptFlashAttention_13` | 1 | 532.191 |
| `PromptFlashAttention_25` | 1 | 531.670 |
| `PromptFlashAttention` | 1 | 531.611 |
| `PromptFlashAttention_2` | 1 | 531.591 |
| `PromptFlashAttention` | 1 | 530.930 |
| `PromptFlashAttention_22` | 1 | 530.430 |
| `PromptFlashAttention_23` | 1 | 530.350 |
| `PromptFlashAttention_25` | 1 | 530.230 |
| `PromptFlashAttention_10` | 1 | 530.090 |
| `PromptFlashAttention_21` | 1 | 530.051 |
| `PromptFlashAttention_10` | 1 | 529.791 |
| `PromptFlashAttention_10` | 1 | 529.610 |
| `PromptFlashAttention_23` | 1 | 529.591 |
| `PromptFlashAttention_25` | 1 | 529.511 |
| `PromptFlashAttention_23` | 1 | 528.930 |
| `PromptFlashAttention_2` | 1 | 528.611 |
| `PromptFlashAttention_24` | 1 | 528.610 |
| `PromptFlashAttention_2` | 1 | 528.551 |
| `PromptFlashAttention_28` | 1 | 528.410 |
| `PromptFlashAttention_16` | 1 | 528.251 |
| `PromptFlashAttention_6` | 1 | 527.670 |
| `PromptFlashAttention_24` | 1 | 527.451 |
| `PromptFlashAttention_18` | 1 | 527.430 |
| `PromptFlashAttention_6` | 1 | 527.130 |
| `PromptFlashAttention_24` | 1 | 526.790 |
| `PromptFlashAttention` | 1 | 525.990 |
| `PromptFlashAttention_5` | 1 | 525.830 |
| `PromptFlashAttention_18` | 1 | 525.811 |
| `PromptFlashAttention_16` | 1 | 525.670 |
| `PromptFlashAttention_28` | 1 | 525.630 |
| `PromptFlashAttention_5` | 1 | 525.410 |
| `PromptFlashAttention_16` | 1 | 525.150 |
| `PromptFlashAttention_18` | 1 | 524.310 |
| `PromptFlashAttention_5` | 1 | 524.171 |
| `PromptFlashAttention_6` | 1 | 522.851 |
| `PromptFlashAttention_7` | 1 | 522.810 |
| `PromptFlashAttention_7` | 1 | 522.390 |
| `PromptFlashAttention_9` | 1 | 522.211 |
| `PromptFlashAttention_14` | 1 | 522.031 |
| `PromptFlashAttention_8` | 1 | 521.731 |
| `PromptFlashAttention_7` | 1 | 521.711 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 53566.681 |
| `TorchDynamo Cache Lookup` | 3 | 52677.101 |
| `Torch-Compiled Region: 0/0` | 3 | 1358.130 |
| `TorchNpuGraphBase::Run` | 3 | 755.500 |
| `ExecuteGraph` | 3 | 281.020 |
| `RefreshAtTensorFromGeTensor` | 3 | 159.980 |
| `AssembleInputs` | 3 | 141.950 |
| `aten::empty` | 3 | 77.790 |
| `empty_tensor` | 3 | 44.220 |
| `AssembleOutputs` | 3 | 43.470 |
| `aten::set_` | 3 | 40.120 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 296782.870 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 158391.290 |
| `launch` | 1442 | 26445.210 |
| `InputCopy` | 3 | 140.060 |
| `ModelExecute` | 3 | 88.910 |
| `step_info` | 6 | 51.240 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 27.440 |
| `OutputCopy` | 3 | 2.380 |

