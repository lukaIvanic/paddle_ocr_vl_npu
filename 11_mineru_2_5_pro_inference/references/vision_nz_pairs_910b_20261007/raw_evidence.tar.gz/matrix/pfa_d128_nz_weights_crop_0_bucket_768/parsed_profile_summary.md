# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_d128_nz_weights_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_d128_nz_weights_crop_0_bucket_768/profile/liteserver-c001-4_208553_20261007143033378_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `19362.730 us`
- `Free`: `974.897 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `885.000 us`
- `Stage`: `20337.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 15713.462 |
| `PromptFlashAttention` | 96 | 8444.377 |
| `StridedSliceD` | 480 | 5993.481 |
| `Mul` | 576 | 4366.930 |
| `PadV3` | 288 | 3766.031 |
| `Add` | 384 | 3581.139 |
| `AutomaticBufferFusionOp` | 480 | 3009.475 |
| `Transpose` | 288 | 2745.219 |
| `ReduceMeanD` | 384 | 2602.508 |
| `Sub` | 192 | 1861.472 |
| `ConcatV2D` | 192 | 1653.935 |
| `Cast` | 195 | 1576.609 |
| `Neg` | 192 | 1432.882 |
| `Unpack` | 96 | 820.863 |
| `ConfusionTransposeD` | 96 | 488.787 |
| `te_memset_a8b1f5b1b0c44beef84d40753f2a30539fad1ae9efba5fbd957512e0b764e7d9__kernel0` | 288 | 278.584 |
| `Data` | 1 | 5.060 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_14` | 3 | 306.885 |
| `PromptFlashAttention_11` | 3 | 304.926 |
| `PromptFlashAttention_24` | 3 | 291.686 |
| `PromptFlashAttention_4` | 3 | 291.226 |
| `PromptFlashAttention_12` | 3 | 284.747 |
| `te_memset_a8b1f5b1b0c44beef84d40753f2a30539fad1ae9efba5fbd957512e0b764e7d9__kernel0` | 288 | 278.584 |
| `PromptFlashAttention_5` | 3 | 277.726 |
| `PromptFlashAttention_21` | 3 | 275.026 |
| `PromptFlashAttention_23` | 3 | 274.265 |
| `PromptFlashAttention_8` | 3 | 271.666 |
| `PromptFlashAttention_22` | 3 | 267.744 |
| `PromptFlashAttention_28` | 3 | 267.566 |
| `PromptFlashAttention_7` | 3 | 267.506 |
| `PromptFlashAttention_19` | 3 | 265.886 |
| `PromptFlashAttention_10` | 3 | 264.965 |
| `PromptFlashAttention` | 3 | 263.986 |
| `PromptFlashAttention_25` | 3 | 262.906 |
| `PromptFlashAttention_2` | 3 | 262.824 |
| `PromptFlashAttention_31` | 3 | 262.186 |
| `PromptFlashAttention_9` | 3 | 261.526 |
| `PromptFlashAttention_15` | 3 | 260.726 |
| `PromptFlashAttention_6` | 3 | 254.266 |
| `PromptFlashAttention_13` | 3 | 252.246 |
| `PromptFlashAttention_29` | 3 | 251.166 |
| `PromptFlashAttention_16` | 3 | 250.905 |
| `PromptFlashAttention_30` | 3 | 250.384 |
| `PromptFlashAttention_18` | 3 | 245.586 |
| `PromptFlashAttention_27` | 3 | 243.865 |
| `PromptFlashAttention_3` | 3 | 243.506 |
| `PromptFlashAttention_26` | 3 | 242.945 |
| `PromptFlashAttention_20` | 3 | 242.165 |
| `PromptFlashAttention_1` | 3 | 242.164 |
| `PromptFlashAttention_17` | 3 | 239.205 |
| `MatMulV2_59` | 3 | 154.843 |
| `MatMulV2_75` | 3 | 154.803 |
| `MatMulV2_119` | 3 | 154.703 |
| `MatMulV2_63` | 3 | 154.683 |
| `MatMulV2_19` | 3 | 154.283 |
| `MatMulV2_43` | 3 | 153.723 |
| `MatMulV2_115` | 3 | 153.723 |
| `MatMulV2_35` | 3 | 153.624 |
| `MatMulV2_107` | 3 | 153.503 |
| `MatMulV2_15` | 3 | 153.503 |
| `MatMulV2_51` | 3 | 153.363 |
| `MatMulV2_11` | 3 | 152.943 |
| `MatMulV2_83` | 3 | 152.943 |
| `MatMulV2_103` | 3 | 152.923 |
| `MatMulV2_87` | 3 | 152.863 |
| `MatMulV2_79` | 3 | 152.743 |
| `MatMulV2_31` | 3 | 152.523 |
| `MatMulV2_23` | 3 | 152.303 |
| `MatMulV2_111` | 3 | 152.263 |
| `MatMulV2_3` | 3 | 152.083 |
| `MatMulV2_95` | 3 | 151.783 |
| `MatMulV2_27` | 3 | 151.663 |
| `MatMulV2_67` | 3 | 151.603 |
| `MatMulV2_127` | 3 | 151.563 |
| `MatMulV2_99` | 3 | 151.103 |
| `MatMulV2_7` | 3 | 150.643 |
| `MatMulV2_39` | 3 | 150.503 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_59` | 3 | 154.843 |
| `MatMulV2_75` | 3 | 154.803 |
| `MatMulV2_119` | 3 | 154.703 |
| `MatMulV2_63` | 3 | 154.683 |
| `MatMulV2_19` | 3 | 154.283 |
| `MatMulV2_43` | 3 | 153.723 |
| `MatMulV2_115` | 3 | 153.723 |
| `MatMulV2_35` | 3 | 153.624 |
| `MatMulV2_107` | 3 | 153.503 |
| `MatMulV2_15` | 3 | 153.503 |
| `MatMulV2_51` | 3 | 153.363 |
| `MatMulV2_11` | 3 | 152.943 |
| `MatMulV2_83` | 3 | 152.943 |
| `MatMulV2_103` | 3 | 152.923 |
| `MatMulV2_87` | 3 | 152.863 |
| `MatMulV2_79` | 3 | 152.743 |
| `MatMulV2_31` | 3 | 152.523 |
| `MatMulV2_23` | 3 | 152.303 |
| `MatMulV2_111` | 3 | 152.263 |
| `MatMulV2_3` | 3 | 152.083 |
| `MatMulV2_95` | 3 | 151.783 |
| `MatMulV2_27` | 3 | 151.663 |
| `MatMulV2_67` | 3 | 151.603 |
| `MatMulV2_127` | 3 | 151.563 |
| `MatMulV2_99` | 3 | 151.103 |
| `MatMulV2_7` | 3 | 150.643 |
| `MatMulV2_39` | 3 | 150.503 |
| `MatMulV2_123` | 3 | 150.383 |
| `MatMulV2_47` | 3 | 150.363 |
| `MatMulV2_55` | 3 | 149.903 |
| `MatMulV2_71` | 3 | 149.503 |
| `MatMulV2_91` | 3 | 146.763 |
| `MatMulV2_98` | 3 | 140.123 |
| `MatMulV2_70` | 3 | 139.463 |
| `MatMulV2_2` | 3 | 138.803 |
| `MatMulV2_114` | 3 | 138.322 |
| `MatMulV2_90` | 3 | 138.043 |
| `MatMulV2_18` | 3 | 137.963 |
| `MatMulV2_118` | 3 | 137.943 |
| `MatMulV2_22` | 3 | 137.923 |
| `MatMulV2_106` | 3 | 137.903 |
| `MatMulV2_66` | 3 | 137.583 |
| `MatMulV2_38` | 3 | 137.543 |
| `MatMulV2_50` | 3 | 137.483 |
| `MatMulV2_14` | 3 | 136.861 |
| `MatMulV2_10` | 3 | 136.622 |
| `MatMulV2_54` | 3 | 136.423 |
| `MatMulV2_34` | 3 | 136.262 |
| `MatMulV2_82` | 3 | 136.123 |
| `MatMulV2_122` | 3 | 136.063 |
| `MatMulV2_62` | 3 | 136.002 |
| `MatMulV2_30` | 3 | 135.562 |
| `MatMulV2_42` | 3 | 135.502 |
| `MatMulV2_102` | 3 | 135.162 |
| `MatMulV2_58` | 3 | 134.923 |
| `MatMulV2_86` | 3 | 134.003 |
| `MatMulV2_110` | 3 | 133.962 |
| `MatMulV2_126` | 3 | 133.783 |
| `MatMulV2_46` | 3 | 133.703 |
| `MatMulV2_26` | 3 | 133.603 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;320,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4874.117 |
| `MatMulV2 | "768,1280;80,320,16,16;5120" -> "768,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4354.322 |
| `MatMulV2 | "768,1280;80,240,16,16;3840" -> "768,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3609.263 |
| `MatMulV2 | "768,1280;80,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 2875.760 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_14` | 1 | 110.282 |
| `PromptFlashAttention_11` | 1 | 109.622 |
| `PromptFlashAttention_12` | 1 | 107.163 |
| `PromptFlashAttention_11` | 1 | 103.582 |
| `PromptFlashAttention_14` | 1 | 103.422 |
| `PromptFlashAttention_4` | 1 | 102.662 |
| `PromptFlashAttention_8` | 1 | 101.702 |
| `PromptFlashAttention` | 1 | 100.502 |
| `PromptFlashAttention_7` | 1 | 99.782 |
| `PromptFlashAttention_24` | 1 | 98.982 |
| `PromptFlashAttention_24` | 1 | 96.962 |
| `PromptFlashAttention_28` | 1 | 96.922 |
| `PromptFlashAttention_21` | 1 | 96.402 |
| `PromptFlashAttention_24` | 1 | 95.742 |
| `PromptFlashAttention_4` | 1 | 95.402 |
| `PromptFlashAttention_2` | 1 | 95.321 |
| `PromptFlashAttention_23` | 1 | 95.182 |
| `PromptFlashAttention_19` | 1 | 94.782 |
| `PromptFlashAttention_23` | 1 | 93.461 |
| `PromptFlashAttention_5` | 1 | 93.382 |
| `PromptFlashAttention_14` | 1 | 93.181 |
| `PromptFlashAttention_4` | 1 | 93.162 |
| `PromptFlashAttention_25` | 1 | 92.942 |
| `PromptFlashAttention_5` | 1 | 92.942 |
| `PromptFlashAttention_12` | 1 | 91.762 |
| `PromptFlashAttention_11` | 1 | 91.722 |
| `PromptFlashAttention_19` | 1 | 91.682 |
| `PromptFlashAttention_5` | 1 | 91.402 |
| `PromptFlashAttention_30` | 1 | 90.941 |
| `PromptFlashAttention_28` | 1 | 90.782 |
| `PromptFlashAttention_16` | 1 | 90.721 |
| `PromptFlashAttention_22` | 1 | 90.402 |
| `PromptFlashAttention_22` | 1 | 90.241 |
| `PromptFlashAttention_10` | 1 | 89.681 |
| `PromptFlashAttention_21` | 1 | 89.442 |
| `PromptFlashAttention_21` | 1 | 89.182 |
| `PromptFlashAttention_2` | 1 | 89.161 |
| `PromptFlashAttention_8` | 1 | 88.942 |
| `PromptFlashAttention_10` | 1 | 87.942 |
| `PromptFlashAttention_31` | 1 | 87.882 |
| `PromptFlashAttention_9` | 1 | 87.502 |
| `PromptFlashAttention_31` | 1 | 87.442 |
| `PromptFlashAttention_9` | 1 | 87.402 |
| `PromptFlashAttention_10` | 1 | 87.342 |
| `PromptFlashAttention_15` | 1 | 87.222 |
| `PromptFlashAttention_22` | 1 | 87.101 |
| `PromptFlashAttention_7` | 1 | 87.042 |
| `PromptFlashAttention_15` | 1 | 86.982 |
| `PromptFlashAttention_31` | 1 | 86.862 |
| `PromptFlashAttention_9` | 1 | 86.622 |
| `PromptFlashAttention_15` | 1 | 86.522 |
| `PromptFlashAttention_12` | 1 | 85.822 |
| `PromptFlashAttention_23` | 1 | 85.622 |
| `PromptFlashAttention_6` | 1 | 85.402 |
| `PromptFlashAttention_25` | 1 | 85.142 |
| `PromptFlashAttention_25` | 1 | 84.822 |
| `PromptFlashAttention_6` | 1 | 84.502 |
| `PromptFlashAttention_6` | 1 | 84.362 |
| `PromptFlashAttention_13` | 1 | 84.202 |
| `PromptFlashAttention_29` | 1 | 84.162 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 20244.305 |
| `TorchDynamo Cache Lookup` | 3 | 19359.045 |
| `Torch-Compiled Region: 0/0` | 3 | 1376.170 |
| `TorchNpuGraphBase::Run` | 3 | 771.780 |
| `ExecuteGraph` | 3 | 278.600 |
| `RefreshAtTensorFromGeTensor` | 3 | 169.540 |
| `AssembleInputs` | 3 | 150.360 |
| `aten::empty` | 3 | 79.570 |
| `empty_tensor` | 3 | 46.210 |
| `aten::set_` | 3 | 41.640 |
| `AssembleOutputs` | 3 | 39.660 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 293248.920 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 58743.390 |
| `launch` | 1442 | 24988.310 |
| `InputCopy` | 3 | 133.330 |
| `ModelExecute` | 3 | 91.350 |
| `step_info` | 6 | 52.570 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 25.290 |
| `OutputCopy` | 3 | 1.900 |

