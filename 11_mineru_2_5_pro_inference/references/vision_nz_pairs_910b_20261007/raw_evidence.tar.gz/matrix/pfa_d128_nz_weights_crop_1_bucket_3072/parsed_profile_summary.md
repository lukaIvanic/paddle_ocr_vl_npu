# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_d128_nz_weights_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_d128_nz_weights_crop_1_bucket_3072/profile/liteserver-c001-4_209964_20261007143217241_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `52688.273 us`
- `Free`: `1039.261 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `855.000 us`
- `Stage`: `53727.500 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50452.389 |
| `MatMulV2` | 384 | 45707.099 |
| `StridedSliceD` | 480 | 14675.474 |
| `PadV3` | 288 | 7224.185 |
| `Mul` | 576 | 7179.154 |
| `AutomaticBufferFusionOp` | 480 | 6302.407 |
| `Add` | 384 | 5337.404 |
| `ReduceMeanD` | 384 | 4791.694 |
| `Transpose` | 288 | 3874.510 |
| `Sub` | 192 | 3179.090 |
| `ConcatV2D` | 192 | 2320.224 |
| `Cast` | 195 | 2164.464 |
| `Unpack` | 96 | 2064.804 |
| `Neg` | 192 | 1773.377 |
| `ConfusionTransposeD` | 96 | 910.899 |
| `te_memset_a8b1f5b1b0c44beef84d40753f2a30539fad1ae9efba5fbd957512e0b764e7d9__kernel0` | 288 | 285.026 |
| `Data` | 1 | 6.460 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_14` | 3 | 1617.873 |
| `PromptFlashAttention_10` | 3 | 1606.112 |
| `PromptFlashAttention_25` | 3 | 1603.212 |
| `PromptFlashAttention_12` | 3 | 1601.672 |
| `PromptFlashAttention_24` | 3 | 1598.532 |
| `PromptFlashAttention_6` | 3 | 1593.252 |
| `PromptFlashAttention_21` | 3 | 1590.911 |
| `PromptFlashAttention` | 3 | 1589.832 |
| `PromptFlashAttention_4` | 3 | 1588.593 |
| `PromptFlashAttention_5` | 3 | 1588.071 |
| `PromptFlashAttention_22` | 3 | 1583.632 |
| `PromptFlashAttention_23` | 3 | 1583.530 |
| `PromptFlashAttention_13` | 3 | 1583.451 |
| `PromptFlashAttention_11` | 3 | 1582.352 |
| `PromptFlashAttention_28` | 3 | 1581.571 |
| `PromptFlashAttention_30` | 3 | 1577.352 |
| `PromptFlashAttention_9` | 3 | 1576.871 |
| `PromptFlashAttention_31` | 3 | 1574.952 |
| `PromptFlashAttention_8` | 3 | 1574.752 |
| `PromptFlashAttention_18` | 3 | 1569.012 |
| `PromptFlashAttention_3` | 3 | 1567.592 |
| `PromptFlashAttention_27` | 3 | 1567.351 |
| `PromptFlashAttention_15` | 3 | 1565.731 |
| `PromptFlashAttention_17` | 3 | 1561.691 |
| `PromptFlashAttention_19` | 3 | 1558.191 |
| `PromptFlashAttention_7` | 3 | 1556.731 |
| `PromptFlashAttention_1` | 3 | 1555.192 |
| `PromptFlashAttention_20` | 3 | 1555.071 |
| `PromptFlashAttention_16` | 3 | 1553.551 |
| `PromptFlashAttention_26` | 3 | 1549.450 |
| `PromptFlashAttention_2` | 3 | 1548.792 |
| `PromptFlashAttention_29` | 3 | 1547.511 |
| `MatMulV2_91` | 3 | 457.209 |
| `MatMulV2_59` | 3 | 457.189 |
| `MatMulV2_83` | 3 | 456.029 |
| `MatMulV2_123` | 3 | 456.029 |
| `MatMulV2_115` | 3 | 455.909 |
| `MatMulV2_79` | 3 | 455.529 |
| `MatMulV2_111` | 3 | 454.149 |
| `MatMulV2_71` | 3 | 453.309 |
| `MatMulV2_11` | 3 | 452.949 |
| `MatMulV2_63` | 3 | 452.630 |
| `MatMulV2_103` | 3 | 452.469 |
| `MatMulV2_95` | 3 | 452.329 |
| `MatMulV2_35` | 3 | 452.309 |
| `MatMulV2_19` | 3 | 452.129 |
| `MatMulV2_23` | 3 | 451.309 |
| `MatMulV2_75` | 3 | 450.309 |
| `MatMulV2_15` | 3 | 449.829 |
| `MatMulV2_31` | 3 | 449.789 |
| `MatMulV2_127` | 3 | 448.949 |
| `MatMulV2_51` | 3 | 448.669 |
| `MatMulV2_107` | 3 | 448.549 |
| `MatMulV2_39` | 3 | 447.429 |
| `MatMulV2_67` | 3 | 447.309 |
| `MatMulV2_47` | 3 | 447.049 |
| `MatMulV2_27` | 3 | 446.849 |
| `MatMulV2_43` | 3 | 446.789 |
| `MatMulV2_87` | 3 | 446.709 |
| `MatMulV2_3` | 3 | 446.549 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_91` | 3 | 457.209 |
| `MatMulV2_59` | 3 | 457.189 |
| `MatMulV2_83` | 3 | 456.029 |
| `MatMulV2_123` | 3 | 456.029 |
| `MatMulV2_115` | 3 | 455.909 |
| `MatMulV2_79` | 3 | 455.529 |
| `MatMulV2_111` | 3 | 454.149 |
| `MatMulV2_71` | 3 | 453.309 |
| `MatMulV2_11` | 3 | 452.949 |
| `MatMulV2_63` | 3 | 452.630 |
| `MatMulV2_103` | 3 | 452.469 |
| `MatMulV2_95` | 3 | 452.329 |
| `MatMulV2_35` | 3 | 452.309 |
| `MatMulV2_19` | 3 | 452.129 |
| `MatMulV2_23` | 3 | 451.309 |
| `MatMulV2_75` | 3 | 450.309 |
| `MatMulV2_15` | 3 | 449.829 |
| `MatMulV2_31` | 3 | 449.789 |
| `MatMulV2_127` | 3 | 448.949 |
| `MatMulV2_51` | 3 | 448.669 |
| `MatMulV2_107` | 3 | 448.549 |
| `MatMulV2_39` | 3 | 447.429 |
| `MatMulV2_67` | 3 | 447.309 |
| `MatMulV2_47` | 3 | 447.049 |
| `MatMulV2_27` | 3 | 446.849 |
| `MatMulV2_43` | 3 | 446.789 |
| `MatMulV2_87` | 3 | 446.709 |
| `MatMulV2_3` | 3 | 446.549 |
| `MatMulV2_99` | 3 | 446.149 |
| `MatMulV2_7` | 3 | 446.089 |
| `MatMulV2_119` | 3 | 445.349 |
| `MatMulV2_55` | 3 | 444.889 |
| `MatMulV2_110` | 3 | 432.509 |
| `MatMulV2_62` | 3 | 431.229 |
| `MatMulV2_2` | 3 | 430.309 |
| `MatMulV2_70` | 3 | 429.748 |
| `MatMulV2_94` | 3 | 429.489 |
| `MatMulV2_58` | 3 | 428.928 |
| `MatMulV2_114` | 3 | 428.429 |
| `MatMulV2_90` | 3 | 428.009 |
| `MatMulV2_50` | 3 | 428.009 |
| `MatMulV2_26` | 3 | 427.408 |
| `MatMulV2_82` | 3 | 427.388 |
| `MatMulV2_18` | 3 | 427.169 |
| `MatMulV2_10` | 3 | 426.909 |
| `MatMulV2_6` | 3 | 426.469 |
| `MatMulV2_122` | 3 | 426.349 |
| `MatMulV2_42` | 3 | 426.069 |
| `MatMulV2_22` | 3 | 425.708 |
| `MatMulV2_86` | 3 | 424.548 |
| `MatMulV2_78` | 3 | 424.468 |
| `MatMulV2_38` | 3 | 424.429 |
| `MatMulV2_54` | 3 | 423.949 |
| `MatMulV2_14` | 3 | 423.649 |
| `MatMulV2_106` | 3 | 423.207 |
| `MatMulV2_118` | 3 | 422.929 |
| `MatMulV2_46` | 3 | 422.909 |
| `MatMulV2_34` | 3 | 422.868 |
| `MatMulV2_74` | 3 | 422.568 |
| `MatMulV2_102` | 3 | 422.088 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "3072,5120;320,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 14418.729 |
| `MatMulV2 | "3072,1280;80,320,16,16;5120" -> "3072,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 13621.293 |
| `MatMulV2 | "3072,1280;80,240,16,16;3840" -> "3072,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 10763.258 |
| `MatMulV2 | "3072,1280;80,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 6903.819 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_14` | 1 | 541.571 |
| `PromptFlashAttention_14` | 1 | 539.171 |
| `PromptFlashAttention_14` | 1 | 537.131 |
| `PromptFlashAttention_25` | 1 | 536.091 |
| `PromptFlashAttention_10` | 1 | 535.670 |
| `PromptFlashAttention_12` | 1 | 535.591 |
| `PromptFlashAttention_10` | 1 | 535.431 |
| `PromptFlashAttention_10` | 1 | 535.011 |
| `PromptFlashAttention_25` | 1 | 534.231 |
| `PromptFlashAttention_12` | 1 | 533.450 |
| `PromptFlashAttention_24` | 1 | 533.430 |
| `PromptFlashAttention_6` | 1 | 533.250 |
| `PromptFlashAttention_24` | 1 | 533.151 |
| `PromptFlashAttention_4` | 1 | 532.931 |
| `PromptFlashAttention_25` | 1 | 532.890 |
| `PromptFlashAttention_12` | 1 | 532.631 |
| `PromptFlashAttention_24` | 1 | 531.951 |
| `PromptFlashAttention_6` | 1 | 531.891 |
| `PromptFlashAttention_23` | 1 | 531.570 |
| `PromptFlashAttention_21` | 1 | 531.290 |
| `PromptFlashAttention` | 1 | 531.170 |
| `PromptFlashAttention_5` | 1 | 530.911 |
| `PromptFlashAttention_4` | 1 | 530.591 |
| `PromptFlashAttention_13` | 1 | 530.550 |
| `PromptFlashAttention_21` | 1 | 530.290 |
| `PromptFlashAttention` | 1 | 530.151 |
| `PromptFlashAttention_21` | 1 | 529.331 |
| `PromptFlashAttention_22` | 1 | 529.111 |
| `PromptFlashAttention_5` | 1 | 529.050 |
| `PromptFlashAttention` | 1 | 528.511 |
| `PromptFlashAttention_22` | 1 | 528.430 |
| `PromptFlashAttention_6` | 1 | 528.111 |
| `PromptFlashAttention_5` | 1 | 528.110 |
| `PromptFlashAttention_13` | 1 | 528.011 |
| `PromptFlashAttention_11` | 1 | 527.751 |
| `PromptFlashAttention_28` | 1 | 527.750 |
| `PromptFlashAttention_8` | 1 | 527.471 |
| `PromptFlashAttention_11` | 1 | 527.451 |
| `PromptFlashAttention_28` | 1 | 527.390 |
| `PromptFlashAttention_11` | 1 | 527.150 |
| `PromptFlashAttention_23` | 1 | 526.670 |
| `PromptFlashAttention_9` | 1 | 526.591 |
| `PromptFlashAttention_28` | 1 | 526.431 |
| `PromptFlashAttention_30` | 1 | 526.210 |
| `PromptFlashAttention_22` | 1 | 526.091 |
| `PromptFlashAttention_30` | 1 | 525.711 |
| `PromptFlashAttention_9` | 1 | 525.670 |
| `PromptFlashAttention_31` | 1 | 525.571 |
| `PromptFlashAttention_30` | 1 | 525.431 |
| `PromptFlashAttention_23` | 1 | 525.290 |
| `PromptFlashAttention_4` | 1 | 525.071 |
| `PromptFlashAttention_13` | 1 | 524.890 |
| `PromptFlashAttention_31` | 1 | 524.711 |
| `PromptFlashAttention_31` | 1 | 524.670 |
| `PromptFlashAttention_9` | 1 | 524.610 |
| `PromptFlashAttention_8` | 1 | 524.171 |
| `PromptFlashAttention_3` | 1 | 523.371 |
| `PromptFlashAttention_18` | 1 | 523.311 |
| `PromptFlashAttention_8` | 1 | 523.110 |
| `PromptFlashAttention_18` | 1 | 523.031 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 53672.781 |
| `TorchDynamo Cache Lookup` | 3 | 52688.861 |
| `Torch-Compiled Region: 0/0` | 3 | 1450.530 |
| `TorchNpuGraphBase::Run` | 3 | 819.350 |
| `ExecuteGraph` | 3 | 266.630 |
| `AssembleInputs` | 3 | 197.970 |
| `RefreshAtTensorFromGeTensor` | 3 | 174.460 |
| `aten::empty` | 3 | 82.590 |
| `empty_tensor` | 3 | 48.410 |
| `AssembleOutputs` | 3 | 41.160 |
| `aten::set_` | 3 | 39.100 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 289829.770 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 158650.430 |
| `launch` | 1442 | 26431.520 |
| `InputCopy` | 3 | 121.140 |
| `ModelExecute` | 3 | 93.820 |
| `step_info` | 6 | 46.310 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 25.530 |
| `OutputCopy` | 3 | 1.690 |

