# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_nz_weights_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_nz_weights_crop_0_bucket_768/profile/liteserver-c001-4_189382_20261007141045086_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `18417.854 us`
- `Free`: `818.530 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `918.750 us`
- `Stage`: `19236.250 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `MatMulV2` | 384 | 15808.109 |
| `PromptFlashAttention` | 96 | 8060.223 |
| `StridedSliceD` | 384 | 5760.673 |
| `Mul` | 576 | 4444.383 |
| `Add` | 384 | 3729.057 |
| `AutomaticBufferFusionOp` | 480 | 3267.473 |
| `Transpose` | 288 | 3094.140 |
| `ReduceMeanD` | 384 | 2590.312 |
| `Cast` | 195 | 1944.921 |
| `Sub` | 192 | 1882.195 |
| `Neg` | 192 | 1751.795 |
| `ConcatV2D` | 192 | 1659.475 |
| `Unpack` | 96 | 824.476 |
| `ConfusionTransposeD` | 96 | 522.713 |
| `Data` | 1 | 6.160 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_1` | 3 | 269.785 |
| `PromptFlashAttention_24` | 3 | 269.145 |
| `PromptFlashAttention_25` | 3 | 267.685 |
| `PromptFlashAttention_9` | 3 | 266.905 |
| `PromptFlashAttention_16` | 3 | 266.766 |
| `PromptFlashAttention_15` | 3 | 262.705 |
| `PromptFlashAttention_12` | 3 | 261.725 |
| `PromptFlashAttention_28` | 3 | 257.924 |
| `PromptFlashAttention_20` | 3 | 256.845 |
| `PromptFlashAttention_31` | 3 | 254.645 |
| `PromptFlashAttention_30` | 3 | 254.405 |
| `PromptFlashAttention_13` | 3 | 254.384 |
| `PromptFlashAttention_8` | 3 | 254.305 |
| `PromptFlashAttention_7` | 3 | 252.385 |
| `PromptFlashAttention_14` | 3 | 252.046 |
| `PromptFlashAttention_6` | 3 | 251.926 |
| `PromptFlashAttention_19` | 3 | 251.046 |
| `PromptFlashAttention_23` | 3 | 250.825 |
| `PromptFlashAttention_4` | 3 | 249.925 |
| `PromptFlashAttention_26` | 3 | 249.325 |
| `PromptFlashAttention_27` | 3 | 249.225 |
| `PromptFlashAttention_5` | 3 | 248.506 |
| `PromptFlashAttention_11` | 3 | 247.806 |
| `PromptFlashAttention` | 3 | 245.486 |
| `PromptFlashAttention_29` | 3 | 245.085 |
| `PromptFlashAttention_10` | 3 | 243.103 |
| `PromptFlashAttention_22` | 3 | 241.305 |
| `PromptFlashAttention_17` | 3 | 239.165 |
| `PromptFlashAttention_2` | 3 | 238.245 |
| `PromptFlashAttention_21` | 3 | 236.025 |
| `PromptFlashAttention_3` | 3 | 235.985 |
| `PromptFlashAttention_18` | 3 | 235.585 |
| `MatMulV2_127` | 3 | 152.743 |
| `MatMulV2_79` | 3 | 152.603 |
| `MatMulV2_123` | 3 | 151.283 |
| `MatMulV2_59` | 3 | 151.043 |
| `MatMulV2_39` | 3 | 150.683 |
| `MatMulV2_51` | 3 | 150.643 |
| `MatMulV2_67` | 3 | 150.463 |
| `MatMulV2_87` | 3 | 150.402 |
| `MatMulV2_115` | 3 | 149.923 |
| `MatMulV2_47` | 3 | 149.903 |
| `MatMulV2_43` | 3 | 149.803 |
| `MatMulV2_83` | 3 | 149.403 |
| `MatMulV2_3` | 3 | 149.343 |
| `MatMulV2_95` | 3 | 149.283 |
| `MatMulV2_91` | 3 | 149.243 |
| `MatMulV2_107` | 3 | 149.003 |
| `MatMulV2_111` | 3 | 148.443 |
| `MatMulV2_103` | 3 | 148.303 |
| `MatMulV2_71` | 3 | 148.163 |
| `MatMulV2_23` | 3 | 148.103 |
| `MatMulV2_75` | 3 | 147.743 |
| `MatMulV2_63` | 3 | 147.423 |
| `MatMulV2_31` | 3 | 146.942 |
| `MatMulV2_11` | 3 | 146.743 |
| `MatMulV2_55` | 3 | 146.343 |
| `MatMulV2_19` | 3 | 146.203 |
| `MatMulV2_15` | 3 | 146.143 |
| `MatMulV2_27` | 3 | 145.363 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_127` | 3 | 152.743 |
| `MatMulV2_79` | 3 | 152.603 |
| `MatMulV2_123` | 3 | 151.283 |
| `MatMulV2_59` | 3 | 151.043 |
| `MatMulV2_39` | 3 | 150.683 |
| `MatMulV2_51` | 3 | 150.643 |
| `MatMulV2_67` | 3 | 150.463 |
| `MatMulV2_87` | 3 | 150.402 |
| `MatMulV2_115` | 3 | 149.923 |
| `MatMulV2_47` | 3 | 149.903 |
| `MatMulV2_43` | 3 | 149.803 |
| `MatMulV2_83` | 3 | 149.403 |
| `MatMulV2_3` | 3 | 149.343 |
| `MatMulV2_95` | 3 | 149.283 |
| `MatMulV2_91` | 3 | 149.243 |
| `MatMulV2_107` | 3 | 149.003 |
| `MatMulV2_111` | 3 | 148.443 |
| `MatMulV2_103` | 3 | 148.303 |
| `MatMulV2_71` | 3 | 148.163 |
| `MatMulV2_23` | 3 | 148.103 |
| `MatMulV2_75` | 3 | 147.743 |
| `MatMulV2_63` | 3 | 147.423 |
| `MatMulV2_31` | 3 | 146.942 |
| `MatMulV2_11` | 3 | 146.743 |
| `MatMulV2_55` | 3 | 146.343 |
| `MatMulV2_19` | 3 | 146.203 |
| `MatMulV2_15` | 3 | 146.143 |
| `MatMulV2_27` | 3 | 145.363 |
| `MatMulV2_35` | 3 | 144.983 |
| `MatMulV2_119` | 3 | 144.663 |
| `MatMulV2_102` | 3 | 143.663 |
| `MatMulV2_99` | 3 | 142.583 |
| `MatMulV2_7` | 3 | 142.522 |
| `MatMulV2_34` | 3 | 141.363 |
| `MatMulV2_6` | 3 | 141.263 |
| `MatMulV2_66` | 3 | 140.443 |
| `MatMulV2_106` | 3 | 139.423 |
| `MatMulV2_14` | 3 | 138.603 |
| `MatMulV2_122` | 3 | 138.603 |
| `MatMulV2_70` | 3 | 138.483 |
| `MatMulV2_110` | 3 | 138.403 |
| `MatMulV2_10` | 3 | 138.342 |
| `MatMulV2_46` | 3 | 138.303 |
| `MatMulV2_94` | 3 | 137.922 |
| `MatMulV2_30` | 3 | 137.723 |
| `MatMulV2_82` | 3 | 137.243 |
| `MatMulV2_118` | 3 | 137.002 |
| `MatMulV2_114` | 3 | 136.903 |
| `MatMulV2_42` | 3 | 136.883 |
| `MatMulV2_90` | 3 | 136.762 |
| `MatMulV2_26` | 3 | 136.683 |
| `MatMulV2_2` | 3 | 136.543 |
| `MatMulV2_54` | 3 | 136.483 |
| `MatMulV2_50` | 3 | 136.403 |
| `MatMulV2_62` | 3 | 136.343 |
| `MatMulV2_98` | 3 | 136.323 |
| `MatMulV2_18` | 3 | 136.163 |
| `MatMulV2_38` | 3 | 135.882 |
| `MatMulV2_126` | 3 | 135.523 |
| `MatMulV2_58` | 3 | 135.262 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;320,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4746.433 |
| `MatMulV2 | "768,1280;80,320,16,16;5120" -> "768,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4390.110 |
| `MatMulV2 | "768,1280;80,240,16,16;3840" -> "768,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3605.269 |
| `MatMulV2 | "768,1280;80,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3066.297 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_24` | 1 | 94.422 |
| `PromptFlashAttention_9` | 1 | 91.941 |
| `PromptFlashAttention_9` | 1 | 91.222 |
| `PromptFlashAttention_24` | 1 | 90.361 |
| `PromptFlashAttention_1` | 1 | 90.202 |
| `PromptFlashAttention_1` | 1 | 90.162 |
| `PromptFlashAttention_12` | 1 | 89.842 |
| `PromptFlashAttention_25` | 1 | 89.542 |
| `PromptFlashAttention_25` | 1 | 89.481 |
| `PromptFlashAttention_15` | 1 | 89.442 |
| `PromptFlashAttention_1` | 1 | 89.421 |
| `PromptFlashAttention_16` | 1 | 89.302 |
| `PromptFlashAttention_16` | 1 | 89.102 |
| `PromptFlashAttention_4` | 1 | 88.662 |
| `PromptFlashAttention_25` | 1 | 88.662 |
| `PromptFlashAttention_15` | 1 | 88.541 |
| `PromptFlashAttention_16` | 1 | 88.362 |
| `PromptFlashAttention_7` | 1 | 88.242 |
| `PromptFlashAttention_27` | 1 | 87.942 |
| `PromptFlashAttention_28` | 1 | 87.261 |
| `PromptFlashAttention_28` | 1 | 87.122 |
| `PromptFlashAttention_20` | 1 | 86.722 |
| `PromptFlashAttention` | 1 | 86.342 |
| `PromptFlashAttention_20` | 1 | 86.181 |
| `PromptFlashAttention_12` | 1 | 86.102 |
| `PromptFlashAttention_14` | 1 | 85.902 |
| `PromptFlashAttention_12` | 1 | 85.781 |
| `PromptFlashAttention_30` | 1 | 85.321 |
| `PromptFlashAttention_31` | 1 | 85.302 |
| `PromptFlashAttention_13` | 1 | 85.181 |
| `PromptFlashAttention_13` | 1 | 85.142 |
| `PromptFlashAttention_8` | 1 | 85.121 |
| `PromptFlashAttention_8` | 1 | 84.962 |
| `PromptFlashAttention_31` | 1 | 84.901 |
| `PromptFlashAttention_14` | 1 | 84.842 |
| `PromptFlashAttention_15` | 1 | 84.722 |
| `PromptFlashAttention_19` | 1 | 84.682 |
| `PromptFlashAttention_30` | 1 | 84.622 |
| `PromptFlashAttention_30` | 1 | 84.462 |
| `PromptFlashAttention_31` | 1 | 84.442 |
| `PromptFlashAttention_19` | 1 | 84.422 |
| `PromptFlashAttention_24` | 1 | 84.362 |
| `PromptFlashAttention_8` | 1 | 84.222 |
| `PromptFlashAttention_6` | 1 | 84.122 |
| `PromptFlashAttention_13` | 1 | 84.061 |
| `PromptFlashAttention_20` | 1 | 83.942 |
| `PromptFlashAttention_6` | 1 | 83.902 |
| `PromptFlashAttention_6` | 1 | 83.902 |
| `PromptFlashAttention_23` | 1 | 83.781 |
| `PromptFlashAttention_9` | 1 | 83.742 |
| `PromptFlashAttention_23` | 1 | 83.662 |
| `PromptFlashAttention_28` | 1 | 83.541 |
| `PromptFlashAttention_26` | 1 | 83.501 |
| `PromptFlashAttention_5` | 1 | 83.482 |
| `PromptFlashAttention_23` | 1 | 83.382 |
| `PromptFlashAttention_26` | 1 | 83.302 |
| `PromptFlashAttention_11` | 1 | 83.142 |
| `PromptFlashAttention_22` | 1 | 82.961 |
| `PromptFlashAttention_29` | 1 | 82.942 |
| `PromptFlashAttention_11` | 1 | 82.922 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 19586.428 |
| `TorchDynamo Cache Lookup` | 3 | 18511.988 |
| `Torch-Compiled Region: 0/0` | 3 | 1559.950 |
| `TorchNpuGraphBase::Run` | 3 | 910.820 |
| `ExecuteGraph` | 3 | 276.990 |
| `AssembleInputs` | 3 | 230.290 |
| `RefreshAtTensorFromGeTensor` | 3 | 212.400 |
| `aten::empty` | 3 | 92.490 |
| `aten::set_` | 3 | 63.960 |
| `empty_tensor` | 3 | 47.320 |
| `AssembleOutputs` | 3 | 45.810 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 264805.880 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 54972.800 |
| `launch` | 1314 | 20950.470 |
| `InputCopy` | 3 | 136.690 |
| `ModelExecute` | 3 | 84.230 |
| `step_info` | 6 | 53.080 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 25.950 |
| `OutputCopy` | 3 | 2.910 |

