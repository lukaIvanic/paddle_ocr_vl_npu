# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_nz_weights_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/pfa_nz_weights_crop_1_bucket_3072/profile/liteserver-c001-4_191118_20261007141222270_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `50078.646 us`
- `Free`: `798.251 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `943.000 us`
- `Stage`: `50877.250 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention` | 96 | 50103.003 |
| `MatMulV2` | 384 | 45860.825 |
| `StridedSliceD` | 384 | 13174.011 |
| `Mul` | 576 | 7492.674 |
| `AutomaticBufferFusionOp` | 480 | 6607.416 |
| `Add` | 384 | 5157.831 |
| `ReduceMeanD` | 384 | 5004.552 |
| `Transpose` | 288 | 4149.799 |
| `Sub` | 192 | 3423.023 |
| `ConcatV2D` | 192 | 2348.068 |
| `Cast` | 195 | 2282.389 |
| `Unpack` | 96 | 2096.775 |
| `Neg` | 192 | 1779.806 |
| `ConfusionTransposeD` | 96 | 981.956 |
| `Data` | 1 | 6.440 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_8` | 3 | 1595.651 |
| `PromptFlashAttention_15` | 3 | 1582.532 |
| `PromptFlashAttention_6` | 3 | 1580.231 |
| `PromptFlashAttention_26` | 3 | 1579.090 |
| `PromptFlashAttention_3` | 3 | 1578.212 |
| `PromptFlashAttention_25` | 3 | 1576.893 |
| `PromptFlashAttention_16` | 3 | 1576.792 |
| `PromptFlashAttention_12` | 3 | 1576.392 |
| `PromptFlashAttention_24` | 3 | 1573.151 |
| `PromptFlashAttention_27` | 3 | 1572.693 |
| `PromptFlashAttention_19` | 3 | 1571.212 |
| `PromptFlashAttention_10` | 3 | 1568.771 |
| `PromptFlashAttention_1` | 3 | 1568.671 |
| `PromptFlashAttention_9` | 3 | 1568.192 |
| `PromptFlashAttention_13` | 3 | 1566.832 |
| `PromptFlashAttention` | 3 | 1565.252 |
| `PromptFlashAttention_7` | 3 | 1565.052 |
| `PromptFlashAttention_30` | 3 | 1563.052 |
| `PromptFlashAttention_20` | 3 | 1561.991 |
| `PromptFlashAttention_14` | 3 | 1560.911 |
| `PromptFlashAttention_5` | 3 | 1559.451 |
| `PromptFlashAttention_23` | 3 | 1558.871 |
| `PromptFlashAttention_4` | 3 | 1558.390 |
| `PromptFlashAttention_31` | 3 | 1558.091 |
| `PromptFlashAttention_22` | 3 | 1557.031 |
| `PromptFlashAttention_18` | 3 | 1556.790 |
| `PromptFlashAttention_21` | 3 | 1556.491 |
| `PromptFlashAttention_11` | 3 | 1555.531 |
| `PromptFlashAttention_17` | 3 | 1554.431 |
| `PromptFlashAttention_29` | 3 | 1546.311 |
| `PromptFlashAttention_28` | 3 | 1545.191 |
| `PromptFlashAttention_2` | 3 | 1544.851 |
| `MatMulV2_123` | 3 | 459.629 |
| `MatMulV2_59` | 3 | 459.510 |
| `MatMulV2_83` | 3 | 458.390 |
| `MatMulV2_99` | 3 | 458.230 |
| `MatMulV2_75` | 3 | 457.709 |
| `MatMulV2_111` | 3 | 457.069 |
| `MatMulV2_67` | 3 | 456.869 |
| `MatMulV2_19` | 3 | 456.390 |
| `MatMulV2_107` | 3 | 456.210 |
| `MatMulV2_15` | 3 | 455.949 |
| `MatMulV2_47` | 3 | 455.889 |
| `MatMulV2_27` | 3 | 455.809 |
| `MatMulV2_3` | 3 | 455.709 |
| `MatMulV2_43` | 3 | 455.329 |
| `MatMulV2_95` | 3 | 454.909 |
| `MatMulV2_7` | 3 | 454.169 |
| `MatMulV2_51` | 3 | 454.169 |
| `MatMulV2_115` | 3 | 454.069 |
| `MatMulV2_79` | 3 | 454.009 |
| `MatMulV2_11` | 3 | 453.889 |
| `MatMulV2_55` | 3 | 453.729 |
| `MatMulV2_63` | 3 | 453.450 |
| `MatMulV2_35` | 3 | 453.229 |
| `MatMulV2_119` | 3 | 453.209 |
| `MatMulV2_31` | 3 | 452.729 |
| `MatMulV2_91` | 3 | 452.589 |
| `MatMulV2_23` | 3 | 452.409 |
| `MatMulV2_71` | 3 | 452.329 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `MatMulV2_123` | 3 | 459.629 |
| `MatMulV2_59` | 3 | 459.510 |
| `MatMulV2_83` | 3 | 458.390 |
| `MatMulV2_99` | 3 | 458.230 |
| `MatMulV2_75` | 3 | 457.709 |
| `MatMulV2_111` | 3 | 457.069 |
| `MatMulV2_67` | 3 | 456.869 |
| `MatMulV2_19` | 3 | 456.390 |
| `MatMulV2_107` | 3 | 456.210 |
| `MatMulV2_15` | 3 | 455.949 |
| `MatMulV2_47` | 3 | 455.889 |
| `MatMulV2_27` | 3 | 455.809 |
| `MatMulV2_3` | 3 | 455.709 |
| `MatMulV2_43` | 3 | 455.329 |
| `MatMulV2_95` | 3 | 454.909 |
| `MatMulV2_7` | 3 | 454.169 |
| `MatMulV2_51` | 3 | 454.169 |
| `MatMulV2_115` | 3 | 454.069 |
| `MatMulV2_79` | 3 | 454.009 |
| `MatMulV2_11` | 3 | 453.889 |
| `MatMulV2_55` | 3 | 453.729 |
| `MatMulV2_63` | 3 | 453.450 |
| `MatMulV2_35` | 3 | 453.229 |
| `MatMulV2_119` | 3 | 453.209 |
| `MatMulV2_31` | 3 | 452.729 |
| `MatMulV2_91` | 3 | 452.589 |
| `MatMulV2_23` | 3 | 452.409 |
| `MatMulV2_71` | 3 | 452.329 |
| `MatMulV2_127` | 3 | 451.509 |
| `MatMulV2_87` | 3 | 450.789 |
| `MatMulV2_103` | 3 | 450.189 |
| `MatMulV2_39` | 3 | 448.889 |
| `MatMulV2_122` | 3 | 435.849 |
| `MatMulV2_82` | 3 | 430.828 |
| `MatMulV2_74` | 3 | 430.748 |
| `MatMulV2_2` | 3 | 429.869 |
| `MatMulV2_90` | 3 | 429.569 |
| `MatMulV2_50` | 3 | 429.269 |
| `MatMulV2_126` | 3 | 428.588 |
| `MatMulV2_42` | 3 | 428.368 |
| `MatMulV2_66` | 3 | 428.329 |
| `MatMulV2_10` | 3 | 428.108 |
| `MatMulV2_58` | 3 | 427.509 |
| `MatMulV2_26` | 3 | 427.069 |
| `MatMulV2_54` | 3 | 427.049 |
| `MatMulV2_110` | 3 | 426.569 |
| `MatMulV2_94` | 3 | 426.109 |
| `MatMulV2_22` | 3 | 426.108 |
| `MatMulV2_106` | 3 | 426.108 |
| `MatMulV2_18` | 3 | 425.769 |
| `MatMulV2_70` | 3 | 425.748 |
| `MatMulV2_14` | 3 | 423.908 |
| `MatMulV2_6` | 3 | 423.808 |
| `MatMulV2_78` | 3 | 423.568 |
| `MatMulV2_118` | 3 | 423.427 |
| `MatMulV2_102` | 3 | 422.529 |
| `MatMulV2_30` | 3 | 422.248 |
| `MatMulV2_34` | 3 | 420.968 |
| `MatMulV2_46` | 3 | 420.508 |
| `MatMulV2_38` | 3 | 420.389 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "3072,5120;320,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 14548.954 |
| `MatMulV2 | "3072,1280;80,320,16,16;5120" -> "3072,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 13617.952 |
| `MatMulV2 | "3072,1280;80,240,16,16;3840" -> "3072,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 10682.895 |
| `MatMulV2 | "3072,1280;80,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 7011.024 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `PromptFlashAttention_8` | 1 | 533.710 |
| `PromptFlashAttention_8` | 1 | 531.091 |
| `PromptFlashAttention_8` | 1 | 530.850 |
| `PromptFlashAttention_3` | 1 | 529.350 |
| `PromptFlashAttention_16` | 1 | 528.411 |
| `PromptFlashAttention_15` | 1 | 527.850 |
| `PromptFlashAttention_6` | 1 | 527.750 |
| `PromptFlashAttention_15` | 1 | 527.731 |
| `PromptFlashAttention_15` | 1 | 526.951 |
| `PromptFlashAttention_12` | 1 | 526.910 |
| `PromptFlashAttention_12` | 1 | 526.831 |
| `PromptFlashAttention_6` | 1 | 526.810 |
| `PromptFlashAttention_3` | 1 | 526.771 |
| `PromptFlashAttention_26` | 1 | 526.510 |
| `PromptFlashAttention_26` | 1 | 526.490 |
| `PromptFlashAttention_25` | 1 | 526.351 |
| `PromptFlashAttention_26` | 1 | 526.090 |
| `PromptFlashAttention_6` | 1 | 525.671 |
| `PromptFlashAttention_25` | 1 | 525.671 |
| `PromptFlashAttention_24` | 1 | 525.650 |
| `PromptFlashAttention_16` | 1 | 525.150 |
| `PromptFlashAttention_27` | 1 | 525.091 |
| `PromptFlashAttention_19` | 1 | 524.991 |
| `PromptFlashAttention_25` | 1 | 524.871 |
| `PromptFlashAttention_24` | 1 | 524.831 |
| `PromptFlashAttention_27` | 1 | 524.451 |
| `PromptFlashAttention_10` | 1 | 523.870 |
| `PromptFlashAttention_9` | 1 | 523.311 |
| `PromptFlashAttention_16` | 1 | 523.231 |
| `PromptFlashAttention_13` | 1 | 523.191 |
| `PromptFlashAttention_19` | 1 | 523.190 |
| `PromptFlashAttention_1` | 1 | 523.170 |
| `PromptFlashAttention_27` | 1 | 523.151 |
| `PromptFlashAttention_1` | 1 | 523.151 |
| `PromptFlashAttention` | 1 | 523.131 |
| `PromptFlashAttention_19` | 1 | 523.031 |
| `PromptFlashAttention_10` | 1 | 522.831 |
| `PromptFlashAttention_14` | 1 | 522.770 |
| `PromptFlashAttention_9` | 1 | 522.751 |
| `PromptFlashAttention_24` | 1 | 522.670 |
| `PromptFlashAttention_12` | 1 | 522.651 |
| `PromptFlashAttention_13` | 1 | 522.630 |
| `PromptFlashAttention_7` | 1 | 522.570 |
| `PromptFlashAttention_1` | 1 | 522.350 |
| `PromptFlashAttention_9` | 1 | 522.130 |
| `PromptFlashAttention_3` | 1 | 522.091 |
| `PromptFlashAttention_10` | 1 | 522.070 |
| `PromptFlashAttention_30` | 1 | 521.971 |
| `PromptFlashAttention_7` | 1 | 521.891 |
| `PromptFlashAttention` | 1 | 521.451 |
| `PromptFlashAttention_20` | 1 | 521.270 |
| `PromptFlashAttention_13` | 1 | 521.011 |
| `PromptFlashAttention_4` | 1 | 520.870 |
| `PromptFlashAttention` | 1 | 520.670 |
| `PromptFlashAttention_4` | 1 | 520.630 |
| `PromptFlashAttention_7` | 1 | 520.591 |
| `PromptFlashAttention_30` | 1 | 520.570 |
| `PromptFlashAttention_30` | 1 | 520.511 |
| `PromptFlashAttention_20` | 1 | 520.510 |
| `PromptFlashAttention_5` | 1 | 520.291 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `cache_compiler inference` | 3 | 51155.401 |
| `TorchDynamo Cache Lookup` | 3 | 50169.041 |
| `Torch-Compiled Region: 0/0` | 3 | 1515.470 |
| `TorchNpuGraphBase::Run` | 3 | 880.620 |
| `ExecuteGraph` | 3 | 282.180 |
| `RefreshAtTensorFromGeTensor` | 3 | 220.270 |
| `AssembleInputs` | 3 | 185.660 |
| `aten::empty` | 3 | 96.760 |
| `aten::set_` | 3 | 68.610 |
| `empty_tensor` | 3 | 51.000 |
| `AssembleOutputs` | 3 | 44.710 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `ModelLoad` | 1 | 250137.760 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 150074.240 |
| `launch` | 1314 | 18774.260 |
| `InputCopy` | 3 | 136.630 |
| `ModelExecute` | 3 | 89.300 |
| `step_info` | 6 | 57.150 |
| `aclrtLaunchKernelWithHostArgs` | 1 | 25.670 |
| `OutputCopy` | 3 | 3.000 |

