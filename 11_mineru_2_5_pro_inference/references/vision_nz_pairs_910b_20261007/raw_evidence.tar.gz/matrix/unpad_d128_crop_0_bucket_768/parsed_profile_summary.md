# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/unpad_d128_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/unpad_d128_crop_0_bucket_768/profile/liteserver-c001-4_215436_20261007143712561_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `92811.124 us`
- `Free`: `139393.275 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `619.750 us`
- `Stage`: `232204.250 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `Transpose` | 768 | 18075.385 |
| `MatMulV2` | 384 | 13864.059 |
| `Mul` | 960 | 11586.988 |
| `UnpadFlashAttentionNdKernel` | 96 | 7204.098 |
| `Slice` | 768 | 7104.934 |
| `ReduceMean` | 384 | 6064.587 |
| `Add` | 768 | 5492.833 |
| `PadV3` | 288 | 5229.847 |
| `Cast` | 768 | 5026.001 |
| `Sub` | 192 | 3462.175 |
| `Pows` | 192 | 3119.220 |
| `MemSet` | 288 | 2137.769 |
| `ConcatD` | 192 | 1856.800 |
| `Sigmoid` | 96 | 1282.019 |
| `Neg` | 192 | 1057.910 |
| `Rsqrt` | 192 | 248.285 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 768 | 18075.385 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 384 | 13864.059 |
| `aclnnMul_MulAiCore_Mul` | 864 | 10488.697 |
| `UnpadFlashAttentionNdKernel` | 96 | 7204.098 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 6064.587 |
| `aclnnConstantPadNd_PadV3AiCore_PadV3` | 288 | 5229.847 |
| `aclnnAdd_AddAiCore_Add` | 576 | 5217.971 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 5026.001 |
| `aclnnSub_SubAiCore_Sub` | 192 | 3462.175 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3119.220 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 384 | 2585.485 |
| `aclnnNeg_SliceAiCore_Slice` | 192 | 2264.050 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 2255.399 |
| `aclnnConstantPadNd_PadV3AiCore_MemSet` | 288 | 2137.769 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 1856.800 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 1282.019 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 1098.291 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1057.910 |
| `aclnnAdds_AddAiCore_Add` | 192 | 274.862 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 248.285 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulCommon_MatMulV2` | 384 | 13864.059 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;1280,5120;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 4670.873 |
| `MatMulV2 | "768,1280;5120,1280;5120" -> "768,5120" | ND;ND;ND -> ND` | 96 | 3988.583 |
| `MatMulV2 | "768,1280;3840,1280;3840" -> "768,3840" | ND;ND;ND -> ND` | 96 | 3329.336 |
| `MatMulV2 | "768,1280;1280,1280;1280" -> "768,1280" | ND;ND;ND -> ND` | 96 | 1875.267 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 1 | 78.121 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.181 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.162 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.942 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.941 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.862 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.642 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.521 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.502 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.462 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.302 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.221 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.221 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.122 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.102 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.102 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.041 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.882 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.841 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.841 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.781 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.781 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.741 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.622 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.541 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.481 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.462 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.422 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.421 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.402 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.402 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.381 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.361 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.342 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.301 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.201 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.101 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.082 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.081 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.041 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.022 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.022 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.021 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.961 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.941 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.941 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.902 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.901 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.881 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.861 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.822 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.782 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.781 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.762 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.761 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.741 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.701 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.642 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.641 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.602 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `aten::copy_` | 1728 | 33166.641 |
| `aclnnInplaceCopy` | 1632 | 25904.924 |
| `aten::to` | 960 | 24568.690 |
| `aten::clone` | 960 | 24543.696 |
| `aten::contiguous` | 864 | 24093.702 |
| `empty_tensor` | 5568 | 23541.080 |
| `aten::_to_copy` | 768 | 21970.900 |
| `aten::mul` | 960 | 18522.309 |
| `aten::linear` | 384 | 17956.753 |
| `aten::add` | 768 | 16280.900 |
| `aten::addmm` | 384 | 14414.529 |
| `aclnnAddmm` | 384 | 13864.037 |
| `aclnnMul` | 864 | 10488.689 |
| `aten::as_strided` | 2496 | 8779.990 |
| `aten::mean` | 384 | 8670.723 |
| `aten::transpose` | 1152 | 8130.760 |
| `aten::pad` | 288 | 7784.841 |
| `aten::constant_pad_nd` | 288 | 7424.764 |
| `aclnnConstantPadNd` | 288 | 7367.627 |
| `atb::_npu_flash_attention_unpad` | 96 | 7252.233 |
| `SelfAttentionOperation` | 96 | 7204.104 |
| `aclnnMean` | 384 | 6074.981 |
| `aten::empty` | 768 | 5542.240 |
| `aclnnAdd` | 576 | 5300.886 |
| `aten::square` | 192 | 5116.760 |
| `aten::cat` | 192 | 4694.628 |
| `aten::pow` | 192 | 4600.850 |
| `aten::select` | 576 | 4294.410 |
| `aten::neg` | 192 | 4256.140 |
| `aclnnCat` | 192 | 4112.202 |
| `aten::sub` | 192 | 3951.771 |
| `aten::slice` | 480 | 3507.840 |
| `aclnnSub` | 192 | 3462.169 |
| `aten::view` | 960 | 3403.970 |
| `aclnnNeg` | 192 | 3321.946 |
| `aclnnPowTensorScalar` | 192 | 3208.862 |
| `aten::rsqrt` | 192 | 3090.900 |
| `aten::t` | 384 | 2866.740 |
| `aten::unbind` | 96 | 2529.760 |
| `aten::unsqueeze` | 288 | 1988.140 |
| `aten::sigmoid` | 96 | 1616.261 |
| `aclnnSigmoid` | 96 | 1282.026 |
| `aclnnMuls` | 96 | 1098.282 |
| `aclnnAdds` | 192 | 1070.590 |
| `aclnnRsqrt` | 192 | 1001.830 |
| `aten::empty_like` | 96 | 937.530 |
| `aten::item` | 288 | 914.030 |
| `aten::empty_strided` | 96 | 595.180 |
| `aten::_local_scalar_dense` | 288 | 403.990 |
| `aten::result_type` | 192 | 327.910 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 6528 | 38741.520 |
| `aclrtLaunchKernelWithHostArgs` | 6432 | 29949.530 |
| `aclnnInplaceCopy` | 1632 | 16891.850 |
| `aclnnMul` | 864 | 7204.530 |
| `aclnnAdd` | 576 | 4842.930 |
| `SelfAttentionOperation::Setup` | 96 | 4736.240 |
| `aclnnConstantPadNd` | 288 | 4373.780 |
| `aclnnMean` | 384 | 4370.230 |
| `SelfAttentionOperation::Execute` | 96 | 4055.040 |
| `aclnnAddmm` | 384 | 3399.740 |
| `aclnnCat` | 192 | 2544.630 |
| `aclnnNeg` | 192 | 2463.370 |
| `aclrtGetStreamAttribute` | 5472 | 2140.980 |
| `aclnnSub` | 192 | 1712.220 |
| `aclnnAdds` | 192 | 1708.960 |
| `aclnnPowTensorScalar` | 192 | 1658.640 |
| `aclnnRsqrt` | 192 | 1617.520 |
| `aclnnMuls` | 96 | 854.530 |
| `aclnnSigmoid` | 96 | 832.420 |
| `aclrtGetHardwareSyncAddr` | 672 | 439.470 |
| `aclmdlRICaptureGetInfo` | 192 | 179.470 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 66.980 |

