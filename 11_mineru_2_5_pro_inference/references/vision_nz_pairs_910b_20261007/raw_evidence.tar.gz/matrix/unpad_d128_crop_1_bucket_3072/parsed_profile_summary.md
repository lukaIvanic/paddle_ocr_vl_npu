# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/unpad_d128_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/unpad_d128_crop_1_bucket_3072/profile/liteserver-c001-4_216349_20261007143808856_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `208177.767 us`
- `Free`: `27169.015 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `611.250 us`
- `Stage`: `235346.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 96 | 57459.187 |
| `MatMulV3` | 288 | 36592.391 |
| `Transpose` | 768 | 22799.164 |
| `Mul` | 960 | 19976.806 |
| `ReduceMean` | 384 | 9306.969 |
| `Slice` | 576 | 9085.546 |
| `Add` | 768 | 8974.737 |
| `Cast` | 768 | 8080.957 |
| `PadV3` | 288 | 7628.611 |
| `MatMulV2` | 96 | 6582.715 |
| `Sub` | 192 | 5010.059 |
| `Pows` | 192 | 3940.180 |
| `Sigmoid` | 96 | 3265.270 |
| `ConcatD` | 192 | 2939.514 |
| `SliceV2` | 192 | 2307.536 |
| `MemSet` | 288 | 2157.769 |
| `Neg` | 192 | 1733.647 |
| `Rsqrt` | 192 | 339.128 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 96 | 57459.187 |
| `aclnnAddmm_MatMulV3Common_MatMulV3` | 288 | 36592.391 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 768 | 22799.164 |
| `aclnnMul_MulAiCore_Mul` | 864 | 17319.111 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 9306.969 |
| `aclnnAdd_AddAiCore_Add` | 576 | 8635.571 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 8080.957 |
| `aclnnConstantPadNd_PadV3AiCore_PadV3` | 288 | 7628.611 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 96 | 6582.715 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 384 | 5078.894 |
| `aclnnSub_SubAiCore_Sub` | 192 | 5010.059 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 4006.652 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3940.180 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 3265.270 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 2939.514 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 2657.695 |
| `aclnnNeg_SliceV2AiCore_SliceV2` | 192 | 2307.536 |
| `aclnnConstantPadNd_PadV3AiCore_MemSet` | 288 | 2157.769 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1733.647 |
| `aclnnAdds_AddAiCore_Add` | 192 | 339.166 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 339.128 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmm_MatMulV3Common_MatMulV3` | 288 | 36592.391 |
| `aclnnAddmm_MatMulCommon_MatMulV2` | 96 | 6582.715 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;5120,1280;5120" -> "3072,5120" | ND;ND;ND -> ND` | 96 | 13674.629 |
| `MatMulV3 | "3072,5120;1280,5120;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 12915.964 |
| `MatMulV3 | "3072,1280;3840,1280;3840" -> "3072,3840" | ND;ND;ND -> ND` | 96 | 10001.798 |
| `MatMulV2 | "3072,1280;1280,1280;1280" -> "3072,1280" | ND;ND;ND -> ND` | 96 | 6582.715 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 1 | 607.472 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.292 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.352 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.752 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.132 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.612 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.172 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.952 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.932 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.912 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.852 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.772 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.672 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.652 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.292 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.232 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.212 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.192 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.192 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.032 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.992 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.912 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.652 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.612 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.592 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.592 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.412 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.372 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.332 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.332 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.292 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.212 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.132 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.052 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.052 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.972 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.912 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.692 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.612 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.592 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.592 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.472 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.412 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.352 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.272 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.252 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.232 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.152 |
| `UnpadFlashAttentionNdKernel` | 1 | 598.052 |
| `UnpadFlashAttentionNdKernel` | 1 | 597.972 |
| `UnpadFlashAttentionNdKernel` | 1 | 597.952 |
| `UnpadFlashAttentionNdKernel` | 1 | 597.952 |
| `UnpadFlashAttentionNdKernel` | 1 | 597.912 |
| `UnpadFlashAttentionNdKernel` | 1 | 597.852 |
| `UnpadFlashAttentionNdKernel` | 1 | 597.851 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `atb::_npu_flash_attention_unpad` | 96 | 57459.188 |
| `SelfAttentionOperation` | 96 | 57459.188 |
| `aten::linear` | 384 | 43175.103 |
| `aten::addmm` | 384 | 43175.103 |
| `aclnnAddmm` | 384 | 43175.103 |
| `aten::copy_` | 1728 | 39827.908 |
| `aclnnInplaceCopy` | 1632 | 35982.354 |
| `aten::clone` | 960 | 28795.703 |
| `aten::contiguous` | 864 | 27477.923 |
| `aten::to` | 960 | 24754.820 |
| `empty_tensor` | 5568 | 24198.870 |
| `aten::_to_copy` | 768 | 22125.350 |
| `aten::mul` | 960 | 21713.077 |
| `aclnnMul` | 864 | 17319.126 |
| `aten::add` | 768 | 16482.683 |
| `aten::pad` | 288 | 9786.375 |
| `aten::constant_pad_nd` | 288 | 9786.375 |
| `aclnnConstantPadNd` | 288 | 9786.375 |
| `aten::mean` | 384 | 9458.358 |
| `aclnnMean` | 384 | 9306.966 |
| `aten::as_strided` | 2496 | 8864.950 |
| `aclnnAdd` | 576 | 8635.573 |
| `aten::transpose` | 1152 | 8222.900 |
| `aten::cat` | 192 | 6948.468 |
| `aclnnCat` | 192 | 6946.159 |
| `aten::empty` | 768 | 5541.260 |
| `aten::square` | 192 | 5123.720 |
| `aten::sub` | 192 | 5019.550 |
| `aclnnSub` | 192 | 5010.060 |
| `aten::pow` | 192 | 4595.792 |
| `aten::neg` | 192 | 4450.474 |
| `aten::select` | 576 | 4265.760 |
| `aclnnNeg` | 192 | 4041.181 |
| `aclnnPowTensorScalar` | 192 | 3940.179 |
| `aten::slice` | 480 | 3481.970 |
| `aten::view` | 960 | 3327.310 |
| `aten::sigmoid` | 96 | 3265.265 |
| `aclnnSigmoid` | 96 | 3265.265 |
| `aten::rsqrt` | 192 | 3120.500 |
| `aten::t` | 384 | 2900.620 |
| `aclnnMuls` | 96 | 2662.863 |
| `aten::unbind` | 96 | 2547.740 |
| `aten::unsqueeze` | 288 | 2015.010 |
| `aclnnAdds` | 192 | 1095.140 |
| `aclnnRsqrt` | 192 | 1030.780 |
| `aten::empty_like` | 96 | 972.390 |
| `aten::item` | 288 | 903.520 |
| `aten::empty_strided` | 96 | 601.120 |
| `aten::_local_scalar_dense` | 288 | 384.750 |
| `aten::result_type` | 192 | 327.570 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 6528 | 37148.400 |
| `aclrtLaunchKernelWithHostArgs` | 6432 | 28762.500 |
| `aclnnInplaceCopy` | 1632 | 16170.400 |
| `aclnnMul` | 864 | 6832.670 |
| `aclnnAdd` | 576 | 4570.080 |
| `aclnnConstantPadNd` | 288 | 4217.200 |
| `aclnnMean` | 384 | 4208.340 |
| `SelfAttentionOperation::Setup` | 96 | 3611.900 |
| `aclnnAddmm` | 384 | 3542.060 |
| `SelfAttentionOperation::Execute` | 96 | 3478.640 |
| `aclnnCat` | 192 | 2358.800 |
| `aclnnNeg` | 192 | 2350.770 |
| `aclrtGetStreamAttribute` | 5472 | 2070.820 |
| `aclnnAdds` | 192 | 1659.850 |
| `aclnnSub` | 192 | 1605.320 |
| `aclnnPowTensorScalar` | 192 | 1593.940 |
| `aclnnRsqrt` | 192 | 1548.970 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 1320.400 |
| `aclnnMuls` | 96 | 808.590 |
| `aclnnSigmoid` | 96 | 758.170 |
| `aclrtGetHardwareSyncAddr` | 960 | 589.180 |
| `aclmdlRICaptureGetInfo` | 192 | 187.300 |

