# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/unpad_d128_nz_weights_crop_0_bucket_768/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/unpad_d128_nz_weights_crop_0_bucket_768/profile/liteserver-c001-4_216867_20261007143913111_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `93483.236 us`
- `Free`: `148879.227 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `765.500 us`
- `Stage`: `242362.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `Transpose` | 768 | 17270.275 |
| `MatMulV2` | 384 | 13295.791 |
| `Mul` | 960 | 11630.101 |
| `UnpadFlashAttentionNdKernel` | 96 | 7185.988 |
| `Slice` | 768 | 7095.315 |
| `ReduceMean` | 384 | 5900.638 |
| `Cast` | 768 | 5527.929 |
| `Add` | 768 | 5497.974 |
| `PadV3` | 288 | 5208.824 |
| `Sub` | 192 | 4848.515 |
| `Pows` | 192 | 3122.644 |
| `MemSet` | 288 | 2265.031 |
| `ConcatD` | 192 | 1875.376 |
| `Sigmoid` | 96 | 1356.942 |
| `Neg` | 192 | 1154.973 |
| `Rsqrt` | 192 | 248.685 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 768 | 17270.275 |
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 384 | 13295.791 |
| `aclnnMul_MulAiCore_Mul` | 864 | 10529.656 |
| `UnpadFlashAttentionNdKernel` | 96 | 7185.988 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 5900.638 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 5527.929 |
| `aclnnAdd_AddAiCore_Add` | 576 | 5222.888 |
| `aclnnConstantPadNd_PadV3AiCore_PadV3` | 288 | 5208.824 |
| `aclnnSub_SubAiCore_Sub` | 192 | 4848.515 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 3122.644 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 384 | 2583.068 |
| `aclnnConstantPadNd_PadV3AiCore_MemSet` | 288 | 2265.031 |
| `aclnnNeg_SliceAiCore_Slice` | 192 | 2264.262 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 2247.985 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 1875.376 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 1356.942 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1154.973 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 1100.445 |
| `aclnnAdds_AddAiCore_Add` | 192 | 275.086 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 248.685 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 384 | 13295.791 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV2 | "768,5120;320,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 4428.469 |
| `MatMulV2 | "768,1280;80,320,16,16;5120" -> "768,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3945.737 |
| `MatMulV2 | "768,1280;80,240,16,16;3840" -> "768,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 3215.937 |
| `MatMulV2 | "768,1280;80,80,16,16;1280" -> "768,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 1705.648 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 1 | 77.702 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.541 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.482 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.461 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.242 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.221 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.161 |
| `UnpadFlashAttentionNdKernel` | 1 | 77.102 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.982 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.922 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.822 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.761 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.741 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.722 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.582 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.541 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.541 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.441 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.382 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.381 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.322 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.321 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.302 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.301 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.301 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.221 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.162 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.102 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.101 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.061 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.061 |
| `UnpadFlashAttentionNdKernel` | 1 | 76.021 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.741 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.721 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.361 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.342 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.341 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.261 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.222 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.141 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.122 |
| `UnpadFlashAttentionNdKernel` | 1 | 75.002 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.962 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.942 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.922 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.901 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.882 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.862 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.862 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.842 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.822 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.662 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.662 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.642 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.601 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.582 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.521 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.502 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.481 |
| `UnpadFlashAttentionNdKernel` | 1 | 74.462 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `aten::copy_` | 1728 | 33136.629 |
| `aclnnInplaceCopy` | 1632 | 25637.747 |
| `aten::to` | 960 | 25569.570 |
| `aten::clone` | 960 | 25233.985 |
| `aten::contiguous` | 864 | 25122.777 |
| `empty_tensor` | 5568 | 23635.560 |
| `aten::_to_copy` | 768 | 22733.780 |
| `aten::mul` | 960 | 19533.066 |
| `aten::linear` | 384 | 18810.033 |
| `aten::add` | 768 | 17185.540 |
| `aten::addmm` | 384 | 14288.751 |
| `aclnnAddmmWeightNz` | 384 | 13295.806 |
| `aclnnMul` | 864 | 10548.880 |
| `aten::as_strided` | 2496 | 9357.570 |
| `aten::mean` | 384 | 9097.160 |
| `aten::transpose` | 1152 | 8648.120 |
| `aten::pad` | 288 | 8392.075 |
| `aten::constant_pad_nd` | 288 | 7876.160 |
| `aclnnConstantPadNd` | 288 | 7473.849 |
| `atb::_npu_flash_attention_unpad` | 96 | 7261.729 |
| `SelfAttentionOperation` | 96 | 7185.984 |
| `aclnnMean` | 384 | 5900.638 |
| `aten::empty` | 768 | 5574.000 |
| `aclnnAdd` | 576 | 5313.696 |
| `aten::square` | 192 | 5235.050 |
| `aten::sub` | 192 | 4869.084 |
| `aclnnSub` | 192 | 4848.517 |
| `aten::cat` | 192 | 4707.623 |
| `aten::pow` | 192 | 4675.850 |
| `aten::select` | 576 | 4415.690 |
| `aten::neg` | 192 | 4260.081 |
| `aclnnCat` | 192 | 4123.362 |
| `aten::slice` | 480 | 3652.660 |
| `aten::view` | 960 | 3453.110 |
| `aclnnNeg` | 192 | 3419.228 |
| `aten::rsqrt` | 192 | 3299.870 |
| `aten::t` | 384 | 3198.190 |
| `aclnnPowTensorScalar` | 192 | 3122.642 |
| `aten::unbind` | 96 | 2653.910 |
| `aten::unsqueeze` | 288 | 2091.100 |
| `aten::sigmoid` | 96 | 1699.130 |
| `aclnnSigmoid` | 96 | 1356.947 |
| `aclnnAdds` | 192 | 1135.850 |
| `aclnnMuls` | 96 | 1100.442 |
| `aclnnRsqrt` | 192 | 1058.860 |
| `aten::item` | 288 | 994.640 |
| `aten::empty_like` | 96 | 973.800 |
| `aten::empty_strided` | 96 | 614.210 |
| `aten::_local_scalar_dense` | 288 | 442.060 |
| `aten::result_type` | 192 | 330.640 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 6528 | 39893.160 |
| `aclrtLaunchKernelWithHostArgs` | 6432 | 31296.200 |
| `aclnnInplaceCopy` | 1632 | 17310.830 |
| `aclnnMul` | 864 | 7456.950 |
| `aclnnAdd` | 576 | 4966.430 |
| `aclnnConstantPadNd` | 288 | 4547.120 |
| `aclnnMean` | 384 | 4483.300 |
| `SelfAttentionOperation::Setup` | 96 | 3623.550 |
| `SelfAttentionOperation::Execute` | 96 | 3561.390 |
| `aclnnAddmmWeightNz` | 384 | 3390.000 |
| `aclnnCat` | 192 | 2602.060 |
| `aclnnNeg` | 192 | 2512.000 |
| `aclrtGetStreamAttribute` | 5472 | 2433.700 |
| `aclnnPowTensorScalar` | 192 | 1707.230 |
| `aclnnSub` | 192 | 1690.140 |
| `aclnnAdds` | 192 | 1671.440 |
| `aclnnRsqrt` | 192 | 1650.600 |
| `aclnnMuls` | 96 | 883.560 |
| `aclnnSigmoid` | 96 | 847.220 |
| `aclrtGetHardwareSyncAddr` | 672 | 475.790 |
| `aclmdlRICaptureGetInfo` | 192 | 216.050 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 64.920 |

