# NPU Profile Summary

profile_dir: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/unpad_d128_nz_weights_crop_1_bucket_3072/profile`
runs: `1`

## Run 1
run_root: `/workspace/repos/paddle_ocr_vl_npu_vision_diagnostics_retry/tmp/11_mineru_2_5_pro_inference/vision_nz_pairs_910B_20261007T140703Z_a55d24df/matrix/unpad_d128_nz_weights_crop_1_bucket_3072/profile/liteserver-c001-4_219124_20261007144025376_ascend_pt`

### Step Trace Totals
- `Bubble`: `0.000 us`
- `Communication`: `0.000 us`
- `Communication(Not Overlapped and Exclude Receive)`: `0.000 us`
- `Communication(Not Overlapped)`: `0.000 us`
- `Computing`: `210544.109 us`
- `Free`: `32592.288 us`
- `Overlapped`: `0.000 us`
- `Preparing`: `749.750 us`
- `Stage`: `243136.750 us`

### Kernel Types
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 96 | 57616.970 |
| `MatMulV3` | 288 | 35871.961 |
| `Transpose` | 768 | 23220.736 |
| `Mul` | 960 | 19812.334 |
| `ReduceMean` | 384 | 9351.670 |
| `Slice` | 576 | 9182.617 |
| `Add` | 768 | 8991.894 |
| `Cast` | 768 | 8765.705 |
| `PadV3` | 288 | 7864.654 |
| `MatMulV2` | 96 | 6876.719 |
| `Sub` | 192 | 6042.740 |
| `Pows` | 192 | 4008.817 |
| `Sigmoid` | 96 | 3330.005 |
| `ConcatD` | 192 | 2926.887 |
| `MemSet` | 288 | 2265.120 |
| `SliceV2` | 192 | 2204.962 |
| `Neg` | 192 | 1890.556 |
| `Rsqrt` | 192 | 322.184 |

### Kernel Names
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 96 | 57616.970 |
| `aclnnAddmmWeightNz_MatMulV3Common_MatMulV3` | 288 | 35871.961 |
| `aclnnInplaceCopy_TransposeAiCore_Transpose` | 768 | 23220.736 |
| `aclnnMul_MulAiCore_Mul` | 864 | 17172.741 |
| `aclnnMean_ReduceMeanAiCore_ReduceMean` | 384 | 9351.670 |
| `aclnnInplaceCopy_CastAiCore_Cast` | 768 | 8765.705 |
| `aclnnAdd_AddAiCore_Add` | 576 | 8668.067 |
| `aclnnConstantPadNd_PadV3AiCore_PadV3` | 288 | 7864.654 |
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 96 | 6876.719 |
| `aclnnSub_SubAiCore_Sub` | 192 | 6042.740 |
| `aclnnInplaceCopy_SliceAiCore_Slice` | 384 | 5133.826 |
| `aclnnCat_SliceAiCore_Slice` | 192 | 4048.791 |
| `aclnnPowTensorScalar_PowsAiCore_Pows` | 192 | 4008.817 |
| `aclnnSigmoid_SigmoidAiCore_Sigmoid` | 96 | 3330.005 |
| `aclnnCat_ConcatD_ConcatD` | 192 | 2926.887 |
| `aclnnMuls_MulAiCore_Mul` | 96 | 2639.593 |
| `aclnnConstantPadNd_PadV3AiCore_MemSet` | 288 | 2265.120 |
| `aclnnNeg_SliceV2AiCore_SliceV2` | 192 | 2204.962 |
| `aclnnNeg_NegAiCore_Neg` | 192 | 1890.556 |
| `aclnnAdds_AddAiCore_Add` | 192 | 323.827 |
| `aclnnRsqrt_RsqrtAiCore_Rsqrt` | 192 | 322.184 |

### MatMul Names
| name | count | total_us |
|---|---:|---:|
| `aclnnAddmmWeightNz_MatMulV3Common_MatMulV3` | 288 | 35871.961 |
| `aclnnAddmmWeightNz_MatMulCommon_MatMulV2` | 96 | 6876.719 |

### MatMul Shape And Format Signatures
| name | count | total_us |
|---|---:|---:|
| `MatMulV3 | "3072,1280;80,320,16,16;5120" -> "3072,5120" | ND;FRACTAL_NZ;ND -> ND` | 96 | 13456.312 |
| `MatMulV3 | "3072,5120;320,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 12471.130 |
| `MatMulV3 | "3072,1280;80,240,16,16;3840" -> "3072,3840" | ND;FRACTAL_NZ;ND -> ND` | 96 | 9944.519 |
| `MatMulV2 | "3072,1280;80,80,16,16;1280" -> "3072,1280" | ND;FRACTAL_NZ;ND -> ND` | 96 | 6876.719 |

### TransData Names
_No rows._

### TransData Shape And Format Signatures
_No rows._

### Suspect Kernels
| name | count | total_us |
|---|---:|---:|
| `UnpadFlashAttentionNdKernel` | 1 | 609.092 |
| `UnpadFlashAttentionNdKernel` | 1 | 606.092 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.852 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.512 |
| `UnpadFlashAttentionNdKernel` | 1 | 605.132 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.192 |
| `UnpadFlashAttentionNdKernel` | 1 | 604.112 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.572 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.472 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.432 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.312 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.252 |
| `UnpadFlashAttentionNdKernel` | 1 | 603.052 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.992 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.652 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.552 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.352 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.292 |
| `UnpadFlashAttentionNdKernel` | 1 | 602.252 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.912 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.872 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.732 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.712 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.692 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.612 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.592 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.452 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.372 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.372 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.192 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.132 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.132 |
| `UnpadFlashAttentionNdKernel` | 1 | 601.113 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.992 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.872 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.592 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.552 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.492 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.472 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.412 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.252 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.212 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.152 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.152 |
| `UnpadFlashAttentionNdKernel` | 1 | 600.072 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.972 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.892 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.792 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.752 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.692 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.672 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.592 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.552 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.512 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.432 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.232 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.172 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.152 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.132 |
| `UnpadFlashAttentionNdKernel` | 1 | 599.092 |


### Operators
| name | count | total_us |
|---|---:|---:|
| `atb::_npu_flash_attention_unpad` | 96 | 57616.971 |
| `SelfAttentionOperation` | 96 | 57616.971 |
| `aten::linear` | 384 | 44557.930 |
| `aten::addmm` | 384 | 44516.342 |
| `aclnnAddmmWeightNz` | 384 | 42748.674 |
| `aten::copy_` | 1728 | 40492.755 |
| `aclnnInplaceCopy` | 1632 | 37132.719 |
| `aten::clone` | 960 | 29117.663 |
| `aten::contiguous` | 864 | 27655.995 |
| `aten::to` | 960 | 25357.600 |
| `empty_tensor` | 5568 | 24150.570 |
| `aten::_to_copy` | 768 | 22608.100 |
| `aten::mul` | 960 | 21690.239 |
| `aclnnMul` | 864 | 17179.033 |
| `aten::add` | 768 | 16787.232 |
| `aten::pad` | 288 | 10151.451 |
| `aten::constant_pad_nd` | 288 | 10145.901 |
| `aclnnConstantPadNd` | 288 | 10129.782 |
| `aten::mean` | 384 | 9474.012 |
| `aclnnMean` | 384 | 9351.667 |
| `aten::as_strided` | 2496 | 9083.300 |
| `aclnnAdd` | 576 | 8668.073 |
| `aten::transpose` | 1152 | 8463.990 |
| `aten::cat` | 192 | 6980.618 |
| `aclnnCat` | 192 | 6975.679 |
| `aten::sub` | 192 | 6053.960 |
| `aclnnSub` | 192 | 6042.741 |
| `aten::empty` | 768 | 5708.190 |
| `aten::square` | 192 | 5124.531 |
| `aten::pow` | 192 | 4593.652 |
| `aten::neg` | 192 | 4505.401 |
| `aten::select` | 576 | 4325.700 |
| `aclnnNeg` | 192 | 4095.522 |
| `aclnnPowTensorScalar` | 192 | 4008.820 |
| `aten::slice` | 480 | 3530.240 |
| `aten::view` | 960 | 3442.030 |
| `aten::sigmoid` | 96 | 3330.007 |
| `aclnnSigmoid` | 96 | 3330.007 |
| `aten::rsqrt` | 192 | 3184.170 |
| `aten::t` | 384 | 3096.180 |
| `aclnnMuls` | 96 | 2639.593 |
| `aten::unbind` | 96 | 2581.280 |
| `aten::unsqueeze` | 288 | 2044.780 |
| `aclnnAdds` | 192 | 1134.330 |
| `aclnnRsqrt` | 192 | 1051.620 |
| `aten::item` | 288 | 967.470 |
| `aten::empty_like` | 96 | 959.920 |
| `aten::empty_strided` | 96 | 604.700 |
| `aten::_local_scalar_dense` | 288 | 448.690 |
| `aten::result_type` | 192 | 312.740 |


### APIs
| name | count | total_us |
|---|---:|---:|
| `launch` | 6528 | 40070.680 |
| `aclrtLaunchKernelWithHostArgs` | 6432 | 31079.230 |
| `aclnnInplaceCopy` | 1632 | 17370.620 |
| `aclnnMul` | 864 | 7520.310 |
| `aclnnAdd` | 576 | 4957.610 |
| `aclnnConstantPadNd` | 288 | 4535.940 |
| `aclnnMean` | 384 | 4397.990 |
| `SelfAttentionOperation::Setup` | 96 | 4211.050 |
| `aclnnAddmmWeightNz` | 384 | 3792.720 |
| `SelfAttentionOperation::Execute` | 96 | 3767.500 |
| `aclnnCat` | 192 | 2561.310 |
| `aclnnNeg` | 192 | 2560.430 |
| `aclrtGetStreamAttribute` | 5472 | 2377.850 |
| `aclnnSub` | 192 | 1708.990 |
| `aclnnPowTensorScalar` | 192 | 1700.340 |
| `aclnnRsqrt` | 192 | 1693.080 |
| `aclnnAdds` | 192 | 1672.700 |
| `aclrtSynchronizeDeviceWithTimeout` | 4 | 1285.710 |
| `aclnnMuls` | 96 | 873.270 |
| `aclnnSigmoid` | 96 | 839.250 |
| `aclrtGetHardwareSyncAddr` | 960 | 623.390 |
| `aclmdlRICaptureGetInfo` | 192 | 266.120 |

