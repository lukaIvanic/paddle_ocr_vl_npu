TOP 10 POINTERS FOR A GOOD TALK

6. Use color to emphasize

7. Use illustrations to get across key concepts

• May include limited animation

Blue arrow pointing leftward with a wavy line extending upward (no text or symbols)

8. Make eye contact

9. Be ready to skip slides if time is short

10. Practice !!