Slope

- Slope = rise/run

• =  \( \Delta y/\Delta x \)

\(\bullet\) \(= (y_{2} - y_{1}) / (x_{2} - x_{1})\)

- Order of points 1 and 2 not critical, but keeping them together is

- Points may lie in any quadrant: slope will work out

- Leibniz notation for derivative based on \(\Delta y / \Delta x\); the derivative is written \(dy/dx\)

y₂
y₁
Run
x₁
x₂
R/ho