Partial Derivatives

| Category | Value Range |
| --- | --- |
| Dark Blue | 2.5-3 |
| Light Blue | 2-2.5 |
| Cyan | 1.5-2 |
| Salmon | 1-1.5 |
| Purple | 0.5-1 |
| Light Green | 0-0.5 |
| Pale Yellow | -0.5-0 |
| Maroon | -1--0.5 |
| Blue | -1.5--1 |

- Functions of more than one variable

• Example:  \( C(x,y) = x^{4} + y^{3} + xy \)