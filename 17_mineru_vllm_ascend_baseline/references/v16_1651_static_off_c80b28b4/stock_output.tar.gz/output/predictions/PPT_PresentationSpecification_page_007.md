IMPORTANT DATES

You should:

By Jan 24, 2016;

☐ Form groups with 4 students; and

☐ Determine your presentation topic; and

By Jan 31, 2016;

☐ Submit the Group Presentation Topic and Desc;

□ Don't miss the due dates!!!

☐ We suggest you taking action as early as possible;

ENGG1000 Presentation Specification

5/21/2025

7