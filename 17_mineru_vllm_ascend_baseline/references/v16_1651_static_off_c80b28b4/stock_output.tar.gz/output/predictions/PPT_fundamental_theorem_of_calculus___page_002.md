To estimate area A

under \( y = 3x^{2} \) from

\[
x = 2 \text {to} x = 4
\]

we could split it into small rectangles:

| X | Y |
| --- | --- |
| 0 | 0 |
| 2 | ~12 |
| 4 | ~48 |

With 4 rectangles,
the area ≈ 48.96 units²

| X | Y (Line) | Y (Bar) |
| --- | --- | --- |
| -4 | ~57 | — |
| -3 | ~28 | — |
| -2 | ~10 | — |
| -1 | ~2 | — |
| 0 | 0 | — |
| 1 | ~5 | — |
| 2 | ~12 | 12 |
| 2.5 | ~19 | 19 |
| 3 | ~27 | 27 |
| 3.5 | ~36 | 37 |
| 4 | ~50 | — |