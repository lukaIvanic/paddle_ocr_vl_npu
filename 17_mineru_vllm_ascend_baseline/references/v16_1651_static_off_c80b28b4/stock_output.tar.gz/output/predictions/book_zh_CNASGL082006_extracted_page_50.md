CNAS-GL08: 2006

第 49 页 共 119 页

\[
P _ {x} = \frac {w}{t} \quad w = \frac {n}{N} \times 3. 6 \times 1 0 ^ {6} \text {瓦秒}
\]

\( P_{x} \) ——被测功率 W;

w——电度表累积测得电能；

N——电度表每千瓦时盘转动数；

n——电度表的转数 转；

t——测量时间 s

3 方差与传播系数

\[
\begin{array}{l} u ^ {2} (P _ {x}) = \left(\frac {\partial f}{\partial w}\right) ^ {2} u ^ {2} (w) + \left(\frac {\partial f}{\partial t}\right) ^ {2} u ^ {2} (t) = c ^ {2} (w) u ^ {2} (w) + c ^ {2} (t) u ^ {2} (t) \\ c (w) = \frac {1}{t} \quad c (t) = - \frac {w}{t ^ {2}} \\ u ^ {2} (P _ {x}) = \frac {1}{t ^ {2}} u ^ {2} (w) + \frac {w ^ {2}}{t ^ {4}} u ^ {2} (t) \\ \left(\frac {u (P _ {x})}{P _ {x}}\right) ^ {2} = \frac {u ^ {2} (w)}{w ^ {2}} + \frac {u ^ {2} (t)}{t ^ {2}} \\ \end{array}
\]

本不确定度分析以榨汁机为例

4 标准不确定度一览表

表 4-1 标准不确定度一览表

<table><tr><td>标准不确定度分量 \( {u}_{i} \)</td><td>不确定度来源</td><td>标准不确定度值</td><td>\( {c}_{i} = \partial f/{\partial x}_{i} \)</td><td>\( \left| {c}_{i}\right| \times u\left( {x}_{i}\right) \)</td><td>自由度</td></tr><tr><td>\( {u}_{1} \)</td><td>重复性误差</td><td>0.2%</td><td>1</td><td>0.2%</td><td>2</td></tr><tr><td>\( {u}_{2} \)</td><td>表头示值误差</td><td>0.29%</td><td>1</td><td>0.29%</td><td>50</td></tr><tr><td>\( {u}_{3} \)</td><td>电子秒表误差</td><td>0.02%</td><td>1</td><td>0.02%</td><td>8</td></tr><tr><td colspan="6">\( {u}_{i}\left( {P}_{i}\right) = {0.35}\% \)\( {v}_{\text{eff }} = {16} \)</td></tr></table>

2006年06月01日发布

2015年06月01日 第一次修订  
2015年06月01日 修订实施

2006年07月01日实施