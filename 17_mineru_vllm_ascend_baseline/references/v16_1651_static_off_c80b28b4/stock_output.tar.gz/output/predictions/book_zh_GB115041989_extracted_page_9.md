GB 11504-89

度为  \( 597 \mu mol/L (1 mL = 100 \mu g) \delta-ALA \) ，贮于冰箱中可保存两个月以上。

应用液:取贮备液 10 mL 于 100 mL 容量瓶中,并稀释至刻度,此液浓度约等于 59.7 μmol/L(1 mL = 10 μg)δ-ALA。

E4 尿样分析步骤

E4.1 分别量取 2 mL 尿样于两支 10 mL 具塞比色管内, 各加入 2 mL 乙酸缓冲液, 混匀, 其一为样品管, 另一为尿样空白管。向样品管中加入 0.4 mL 乙酰乙酸乙酯, 向尿样空白管中补加 0.4 mL 乙酸缓冲液, 分别混匀, 同时置沸水浴中加热 10 min, 取出冷却至室温。

E4.2 以下步骤按标准曲线的绘制 E5.3～E5.5 进行。

E5 标准曲线的绘制

E5.1 取 10 mL 具塞离心管 6 支, 按表 E1 配制标准色列:

表 E1

<table><tr><td>管号</td><td>0</td><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td></tr><tr><td>δ-ALA 标准应用液,mL</td><td>0</td><td>0.2</td><td>0.6</td><td>1.0</td><td>1.4</td><td>2.0</td></tr><tr><td>水,mL</td><td>2.0</td><td>1.8</td><td>1.4</td><td>1.0</td><td>0.6</td><td>0</td></tr><tr><td>δ-ALA 含量,μmol(μg)</td><td>0</td><td>11.9(2)</td><td>35.7(6)</td><td>59.5(10)</td><td>83.3(14)</td><td>119.0(20)</td></tr></table>

E5.2 各加 2 mL 乙酸缓冲液, 0.4 mL 乙酰乙酸乙酯, 混匀, 于沸水浴中加热 10 min, 取出冷至室温。

E5.3 各加 4 mL 乙酸乙酯, 加塞振摇 50 次, 离心 5 min, 取出静置分层。

E5.4 各取 2 mL 乙酸乙酯萃取液，于另外 6 支 10 mL 具塞比色管中，各加改良显色剂 2 mL，加塞振摇，静置 10 min。

E5.5 用比色皿在波长 553 nm(或绿色滤光片)下,以乙酸乙酯作参比,测得各标准管吸光度。

E5.6 以吸光度(扣除空白吸光度)为纵坐标,δ-ALA量为横坐标,在坐标纸上绘制标准曲线。

E6 计算

样品管吸光度减去尿空白管吸光度，查标准曲线得样品管中δ-ALA含量 \( \left[\mu\mathrm{mol}(\mathrm{ug})\right] \) 。

\[
\begin{array}{l} \text {尿中} \delta - \mathrm{ALA} \text {的含量} [ \mu \mathrm{mol} / \mathrm{L} (\mathrm{mg} / \mathrm{L}) ] \\ = \frac {\text {样品中} \delta - \mathrm{ALA} \text {的含量} [ \mu \mathrm{mol} (\mu \mathrm{g}) ]}{\text {分析样品的体积} [ 1 0 ^ {- 3} \mathrm{L} (\mathrm{mL}) ]} \quad \dots \tag {E1} \\ \end{array}
\]

E7 说明

a. 乙酸乙酯、乙酰乙酸乙酯最好为近期产品。改良显色剂宜新鲜配制；

b. 加入显色剂后,应静置 10 min,比色应在 30 min 内完成;

c. 尿液易腐败,可导致 \(\mathrm{pH}\) 升高,影响测定结果。如不能及时测定,应将尿液保存在冰箱中;

d. 其他与对二甲氨基苯甲醛显色剂反应的阳性物质,由于不被乙酸乙酯萃取,故不干扰测定;

e. 测定尿样时,可同时做标准测定(取 2 mL 标准应用液)。

计算：

\[
\delta \text {-ALA} [ \mu \mathrm{mol} / \mathrm{L} (\mathrm{mg} / \mathrm{L}) ] = \frac {U - O}{S} \times 0. 0 2 \times \frac {1 0 0 0}{2} = \frac {U - O}{S} \times 1 0 \quad \dots \tag {E2}
\]

式中：U——测定管吸光度；

o——空白管吸光度；

S——标准管吸光度。

17