Lesson 1

A Listen and match.

Illustration of a smiling boy holding a colorful cube (no text or symbols)

Peter

Illustration of a brown dog pushing a green dog's hat (no text or symbols)

Helen

Illustration of a child reading a book at a desk (no text or symbols visible)

Tom

Illustration of a girl and an adult holding and reading files (no text or symbols present)

Mary

Illustration of a woman and child sitting together, both showing emotional distress (no text or symbols present)

Line drawing of a ballerina in mid-stance, no text or symbols present

Illustration of a classroom scene with students raising hands (no text or symbols visible)

Illustration of a person holding a basketball and raising a sun, with a crowd in the background (no text or symbols)

B Think and say.

Let's talk about our classmates.

Lily is cute.

And she's friendly, too.

Illustration of three children sitting at a table, engaged in an activity with papers and writing (no text or symbols present)

<table><tr><td></td><td>clever</td><td>careless</td><td>quiet</td><td>friendly</td><td>popular</td><td>active</td><td>polite</td><td>cute</td><td>helpful</td></tr><tr><td>Lily</td><td></td><td></td><td></td><td>√</td><td></td><td></td><td></td><td>√</td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr><tr><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

© Let's write.

Lily is friendly and ____.

____ is ____ and ____.

____ is ____ and ____.

3