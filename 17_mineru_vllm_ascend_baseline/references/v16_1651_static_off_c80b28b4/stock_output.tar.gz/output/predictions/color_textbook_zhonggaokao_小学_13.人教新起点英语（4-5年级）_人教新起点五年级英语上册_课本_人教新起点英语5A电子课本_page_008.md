3. Now read and tick.

<table><tr><td>make model ships( )</td><td>make model planes( )</td><td>cute( )</td><td>clever( )</td></tr><tr><td>helpful( )</td><td>polite( )</td><td>popular( )</td><td>active( )</td></tr></table>

<table><tr><td>quiet</td><td>careless</td></tr><tr><td>( )</td><td>( )</td></tr></table>

B Let's play a guessing game.

Talk about our friends.

```mermaid
graph TD
  A["Node 1"] --> B["Central Process"]
  C["Node 2"] --> B
  D["Node 3"] --> B
  E["Node 4"] --> B
  F["Node 5"] --> B
  G["Node 6"] --> B
  H["Node 7"] --> B
  I["Node 8"] --> B
  J["Node 9"] --> B
  K["Node 10"] --> B
  L["Node 11"] --> B
  M["Node 12"] --> B
  N["Node 13"] --> B
  O["Node 14"] --> B
  P["Node 15"] --> B
  Q["Node 16"] --> B
  R["Node 17"] --> B
  S["Node 18"] --> B
  T["Node 19"] --> B
  U["Node 20"] --> B
  V["Node 21"] --> B
  W["Node 22"] --> B
  X["Node 23"] --> B
  Y["Node 24"] --> B
  Z["Node 25"] --> B
  AA["Node 26"] --> B
  AB["Node 27"] --> B
  AC["Node 28"] --> B
  AD["Node 29"] --> B
  AE["Node 30"] --> B
  AF["Node 31"] --> B
  AG["Node 32"] --> B
  AH["Node 33"] --> B
  AI["Node 34"] --> B
  AJ["Node 35"] --> B
  AK["Node 36"] --> B
  AL["Node 37"] --> B
  AM["Node 38"] --> B
  AN["Node 39"] --> B
  AO["Node 40"] --> B
  AP["Node 41"] --> B
  AQ["Node 42"] --> B
  AR["Node 43"] --> B
  AS["Node 44"] --> B
  AT["Node 45"] --> B
  AU["Node 46"] --> B
  AV["Node 47"] --> B
  AW["Node 48"] --> B
  AX["Node 49"] --> B
  AY["Node 50"] --> B
  AZ["Node 51"] --> B
  BA["Node 52"] --> B
  BB["Node 53"] --> B
  BC["Node 54"] --> B
  BD["Node 55"] --> B
  BE["Node 56"] --> B
  BF["Node 57"] --> B
  BG["Node 58"] --> B
  BH["Node 59"] --> B
  BI["Node 60"] --> B
  BJ["Node 61"] --> B
  BK["Node 62"] --> B
  BL["Node 63"] --> B
  BM["Node 64"] --> B
  BN["Node 65"] --> B
  BO["Node 66"] --> B
  BP["Node 67"] --> B
  BR["Node 68"] --> B
  BRD["Node 69"] --> B
  BRDQ["Node 70"] --> B
  BRDQQ["Node 71"] --> B
  <|box_start|> BRDQQQ["Node 72"] --> B
  <|box_start|> BRDQQQ["Node 73"] --> B
  <|box_start|> BRDQQQ["Node 74"] --> B
  <|box_start|> BRDQQQ["Node 75"] --> B
  <|box_start|> BRDQQQ["Node 76"] --> B
  <|box_start|> BRDQQQ["Node 77"] --> B
  <|box_start|> BRDQQQ["Node 78"] --> B
  <|box_start|> BRDQQQ["Node 79"] --> B
  <|box_start|> BRDQQQ["Node 80"] --> B
  <|box_start|> BRDQQQ["Node 81"] --> B
  <|box_start|> BRDQQQ["Node 82"] --> B
  <|box_start|> BRDQQQ["Node 83"] --> B
  <|box_start|> BRDQQQ["Node 84"] --> B
  <|box_start|> BRDQQQ["Node 85"] --> B
  <|box_start|> BRDQQQ["Node 86"] --> B
  <|box_start|> BRDQQQ["Node 87"] --> B
  <|box_start|> BRDQQQ["Node 88"] --> B
  <|box_start|> BRDQQQ["Node 89"] --> B
  <|box_start|> BRDQQQ["Node 90"] --> B
  <|box_start|> BRDQQQ["Node 91"] --> B
  <|box_start|> BRDQQQ["Node 92"] --> B
  <|box_start|> BRDQQQ["Node 93"] --> B
  <|box_start|> BRDQQQ["Node 94"] --> B
  <|box_start|> BRDQQQ["Node 95"] --> B
  <|box_start|> BRDQQQ["Node 96"] --> B
  <|box_start|> BRDQQQ["Node 97"] --> B
  <|box_start|> BRDQQQ["Node 98"] --> B
  <|box_start|> BRDQQQ["Node 99"] --> B
<|box_start|> BRDQQQ“B”(Note: The node in the middle) is highlighted with a dashed arrow indicating a transition or flow between states.
```

© Let's write.

What is Peter like?

5