© Read, choose and write.

Illustration of a smiling girl with braided hair wearing a red top (no text or symbols)

Lucy

Tomorrow is my first day back at school. I want to buy a new schoolbag. First my mum and I go to Xinxin Stationery Shop. I see a big orange bag there. It's 70 yuan. My mum likes it, but I don't like orange. I want a blue bag.

Then we go to Headstart School Shop. There is a blue bag there. It's 110 yuan, but I only have 100 yuan.

Then we go to Kids Right Shop. There is a blue bag there. It's small, but it's 60 yuan. I buy it. I'm very happy.

Which bag does Lucy buy?

Illustration of a pink backpack with orange casing and straps (no text or symbols)

¥

Illustration of a blue backpack with straps and backpacks (no text or symbols)

¥

Illustration of a blue backpack with straps and handle (no text or symbols)

¥

D Answer the questions and draw your bag.

1. What colour is your school bag?

2. How much is it?

3. Do you like it?

Checkpoint

<table><tr><td>structures</td><td>vocabulary</td></tr><tr><td>How much is it?It&#x27;s ...</td><td>exercise book, pencil sharpener,a pair of scissors, pencil box,a box of crayons, please</td></tr></table>

53