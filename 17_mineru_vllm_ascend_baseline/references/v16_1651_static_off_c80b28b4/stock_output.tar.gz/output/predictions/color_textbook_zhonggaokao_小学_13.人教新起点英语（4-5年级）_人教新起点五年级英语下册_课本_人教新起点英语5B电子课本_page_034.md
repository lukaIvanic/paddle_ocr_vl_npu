B Choose, think and say.

© Draw and write.

What would you like to do on Children's Day?

Illustration of three children in traditional attire holding a red diamond-shaped sign with Chinese character '六' (six) above them, no text or symbols present.

29