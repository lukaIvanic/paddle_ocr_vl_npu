第四课 口语部分Part 2详解下

轻松搞定

KET口语25分

内容提要

KET 口语part 2 问题卡怎么看

- KET 口语part 2 重点句型

KET 口语part 2 信息卡、问题卡综合训练

- KET 口语part 2 专项训练

```mermaid
graph LR
  A["Stage 1"] --> B["Stage 2"]
  B --> C["Stage 3"]
  C --> D["Stage 4"]
  D --> E["Stage 5"]
  E --> F["Stage 6"]
  F --> G["Stage 7"]
  G --> H["Stage 8"]
  H --> I["Stage 9"]
  I --> J["Stage 10"]
  J --> K["Stage 11"]
  K --> L["Stage 12"]
  L --> M["Stage 13"]
  M --> N["Stage 14"]
  N --> O["Stage 15"]
  O --> P["Stage 16"]
  P --> Q["Stage 17"]
  Q --> R["Stage 18"]
  R --> S["Stage 19"]
  S --> T["Stage 20"]
```

```mermaid
graph TD
  A["Stage 1"] --> B["Process Node 1"]
  B --> C["Stage 2"]
  C --> D["Stage 3"]
  D --> E["Stage 4"]
  E --> F["Stage 5"]
  F --> G["Stage 6"]
  G --> H["Stage 7"]
  H --> I["Stage 8"]
  I --> J["Stage 9"]
  J --> K["Stage 10"]
  K --> L["Stage 11"]
  L --> M["Stage 12"]
  M --> N["Stage 13"]
  N --> O["Stage 14"]
  O --> P["Stage 15"]
  P --> Q["Stage 16"]
  Q --> R["Stage 17"]
  R --> S["Stage 18"]
  S --> T["Stage 19"]
  T --> U["Stage 20"]
  U --> V["Stage 21"]
  V --> W["Stage 22"]
  W --> X["Stage 23"]
  X --> Y["Stage 24"]
  Y --> Z["Stage 25"]
  Z --> AA["Stage 26"]
  AA --> AB["Stage 27"]
  AB --> AC["Stage 28"]
  AC --> AD["Stage 29"]
  AD --> AE["Stage 30"]
  AE --> AF["Stage 31"]
  AF --> AG["Stage 32"]
  AG --> AH["Stage 33"]
  AH --> AI["Stage 34"]
  AI --> AJ["Stage 35"]
  AJ --> AK["Stage 36"]
  AK --> AL["Stage 37"]
  AL --> AM["Stage 38"]
  AM --> AN["Stage 39"]
  AN --> AO["Stage 40"]
  AO --> AP["Stage 41"]
  AP --> AQ["Stage 42"]
  AQ --> AR["Stage 43"]
  AR --> AS["Stage 44"]
  AS --> AT["Stage 45"]
  AT --> AU["Stage 46"]
  AU --> AV["Stage 47"]
  AV --> AW["Stage 48"]
  AW --> AX["Stage 49"]
  AX --> AY["Stage 50"]
```

KET口语 part 2 考试技巧

- Give clear answers

• Only use the information in the booklet

Can't get higher marks for adding extra information

KET口语 part 2 重点句型

问名字：What's the name of the show?

问日期：When's the show?

问时间：What time dose the show start?

问地址：Where's the show?

1