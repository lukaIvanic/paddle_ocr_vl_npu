第一部分 一 二 三 四

第二部分

第三部分

073

Scenic view of a pond with lily pads and blooming yellow flowers, surrounded by green trees and willow trees (no text or symbols visible)

在湿地公园中大面积应用的芹菜

Garden pond with yellow lily pads and green leaves, stone wall in background (no text or symbols)

盛花期的荇菜

重点提示

◆ 苻菜形态似微型睡莲，花虽小，但密集成片，有着不同情调的景观效果。在长江流域及以南地区的冬季，荇菜还常以常绿或半常绿形式生长；在炎热的夏季长势缓慢，在浅水水域甚至出现枯黄现象。

◆莼菜属于一种高贵、优良的水生蔬菜，但产出比不高。在工程应用上，可结合其经济功能综合考虑配置。

品种、类似种

荇菜属有数个原生品种，外形差异不大。有景观效果类似的同属植物——金银莲花（N. indica）、水皮莲（N. cristatum）等，花为白色，叶形与荇菜差异不大。有景观效果近似的不同科属品种——莼菜（Brasenia schreberi），叶为椭圆形，与荇菜叶形有区别，花较小，红褐色。

工程应用

荇菜叶片翠绿，小黄花密集，精巧别致，是优良的小型浮叶景观植物。