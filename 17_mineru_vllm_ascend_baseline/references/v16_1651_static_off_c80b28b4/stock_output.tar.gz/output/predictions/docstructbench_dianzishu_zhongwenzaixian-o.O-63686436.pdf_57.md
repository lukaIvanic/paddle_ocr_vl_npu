习茶18课

大红袍

武夷岩茶有“茶中之王”的美誉，为中国十大名茶之一，其中大红袍是武夷岩茶中的极品，享誉全球。

Pile of dried tea leaves with dark brown and white speckles (no text or symbols visible)

外形

紧结壮实，稍扭曲，色泽油润

Top-down view of a white bowl containing a golden-brown liquid (no text or symbols visible)

茶汤

汤色深橙黄，香气浓长，滋味醇厚，岩韵明显

Two dark, elongated objects resembling dried herbs or roots, arranged side by side on a white background (no text or symbols visible)

叶底

软亮匀齐

产区 福建武夷山。

武夷山市
福建省

历史传说

武夷岩茶历史悠久，而大红袍乃是武夷岩茶中的佼佼者。大红袍之所以特别引人关注，首先在于它的稀贵。历史上的大红袍，本来就少，而如今公认的大红袍茶树，仅是九龙窠岩壁上的那几棵。

保健功效

强心解挛：大红袍中的咖啡碱具有强心、解痉、松弛平滑肌的功效，能解除支气管痉挛，促进血液循环。

抗菌抑菌：大红袍中的茶多酚和鞣酸作用于细菌，能凝固细菌的蛋白质，将细菌杀死。

最佳品饮时节 春夏时节。

储藏方法

大红袍保存时最好不要使用玻璃罐、瓷罐、木盒或药罐，因为这些器具具有透光、不防潮、易碎的缺点。最好先用小罐子分装少量茶叶，以便随时取用，其余的茶叶则用大罐子密封起来储存在冰箱里保存。

适合人群

一般人群皆可饮用，儿童、孕妇不适宜饮用。

50