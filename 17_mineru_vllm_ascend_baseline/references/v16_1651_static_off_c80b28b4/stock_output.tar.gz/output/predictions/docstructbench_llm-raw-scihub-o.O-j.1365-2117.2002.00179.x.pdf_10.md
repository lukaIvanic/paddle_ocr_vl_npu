T. Muto and R. J. Steel

| Basinward horizontal distance (km) | Height (km) | Series |
| --- | --- | --- |
| ~-10 | ~1.9 | Averaged [x, y] |
| ~-5 | ~0.2 | y_i = 0.05 |
| ~-5 | ~0.3 | y_i = 0.10 |
| ~-5 | ~0.4 | y_i = 0.15 |
| ~-5 | ~0.5 | y_i = 0.20 |
| ~-5 | ~0.6 | y_i = 0.35 |
| ~-5 | ~0.7 | y_i = 0.45 |
| ~-5 | ~0.8 | y_i = 0.50 |
| ~-5 | ~0.9 | y_i = 0.60 |
| ~-5 | ~1.0 | y_i = 0.65 |
| ~-5 | ~1.1 | y_i = 0.70 |
| ~-5 | ~1.2 | y_i = 0.75 |
| ~-5 | ~1.3 | y_i = 0.80 |
| ~-5 | ~1.4 | y_i = 0.85 |
| ~-5 | ~1.5 | y_i = 0.90 |
| ~-5 | ~1.6 | y_i = 0.95 |
| ~-5 | ~1.7 | y_i = 1.00 |
| ~-5 | ~1.8 | y_i = 1.05 |
| ~12 | ~1.2 | P |
| ~32 | ~1.2 | M |
| ~38 | ~2.3 | D |
| ~42 | ~2.6 | D |
| ~45 | ~2.7 | D |
| ~32 | ~0.8 | y_i = 0.25 |
| ~38 | ~1.0 | y_i = 0.30 |
| ~42 | ~1.2 | y_i = 0.35 |
| ~45 | ~1.4 | y_i = 0.40 |
| ~48 | ~1.6 | y_i = 0.45 |
| ~48 | ~1.8 | y_i = 0.50 |
| ~48 | ~2.0 | y_i = 0.55 |
| ~48 | ~2.2 | y_i = 0.60 |
| ~48 | ~2.4 | y_i = 0.65 |
| ~48 | ~2.6 | y_i = 0.70 |
| ~48 | ~2.8 | y_i = 0.75 |
| ~48 | ~3.0 | y_i = 0.80 |
| ~48 | ~3.2 | y_i = 0.85 |
| ~48 | ~3.4 | y_i = 0.90 |
| ~48 | ~3.6 | y_i = 0.95 |
| ~48 | ~3.8 | y_i = 1.00 |
| ~48 | ~4.0 | y_i = 1.05 |

Fig. 10. Reconstructed shoreline trajectories. Note that the trajectories for \( y_{\mathrm{i}} = 0.45 \pm 0.10 \mathrm{~km} \) show concave-basinward geometry.

\( y_{i}=0.45\pm0.10 \) km, however, the trend of steady increase in S is still retained. With \( y_{i}=0.45 \) km, the magnitude of S in the middle stage, when the shelf edge was located somewhere between sites P–M, is three times as large as in the initial stage. In the latest stage, furthermore, the magnitude of S became over 14 times as large as in the initial stage. A significantly different trend of S is seen with \( y_{i}\geq0.70 \) km: S decreases in the early stage and then increases later. It is an important point that, whatever magnitude \( y_{i} \) took, S tended to become highest at the latest stage, when the shelf edge was migrating from site M to site D.

The pattern of changing A, opposite to that of changing S (Eq. (10)), is shown in Fig. 12 in the form of a relative sea-level curve. When  \( y_{i} \)  takes a low magnitude (e.g. 0.05–0.20 km), the relative sea-level change is characterized with a rapid rise in the early stage followed by a slow rise or nearly a standstill in the late stage. This trend is also seen in the case of  \( y_{i}=0.45\pm0.10 \)  km. When  \( y_{i}=0.80 \)  km, there was no change in A while the shelf edge was prograding from site i to site M. With  \( y_{i}\geq0.85 \)  km, the relative sea-level curve is sigmoidal in shape where the highest magnitude of A is realized between sites P and M.

Assessment of the uncertainty

The results of the analyses of the uncertainty of the field data and related assumptions are shown in Figs 13 and 14.

Polygons  \( \eta_{P} \) ,  \( \eta_{M} \) , and  \( \eta_{D} \)  in the x-y plane represent the spatial distribution of any possible  \( x_{adv} \) , that was obtained from the data sets measured at sites P, M, and D, respectively. The degree of overlap between polygons is expressed as  \( \rho_{PM} \)  (for overlap between  \( \eta_{P} \)  and  \( \eta_{M} \) ) and  \( \rho_{MD} \)  (for overlap between  \( \eta_{M} \)  and  \( \eta_{D} \) ) (see Eq. (11)).

There is no overlap between  \( \eta_{P} \)  and  \( \eta_{M} \)  (i.e.  \( \rho_{PM}=0 \) ) when  \( y_{i}\leq0.35 \)  km and  \( y_{i}\geq1.05 \)  km. With  \( y_{i}=0.40-1.00 \)  km, on the other hand,  \( \eta_{P} \)  and  \( \eta_{M} \)  overlap each other (i.e.  \( 0<\rho_{PM}<1 \) ). However, the highest value of  \( \rho_{PM} \)  (at  \( y_{i}=0.40 \)  km) is as low as 0.137. Excluding the cases that  \( y_{i}=0.40-0.45 \)  km, the overlap is negligible ( \( \rho_{PM}\approx0 \) ). On the other hand, the overlap of  \( \eta_{M} \)  and  \( \eta_{D} \)  is in a significantly different trend from that between  \( \eta_{P} \)  and  \( \eta_{M} \) . There is some overlap between  \( \eta_{M} \)  and  \( \eta_{D} \)  ( \( 0<\rho_{MD} \) ) when  \( y_{i}=0.20-0.90 \)  km. At any magnitude of  \( y_{i} \)  within this range,  \( \rho_{MD} \)  is much larger than that of  \( \rho_{PM} \)  (Fig. 14). The highest values of  \( \rho_{MD} \)  (0.55–0.60) are seen when  \( y_{i}=0.50-0.70 \)  km. With  \( y_{i}=0.45\pm0.10 \)  km,  \( \rho_{MD} \)  ranges between 0.31 and 0.55, still much larger than the highest of  \( \rho_{PM} \) .

Interpretation

The clear monomodal distribution of ‘successful’ runs (Fig. 9) suggests that the initial water depth (\(y_i\)) for the shelf-edge progradation is most likely to have been around 0.45 km. Less attention needs to be paid to other

312

© 2002 Blackwell Science Ltd, Basin Research, 14, 303–318