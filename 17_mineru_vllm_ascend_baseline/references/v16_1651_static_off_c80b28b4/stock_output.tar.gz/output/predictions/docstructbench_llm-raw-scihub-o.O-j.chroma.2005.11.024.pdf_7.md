156

P.A. Tate, J.G. Dorsey / J. Chromatogr. A 1103 (2006) 150–157

| Series | Time (min) | Migration Distance (cm) |
| --- | --- | --- |
| Plate 1 | ~5 | ~1.2 |
| Plate 1 | ~8 | 2 |
| Plate 1 | ~12 | 3 |
| Plate 2 | ~5 | ~1.1 |
| Plate 2 | ~30 | 8.6 |
| Plate 3 | ~10 | ~2.8 |

Fig. 9. Migration of rhodamine B marker on three separate TLC plates. Distances were measured to the center of the zone.

run buffer. Before placing these spotted, solvent saturated plates into the instrument, excess solvent was removed by patting with a Kimwipe. These were quickly placed into the instrument, external pressure applied, then solvent was allowed to contact the TLC layer, and power turned on. Enabling solvent to contact the layer before applying external pressure induced capillary action through the channel of air (due to spacer thickness), diffusing the sample spot. Applying pressure first removes this channel of air by compressing the sealant.

Fig. 9 illustrates migration of rhodamine B on three separate TLC plates. For these experiments the migration rate of rhodamine B was determined to be \(0.29\mathrm{cm / min}\) (\(R^2 = 0.9996\), \(n = 6\)). There are three data points for the first plate and they were taken by performing PPEC for a specified time, lowering the press enough to mark solute migration, reapply pressure then voltage, and repeating. Repeatedly releasing and applying pressure caused extensive zone broadening from solvent perturbations. Subsequent experiments were checked for solute migration less often or only at the end of experimentation, significantly reducing zone dispersion.

These results show that rhodamine B (spotted at the center of a \(2.5\mathrm{cm}\) wide TLC plate) migrates only in the direction of voltage drop. This was a significant problem with earlier experiments; marker solutes would migrate at an angle (in the direction of greatest voltage drop) with the un-stable EOF. Fig. 10 shows

Rectangular white object with a small red mark, placed inside a transparent plastic case (no text or symbols visible)

Fig. 10. Picture showing the 8.5 cm migration of Rhodamine B in 30 min. Notice how the spot stays in the center of the TLC plate. The solute zone has been digitally enhanced by intensifying the pink solute color to a deeper red (for visualization purposes) without compromising the zone shape or diffusion characteristics.

an 8.5 cm migration in 30 min where the solute zone stays in the center of the 2.5 cm wide plate with zone dispersion (zone length of  \( \sim \) 2.6 mm) primarily in the direction of voltage drop. This assures that EOF is only in the direction between positive and negative source electrodes, and there are no localized gradients within the width of the 2.5 cm TLC plate. Analysis of this spot yielded well over 10,000 plates. This was not a point injection and the spot width was not measured prior to PPEC affecting the measure of zone dispersion, therefore over-estimating the actual band broadening. Also, the final zone width was estimated with a ruler and visual inspection, under-estimating the actual band broadening. There may have also been some zone refocusing mechanism as the zone migrated past each reader electrode, helping keep the compact zone shape, but the migration rate (Fig. 9) would not have been so reproducible. Factoring in both under and over-estimations, we feel confident that this zone is still measuring over  \( \sim \) 8000 theoretical plates. This was not typical for efficiencies seen in PPEC experiments, normally producing about half that number of theoretical plates. Better understanding of the many experimental parameters will hopefully make this a more common measure of efficiency.

4. Conclusions

The addition of high-pressure to PEC instrumentation (now referred to as PPEC) has improved the efficacy of this technique by producing homogenous flow profiles that are near theoretical predictions. Linear voltage profiles have finally been achieved, as well as reduced plate equilibration times. These improvements are attributed to the increased efficiency of the electroosmotic forces acting on the reduced solvent volume. Also, use of higher field strengths will increase the utility of this technique. This can be easily implemented with an efficient heat sink to combat Joule heating. Scaling the TLC plate width should not be problematic as earlier data on a \(5.0\mathrm{cm}\) wide TLC plate showed almost identical voltage profiles using two columns of reader electrodes on the REG [31].

A new method for introducing TLC plates onto the apparatus has also been described. This eliminates the need to seal a plate to the REG a day before experimentation, and is essential for sample application and ease of use. This method allows sealant to be attached to the glass sides of a TLC plate, while cured on a removable sheet of Teflon. The plate is then removed from the PTFE and can be inserted into the apparatus anytime afterwards. A 0.25 mm gap between the chromatographic surface and PTFE sheet (when curing) allows compression of the sealant, trapping solvent within the chromatographic phase when external pressure is applied. A plate can now be pre-equilibrated before use (soaking in run buffer) reducing the current required to drive EOF. Sample can then be applied to a plate and placed into the apparatus for PPEC. Unfortunately the plates used do not contain a fluorescent indicator, and routine chromatographic analysis could not be detected. Use of rhodamine B did allow visualization of a marker solute's migration in PPEC. These results visually confirmed that migration is only in the direction of voltage drop, and band broadening is primarily in the same direction resulting in up to  \( \sim \) 8000 theoretical plates.