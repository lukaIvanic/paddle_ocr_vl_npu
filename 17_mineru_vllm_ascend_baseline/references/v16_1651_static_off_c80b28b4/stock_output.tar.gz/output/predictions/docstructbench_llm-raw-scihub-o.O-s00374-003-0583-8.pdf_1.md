Biol Fertil Soils (2003) 37:255–259
DOI 10.1007/s00374-003-0583-8

ORIGINAL PAPER

A. Piccolo \(\cdot\) P. Conte \(\cdot\) R. Spaccini \(\cdot\) M. Chiarella

Effects of some dicarboxylic acids on the association of dissolved humic substances

Received: 23 July 2002 / Accepted: 20 January 2003 / Published online: 27 February 2003  
© Springer-Verlag 2003

Abstract Changes in molecular size distributions of four different humic materials were evaluated through high performance size-exclusion chromatography (HPSEC), before and after treating humic solutions with naturally occurring dicarboxylic (oxalic, malonic, succinic and glutaric) acids. Chromatograms of dissolved humic substances showed a decrease in peak absorbance as well as an increase in peak elution volume when the solution pH was lowered from 7 to 3.5 by addition of dicarboxylic acids before HPSEC analysis. The resulting reduction in molecular size is explained by the disruption of unstable humic superstructures into smaller-sized associations stabilized by the formation of strong intra- and intermolecular hydrogen bonds among humic molecules. The extent of humic size variation was in the order: oxalic<malonic<succinic<glutaric acid. Dicarboxylic acids with an increasing number of C atoms and pKas, had progressively larger degrees of protonation which increasingly reduced the electrostatic repulsion from humic molecules. The less dissociated dicarboxylic acids enabled a closer contact with the hydrophobic domains of weakly bound humic superstructures and produced more extensive conformational rearrangements. Recognition of a process controlling the conformational structure of humic molecules by organic acids exuded in the soil solution by either plant roots or soil microbes may be important in understanding the role of humus in soil-plant interactions.

Keywords Humic substances \(\cdot\) Supramolecular associations \(\cdot\) Dicarboxylic acids \(\cdot\) Self-assembling conformations \(\cdot\) Molecular sizes

A. Piccolo (☒) · P. Conte · R. Spaccini · M. Chiarella
Dipartimento di Scienze del Suolo della Pianta e dell'Ambiente,
Università degli Studi di Napoli “Federico II”,
Via Università 100, 80055 Portici, Italy
e-mail: alpiccol@unina.it
Fax: +39-81-2539186

Introduction

Research findings have shown that different carboxylic acids are exuded by plant roots into the soil solution (Vaughan and Malcolm 1985; Junk 1991; Bar-Yosef 1991; Ohwaki and Hirata 1992; Tyler and Ström 1995). It has been hypothesized that the amphiphilic properties of these organic acids may modify the size of humic substances dissolved in the soil solution and influence root activity (Nardi et al. 1996; Pinton et al. 2001). Enhanced growth of both plant roots and shoots has been repeatedly accounted for by certain molecular properties of humic substances which, by interacting with root cells, would increase their metabolism (Vaughan and Linehan 1976; Vaughan and Malcolm 1985; Nardi et al. 1996; Varanini and Pinton 2001). While the overall mechanism by which humic substances interact with the plant physiological system is still unclear, results showed that small molecular-size humic components, separated from bulk humus by root-exuded organic acids, can be absorbed through membrane carrier systems and affect plant growth by hormone-like activity (Smidova 1960; O'Donnell 1973; Piccolo et al. 1992; Nardi et al. 1994, 1996).

Humic substances have been recently described as supramolecular associations rather than macromolecular polymers (Conte and Piccolo 1999; Piccolo et al. 2001a, 2001b; Piccolo 2001, 2002). This model implies that small and heterogeneous humic molecules self-assemble in supramolecular conformations stabilized mainly by weak forces such as dispersive interactions (van der Waals, \(\pi-\pi\), and CH-\(\pi\) bonds) and hydrogen bonds. These weakly bound conformations have only apparent large molecular dimensions which can be reversibly disrupted into smaller molecular associations by treating humic solutions with small amounts of either methanol, HCl or acetic acid. Treatment of a humic acid (HA) solution with acetic acid before preparative size-exclusion chromatography was found to produce a substantial reduction of the chemical heterogeneity of size separates (Piccolo et al. 2002). Separation of small humic components by dialysis