EX 12 Excel Chapter 1 Creating a Worksheet and an Embedded Chart

Formula Bar

The formula bar appears below the Ribbon (Figure 1–12a). As you type, Excel displays the entry in the formula bar. You can make the formula bar larger by dragging the sizing handle (Figure 1–7) on the formula bar or clicking the expand button to the right of the formula bar. Excel also displays the active cell reference in the Name box on the left side of the formula bar.

Mini Toolbar and Shortcut Menus

The Mini toolbar, which appears automatically based on tasks you perform (such as selecting text), contains commands related to changing the appearance of text in a worksheet. All commands on the Mini toolbar also exist on the Ribbon. The purpose of the Mini toolbar is to minimize mouse movement. For example, if you want to format text using a command that currently is not displayed on the active tab, you can use the command on the Mini toolbar — instead of switching to a different tab to use the command.

When the Mini toolbar appears, it initially is transparent (Figure 1–12a). If you do not use the transparent Mini toolbar, it disappears from the screen. To use the Mini toolbar, move the mouse pointer into the toolbar, which causes the Mini toolbar to change from a transparent to bright appearance (Figure 1–12b).

Clipboard
Font
Alignment
B5
X ✓ fx
Formula bar
sizing handle
Walk and Rock Music
Name box
2
3
4
5
6
A
B
C
D
E
F
Calibri
11
B 1 A A
transparent Mini toolbar
Walk and Rock Music

(a) Transparent Mini Toolbar

commands on
Mini toolbar are
also on Ribbon
B5
B I U
Font
Align
A B C D E
1
2
3
4
5
6
Calibri 11
B I A A*
Walk and Rock Music
bright
Mini toolbar

(b) Bright Mini Toolbar

Figure 1-12

Home
Insert
Page Layout
Formulas
Data
Review
Paste
Clipboard
Font
Alignment
B5
x ✓ fx
Walk and Rock Music
right-clicked text
Calibri 11
Mini toolbar
Walk and Rock Music
Cut
Copy
Paste
Format Cells...
Pick From Drop-down List...
shortcut menu

Figure 1–13

A shortcut menu, which appears when you right-click an object, is a list of frequently used commands that relate to the right-clicked object. If you right-click an item in the document window such as a cell, Excel displays both the Mini toolbar and a shortcut menu (Figure 1–13).