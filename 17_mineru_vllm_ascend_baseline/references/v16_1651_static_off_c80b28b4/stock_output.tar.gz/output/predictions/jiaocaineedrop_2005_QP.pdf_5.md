Each spring requires a 0.4 N force to extend or compress it by 1.0 cm.

(c) What steady force is needed to move the pointer 2.0 cm from O?
____
____ [2]

(d) What steady acceleration is required to move the pointer in (c)? [1]

The car starts from rest at time t = 0 and travels along a straight road. The accelerometer readings are recorded in Table 14.

<table><tr><td>Time / s</td><td>Acceleration / m/s2</td></tr><tr><td>0.00 – 3.00</td><td>11.00</td></tr><tr><td>3.00 – 4.50</td><td>7.00</td></tr><tr><td>4.50 – 7.00</td><td>0.00</td></tr></table>

Table 14

(e) How fast is the car travelling after 7.00 s?
____
____
____ [1]

(f) How far does the car travel in the first 7.00 s?
____
____
____
____
____
____
[3]

(g) Aeroplanes are fitted with three accelerometers as part of their navigation equipment. Why are three accelerometers needed?
____
____ [2]