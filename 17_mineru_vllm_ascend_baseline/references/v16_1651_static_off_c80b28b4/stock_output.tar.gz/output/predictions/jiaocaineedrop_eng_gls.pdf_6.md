organic evolution-prehistory

organic evolution the principle set forth by Darwin that every plant or animal has evolved, or changed, over a long period of time from earlier, simpler forms of life to more complex forms (p. 608)

orthodoxy traditional beliefs, especially in religion (p. 469)

ostracism in ancient Athens, the process for temporarily banning ambitious politicians from the city by popular vote (p. 123)

ozone layer a thin layer of gas in the upper atmosphere that shields Earth from the sun's ultraviolet rays (p. 970)

P

Paleolithic Age from the Greek for "Old Stone," the early period of human history, from approximately 2,500,000 to 10,000 B.C., during which humans used simple stone tools; sometimes called the Old Stone Age (p. 22)

Pan-Africanism the unity of all black Africans, regardless of national boundaries (pp. 788, 923)

Pan-Arabism Arab unity, regardless of national boundaries (p. 931)

partisan a resistance fighter in World War II (p. 822)

pasha an appointed official in the Ottoman Empire who collected taxes, maintained law and order, and was directly responsible to the sultan's court (p. 459)

pastoral nomad a person who domesticates animals for food and clothing and moves along regular migratory routes to provide a steady source of nourishment for those animals (p. 55)

paterfamilias in the Roman social structure, the dominant male head of the household, which also included his wife, sons and their wives and children, unmarried daughters, and slaves (p. 165)

patriarch the head of the Eastern Orthodox Church, originally appointed by the Byzantine emperor (p. 305)

patriarchal dominated by men (p. 41)

patrician great landowners, they formed the ruling class in the Roman Republic (p. 152)

patrilineal tracing lineage through the father (p. 237)

peacekeeping force a military force drawn from neutral members of the United Nations to settle conflicts and supervise truces (p. 975)

peninsular a person born on the Iberian Peninsula; typically, a Spanish or Portuguese official who resided temporarily in Latin America for political and economic gain and then returned to Europe (p. 672)

per capita per person (p. 943)

perestroika Mikhail Gorbachev's plan to reform the Soviet Union by restructuring its economy (p. 877)

permanent revolution an atmosphere of constant revolutionary fervor favored by Mao Zedong to enable China to overcome the past and achieve the final stage of communism (p. 942)

phalanx a wall of shields created by foot soldiers marching close together in a rectangular formation (p. 116)

pharaoh the most common of the various titles for ancient Egyptian monarchs; the term originally meant "great house" or "palace" (p. 47)

philosophe French for "philosopher"; applied to all intellectuals—i.e., writers, journalists, economists, and social reformers—during the Enlightenment (p. 519)

philosophy an organized system of thought, from the Greek for "love of wisdom" (p. 130)

photomontage a picture made of a combination of photographs (p. 774)

pilgrim a person who travels to a shrine or other holy place (p. 85)

plague an epidemic disease (p. 176)

planned economy an economic system directed by government agencies (p. 726)

plantation a large agricultural estate (p. 416)

plateau a relatively high, flat land area (p. 225)

plebeian in the Roman Republic, a social class made up of minor landholders, craftspeople, merchants, and small farmers (p. 152)

plebiscite a popular vote (p. 600)

pogrom organized persecution or massacre of a minority group, especially Jews (p. 639)

policy of containment a plan to keep something, such as communism, within its existing geographical boundaries and prevent further aggressive moves (p. 850)

polis the early Greek city-state, consisting of a city or town and its surrounding territory (p. 115)

Politburo a seven-member committee that became the leading policy-making body of the Communist Party in Russia (p. 761)

polytheistic having many gods (p. 42)

pop art an artistic movement that emerged in the early 1960s; pop artists took images from popular culture and transformed them into works of fine art (p. 892)

pope the bishop of Rome and head of the Roman Catholic Church (p. 287)

porcelain a ceramic made of fine clay baked at very high temperatures (pp. 257, 494)

postmodernism an artistic movement that emerged in the 1980s; it is characterized by a revival of traditional elements and techniques, and includes crafts such as textiles, pottery, and furniture making in addition to traditional artistic media (p. 893)

praetor an official of the Roman Republic in charge of enforcing civil law (p. 152)

predestination the belief that God has determined in advance who will be saved (the elect) and who will be damned (the reprobate) (p. 396)

prefecture in the Japanese Meiji Restoration, a territory governed by its former daimyo lord (p. 699)

prehistory the period before writing was developed (p. 19)

Glossary

Glossary

1009

CONTENTS