所以 \(x_{1} + x_{2} = \frac{8k^{2}}{3 + 4k^{2}}, x_{1}x_{2} = \frac{4k^{2} - 12}{3 + 4k^{2}}\)

(法一) \( |AF_{2}|=\sqrt{(x_{1}-1)^{2}+y_{1}^{2}}=\sqrt{1+k^{2}}|x_{1}-1| \) ,  \( |F_{2}B|=\sqrt{(x_{2}-1)^{2}+y_{2}^{2}}=\sqrt{1+k^{2}}|x_{2}-1| \) ,

\[
| A F _ {2} | \cdot | F _ {2} B | = (1 + k ^ {2}) | x _ {1} x _ {2} - (x _ {1} + x _ {2}) + 1 | = (1 + k ^ {2}) \left| \frac {4 k ^ {2} - 1 2}{3 + 4 k ^ {2}} - \frac {8 k ^ {2}}{3 + 4 k ^ {2}} + 1 \right| = (1 + k ^ {2}) \left| \frac {9}{3 + 4 k ^ {2}} \right| = (1 + k ^ {2}) \left| \frac {9}{3 + 4 k ^ {2}} \right|
\]

\[
k ^ {2}) \frac {9}{3 + 4 k ^ {2}} = \frac {9}{4} \Big (1 + \frac {1}{3 + 4 k ^ {2}} \Big),
\]

当 \(k^2 = 0\) 时，取最大值为3，所以 \(\left|AF_2\right|\cdot \left|F_2B\right|\) 的取值范围 \(\left(\frac{9}{4},3\right]\).

又当 \(k\) 不存在, 即 \(AB \perp x\) 轴时, \(|AF_2| \cdot |F_2B|\) 取值为 \(\frac{9}{4}\).

所以  \( \left|AF_{2}\right|\cdot\left|F_{2}B\right| \)  的取值范围  \( \left[\frac{9}{4},3\right] \) ,

\[
(\text {法二}) | A F _ {2} | \cdot | F _ {2} B | = \overrightarrow {A F _ {2}} \cdot \overrightarrow {F _ {2} B} = - \overrightarrow {F _ {2} A} \cdot \overrightarrow {F _ {2} B} = - (x _ {1} - 1) (x _ {2} - 1) - y _ {1} y _ {2}
\]

\[
= - (x _ {1} - 1) (x _ {2} - 1) - k ^ {2} (x _ {1} - 1) (x _ {2} - 1) = - (1 + k ^ {2}) [ x _ {1} x _ {2} - (x _ {1} + x _ {2}) + 1 ] = - (1 + k ^ {2})
\]

\[
\left(\frac {4 k ^ {2} - 1 2}{3 + 4 k ^ {2}} - \frac {8 k ^ {2}}{3 + 4 k ^ {2}} + 1\right) = (1 + k ^ {2}) \frac {9}{3 + 4 k ^ {2}} = \frac {9}{4} \left(1 + \frac {1}{3 + 4 k ^ {2}}\right),
\]

当 \(k^2 = 0\) 时，取最大值为3，所以 \(\left|AF_2\right|\cdot \left|F_2B\right|\) 的取值范围 \(\left(\frac{9}{4},3\right]\).

又当 \(k\) 不存在, 即 \(AB \perp x\) 轴时, \(|AF_2| \cdot |F_2B|\) 取值为 \(\frac{9}{4}\).

所以  \( \left|AF_{2}\right|\cdot\left|F_{2}B\right| \)  的取值范围  \( \left[\frac{9}{4},3\right] \) .

例26.(2022·全国·南京外国语学校模拟预测)已知抛物线 \(C: x^{2} = 4y\), \(F\) 为其焦点, 过 \(F\) 的直线 \(l\) 与 \(C\) 交于不同的两点 \(A, B\).

(1) 若直线 \(l\) 斜率为 3 , 求 \(|AB|\);

(2)如图， \(C\) 在点 \(A\) 处的切线与在点 \(B\) 处的切线交于点 \(P\) ，连接 \(PF\) ，证明： \(\vert PF\vert^2 = \vert AF\vert \cdot \vert BF\vert\)

【解析】(1)由抛物线 \(C: x^{2} = 4y\), 得 \(F(0,1)\),

若直线l的斜率为3,则直线l的方程为 \( y=3x+1 \) .

设 \( A(x_{1},y_{1}),B(x_{2},y_{2}) \) ,

由 \(\left\{ \begin{array}{l} y = 3x + 1 \\ x^2 = 4y \end{array} \right.\) 消去 \(y\) 得 \(x^2 - 12x - 4 = 0\)，所以 \(\Delta > 0, x_1 + x_2 = 12,\)

所以 \(|AB| = |AF| + |FB| = y_1 + 1 + y_2 + 1 = 3(x_1 + x_2) + 4 = 40.\)

(2) 证明: 由题可知, 直线 l 的斜率存在, 设直线 l 的方程为  \( y = kx + 1 \) ,  \( A(x_{1}, y_{1}) \) ,  \( B(x_{2}, y_{2}) \) ,

抛物线方程为  \( x^{2}=4y \) ，即  \( y=\frac{x^{2}}{4}, y'=\frac{x}{2} \) ，

所以以 A、B 为切点的切线方程分别为  \( x_{1}x = 2y + 2y_{1} \) ， \( x_{2}x = 2y + 2y_{2} \) .

由 \(\left\{ \begin{array}{l} y = kx + 1 \\ x^2 = 4y \end{array} \right.\) 消去 \(y\) 得 \(x^2 - 4kx - 4 = 0\)，所以 \(\Delta > 0, x_1 + x_2 = 4k, x_1x_2 = -4\).

这两条切线的斜率分别为 \( k_{1}=\frac{x_{1}}{2},k_{2}=\frac{x_{2}}{2} \) .

由 \(k_{1}k_{2} = \frac{x_{1}x_{2}}{4} = \frac{-4}{4} = -1\) ，故 \(PA\perp BP\)

设 \(P(x_0,y_0)\) ，则由 \(\left\{ \begin{array}{l}x_{1}x = 2y + 2y_{1}\\ x_{2}x = 2y + 2y_{2} \end{array} \right.\) 可得 \(x_0 = \frac{2(y_1 - y_2)}{x_1 - x_2} = 2k\) ， \(y_0 = \frac{1}{2} x_1x_0 - y_1 = kx_1 - y_1 = -1,\)

当 \(k = 0\) 时, 则 \(x_0 = 0\), 可得 \(AB \perp PF\);

当 \(k \neq 0\) 时, 则 \(x_0 \neq 0\), \(k_{AB} = \frac{x_0}{2}\), \(k_{PF} = \frac{-2}{x_0}\), 所以 \(k_{AB} \cdot k_{PF} = \frac{-2}{x_0} \cdot \frac{x_0}{2} = -1\),

y
B
F
A
O
P
x