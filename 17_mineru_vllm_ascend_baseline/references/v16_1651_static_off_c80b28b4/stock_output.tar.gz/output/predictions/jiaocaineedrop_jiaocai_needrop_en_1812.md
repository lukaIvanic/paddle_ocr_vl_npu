The fine arts

我国从两汉时期始已有多种金属材料，金属工艺品也日趋精巧，精美的工艺品被广泛应用于人们生活中的各个领域。唐代是金属工艺品，尤其是金银器的鼎盛期，创造了浮雕般的金银錾凿工艺。金属工艺品主要有铜镜和金银器皿。至宋、元、明、清时期，随着冶炼技术的不断进步，金属材料的不断增多，金属工艺也更为精进，以明代的宣德炉、清代的掐丝珐琅最为著名。

Ancient bronze ritual vessel with intricate dragon motifs and ornate base (no visible text or symbols)

▲ 错金银四龙四凤方案座 [战国] 高36.2 cm，长7.5 cm，宽47 cm 金银器 河北博物院

Ornate metallic pitcher with a golden horse illustration, no visible text or symbols

▲ 鎏金舞马衔杯纹银壶 [唐] 通高14.8 cm，口径2.3 cm，短径9 cm，腹长径11.1 cm，壁厚0.12 cm 金银器 陕西历史博物馆

Ornate ceramic vessel with intricate gold and black patterns, no visible text or symbols

▲ 鎏金银鸡冠壶 [辽] 高26.3 cm，口径5.5 cm，底长21.2 cm 金银器 中国国家博物馆

Ancient bronze incense burner with three legs and two handles (no visible text or symbols)

▲ 铜冲耳乳足炉 [明] 高11.2 cm，口径14.3 cm
铜器 故宫博物院

16