You are a AI assistant specialized in OCR. You are provided with the original document image. Please follow these instructions for the conversion:
# 1. General Text & Math Processing
-   **Structure:** Maintain original headings, paragraphs, and list structures.
-   **De-hyphenation:** If a word is split by a hyphen at a line break in the image (e.g., `con-` \n `nection`), merge it into a single word (`connection`) in your output.
-   **Math Formulas:**
    -   Use LaTeX for all inline math content: `\( E=mc^2 \)`
-   **Tables:** **STRICTLY PROHIBITED.** Do NOT use Markdown tables. TreatAll rights reserved.

数学

SHUXUE

三年级上册

4. \(23 \times 3 = 69\) (根)

5. \(22 \times 4 = 88\) (元)

6. (1) \(21 \times 2 = 42\) (盆)

(2) \( 42 \times 2 = 84 \) (盆)

7. \(4 - 1 = 3\) (层) \(21 \times 3 = 63\) (级)

第 8 课时 两、三位数乘

一位数(不连续进位)

1.72 255 386 2448 个 十 前一
几

2.72 81 1464 489 654 688(竖式计算略)

3.  \( 28 \times 3 = 84 \)  (人)

4. \(41 \times 7 = 287\) (个)

5. \(411 \times 8 = 3288\)

6.  \( 5 \times (132 - 1) = 655 \)  (米)

第 9 课时 练习二(1)

1. 27 61 23 24 54 66 22 34

2. 166 76 872 3284

3.  \( \frac{39}{78} \)   \( \frac{114}{684} \)   \( \frac{163}{489} \)

4.96 188 566 585 1248 1248(竖式计算略)

5.96 72 78

6.  \( 182 \times 3 = 546 \)  (米)

7. 不行 √

第 10 课时 练习二(2)

1. 60 63 69;80 82 86
2. 62 88 86 66 96;48 88 69 68
3 88 84 48 99

3. 想略 126 72 1293 429

4.76 288 651 3648 917 1866(竖式计算略)

5. \(16 \times 6 = 96\) (棵) \(96 + 50 = 146\) (棵)

6. \(15 + 9 = 24\) （个） \(24 \times 3 = 72\) （个）

7. (答案不唯一)

2 1
× 4
— 8 4
2 2
× 4
— 8 8
2 3
× 4
— 9 2
2 4
× 4
— 9 6

第 11 课时 两、三位数乘

一位数(连续进位)

1. 424 282 2555 744
2. 78 561 632
   × 23 × 3 5 × 218
   234 2805 5056

3. 228 296 5535 3661(竖式计算略)

4. \(186 \times 3 = 558\) (本)

5. \(98 \times 4 = 392\) (张) \(428 - 392 = 36\) (张)

张叔叔的邮票多,多 36 张

6. (1) \(83 \times 5 = 415\) (箱)

(2) \(415 + 36 = 451\) (箱)

7.  \( 66 \times 7 = 462 \)  (米)  \( 462 + 6 = 468 \)  (米)

第 12 课时 练习三(1)

1. 51 30 71 50 33 31

2. 371 416 370 1518 612 885 2896

2730(竖式计算略)

3. 640 1140 2690;172 1692 1972

4. 小红: \(98 \times 6 = 588\) (个)

小美: \(116 \times 5 = 580\) (个)

5. \(18 \times 3 + 8 = 62\) (元)

6. \(24 \times 4 - 38 = 58\) (瓶)

7.  \( \boxed{1} \)  5  \( \boxed{2} \) 
×    7
1 0 6 4
6 8 (答案不唯一)
× 3
2 0 4

第 13 课时 练习三(2)

1. 36 51;26 78

2.(从下到上)87 136 72 96 52;81
60 84 96

3. 112 5517 1335 651 2790 6656 (竖算略)

4. \(29 \times 4 = 116\) (页) \(116 > 106\) \(116 - 106\)
(页)

凡凡看得多，多10页。

5. (1) \(16 \times 5 - 24 = 56\) (块)

(2) \(28 + 42 - 24 = 46\) (块)

6. (1) \(145 \times 8 = 1160\) (元) \(1160 < 1200\)

够。或把 145 看作 \(150, 150 \times 8 = 1200\) (元)

志鸿超仁

86

关注微信公众号“教辅资料站”获取更多学习资料