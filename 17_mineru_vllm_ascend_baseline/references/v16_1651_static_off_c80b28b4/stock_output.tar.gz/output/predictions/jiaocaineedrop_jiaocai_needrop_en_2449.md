2. 关于物态变化, 下列说法正确的是( )

C. 雾的形成，属于汽化现象

C. 雾的形成，属于汽化现象

D. 霜的形成，属于凝华现象

D. 霜的形成，属于凝华现象

3. 下列现象中届于蒸发的是( )

A. 铁块变成铁水

B. 夏天从冰箱拿出的苹果 “冒汗”

C. 霜的形成

D. 把酒精擦在手背上，一会儿不见了

4. 下列做法能使水的蒸发加快的是( )

A. 用电热吹风机将湿头发吹干

B. 用扫帚把地面的积水向周围扫开

C. 把粮食拿到向阳的地方晒

D. 把水果用保鲜膜包好放在冷藏柜里

5. (2012·广州)下表为不同气压下水的沸点

<table><tr><td>P/×105Pa</td><td>0.98</td><td>1.01</td><td>1.13</td><td>1.29</td><td>1.48</td><td>1.69</td><td>1.80</td><td>2.05</td></tr><tr><td>t/°C</td><td>99</td><td>100</td><td>103</td><td>107</td><td>111</td><td>115</td><td>117</td><td>121</td></tr></table>

压力锅工作时锅内气体压强最大可达 \( 1.80\times10^{5} \) Pa，锅内水的最高温度()

A. 可达 \(100^{\circ} \mathrm{C}\)

B. 可达 \( {117}^{ \circ  }\mathrm{C} \)

C. 可达 \( {121}^{ \circ  }\mathrm{C} \)

D. 取决于加热时间

6. (2012·德州)祖国的山河一年四季美景如画, 如图中的描述属于液化的是 ( )

A. 春天,冰雪融化

Close-up of frost-covered tree branches with visible snow patches (no text or symbols)

C. 秋天, 枝头挂满白霜

B. 夏天, 草叶上形成露珠

Abstract sculpture of a seated figure with glowing effect, surrounded by geometric shapes and a glowing base (no text or symbols)

D. 冬天,冰雕逐渐变小

7. 如图所示, 正确反映 “探究水的沸腾” 过程中温度随时间变化关系是( )

2