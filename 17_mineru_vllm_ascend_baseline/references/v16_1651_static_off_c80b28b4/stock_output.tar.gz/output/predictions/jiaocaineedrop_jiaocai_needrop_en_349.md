\[
\begin{array}{l} \therefore \sin^ {2} \alpha + 4 \sin \alpha \cos \alpha + 4 \cos^ {2} \alpha = \frac {5}{2}, \\ \therefore \frac {\tan^ {2} \alpha + 4 \tan \alpha + 4}{\tan^ {2} \alpha + 1} = \frac {5}{2}, \text {解得} \tan \alpha = - \frac {1}{3} \text {或} \tan \alpha = 3, \\ \text {当} \tan \alpha = - \frac {1}{3} \text {时,} \tan 2 \alpha = \frac {2 \times \left(- \frac {1}{3}\right)}{1 - \frac {1}{9}} = - \frac {3}{4}, \\ \text {当} \tan \alpha = 3 \text {时,} \tan 2 \alpha = \frac {6}{1 - 9} = - \frac {3}{4}, \therefore \tan 2 \alpha = - \frac {3}{4}, \text {故选B.} \\ 8. \text {选} \mathrm{D} \quad \cos \left(\frac {\pi}{3} + 2 \alpha\right) = - \cos \left(\frac {2 \pi}{3} - 2 \alpha\right) = - 1 + 2 \sin^ {2} \left(\frac {\pi}{3} - \alpha\right) = \\ - 1 + \frac {2}{9} = - \frac {7}{9}, \text {故选D.} \\ \end{array}
\]

\[
\begin{array}{l} 8. \text {选} \mathrm{D} \quad \cos \left(\frac {\pi}{3} + 2 \alpha\right) = - \cos \left(\frac {2 \pi}{3} - 2 \alpha\right) = - 1 + 2 \sin^ {2} \left(\frac {\pi}{3} - \alpha\right) = \\ - 1 + \frac {2}{9} = - \frac {7}{9}, \text {故选D.} \\ \end{array}
\]

\[
9. \text {选 C} 4 \cos 5 0 ^ {\circ} - \tan 4 0 ^ {\circ}
\]

\[
= 4 \cos 50^ {\circ} - \frac {\sin 40 ^ {\circ}}{\cos 40 ^ {\circ}}
\]

\[
= \frac {4 \sin 4 0 ^ {\circ} \cos 4 0 ^ {\circ} - \sin 4 0 ^ {\circ}}{\cos 4 0 ^ {\circ}}
\]

\[
= \frac {2 \sin 8 0 ^ {\circ} - \sin 4 0 ^ {\circ}}{\cos 4 0 ^ {\circ}}
\]

\[
= \frac {2 \sin (5 0 ^ {\circ} + 3 0 ^ {\circ}) - \cos 5 0 ^ {\circ}}{\cos 4 0 ^ {\circ}}
\]

\[
= \frac {\sqrt {3} \sin 5 0 ^ {\circ}}{\cos 4 0 ^ {\circ}}
\]

\[
= \sqrt {3}, \text {故选} C.
\]

\[
1 0. \text {选A} \quad \text {原式} = \frac {\sin \frac {\pi}{9} \cos \frac {\pi}{9} \cos \frac {2 \pi}{9} \cos \frac {5 \pi}{9}}{\sin \frac {\pi}{9}}
\]

\[
= \frac {\frac {1}{2} \sin \frac {2 \pi}{9} \cos \frac {2 \pi}{9} \left(- \cos \frac {4 \pi}{9}\right)}{\sin \frac {\pi}{9}}
\]

\[
= \frac {- \frac {1}{4} \sin \frac {4 \pi}{9} \cos \frac {4 \pi}{9}}{\sin \frac {\pi}{9}}
\]

\[
= \frac {- \frac {1}{8} \sin \frac {8 \pi}{9}}{\sin \frac {\pi}{9}}
\]

\[
= - \frac {1}{8}.
\]

\[
1 1. \mathrm{解析:原式} = \frac {2 \sin \alpha + 2 \sin \alpha \cos \alpha}{1 + \cos \alpha} = \frac {2 \sin \alpha (1 + \cos \alpha)}{1 + \cos \alpha} = 2 \sin \alpha .
\]

答案:  \( 2\sin\alpha \)

\[
1 2. \text {解析:} \because f (x) = 2 \tan x + \frac {1 - 2 \sin^ {2} \frac {x}{2}}{\frac {1}{2} \sin x} = 2 \tan x + \frac {2 \cos x}{\sin x} = \frac {2 \sin x}{\cos x} +
\]

\[
\frac {2 \cos x}{\sin x} = \frac {2}{\sin x \cos x} = \frac {4}{\sin 2 x},
\]

\[
\therefore f \left(\frac {\pi}{1 2}\right) = \frac {4}{\sin \frac {\pi}{6}} = 8.
\]

答案:8

高考真题

\[
1 3. \mathrm{选B} \quad \cos 2 \alpha = 1 - 2 \sin^ {2} \alpha = 1 - \frac {2}{9} = \frac {7}{9}.
\]

\[
1 4. \text {选B} \quad \text {由二倍角公式可知,} 4 \sin \alpha \cos \alpha = 2 \cos^ {2} \alpha,
\]

\[
\because \alpha \in \left(0, \frac {\pi}{2}\right), \therefore \cos \alpha \neq 0,
\]

\[
\therefore 2 \sin \alpha = \cos \alpha , \text {又} \sin^ {2} \alpha + \cos^ {2} \alpha = 1.
\]

\[
\therefore \sin \alpha = \frac {\sqrt {5}}{5}. \text {故选B.}
\]

\[
\begin{array}{r l} & 1 5. \text {选D} \quad \sin 2 \alpha = \cos \left(\frac {\pi}{2} - 2 \alpha\right) = 2 \cos^ {2} \left(\frac {\pi}{4} - \alpha\right) - 1 = - \frac {7}{2 5}, \text {故} \\ & \text {选D}. \end{array}
\]

\[
1 6. \text {解析:由已知得,} \frac {\tan \alpha}{\frac {\tan \alpha + 1}{1 - \tan \alpha}} = - \frac {2}{3},
\]

\[
\text {解得} \tan \alpha = 2 \text {或} \tan \alpha = - \frac {1}{3},
\]

\[
\mathrm{又因为} \sin \left(2 \alpha + \frac {\pi}{4}\right) = \frac {\sqrt {2}}{2} (\sin 2 \alpha + \cos 2 \alpha)
\]

\[
\begin{array}{l} = \frac {\sqrt {2}}{2} (2 \sin \alpha \cos \alpha + 2 \cos^ {2} \alpha - 1) \\ = \sqrt {2} \sin \alpha \cos \alpha + \sqrt {2} \cos^ {2} \alpha - \frac {\sqrt {2}}{2} \\ = \frac {\sqrt {2} \sin \alpha \cos \alpha + \sqrt {2} \cos^ {2} \alpha}{\sin^ {2} \alpha + \cos^ {2} \alpha} - \frac {\sqrt {2}}{2} \\ = \frac {\sqrt {2} \tan \alpha + \sqrt {2}}{\tan^ {2} \alpha + 1} - \frac {\sqrt {2}}{2}, \\ \end{array}
\]

\[
\text {所以当} \tan \alpha = 2 \text {时,原式} = \frac {\sqrt {2}}{1 0},
\]

\[
\text {当} \tan \alpha = - \frac {1}{3}, \text {原式} = \frac {\sqrt {2}}{1 0}.
\]

答案: \( \frac{\sqrt{2}}{10} \)

实战演练

\[
\begin{array}{l} 1 7. \mathrm{选A} \frac {\sqrt {2}}{2} \cos 1 5 ^ {\circ} - \frac {\sqrt {2}}{2} \sin 1 9 5 ^ {\circ} \\ = \sin 45^\circ \cos 15^\circ + \cos 45^\circ \sin 15^\circ \\ = \sin (45^\circ +15^\circ) \\ = \sin 60^{\circ} \\ = \frac {\sqrt {3}}{2} \text {, 故选 A.} \\ \end{array}
\]

\[
\begin{array}{l} 1 8. \text {选} C \quad \cos \left(\frac {5 \pi}{3} + 2 \alpha\right) = \cos \left(\frac {\pi}{3} - 2 \alpha\right) = 2 \cos^ {2} \left(\frac {\pi}{6} - \alpha\right) - 1 = 2 \times \\ \frac {4}{9} - 1 = - \frac {1}{9}. \mathrm{故选C} \\ \end{array}
\]

\[
1 9. \text {选B} \quad \because \frac {1 2}{\sin \alpha} + \frac {1 2}{\cos \alpha} = 3 5, \alpha \in \left(\frac {\pi}{4}, \frac {\pi}{2}\right),
\]

\[
\therefore 1 2 (\sin \alpha + \cos \alpha) = 3 5 \sin \alpha \cos \alpha,
\]

\[
\mathrm{令} \sin \alpha + \cos \alpha = t, t \in (1, \sqrt {2}), \mathrm{则} \sin \alpha \cos \alpha = \frac {t ^ {2} - 1}{2},
\]

\[
\therefore 1 2 t = 3 5 \cdot \frac {t ^ {2} - 1}{2},
\]

\[
\therefore 3 5 t ^ {2} - 2 4 t - 3 5 = 0,
\]

\[
\therefore t = \frac {7}{5} \text {或} t = - \frac {5}{7} (\text {舍}).
\]

\[
\therefore \sin \alpha + \cos \alpha = \frac {7}{5}, \text {两边平方得} 2 \sin \alpha \cos \alpha = \frac {2 4}{2 5},
\]

\[
\therefore \sin 2 \alpha = \frac {2 4}{2 5}, \text {又} \because 2 \alpha \in \left(\frac {\pi}{2}, \pi\right), \therefore \cos 2 \alpha = - \frac {7}{2 5},
\]

\[
\therefore \tan 2 \alpha = - \frac {2 4}{7}, \text {故选B.}
\]

\[
2 0. \text {选D} \quad \because \frac {\sin \alpha - 2 \cos \alpha}{\sin \alpha + \cos \alpha} = 2, \therefore \frac {\tan \alpha - 2}{\tan \alpha + 1} = 2,
\]

\[
\begin{array}{l} \therefore \tan \alpha = - 4. \\ \therefore \sin \alpha = - 4 \cos \alpha, \\ \therefore \cos^ {2} \alpha = \frac {1}{1 7}, \\ \end{array}
\]

\[
\therefore \sin 2 \alpha = 2 \sin \alpha \cos \alpha = - 8 \cos^ {2} \alpha = - \frac {8}{1 7}, \text {故选D.}
\]

\[
2 1. \text {选D} \because \frac {1 + \cos 2 \alpha}{\sin 2 \alpha} = \frac {2 \cos^ {2} \alpha}{2 \sin \alpha \cos \alpha} = \frac {\cos \alpha}{\sin \alpha} = \frac {1}{2},
\]

\[
\therefore \tan \alpha = 2.
\]

\[
\therefore \tan 2 \alpha = \frac {2 \tan \alpha}{1 - \tan^ {2} \alpha} = - \frac {4}{3}, \text {故选D.}
\]

\[
2 2. \text {选D} \frac {1 + \cos \alpha}{\sin \alpha} = \frac {\sin \alpha}{1 - \cos \alpha} = 5. \text {故选D}.
\]

\[
\text {23. 选 A} \frac {\tan 2 0 ^ {\circ} + \tan 4 0 ^ {\circ} + \tan 1 2 0 ^ {\circ}}{\tan 2 0 ^ {\circ} \tan 4 0 ^ {\circ}}
\]

\[
\begin{array}{l} = \frac {\tan 6 0 ^ {\circ} (1 - \tan 2 0 ^ {\circ} \tan 4 0 ^ {\circ}) + \tan 1 2 0 ^ {\circ}}{\tan 2 0 ^ {\circ} \tan 4 0 ^ {\circ}} \\ = - \sqrt {3}, \text {故选} \mathrm{A}. \\ \end{array}
\]

\[
2 4. \text {解析: 解法一}: \because \sin \left(\frac {\alpha}{2} - \frac {\pi}{4}\right) \cos \left(\frac {\alpha}{2} + \frac {\pi}{4}\right) = - \frac {3}{4},
\]

\[
\therefore \left(\frac {\sqrt {2}}{2} \sin \frac {\alpha}{2} - \frac {\sqrt {2}}{2} \cos \frac {\alpha}{2}\right) \left(\frac {\sqrt {2}}{2} \cos \frac {\alpha}{2} - \frac {\sqrt {2}}{2} \sin \frac {\alpha}{2}\right) =
\]

\[
- \frac {3}{4}, \mathrm{化简得}, \left(\cos \frac {\alpha}{2} - \sin \frac {\alpha}{2}\right) ^ {2} = \frac {3}{2},
\]

\[
\therefore 1 - 2 \sin \frac {\alpha}{2} \cos \frac {\alpha}{2} = \frac {3}{2}, \therefore 1 - \sin \alpha = \frac {3}{2},
\]

\[
\therefore \sin \alpha = - \frac {1}{2}.
\]

\[
\begin{array}{l} \text {解法二}: \because \sin \left(\frac {\alpha}{2} - \frac {\pi}{4}\right) \cos \left(\frac {\alpha}{2} + \frac {\pi}{4}\right) = - \frac {3}{4}, \\ \therefore \sin \left(\frac {\alpha}{2} - \frac {\pi}{4}\right) \cos \left(\frac {\pi}{2} + \frac {\alpha}{2} - \frac {\pi}{4}\right) = - \frac {3}{4}, \\ \therefore - \sin \left(\frac {\alpha}{2} - \frac {\pi}{4}\right) \sin \left(\frac {\alpha}{2} - \frac {\pi}{4}\right) = - \frac {3}{4}, \\ \therefore \sin^ {2} \left(\frac {\alpha}{2} - \frac {\pi}{4}\right) = \frac {3}{4}, \\ \therefore \frac {1 - \cos \left(\alpha - \frac {\pi}{2}\right)}{2} = \frac {3}{4} \\ \therefore \frac {1 - \sin \alpha}{2} = \frac {3}{4}, \therefore \sin \alpha = - \frac {1}{2}. \\ \end{array}
\]

答案： \( -\frac{1}{2} \)

大题冲关——提升能力

高考大题

25. 解: (1) 由正弦定理及已知  \( 3c \sin B = 4a \sin C \) , 得 3bc = 4ac,  \( \therefore 3b = 4a \) ,

\[
\text {又} b + c = 2 a, \therefore b = \frac {4}{3} a, c = \frac {2}{3} a.
\]

\[
\therefore \cos B = \frac {a ^ {2} + c ^ {2} - b ^ {2}}{2 a c} = \frac {a ^ {2} + \frac {4}{9} a ^ {2} - \frac {1 6}{9} a ^ {2}}{2 \cdot a \cdot \frac {2}{3} a} = - \frac {1}{4}.
\]

\[
(2) \text {由(1)知,} \cos B = - \frac {1}{4}, B \in (0, \pi), \therefore \sin B = \frac {\sqrt {1 5}}{4},
\]

\[
\therefore \sin 2 B = - \frac {\sqrt {1 5}}{8}, \cos 2 B = - \frac {7}{8},
\]

\[
\therefore \sin \left(2 B + \frac {\pi}{6}\right) = \sin 2 B \cos \frac {\pi}{6} + \cos 2 B \sin \frac {\pi}{6} = - \frac {3 \sqrt {5} + 7}{1 6}.
\]

大题精练

\[
2 6. \text {解}: (1) \because f (x) = \cos 2 x + \frac {\sqrt {3}}{2} \sin 2 x - \frac {1}{2} \cos 2 x
\]

\[
= \frac {\sqrt {3}}{2} \sin 2 x + \frac {1}{2} \cos 2 x = \sin \left(2 x + \frac {\pi}{6}\right),
\]

\[
\therefore \text {函数} f (x) \text {的最小正周期} T = \pi .
\]

\[
f (\alpha) = \frac {1}{3}, \text {可得} \sin \left(2 \alpha + \frac {\pi}{6}\right) = \frac {1}{3}. \tag {2}
\]

\[
\because \alpha \in \left(0, \frac {\pi}{2}\right), \therefore 2 \alpha + \frac {\pi}{6} \in \left(\frac {\pi}{6}, \frac {7 \pi}{6}\right),
\]

\[
\text {又} 0 <   \sin \left(2 \alpha + \frac {\pi}{6}\right) = \frac {1}{3} <   \frac {1}{2}, \therefore 2 \alpha + \frac {\pi}{6} \in \left(\frac {\pi}{2}, \pi\right),
\]

\[
\therefore \cos \left(2 \alpha + \frac {\pi}{6}\right) = - \frac {2 \sqrt {2}}{3},
\]

\[
\therefore \cos 2 \alpha = \cos \left[ \left(2 \alpha + \frac {\pi}{6}\right) - \frac {\pi}{6} \right]
\]

\[
= \cos \left(2 \alpha + \frac {\pi}{6}\right) \cos \frac {\pi}{6} + \sin \left(2 \alpha + \frac {\pi}{6}\right) \sin \frac {\pi}{6} = \frac {1 - 2 \sqrt {6}}{6}.
\]

\[
\begin{array}{l} 2 7. \text {解}: (1) \text {因为} \alpha \in \left(\frac {\pi}{2}, \pi\right), \cos \alpha = - \frac {3}{5}, \text {所以} \sin \alpha = \sqrt {1 - \cos^ {2} \alpha} = \\ \sqrt {1 - \left(- \frac {3}{5}\right) ^ {2}} = \frac {4}{5}. \text {所以} \tan \alpha = \frac {\sin \alpha}{\cos \alpha} = - \frac {4}{3}. \\ \end{array}
\]

\[
(2) \text {由(1)知,} \sin \alpha = \frac {4}{5}, \cos \alpha = - \frac {3}{5},
\]

\[
\text {所以} \sin 2 \alpha = 2 \sin \alpha \cos \alpha = 2 \times \frac {4}{5} \times \left(- \frac {3}{5}\right) = - \frac {2 4}{2 5},
\]

\[
\cos 2 \alpha = 2 \cos^ {2} \alpha - 1 = 2 \times \left(- \frac {3}{5}\right) ^ {2} - 1 = - \frac {7}{2 5}.
\]

\[
\mathrm{所以} \frac {\cos 2 \alpha}{\sin 2 \alpha + 1} = \frac {- \frac {7}{2 5}}{- \frac {2 4}{2 5} + 1} = - 7.
\]

\[
\text {28. 解: 因为} \tan \alpha = 2 > 0, \alpha \in (0, \pi), \text {所以} \alpha \in \left(0, \frac {\pi}{2}\right).
\]

\[
\text {因为} \cos \beta = - \frac {7 \sqrt {2}}{1 0}, \beta \in (0, \pi),
\]

\[
\text {所以} \beta \in \left(\frac {\pi}{2}, \pi\right), \text {且} \tan \beta = - \frac {1}{7}.
\]

\[
\text {所以} \alpha - \beta \in (- \pi , 0), \tan (\alpha - \beta) = \frac {\tan \alpha - \tan \beta}{1 + \tan \alpha \tan \beta} = 3 > 0,
\]

\[
\text {所以} \alpha - \beta \in \left(- \pi , - \frac {\pi}{2}\right), \text {所以} 2 \alpha - \beta \in (- \pi , 0).
\]

\[
\begin{array}{l} \text {因为} \tan (2 \alpha - \beta) = \tan [ \alpha + (\alpha - \beta) ] = \frac {\tan \alpha + \tan (\alpha - \beta)}{1 - \tan \alpha \tan (\alpha - \beta)} = - 1, \\ \text {所以} 2 \alpha - \beta = - \frac {\pi}{4}. \\ \end{array}
\]

考点测试 19 三角函数的性质

小题集训——夯实基础

基础巩固

\[
1. \text {选A} \quad \because y = \tan x \text {在} \left(- \frac {\pi}{2}, \frac {\pi}{2}\right) \text {上单调递增,} - \frac {\pi}{5} > - \frac {3 \pi}{7},
\]

\[
\therefore \tan \left(- \frac {\pi}{5}\right) > \tan \left(- \frac {3 \pi}{7}\right), \mathrm{故选A.}
\]

\[
\begin{array}{r l} & 2. \text {选B当} f (x) \text {是奇函数时,} \varphi = \frac {\pi}{2} + k \pi (k \in \mathbf {Z}), \text {充分性不成立；当} \varphi \\ & = \frac {\pi}{2} \text {时,} f (x) = A \cos \left(\omega x + \frac {\pi}{2}\right) = - A \sin \omega x, \text {为奇函数，必要性成立，故选B.} \end{array}
\]

\[
\begin{array}{l} 3. \text {选B} \text {由} - \frac {\pi}{2} + k \pi <   2 x - \frac {\pi}{3} <   \frac {\pi}{2} + k \pi (k \in \mathbf {Z}), \text {得} - \frac {\pi}{1 2} + \frac {k \pi}{2} <   x <  \\ \frac {5}{1 2} \pi + \frac {k \pi}{2} (k \in \mathbf {Z}), \therefore f (x) \text {的单调递增区间为} \\ \left(- \frac {\pi}{1 2} + \frac {k \pi}{2}, \frac {5}{1 2} \pi + \frac {k \pi}{2}\right) (k \in \mathbf {Z}). \end{array}
\]

\[
\begin{array}{l} 4. \text {选C} \quad \because y = 2 \sin^ {2} x + \sin 2 x = 1 - \cos 2 x + \sin 2 x = \sqrt {2} \sin \left(2 x - \frac {\pi}{4}\right) + \\ 1, \therefore T = \frac {2 \pi}{\omega} = \pi , \therefore \text {函数} y = 2 \sin^ {2} x + \sin 2 x \text {的最小正周期是} \pi , \text {故选C}. \end{array}
\]

\[
5. \text {选B} \quad \because f (x) = 8 \sin \left(\omega x - \frac {\pi}{3}\right) (\omega > 0) \text {的最小正周期为} \pi ,
\]

\[
\therefore \omega = 2,
\]

\[
\therefore f (x) = 8 \sin \left(2 x - \frac {\pi}{3}\right)
\]

\[
\because - \frac {\pi}{2 4} \leqslant x \leqslant \frac {2 \pi}{3},
\]

\[
\therefore - \frac {5 \pi}{1 2} \leqslant 2 x - \frac {\pi}{3} \leqslant \pi ,
\]

\[
\because \text {当} - \frac {5 \pi}{1 2} \leqslant 2 x - \frac {\pi}{3} \leqslant \frac {\pi}{2} \text {时，} f (x) \text {单调递增，}
\]

\[
\text {当} \frac {\pi}{2} \leqslant 2 x - \frac {\pi}{3} \leqslant \pi \text {时，} f (x) \text {单调递减，}
\]

\[
\therefore \left\{ \begin{array}{l} \frac {2 m}{3} - \frac {\pi}{3} \leqslant \frac {\pi}{2}, \\ m - \frac {\pi}{3} \geqslant \frac {\pi}{2}, \end{array} \right. \therefore \frac {5 \pi}{6} \leqslant m \leqslant \frac {5 \pi}{4}, \text {故选B.}
\]

\[
6. \text {选} \mathrm{D} \quad \because f (x) = \sin (x + \varphi) \text {在} \left(\frac {\pi}{3}, \frac {2 \pi}{3}\right) \text {上单调递增，}
\]

\[
\therefore \left\{ \begin{array}{l l} \frac {\pi}{3} + \varphi \geqslant - \frac {\pi}{2} + 2 k \pi , \\ \frac {2 \pi}{3} + \varphi \leqslant \frac {\pi}{2} + 2 k \pi , \end{array} \right. \text {解得} 2 k \pi - \frac {5 \pi}{6} \leqslant \varphi \leqslant 2 k \pi - \frac {\pi}{6},
\]

\[
\text {当} k = 1 \text {时,} \frac {7 \pi}{6} \leqslant \varphi \leqslant \frac {1 1 \pi}{6}, \therefore \varphi \text {的值可能是} \frac {3 \pi}{2}, \text {故选D.}
\]

\[
7. \text {选D} \quad \because y = \sin 2 x \text {在} \left(\frac {\pi}{2}, \pi\right) \text {上不单调,排除A;}
\]

\[
y = 2 | \cos x | \text {在} \left(\frac {\pi}{2}, \pi\right) \text {上单调递增，排除B；}
\]

\[
y = \cos {\frac {x}{2}} \mathrm{的最小正周期为} 4 \pi , \mathrm{排除C};
\]

\[
y = \tan (- x) \text {的最小正周期为} \pi , \text {且在区间} \left(\frac {\pi}{2}, \pi\right) \text {上为减函数,故选D.}
\]

\[
8. \text {选A} \quad \because 0 \leqslant x \leqslant 9, \therefore - \frac {\pi}{3} \leqslant \frac {\pi}{6} x - \frac {\pi}{3} \leqslant \frac {7}{6} \pi ,
\]

\[
\therefore - \frac {\sqrt {3}}{2} \leqslant \sin \left(\frac {\pi}{6} x - \frac {\pi}{3}\right) \leqslant 1,
\]

\[
\therefore - \sqrt {3} \leqslant 2 \sin \left(\frac {\pi}{6} x - \frac {\pi}{3}\right) \leqslant 2,
\]

\[
\therefore \text {函数} y = 2 \sin \left(\frac {\pi}{6} x - \frac {\pi}{3}\right) \text {的最大值为} 2, \text {最小值为} - \sqrt {3},
\]

\[
\therefore \text {和为} 2 - \sqrt {3}. \text {故选A.}
\]

\[
\begin{array}{l} 9. \text {选D} \quad \because f (x) = \cos \left(x + \frac {\pi}{4}\right) \sin x = \frac {1}{2} \sin \left(2 x + \frac {\pi}{4}\right) - \frac {\sqrt {2}}{4}. \\ \frac {2 \pi}{2} = \pi , \mathrm{A} \text {错}; \end{array}
\]

— 173 —

高考总复习金考卷

数学(文科)

— 174 —