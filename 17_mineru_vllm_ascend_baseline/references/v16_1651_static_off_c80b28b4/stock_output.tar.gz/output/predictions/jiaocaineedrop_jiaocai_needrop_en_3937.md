一 数据收集整理

You are a AI assistant specialized in OCR. You are provided with the original document image. Please follow these instructions for the conversion:
# 1. General Text & Math Processing
-   **Structure:** Maintain original headings, paragraphs, and list structures.
-   **De-hyphenation:** If a word is split by a hyphen at a line break in the image (e.g., `con-` \n `nection`), merge it into a single word (`connection`) in your output.
-   **Math Formulas:**
    -   Use LaTeX for all inline math content: `\( E=mc^2 \)`
-   **Tables:** **STRICTLY PROHIBITED.** Do NOT use Markdown tables. TreatAll rights reserved.
-   **Figures:** Ignore non-text figures/diagrams.
ENDY

二、下面 统计的是二年级同学参加兴趣小组的情况。(20分)

1. 完成下表。(10分)

<table><tr><td>兴趣小组</td><td>书法小组</td><td>绘画小组</td><td>饲养小组</td><td>田径小组</td><td>游泳小组</td></tr><tr><td>人数</td><td></td><td></td><td></td><td></td><td></td></tr></table>

2. 回答问题。(10 分)

(1)喜欢( )的人数最多,
喜欢( )的人数最少。

(2)喜欢书法的人数比喜欢游泳的人数少( )人。

(3)这个班一共有( )人。

(4)喜欢绘画的人数和喜欢田径的人数一共是( )人。

三、下面是同学们收集的几种邮票统计情况。(20分)

Grid of Santa Claus face stamps featuring various denominations and text, arranged in a 24x2 grid.

1. 用你喜欢的方法统计每种邮票的张数,并完成下表。(8分)

2. 回答问题。(12 分)

(1)哪种邮票收集得最多？(4分)

(2)一共收集了多少张邮票？(4分)

(3) 比多收集多少张？(4分)

四、生活中的数学。(48分)

1. 喜欢吃苹果的小朋友有9人,喜欢吃香蕉的小朋友有18人,喜欢吃梨的小朋友比喜欢吃苹果的多6人。(24分)

(导学号 24082007)

(1)完成统计表。(6分)

(2)喜欢吃香蕉的比喜欢吃苹果的多几人？(6分)

(3)喜欢吃苹果、香蕉、梨的一共有多少人？(6分)

(4)请你再提出一个数学问题并解答。(6分)

2. 下表是二(1)班和二(2)班去年植树情况的统计表,可是不小心弄脏了一部分,你还能回答给出的问题吗?

(24分)

(导学号 24082008)

谚语◎ 良药苦口利于病,忠言逆耳利于行。

11

关注微信公众号“捷思课堂”获取更多学习资料！