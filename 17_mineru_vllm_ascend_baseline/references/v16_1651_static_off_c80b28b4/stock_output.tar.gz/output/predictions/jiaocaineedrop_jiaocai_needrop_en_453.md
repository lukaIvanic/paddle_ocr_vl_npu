www.Jinghua.com “在线名师” → 资料室 免费资料任你下载

精华学校
www.Jinghua.com

25. ---- ____ won the first place in the "Super Girl" singing competition?

---- Lucy did.

A. Who

B. When

C. Where

D. Why

26. Shops in big cities are ____ than those in the country.

A. expensive

B. more expensive

C. most expensive

D. the most expensive

27. You ____ play football in the street. It's too dangerous.

A. wouldn't

B. needn't

C. mustn't

D. couldn't

28. It's snowing now. You'd better ____ your car slowly on a snowy day.

A. drive

B. drove

C. driving

D. to drive

29. My little brother asks me ____ him a story every day.

A. tell

B. told

C. telling

D. to tell

30. Today, more and more people enjoy ____ things online.

A. buy

B. bought

C. buying

D. to buy

31. Don't turn on the radio. Grandpa ____ now.

A. sleeps

B. is sleeping

C. has slept

D. slept

32. ---- Have you ever seen the cartoon Tom and Jerry?

---- Yes. I ____ it many times.

A. see

B. saw

C. will see

D. have seen

33. ---- The pizza ____ by my mum just now. would you like to have some?

---- Yes, please.

A. was made.

B. made

C. is made

D. makes

34. ---- Could you please tell us ____ the Would Expo in Shanghai?

---- In July.

A. when you will visit

B. why you will visit

C. when will you visit

D. why will you visit

35. ---- ____?

---- Yes, please. I want to buy some CDs for my son.

A. How do you do

B. What's wrong with you

C. Can I help you

D. Is that Mary speaking

五、完形填空。（共12分，每小题1分）

I watched as my little brother was caught in the act. He was sitting in the corner of the living room, a____36____in one hand and my father's hymnbook（赞美诗集）in the other.

As my father walked into the room, my brother cowered slightly (轻微地畏缩). He sensed that he had done something _37_. I could see that he had _38_ my father's new hymnal and scribbled (乱涂) in it. Now he was waiting for his punishment.

For my father, books were knowledge. They were important to him. And yet he loved his children. What he did next was _39_. Instead of punishing my brother, he sat down, took the pen from my brother's hand, and then wrote in the book himself, alongside the scribbles John had made: "40 work, 1959, age 2." How many times have I looked into your beautiful face and into your warm eyes looking up at

~ 第 3 页 ~

在线学习网址：www.Jinghua.com

客服热线：400-650-7766（9：00—21：00 everyday）

版权所有 北京天地精华教育科技有限公司