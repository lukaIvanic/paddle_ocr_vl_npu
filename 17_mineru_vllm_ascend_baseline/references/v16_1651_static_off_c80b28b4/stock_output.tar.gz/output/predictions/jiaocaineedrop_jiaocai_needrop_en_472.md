爱护身体

探究与分享

小伟喜欢踢足球，也喜欢看足球比赛。世界杯足球赛期间，他常常半夜悄悄起来看比赛，然后在网上跟球友一起聊天，早上再急急忙忙赶到学校。一天，在体育课跑步时，小伟突然栽倒在地，经医院抢救才转危为安。

针对小伟的情况，一些同学发表了自己的看法。

Illustration of three people in a room with TV watching; no visible text or symbols.

```mermaid
graph LR
  A["I know someone's behavior for health not to be normal; can't make it wrong.&quot;"] --> B["Healthy condition is important, but small negative impact on body health?"]
  C["Mother says, living's细节会影响健康,我觉得这话很有道理.&quot;"] --> D["Living with a family?"]
```

结合自己的经验，说说你的看法和建议。

守护生命首先要关注自己的身体。关心身体的状况，养成健康的生活方式，是一种对生命负责任的态度。

100

第四单元 生命的思考