被子植物与我们的生活息息相关，我们日常生活中的衣、食、住、行，往往都离不开它们。例如，制造汽车和自行车轮胎的原料就来自橡胶树。许多中药材也来自被子植物，如人参、枸杞、杜仲、黄连、甘草等。关于被子植物与我们日常生活的关系，你还能举出哪些更为重要的例子呢？

技能训练

比较

Close-up of a green leaf with visible veins, enclosed in a circular frame (no text or symbols)

白网纹草
(双子叶植物)

叶片上粗细不等的脉络叫叶脉。请仔细观察左右两图中的植物，比较它们的叶脉，说说这两者之间有什么区别。

Close-up of a green leaf with red flowers and black specks, labeled '银线鸟巢园梨' at the bottom (no other text or symbols)

银线鸟巢凤梨（单子叶植物）

练习

1. 判断下列说法是否正确。正确的画“√”，错误的画“×”。

(1) 松的球果不是果实。 ( )

(2) 裸子植物和被子植物的种子中都有胚。 ( )

(3) 裸子植物的种子比被子植物的种子能得到更好的保护。 ( )

2. 将种子的结构与其相应的功能用线连接起来。

<table><tr><td>种皮</td><td>储藏养料</td></tr><tr><td>胚</td><td>保护胚</td></tr><tr><td>胚乳</td><td>能发育成新植株</td></tr></table>

3. 被子植物具有哪些特点，使它们成为地球上分布最广泛的植物类群？

86

第三单元 生物圈中的绿色植物