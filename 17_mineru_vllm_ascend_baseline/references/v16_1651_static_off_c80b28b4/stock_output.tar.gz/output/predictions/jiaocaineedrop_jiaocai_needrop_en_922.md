学校____ 班级____ 姓名____

密……封……装……订……线

夺冠新课堂·五年级英语(下)·KP

Lessons 1~2 测试卷

时间:90 分钟

满分:100 分

<table><tr><td>题号</td><td>I</td><td>II</td><td>III</td><td>IV</td><td>V</td><td>VI</td><td>VII</td><td>VIII</td><td>IX</td><td>X</td><td>总分</td><td>等级</td></tr><tr><td>得分</td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td></tr></table>

听力部分(30 分)

I. 听录音, 选出你所听到的单词。(10 分)

( )1. A. must

B. much

C. may

( )2. A. put

B. eat

C. sit

( )3. A. seat

B. street

C. skate

( )4. A. line

B. learn

C. light

( )5.A.too

B. into

C. in

Ⅱ. 听录音, 按你所听内容, 用数字“1~5”给下列图片排序。(10 分)

P

( )

Cartoon illustration of a smiling child eating at a table with a plate and slice (no text or symbols)

( )

Illustration of two children interacting with a table, no text or symbols present

( )

Symbol showing a crossed-out parking sign with a circular emblem containing the letter 'a'

( )

Illustration of two children walking side by side, one with curly hair and the other in casual clothing (no text or symbols)

( )

Ⅲ. 听录音,选择正确的答语。(10 分)

( )1. A. Good afternoon, Mrs Read.

B. Sorry, she's not in.

( )2. A. I'm having lunch.

B. I'm in the park.

( )3. A. Hello, John!

B. Yes. Here it is.

( )4. A. Yes, we can.

B. You're welcome.

( )5. A. You can sit here.

B. At the sports centre.

47

关注微信公众号“教辅资料站”获取更多学习资料