纸杯龙：由多个纸
杯制作而成。纸杯上打
孔，用丝线绳系住。

想一想
如何用简单的材料和插接方
法制作一条工艺龙呢？

龙的制作主要分为身体和头两部分。首先明确工艺龙的结构特点是由多个圆柱体连接而成。根据这一特点，我们可选取纸杯、胡萝卜段、秸秆段、纸筒等材料，巧妙连接成长而弯曲的龙体，表现龙腾飞的动感。龙头部比较复杂，要根据造型特点和材料特点研究做法，表现龙的威猛。做好后还要加龙尾、鳍、角爪等，并加以装饰，使龙显得神采奕奕。

练一练

尝试用自己喜欢的材料进行插接练习。

Illustration of a stylized orange paper craft with floral patterns and a small figure, no text or symbols present.

纸杯龙：由多个纸杯制作而成。在纸杯口和纸杯底上剪切口，然后根据龙的动态进行插合。龙头由两个纸杯制作，龙须就是杯口的边，眼睛是两个杯底。

Group of children and adults gathered around a table with colorful handmade dragon puppets, indoors (no visible text or symbols)

小提示

纸杯插接的剪切口要与杯口的弧形相同。

12