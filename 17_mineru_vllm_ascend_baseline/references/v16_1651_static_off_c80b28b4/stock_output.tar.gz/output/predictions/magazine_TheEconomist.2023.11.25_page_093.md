ADVERTISEMENT

ECONOMIST IMPACT

Resilient Cities Index

A global benchmark of urban risk, response and recovery

Top five

Cities across America, Europe and Asia have successfully built infrastructural, environmental, social and economic resilience.

01.

Scan to reveal the most resilient city

02.

Colorful stylized city skyline illustration with no text or symbols

Los Angeles

03.

Surreal illustration of a cityscape with a prominent arch, bridge, and skyscrapers at sunset (no text or symbols)

London

04.

Illustration of a modern cityscape with a large lake, greenery, and skyscrapers in the background (no text or symbols visible)

Singapore

05.

Illustration of the Eiffel Tower and its iconic stone archway with a figure in motion (no text or symbols)

Paris

Resilient cities continue to adapt and grow amid uncertainty and change. They identify risks and create systems that enable businesses and residents to recover and thrive after unexpected events. The Resilient Cities Index 2023, devised by Economist Impact, examines the preparedness of 25 cities in four vital areas—critical infrastructure, environment, socio-institutional and economic.

The research highlights the following strategies to build resilience:

- Incentivise businesses and residents to guard against future risks by using financial rewards for hitting targets.

- Plan a cohesive response to shocks by integrating vulnerable groups and offering comprehensive social safety-nets.

- Drive innovative, scalable and cost-effective solutions through a dynamic business ecosystem.

- Promote community stewardship through education and collaboration.

"A resilience strategy is not something developed at a desk by a city official. Cities need to bring a variety of stakeholders together, including community representation, the poor and the vulnerable."

Katrin Bruebach

Global director of programmes and delivery

Resilient Cities Network

What is stopping cities from building holistic resilience?
Read the report to find out more about the risks, rankings and best practices at https://impact.economist.com/projects/resilient-cities/

Sponsored by

TOKIO MARINE

GROUP