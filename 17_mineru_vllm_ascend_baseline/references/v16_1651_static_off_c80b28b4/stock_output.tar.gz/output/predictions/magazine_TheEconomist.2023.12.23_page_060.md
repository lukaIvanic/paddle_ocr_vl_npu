30

Holiday essay

The Economist December 23rd 2023

▶ Explosive harpoons, made possible by the fossil-fuel-driven growth in explosives, made whale hunting easier and also, worst of ironies, more important for nations going to war, as whales were an excellent source of the glycerine used in nitroglycerine.

These new hunting technologies made the great whales a source of fat cheap enough to be used as pet food, a treatment for trench foot and, overwhelmingly, spread on bread. By 1935 roughly 84% of the world's whale oil was being turned into margarine, at a price per barrel of £15 or so. With up to 120 barrels of oil in a typical blue whale's blubber, the largest animal to have ever lived had a market value of about £1,800 (\$130,000 or so in 2023).

Whales are, in principle, a renewable resource. But the rate at which they renew themselves is fairly slow. Blue whales have calves every two or three years. It takes those calves a couple of decades to get to their full size. This meant that as sales increased, stocks diminished, a change which first became a matter of official concern in their breached citadel: the Antarctic waters administered from Britain's South Atlantic colonies.

In 1911, Sir William Allardyce, governor of the Falkland Islands Dependencies, began to worry that the rapid expansion of this Southern Ocean whaling risked becoming unsustainable. The whales were, to all extents and purposes, free to whoever could catch them; the government required only that the whalers pay for a whaling license—£25—and a royalty on each whale caught—£10 for a right whale (so called because they were the right whales to go after), ten shillings for a sperm whale and five shillings for any other whale. Such fees were less than 1% of the whalers' profits.

Had Allardyce been a modern economist he would have raised the prices. Instead he limited the number of licenses he was willing to issue. He also communicated his concerns to London. As a result the British Colonial Office developed an interest in cetology. The levies on whale hunting were used to fund Antarctic research voyages on board the refitted RRS Discovery, once the ship of polar explorer Robert Falcon Scott. Her complement of scientists

took note of the abundance of nutrients in the waters around the islands, their currents and temperatures, the types of phytoplankton (which photosynthesise, like plants) and zooplankton (which eat the phytoplankton) which they were home to, the volume of krill (crustaceans that eat plankton of all sorts) and the populations of whales (most of which eat the krill). To track the whales' movements they fired on them with harpoons which left stainless steel darts buried under their blubber; whalers were paid £1 for every dart they recovered.

The Discovery expeditions showed an appreciation that measuring the true wealth of nations requires ecologists as well as economists: a well-run country needs to know about the natural assets on which its prosperity ultimately depends. They did not call it “natural-capital accounting”, but armed with the expeditions’ data the Colonial Office saw the need to protect the future of the country’s assets. It pressed for restrictions on catches, including limits on the hunting season, and prohibitions on the hunting of juveniles.

Attempts at spreading such regulations internationally, however, were thwarted by politics, economics and technology. When, in 1927, the recently formed League of Nations proposed an international conference on whaling, various countries objected that such issues should properly be bilateral, not global. There were economic objections, too: when it decided not to hold the conference, the league said it was because the market had no need of such regulation: "If hunting becomes unprofitable it will stop by

itself, long before whales are exterminated."

Technology, meanwhile, was helping the industry escape almost all regulation. In Allardyce's day whales killed at sea still had to be processed on land, or at least at a near-shore "floating factory", allowing some oversight. The advent of the factory ship allowed whalers to do all that they needed to do on the high seas, and thereby pay nothing for their catches. Overexploitation continued: whale numbers fell further. Writing in 1933, Harold Salvesen, scion of a whaling family but also, in the 1920s, an economist at the University of Oxford, explained why the simple nostrums that had apparently satisfied the League of Nations did not work. "The reason is quite simple", he wrote. "Whaling companies never have property in the whales they hunt; if one company spares them not the whales but another company will profit from it."

IT WAS THE needs of the whalers, not the whales, which drove change. The Great Depression saw the world with more whale oil than consumers wanted. Unilever, a British consumer-goods company and the world's largest buyer of the stuff, said that it would buy up the excess stock—but only if the Norwegian fleet sat out the 1931-1932 hunting season. The following year the British and Norwegian industries decided to self-regulate, setting quotas for catches so that prices would rise. The companies' quotas were measured in "blue-whale units", each equivalent to a single blue whale, two fin whales, five humpback whales or 12 sei whales. Salvesen, the whaler-economist, bought his rivals' quotas, paying them to keep their ships at home while maximising the capital efficiency of his own.

Prices went up. So did profits. But there was an unforeseen consequence. Giving all blue whales the same value encouraged whalers to seek out the largest of them, which meant the cows, especially pregnant ones storing up blubber for later conversion to milk. In 1932-33 the whalers working under the quota system took 422

BIG-EYED,
WARM-BLOODED AND
VICIOUSLY
SLAUGHTERED, THEY
SERVED WELL AS
STAND-INS FOR PEACE
AND THE ENVIRONMENT

cows for every 100 bulls. They were profiting today at the expense of the future in a peculiarly literal way.

The end of the second world war saw a new internationalism take hold. The International Whaling Commission (IWC) was founded “to provide for the proper conservation of whale stocks and thus make possible the orderly development of the whaling industry”. Its early decades were an abject failure. Alongside the long-standing whaling giants of Norway and Britain, other nations were joining the hunt. General Douglas MacArthur, who administered the American occupation of Japan, encouraged the defeated and semi-starving country to use its decommissioned navy ships to hunt whales in the Southern Ocean.

The Soviet Union, too, became a major whaling nation, with the help of American whaling ships provided through the wartime lend-lease programme and a German factory ship seized as reparations. Joseph Stalin, the Soviet leader, encouraged IWC delegates to conserve whales from “predatory and irrational exploitation”. The logic of scientific socialism would, the USSR thought, do better than free markets at preserving natural resources. It didn’t.

The IWC was not completely supine. From 1955 on it imposed limits on the catch of the largest whales, the blues. But overall it continued to grow. In 1964, roughly the industry's peak, an estimated 82,000 whales were slaughtered. Blues and rights being protected and scarce, sperm whales bore the brunt of the hunt.

In that decade, though, whales, and in particular endangered ones, started to take on a new symbolic and cultural value. Big-