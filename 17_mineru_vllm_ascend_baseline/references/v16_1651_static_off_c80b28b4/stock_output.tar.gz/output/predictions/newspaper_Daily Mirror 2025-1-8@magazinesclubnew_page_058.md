58

DAILY MIRROR

WEDNESDAY 08.01.2025

DMLI

ARSENAL O NEWCASTLE UNITED 2

Isak 37, Gordon 51

ON HOWAY TO

RATINGS by JOHN CROSS

mirror.co.uk/sport/football

ARSENAL

<table><tr><td>Raya</td><td>5</td></tr><tr><td>Lewis-Skelly</td><td>7</td></tr><tr><td>Gabriel</td><td>6</td></tr><tr><td>Saliba</td><td>6</td></tr><tr><td>Timber</td><td>5</td></tr><tr><td>Partey</td><td>5</td></tr><tr><td>Rice</td><td>6</td></tr><tr><td>Trossard</td><td>5</td></tr><tr><td>Odegaard</td><td>6</td></tr><tr><td>Martinelli</td><td>5</td></tr><tr><td>Havertz</td><td>5</td></tr></table>

SUBS

<table><tr><td>Jorginho (Partey 59)</td><td>6</td></tr><tr><td>Gabriel Jesus (Trossard 59)</td><td>5</td></tr><tr><td>Zinchenko (Lewis-Skelly 78)</td><td></td></tr></table>

Illustration of two hands holding up a blank rectangular object (no text or symbols)

NEWCASTLE

<table><tr><td>Dubravka</td><td>7</td></tr><tr><td>Hall</td><td>7</td></tr><tr><td>Burn</td><td>7</td></tr><tr><td>Botman</td><td>7</td></tr><tr><td>Livramento</td><td>7</td></tr><tr><td>Joelinton BOOKED</td><td>7</td></tr><tr><td>Tonali</td><td>7</td></tr><tr><td>Willock</td><td>7</td></tr><tr><td>Gordon BOOKED</td><td>7</td></tr><tr><td>Murphy</td><td>7</td></tr><tr><td>Isak</td><td>8</td></tr></table>

SUBS

<table><tr><td>Longstaff (Willock 65)</td><td>6</td></tr><tr><td>Kelly (Murphy 65)</td><td>6</td></tr><tr><td>Barnes (Isak 65)</td><td>6</td></tr><tr><td>Almiron (Gordon 76)</td><td></td></tr></table>

MAN OF THE MATCH

Soccer player in black and white striped jersey running on field (no visible text or symbols)

ALEXANDER ISAK

Scored one, had a hand in the other

NEXT THREE...

ARSENAL

<table><tr><td>Sun</td><td>Man United (home) .....FAC</td></tr><tr><td>Wed</td><td>Tottenham (home) .....PL</td></tr><tr><td>Jan 18</td><td>Aston Villa (home).....PL</td></tr><tr><td colspan="2">NEWCASTLE</td></tr><tr><td>Sun</td><td>Bromley (home) .....FAC</td></tr><tr><td>Wed</td><td>Wolves (home) .....PL</td></tr><tr><td>Jan 18</td><td>Bournemouth (home) ...PL</td></tr></table>

Group of soccer players in white and black jerseys embracing on the field (no visible text or symbols)

FROM BACK PAGE

that the different Puma match ball in the competition played a part because it is different to what they are used to in the Premier League.

The Gunners boss said: "We kicked a lot of balls over the bar, and it's tricky that these balls fly a lot so there's details that we can do better.

"It's very different to a Premier League ball, and you have to adapt to that because it flies different, when you touch it the grip is very different as well so you adapt to that.

"It's just half-time. When I see the team play, and how we deal with a lot of situations and play against a very good team I must say I have full belief that we can go out there and do it."

Isak scored his 10th goal in nine games (celebrating, above) and his strike partner Gordon claimed: "I don't think there's a better centre

BALL GONE
WRONG FOR
MIKEL & CO

forward in Europe at the moment." Newcastle boss Eddie Howe hailed his team's performance and also that of danger man Isak.

Howe said: "Alex played very well in the first half today, he looked really good physically, his pace and movements were giving them a problem. I was delighted with how he performed.

"When Alex is in that mood, as he was in the first half, he is a brilliant player for us. It goes without saying that he does the hard work and raises our overall level."

Soccer player in black and white jersey dribbling a ball during a match (no visible text or symbols)

Two soccer players in black and white jerseys celebrating together on the field, with spectators cheering in the background (no visible text or symbols)

BY JOHN CROSS

Chief Football Writer
X@johncrossmirror

THE Toon Army are already singing about Wembley.

And no wonder. Newcastle have got one foot in the Carabao Cup final on March 16 after a hugely impressive display at the Emirates.

Eddie Howe's men looked sharp, slick and dangerous while Arsenal were horribly flat with their season now in serious danger of fading away.

In truth, it was all about the

difference a top striker makes. Alexander Isak took his chance while Arsenal's forward line wasted every opening. It is now 50 goals for Isak in all competitions since he joined Newcastle for £63million in August 2022.

He is the reason why they are dreaming of their first major trophy in 56 years.

Isak even played a part in Newcastle's second goal as it was his cross shot which led to Anthony Gordon (left) firing in the rebound to give them a huge advantage for

the second leg. Arsenal need a minor miracle to turn the semi-final on its head in next month's return, but they look ragged, tired and as if they are running on empty.

Even more worryingly, they have hit the wall at just the wrong time.

They face Manchester United in the FA Cup third round on Sunday and are already six points behind Liverpool in the title race, having played a game more.

Arsenal are still in the Champions League, but they

look short of ideas, attacking threat and quality with Bukayo Saka out injured for the next two months.

The squad looks wafer-thin and they lack a proven goals-corer. As good as Kai Havertz was last season, the Arsenal striker horribly mistimed a second-half header (far right) and a chance to haul his team back into the tie.

That miss summed up Arsenal's shortcomings. They were wasteful in attack, sloppy in defence and lacking ideas in midfield. They racked