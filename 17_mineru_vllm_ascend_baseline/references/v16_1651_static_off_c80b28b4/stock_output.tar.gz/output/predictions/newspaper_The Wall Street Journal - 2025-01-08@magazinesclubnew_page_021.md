THE WALL STREET JOURNAL.

Wednesday, January 8, 2025 | B5

BUSINESS & FINANCE

Blackstone Takes
Stake in Audit Firm

BY MARK MAURER

New Mountain Capital is selling its stake in accounting firm Citrin Cooperman to an investor group led by Blackstone, the first flip of an audit firm by a private-equity investor.

The deal, which would value Citrin Cooperman at more than \$2 billion, is the latest in a series of stakes that private-equity firms are taking in midsize audit and consulting firms in the U.S. Accounting firms are hungry for more money to pay for technology and talent. Many private-equity funds consider accounting firms to be low-risk investments that could net a sizable return based in part on recurring revenue streams.

The Blackstone-led group would take a more than two-thirds ownership stake in Citrin, and Blackstone itself holds an interest in the range of 40% to 45% in the group, people familiar with the transaction said.

Citrin Cooperman, a New York-based accounting firm, in October 2021 sold a majority stake to New Mountain, which has about \$55 billion in assets under management.

Citrin Cooperman has grown significantly in the roughly four years since the

sale. The firm reported \$351.8 million in revenue in 2021. Its 2024 revenue totaled about \$900 million, in part due to acquisitions of smaller firms, people familiar said.

Blackstone, which manages about \$55 billion in assets, would be one of the largest private-equity firms to have a stake in an accounting firm. A group led by Hellman & Friedman, which managed \$120 billion in assets at the end of 2023, bought a stake in Baker Tilly in June. Blackstone participated in the debt on that deal, providing \$450 million of a \$1 billion financing package.

The sale allows New Mountain to focus on boosting revenue at Grant Thornton's U.S. unit, in which it acquired a stake last May. New Mountain aims to merge Grant Thornton's nonaudit services in the U.S. and more than 10 other international units over the next five years, primarily in Europe and Asia, a person familiar with the plans said.

Regulators say they are concerned about potential conflicts of interest from the accounting profession's growing ties to private equity, given that an auditor's objectivity is critical to the business of accounting firms.

The Financial Times first reported on the deal.

Sixth Street Strikes a Deal
To Manage Insurer's Assets

Northwestern
Mutual to take a
small minority stake
in investment firm

BY MIRIAM GOTTFRIED

Investment firm Sixth Street is forging a partnership with Northwestern Mutual to manage \$13 billion of the insurer's assets, executives from the companies said. The money will primarily be invested in asset-based finance, a hot area that encompasses a swath of consumer lending, including mortgages, credit-card loans and auto loans.

Milwaukee-based Northwestern Mutual also will take a small minority stake in Sixth Street, bolstering the investment firm's balance sheet to help it fund growth. The stake is of a similar size to the roughly \(10\%\) holding Sixth Street bought back from private-equity firm TPG last year, according to people familiar with the matter.

Wall Street's big push into insurance got under way after Apollo Global Management began managing the assets of Athene, an insurance com-

pany it helped create in the aftermath of the 2008-2009 financial crisis. Other private-equity firms such as KKR, Blackstone and Brookfield have since bought insurers or struck deals to manage their assets.

For many firms, private credit has largely been synonymous with lending to midsize companies, often to finance their buyouts by a private-eq-

uity firm. As managers increasingly take in cash from insurance companies, they are moving deeper into strategies aimed at providing better returns than corporate bonds while remaining rela-

tively low-risk. Insurers invest customers' premiums with the goal of earning more than they must pay out to policy-holders.

Unlike most of the deals done by its publicly traded rivals, Sixth Street's partnership with Northwestern Mutual will happen in phases, with money being invested as the

best opportunities arise.

"If someone gave me \$13 billion and said go invest it tomorrow, I might be able to do it, but I probably wouldn't be able to do it in the best risk-adjusted-return way," said Michael Muscolino, a Sixth Street co-founder who leads its financial-services efforts.

Based in San Francisco, Sixth Street will manage more than \$100 billion in assets af-

Amount of

Northwestern

Mutual's assets involved in the deal

ter the North-
western Mutual
commitment.
The firm was
founded in
2009 by 10
partners, many
of whom had
previously
worked to-
gether under
Chief Executive
Alan Waxman

at Goldman

Sachs. The partners were initially backed by TPG but separated from it in 2020.

Sixth Street built a team of 40 people focused on asset-based finance, hiring Michael Dryden from Credit Suisse in 2022 to lead its expansion. The firm had historically invested in asset-based finance in a more opportunistic way,

snapping up a portfolio of mortgages in the aftermath of the financial crisis, for example. Now it is investing more consistently as banks have scaled back in response to regulatory pressure.

Dryden's group last month announced a deal to buy as much as \$4 billion of loans from buy-now-pay-later platform Affirm.

Sixth Street has a separate team of 25 people solely focused on insurance. It owns and advises on the investments for Talcott Financial Group, an annuities company with \$127 billion in assets.

Northwestern Mutual is owned by its policyholders. The company, which was founded more than 165 years ago, provides life, disability-income and long-term-care insurance, annuities, and brokerage and wealth advisory. It manages the bulk of its \$627 billion in assets internally and has invested in private markets for decades.

But Northwestern Mutual didn't have the capability of finding and structuring asset-based finance deals, a labor-intensive process, according to Jeb Bentley, its chief investment officer.

CFTC Chairman to Step Down When Trump Takes Office

BY MENGQI SUN

Commodity Futures Trading Commission Chairman Rostin Behnam said he would step down from his position on Jan. 20, as the country's top derivatives markets regulator prepares for a second Trump term.

Behnam, a Democrat, has served as the CFTC's chairman since 2022. He previously served as a commissioner be-

tween 2017 and 2021 and was named acting chairman in 2021 after his predecessor, Heath Tarbert, resigned when President Biden took office.

Behnam said that under his leadership, the CFTC shifted its focus from implementing the 2010 Dodd-Frank Act to adapting its oversight responsibilities to address the new issues brought on by evolving technology in the derivatives markets and to tackle regula-

tory gaps.

Behnam has sought a leading role for the CFTC in regulating the cryptocurrency market, which has defied easy categorization within the financial regulatory system. That has put the derivatives regulator in a potential conflict with the Securities and Exchange Commission around jurisdictional power over the nascent industry.

The CFTC has cracked

down on misconduct and fraud related to cryptocurrency over the past few years, suing some of the highest-profile companies in the industry. The regulator in August obtained \$12.7 billion in a judgment against now-bankrupt crypto exchange FTX and crypto trading firm Alameda Research. The CFTC also sued crypto exchange Binance for evading U.S. rules in 2023 and imposed a \$2.7 billion fine on

the company later that year. When a group of regulators announced the deal with Binance at the time, Behnam joined Attorney General Merrick Garland and Treasury Secretary Janet Yellen on the stage.

Behnam said his last day at the agency will be Feb. 7, adding that he would work closely with President-elect Donald Trump's team to ensure a smooth transition.

Portrait of a man in a suit and red tie speaking, with no visible text or symbols on the image itself.

The CFTC's Rostin Behnam.

Are Your Savings
Working Hard Enough?

Find the best high-yield savings accounts to start earning more today.

Black leather wallet with a USB flash, resting on stacks of US dollar bills (no visible text or symbols)

READ

wsj.com/buyside-savings

Buy Side FROM WSJ

REVIEWS & RECOMMENDATIONS TO SAVE YOU TIME AND MONEY