Wednesday 8 January 2025 The Guardian

Arts

41

Continued from page 40

great visual presentation over multiple tours, will always have a director that they have worked with for decades." Halpin namechecks Justin Timberlake as one performer who "loves the practical side" of putting together a stadium spectacle - but "most do not operate on

that technical level, or want to".

Halpin's longest-running relationship is 20 years with Pink, who was inspired by seeing aerialists at a Cher concert to apply her own background in gymnastics to her shows. Over successive tours, Halpin has helped to develop the performance from a simple silks routine to the high-level aerial acro- batics that now define a Pink show.

The moments of a performance that resonate, however, can be unexpected. "Left Shark", the much-memed backing dancer from Katy Perry's Super Bowl spectacle, was "one of those happy accidents", Halpin says. "If anything, I thought the singing palm trees would get more play." But it all worked per- fectly with Perry's fun-filled style of the time: "Audiences can smell fakeness a miles away - it's important that you're always being true to who the artist is."

The creative director's job is to help them to convey that, Halpin adds. He may not be known by fans of Swift, Pink or Perry - just as Chappell Roan fans may not know Sattar. But she has

still profoundly shaped the career of pop's newest superstar, as recognised, albeit indirectly, by the Grammys. "We didn't get the packaging nomination - but we got six other ones," she says triumphantly.

Twin Peaks: The Return - how the reboot of David Lynch's oddball masterpiece improved on the original

Katharine Pollock

When Twin Peaks debuted in 1990, it was a cultural phenomenon. On the surface, it was a classic whodunit: a homecoming queen, Laura Palmer (Sheryl Lee), is found dead and a charming, ebullient FBI special agent, Dale Cooper (Kyle MacLachlan), turns up in town to investigate.

Despite the often violent content, entire families sat down to watch, and groups of friends had viewing parties where they ate cherry pie, drank damn fine coffee and dressed up as characters - including wrapped in plastic as poor Laura. The broad appeal was because of writer-director David Lynch and writer-producer Mark Frost's compelling style, which transformed a small-town murder mystery into an oddball drama, replete with profound tragedy, supernatural forces and complex relationships.

Across two seasons and a pre-quel movie (1992's Fire Walk with Me), Lynch and Frost's uncompromising and unique vision and pastiche of genres and tones - from soap opera to film noir, zany comedy, tragedy and horror - forever changed what television could look like.

Fast forward 25 years and Twin Peaks: The Return landed in 2017 - a third season, featuring 18 episodes, all directed by Lynch. No longer beholden

Three formally dressed individuals standing against a black background, no visible text or symbols

▲ In Twin Peaks season three, FBI special agent Dale Cooper (Kyle MacLachlan) is trapped in the supernatural Black Lodge 25 years after the original series' cliffhanger ending. Photo-graph: Suzanne Tenner/Showtime

to network constraints, Lynch and Frost used their full creative autonomy to execute a vision entirely their own - and the result is strange, sometimes excruciating, but always compelling TV.

In season three, Agent Cooper is trapped in the supernatural Black Lodge 25 years after the original series' cliffhanger ending. He's working to get out and eventually return to Twin Peaks, while his doppelganger, host to evil spirit Bob, is in the real world plotting to prevent Bob's return to the Lodge.

The Return has more subplots than could possibly be summarised here - outstripping even the original - from the dying Log Lady (Catherine E Coulson) urging the Twin Peaks sheriff's department to reopen investigations into Laura's death, to a vicious murder in Buckhorn, South Dakota, that draws the attention of FBI deputy director Gordon Cole (played by Lynch) and his colleagues.

It moves indiscriminately between story arcs, and occasionally timelines and dimensions, and has surreal visual and auditory sequences that beg many more questions than they offer answers. It can feel vexing, even mad-dening - not least of all in episode eight, AKA Gotta Light?, which particularly pushes the boundaries of Lynchian cinematography with a sonically and visually audacious sequence showing the birth of Bob.

And then, like him or loathe him, there's Dougie, Cooper's duplicate (Hel-1000 00 00!).

All of this eccentricity and audacity works - better than in season two, which suffered from silly storylines and narrative incoherence after the mid-season reveal of Laura's killer (a decision forced by the network). The result is bold television that leaves you frustrated, saddened and amused, often all at once.

There's much to appreciate: Mac-Lachlan's performance is phenomenal and a whole host of returning characters scratch a nostalgic itch. New characters enrich the world, with stand-outs including Robert Forster as Sheriff Frank Truman, Naomi Watts as Dougie's abrasive wife, Janey-E Jones, and Matthew Lillard as a hapless high school principal, William Hastings.

As ever with Twin Peaks, the appeal isn't the plot but rather its emotional resonance. Often it's not the dramatic scenes that hit the hardest, but small, simple moments when a character's fear, sadness or joy is starkly depicted.

For instance, when Ed sits apart from his beloved Norma in the Double R Diner; when the Log Lady dies; when we watch Bobby crying at the sight

Interior scene with two people seated in armchairs against a red curtain backdrop, featuring a white statue and patterned floor lamp (no visible text or symbols)

▲ Kyle MacLachlan and Sheryl Lee in episode two of The Return. Photograph: Suzanne Tenner/Showtime

of Laura's photo. It also has scenes of unspeakable violence, banal cruelty and screwball humour. Lynch gifts some characters happy endings but others are simply snuffed out - or, like Audrey Horne, stuck in spaces of torturous liminality. For all its surrealism, in this way the show is true to life's unpredictable vicissitudes.

All seasons of Twin Peaks have in common heart-wrenching final episodes with ambiguous endings. Even as it devastates, there's something satisfying about this narrative bookending. Still, I'm tempted to watch it all again in reverse order, starting with The Return and ending at the very beginning: with baby-faced Cooper telling Diane over dictaphone that he's entering the town of Twin Peaks - and that from there, anything could happen.

Twin Peaks: The Return is streaming on Paramount+ (Australia, UK, US)

Zendaya and Tom Holland might be engaged
- and of course people are being normal
about it

Sian Cain

What is it about Tom Holland and Zen-daya? No really, please tell me. Both of these perfectly good actors seem like perfectly nice and interesting people - and yet for some reason, they attract an intense level of scrutiny that would be more understandably directed at things like insurance policies and war crimes.

On Sunday, when Zendaya appeared on the Golden Globes red carpet wearing a diamond the size of a Quality Street chocolate, all bets were off: she and Holland had to be engaged. Internet sleuths started sleuthing and, within minutes, had determined that the ring she wore was not from Bulgari, whose jewellery Zendaya is contractually obliged to wear as one of their brand ambassadors.

People magazine reported that the ring "appears to be a 5.02-carat East-West Cushion Diamond Button Back Ring from Jessica McCormack, listed in the engagement section on the jewellery brand's website" - and sure enough, someone found a photo of a similar looking McCormack ring on Zendaya's manicurist's Instagram, a post that the actor had liked - all the way back in 2022. Elle of course then interviewed some jewellery experts who variously estimated the ring was worth anywhere between US\$100,000 and \$500,000, which I am sure you are glad you now know.

By Monday - a busy day for "sources close to the couple" everywhere - TMZ and People both were reporting they had confirmed Holland and Zendaya are engaged. And if that is not enough official confirmation for you, Deuxmoi ran a blind item from a reader who claimed that the boyfriend of someone who once tattooed them was the florist who had put together the arrangements for their engagement.

So why are people so keen on this particular celebrity couple? Perhaps it is because both of them have grown up in the public eye: Holland started out as Billy Elliott in London's West End at age 12 then went into film, while Zendaya was a child model and Disney kid.

They seem to genuinely like working together, which is sweet: they first met while playing love interests in the Spider-Man films and have both joined the cast of Christopher Nolan's upcoming adaptation of The Odyssey.

Holland is emotionally aware in the way that young male stars increasingly are, talking earnestly about his mental health and sobriety. He's shorter than her and they're both fine about that fact, which is wildly celebrated by some and criticised by others who have strange ideas about what they should get mad about. On social media they are often jointly praised with unnerving intensity, mainly for being “unproblematic” (surely a low bar) and “authentic”, by people who have never met them and likely never will.

Or perhaps it is because of the implicit provocation they pose to those I will call the “parasocially challenged”, as a famous couple who have an aversion to having their private life picked over by vultures. This has been cynically respun by some as a savvy media

Continued on page 42

The provided image is completely blank and contains no text or visible content. Therefore, there is no OCR result to output.