Text needs consistent contrast

177

Meeting Room Scheduling
Made Easy
e-free Solution to booking meeting rooms
Book a Demo

Too light

Meeting Room Scheduling
Made Easy
s free solution to booking meeting rooms
Book a Demo

Too dark

To solve this problem, you need to reduce the dynamics in the image to make the contrast between the text and the background more consistent.

Add an overlay

One way to increase the overall text contrast is to add a semi-transparent overlay to the background image.

Roommate

Sign in

Schedule a Demo

Meeting Room Scheduling
Made Easy
A hassle-free solution to booking meeting rooms
Book a Demo

background-color: hsla(0, 0%, 0%, .55);