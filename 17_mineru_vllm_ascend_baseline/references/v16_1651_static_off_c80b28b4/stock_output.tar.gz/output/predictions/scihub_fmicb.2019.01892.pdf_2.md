Jambon et al.

Biodegradation of Chlorendic Acid

the groundwater. Based on these measurements, a gradient in chlorendic acid pollution was observed (Figure 1). In March 2013, 24 4-m long hybrid poplar cuttings of the Grimminge cultivar [Populus deltoides × (Populus trichocarpa × Populus deltoides)] were planted on the field for future phytoremediation purposes. The trees were distributed over a defined rectangular grid of 10 m by 35 m, enclosing the area with the highest concentrations of chlorendic acid in the groundwater (>100 mg l \( ^{-1} \) ) (Figure 1). In 2015, samples for isolation of cultivable fungal strains were collected from soil, rhizosphere and roots of common bent and hybrid poplar. Four soil samples were taken in a 1-m perimeter around observation wells OW175-4 and OW149-4 (Figure 1), from surface soil, -1, -1.5, and -2 m. Common bent rhizosphere and roots were sampled inside the 1-m perimeter around each of the observation wells. Poplar rhizosphere and root samples were taken from three trees growing in the zones with high concentrations of chlorendic acid (Figure 1). From each tree, four sample repetitions were taken. In total, 32 soil samples were collected (4 × 4 depths × 2 locations), 8 bentgrass root and rhizosphere samples (4 × 2 locations) and 12 poplar rhizosphere and root samples (4 × 3 trees). Soil samples were taken with sterile tools and transported in sterile bags. Roots were collected with soil particles still adhering to the surface, which was considered the rhizosphere fraction. For poplar, the tertiary fine roots were selected. Roots with adhering rhizosphere fraction were obtained with sterile tools and directly transferred into falcon tubes with 30 ml sterile 10 mM MgSO \( _{4} \) .

Isolation of Bacteria and Fungi

Soil samples were homogenized and vortexed in sterile \(10\mathrm{mM}\) \(\mathrm{MgSO_4}\) prior to isolations. Root and rhizosphere samples were vortexed after which the roots were removed from the \(\mathrm{MgSO_4}\). The resulting soil pellet after centrifugation (15 min, \(2700\mathrm{g}\)) constituted the rhizosphere fraction. Poplar roots were surface sterilized by immersing them for 5 min in 1% NaClO and bunchgrass roots were sterilized with 0.1% NaClO supplemented with 0.1% Tween. Following treatment, all roots were rinsed four times in sterile distilled water. The last rinsing solution was plated on 869 medium (Mergeay et al., 1985) to confirm surface sterility by scoring microbial growth after 7 days of incubation at 30°C. The surface sterilized roots were assembled in 15 ml sterile 10 mM MgSO₄ and mixed for 1 min using a Polytron PR1200 mixer (Kinematica A6).

For fungi isolations, dilutions up to \(10^{-4}\) of the soil, rhizosphere and endophytic root solutions were plated onto peptone-glucose-acid-agar medium pH 5, as described by Dietrich and Lamar (1990), and incubated for 7 days at \(23^{\circ}\mathrm{C}\). After incubation, all fungal mycelia were selected, purified and stored on solid malt extract \([2\% (\mathrm{w / v})]\)-peptone \([0.3\% (\mathrm{w / v})]\) medium pH 5 at \(4^{\circ}\mathrm{C}\).

For bacteria isolation, dilutions of the soil samples were added to a selective minimal medium (Sebastian et al., 1996) supplemented with \(25\mathrm{mg}\mathrm{l}^{-1}\) chlorendic acid as sole carbon source, or with \(3\mathrm{mM}\) glucose in addition to chlorendic acid. Every 10 days, \(10\mathrm{ml}\) of the culture was transferred into \(90\mathrm{ml}\) of fresh medium with a slightly higher concentration of chlorendic acid, ultimately leading to \(60\mathrm{mg}\mathrm{l}^{-1}\) chlorendic acid after 3 months of incubation at \(30^{\circ}\mathrm{C}\) and \(120~\mathrm{rpm}\). At the end of the experiment, chlorendic acid concentrations were determined using High Performance Liquid Chromatography (HPLC). The surviving bacterial strains were purified and stored in a glycerol solution [15% (w:v) glycerol; 0.85% (w:v) NaCl] at \(-40^{\circ}\mathrm{C}\).

Identification of Isolated Bacteria and Fungi

DNA was extracted from bacterial isolates using the DNeasy® Blood and Tissue kit (Qiagen, Venlo, Netherlands) and from fungal isolates using the DNeasy® PowerSoil® kit (Qiagen,

| Cluster | Value |
| --- | --- |
| OW175-4 | 247.00 |
| OW149-4 | 59.80 |

Legend

Observation well

OW149-4

Well ID

OW175-4

Well ID

Poplar

Sampling location soil and grass

Sampling location poplar

CA concentration in groundwater

> 100 mg l\( ^{-1} \)

]30-100] mg l\( ^{-1} \)

[0-30] mg l\( ^{-1} \)

FIGURE 1 | Schematic overview of the sampling site and sampling locations. Soil samples (surface soil, -1, -1.5, and -2 m) and samples of root and rhizosphere of grass were taken in an area of one meter around OW149-4 and OW175-4 (n = 4). Root and rhizosphere samples of poplar were taken of the trees growing closest to the two observation wells, with four repetitions for each tree.

Frontiers in Microbiology | www.frontiersin.org

3

August 2019 | Volume 10 | Article 1892