X.-S. Wang, et al.

Comparative Biochemistry and Physiology, Part B 237 (2019) 110324

Fig. 5. The expression profiles of ATF/CREBs in XX and XY gonads based on transcriptome data from gonads of tilapia at 5, 30, 90 and 180 dah. Four pairs of RNA preparations from gonads of XX and XY tilapia at 5, 30, 90 and 180 dah were sequenced using Illumina 2000 HiSeq technology in our previous study. A normalized measure of RPKM (reads per kb per million reads) was used to normalize the expression profiles of ATF/CREBs.

Table 2
Statistics of ATF/CREB gene expression in tilapia gonads at four developmental stages.

<table><tr><td rowspan="2"></td><td colspan="2">5 dah</td><td colspan="2">30 dah</td><td colspan="2">90 dah</td><td colspan="2">180 dah</td></tr><tr><td>XX</td><td>XY</td><td>XX</td><td>XY</td><td>XX</td><td>XY</td><td>XX</td><td>XY</td></tr><tr><td>Total</td><td>132</td><td>197</td><td>770</td><td>1116</td><td>1247</td><td>1269</td><td>1171</td><td>1313</td></tr><tr><td>Average</td><td>6.9</td><td>10.4</td><td>40.5</td><td>58.8</td><td>65.6</td><td>66.8</td><td>61.6</td><td>69.1</td></tr><tr><td>Most diff</td><td>atf5a</td><td></td><td>atf4b</td><td></td><td>creb1b</td><td></td><td>creb1b</td><td></td></tr></table>

"Total" indicates the total RPKM of all ATF/CREBs.

"Average" indicates the average RPKM of all ATF/CREBs.

“Most diff” indicates the most differentially expressed gene among all ATF/CREBs at each stage.

2009; Tussiwand et al., 2012), indicating the functional conservation of these genes between mammals and teleosts during evolution. atf7 was preferentially expressed in the brain as reported in the mice (Goetz et al., 1996). The expression pattern of atf7b not atf7a in tilapia was similar to that of mammalian ATF7 (Zhao et al., 2005). Amazingly, in tilapia, atf7a was specifically expressed in the testis indicating its potential function in male sex differentiation. Expression pattern shifts following duplication indicated neofunctionalization in atf7a as suggested previously for some regulatory genes (Duarte et al., 2006; Sandve et al., 2018). ATF5 was a highly abundant liver-enriched transcription factor in human (Zhao et al., 2005), however, different from human, atf5a was highly expressed in the heart and atf5b showed low expression level in various tissues in tilapia.

In tilapia gonads, some ATF/CREBs expressed sexual dimorphically

at different stages of development. Generally, these periods represent four key biological events during gonadal development of the tilapia: sex determination and differentiation at 5 dah, initiation of germ cell meiosis in ovary at 30 dah, initiation of germ cell meiosis in testis at 90 dah, and vitellogenesis in ovary and sperm maturation in testis at 180 dah (Tao et al., 2013). The ovary-enriched genes, creb1a, jdp2b and atf4b, were highly expressed at 180 dah, while at relatively low level at early stages with little difference between the ovary and testis, indicating they are important for oogenesis. For instance, knockdown of creb1 promotes apoptosis and decreases estradiol synthesis in mouse granulosa cells (Zhang et al., 2018). It was reported that jdp2 was a novel negative regulator of FSH induction by gonadotropin-releasing hormone 1 (GnRH1) in female mice (Jonak et al., 2017). However, in tilapia, jdp2a and jdp2b were ubiquitously expressed in ovary and testis. These results indicated that in addition to its influence on ovarian development, jdp2 may also play an important role in the development of testis. Among testis-enriched genes, except that the expression of atf4b peaked in 90 dah, the others (creb1b, crema, cremb, atf1, atf7a, atf4a) expressed the highest at 180 dah, followed by 90 dah, suggesting that these genes play an important role in spermatogenesis. Previous research reported that crem was highly expressed in spermatogenic cells and crem-mutant mice caused spermiogenesis deficiency and germ-cell apoptosis (Blendy et al., 1996; Nantel et al., 1996; Wang et al., 2018). Interestingly, in our study, signals of crema were also observed in the phase I and II oocytes of the ovary. Further functional characterization of these sexual dimorphically expressed ATF/CREBs using transgenic over-expression and knockout strategies may help elucidate the exact roles of these genes in sex differentiation and gonadal development in teleosts, as well as in other vertebrates.

7