1386

H. Du et al.

Table 2
Biological characteristics (total length, fork length, weight, age), release information (date, site) and tracking statistics (travelling distance, duration from release to last location) of 28 sub-adult Chinese sturgeon tagged with acoustic transmitter IDs, 2008–2012 reintroduction trials

<table><tr><td>Transmitter ID</td><td>Total length (cm)</td><td>Fork length (cm)</td><td>Weight (kg)</td><td>Age (years)</td><td>Release date</td><td>Release site</td><td>Travel distance (km)</td><td>Time interval from release to last localization (h)</td></tr><tr><td>8270</td><td>120</td><td>94</td><td>8.4</td><td>3</td><td>09 June 2008</td><td>Yibin</td><td>-20b</td><td>240</td></tr><tr><td>8276</td><td>122</td><td>100</td><td>12.3</td><td>5</td><td>10 June 2008</td><td>Yibin</td><td>835</td><td>360</td></tr><tr><td>8269a</td><td>136</td><td>110</td><td>17.6</td><td>5</td><td>10 June 2008</td><td>Yibin</td><td>-15b</td><td>240</td></tr><tr><td>21</td><td>127</td><td>105</td><td>12.7</td><td>5</td><td>10 June 2008</td><td>Yibin</td><td>-25b</td><td>240</td></tr><tr><td>17</td><td>138</td><td>114</td><td>20.4</td><td>5</td><td>13 June 2008</td><td>Yibin</td><td>67</td><td>120</td></tr><tr><td>162</td><td>158</td><td>132</td><td>42.8</td><td>7</td><td>24 May 2010</td><td>Yibin</td><td>877</td><td>347</td></tr><tr><td>166</td><td>145</td><td>124</td><td>17.7</td><td>4</td><td>28 May 2010</td><td>Nanxi</td><td>23</td><td>48</td></tr><tr><td>167</td><td>157</td><td>132</td><td>42.2</td><td>6</td><td>03 June 2010</td><td>Nanxi</td><td>23</td><td>25</td></tr><tr><td>168</td><td>117</td><td>98</td><td>9.5</td><td>3</td><td>08 June 2010</td><td>Nanxi</td><td>75</td><td>12</td></tr><tr><td>164</td><td>119</td><td>96</td><td>9.4</td><td>3</td><td>08 June 2010</td><td>Nanxi</td><td>819</td><td>321</td></tr><tr><td>20</td><td>178</td><td>150</td><td>37.8</td><td>6</td><td>15 June 2009</td><td>Chongqing</td><td>120</td><td>4486</td></tr><tr><td>8268</td><td>165</td><td>146</td><td>28.4</td><td>6</td><td>15 June 2009</td><td>Chongqing</td><td>21.3</td><td>46</td></tr><tr><td>8272</td><td>161</td><td>135</td><td>25.0</td><td>5</td><td>15 June 2009</td><td>Chongqing</td><td>31.4</td><td>48</td></tr><tr><td>8271</td><td>128</td><td>105</td><td>13.2</td><td>4</td><td>15 June 2009</td><td>Chongqing</td><td>28</td><td>26</td></tr><tr><td>8273</td><td>135</td><td>115</td><td>9.1</td><td>4</td><td>15 June 2009</td><td>Chongqing</td><td>21.25</td><td>23</td></tr><tr><td>174</td><td>168</td><td>135</td><td>21.8</td><td>6</td><td>24 July 2011</td><td>Naxi</td><td>ND</td><td>ND</td></tr><tr><td>49012</td><td>150</td><td>124</td><td>22.9</td><td>6</td><td>24 July 2011</td><td>Naxi</td><td>93.2</td><td>19</td></tr><tr><td>49022</td><td>142</td><td>117</td><td>18.8</td><td>6</td><td>24 July 2011</td><td>Naxi</td><td>849</td><td>6063</td></tr><tr><td>172</td><td>140</td><td>114</td><td>17.5</td><td>6</td><td>24 July 2011</td><td>Naxi</td><td>ND</td><td>ND</td></tr><tr><td>49023</td><td>147</td><td>120</td><td>17.5</td><td>6</td><td>24 July 2011</td><td>Naxi</td><td>80.8</td><td>31</td></tr><tr><td>49010</td><td>150</td><td>123</td><td>15.2</td><td>6</td><td>23 October 2011</td><td>Naxi</td><td>395</td><td>288</td></tr><tr><td>175</td><td>141</td><td>118</td><td>12.8</td><td>6</td><td>23 October 2011</td><td>Naxi</td><td>ND</td><td>ND</td></tr><tr><td>49021</td><td>137</td><td>113</td><td>13.8</td><td>6</td><td>23 October 2011</td><td>Naxi</td><td>ND</td><td>ND</td></tr><tr><td>49009</td><td>146</td><td>123</td><td>16.3</td><td>6</td><td>23 October 2011</td><td>Naxi</td><td>395</td><td>167</td></tr><tr><td>169</td><td>158</td><td>130</td><td>14.0</td><td>6</td><td>23 October 2011</td><td>Naxi</td><td>395</td><td>224</td></tr><tr><td>8267a</td><td>170</td><td>144</td><td>33.4</td><td>6</td><td>23 July 2009</td><td>Shennongxi</td><td>ND</td><td>ND</td></tr><tr><td>19</td><td>152</td><td>122</td><td>11.5</td><td>4</td><td>28 July 2009</td><td>Badong</td><td>74.9</td><td>62</td></tr><tr><td>18</td><td>151</td><td>129</td><td>15.7</td><td>6</td><td>08 July 2008</td><td>Badong</td><td>15</td><td>16 776</td></tr></table>

ND, no specific data.

\( ^{a} \) Sturgeon were dead after being recaptured.

\( ^{b} \) Fish made a upstream migration.

Table 3
Traveling speed and swimming depth of juvenile and sub-adult Chinese sturgeon

<table><tr><td rowspan="2">Region</td><td colspan="4">Travelling speed (km h-1)</td><td rowspan="2">Swimming depth of Sub-adults (m)</td><td rowspan="2">N</td></tr><tr><td>Juveniles</td><td>N**</td><td>Sub-adults</td><td>N</td></tr><tr><td>Free-flowing reaches</td><td>2.5 (1.8–5.13)</td><td>5</td><td>3.70 (1.51–8.25)*</td><td>13</td><td>3.63 (2.12–9.03)</td><td>8</td></tr><tr><td>Back-water reaches</td><td>0.45 (0.13–1.20)</td><td>4</td><td>1.05 (0.12–1.82)*</td><td>35</td><td>11.47 (8.26–24.1)</td><td>12</td></tr></table>

*Significant difference (p < 0.05) between groups. **N = sample number.

| Distance (rkm) | 8271 | 20 | 8273 | 8272 | 8268 | 19 | 164 | 162 | 49012 | 49010 | 49009 | 169 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| ~1050 | — | — | — | — | — | — | ~7.5 | ~4.5 | — | — | ~4.8 | — |
| ~950 | — | — | — | — | — | — | ~6.8 | ~7.5 | — | — | ~2.3 | ~1.0 |
| ~850 | — | — | — | — | — | — | ~8.3 | ~4.1 | ~4.7 | ~3.5 | ~4.7 | ~1.6 |
| ~750 | — | — | — | — | — | — | ~7.0 | ~5.2 | ~3.3 | ~3.3 | ~2.1 | ~3.7 |
| ~650 | — | — | — | — | — | — | ~6.0 | ~4.6 | ~3.8 | ~3.8 | ~5.0 | ~1.8 |
| ~550 | — | — | — | — | — | — | ~1.4 | ~2.8 | ~1.8 | ~0.8 | ~2.6 | ~0.3 |
| ~450 | — | — | — | — | — | — | ~1.1 | ~1.9 | ~1.1 | ~0.5 | ~1.1 | ~0.0 |
| ~250 | — | — | — | — | — | — | ~1.4 | ~1.9 | ~0.2 | — | — | — |
| ~150 | — | — | — | — | — | — | — | ~1.9 | — | — | — | — |
| ~50 | — | — | — | — | — | — | — | ~1.9 | — | — | — | — |
| ~-50 | — | — | — | — | — | — | — | ~1.9 | — | — | — | — |

Fig. 3. Traveling speeds of ultrasonically-tagged sub-adult Chinese sturgeons (with transmitter IDs) when passing through free-flowing reaches of upper Yangtze River and Three Gorges Reservoir

distance of the Vemco acoustic system in the Yangtze River was between 300 and 900 m. Water velocity, transparency, silt concentration, distance and surface attachment are all associated factors that highly affect the valid detection distance of the acoustic transmitters, passive receivers and mobile tracking hydrophones in our tests; such interferences may be the main handicaps for acoustic telemetry use in a long-term project in the fast-flowing, seasonal changing water quality of large rivers such as the Yangtze River (Wang et al., 2012). Careful design engineering tasks to improve habitat and recheck the system are important management steps to achieve good results. In our experiment, only four of 28 sub-adult Chinese sturgeon tagged with acoustic transmitters were lost and we still received much telemetric information. The tracking distance of six sub-adults (21.4%) was more than 300 km, with the longest value of 877 km and the most effective in the nearly two-year tracking period.