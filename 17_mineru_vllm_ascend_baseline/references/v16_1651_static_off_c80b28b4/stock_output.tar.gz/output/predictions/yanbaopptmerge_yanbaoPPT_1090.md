1、贾探春简介

2、玫瑰花

3、杏花

4、成立诗社

5、才自清明志自高

6、敏探春兴利除弊

7、巧言解围

8、严词申饬

9、衰世哀音

10、远嫁海疆 / 和亲

莫牵连

収去也

多自保平岁

从今分两地

离合岂无缘

自古穷通皆有空

休把儿具会

朱谷娘

恐哭損残年

把骨肉家园齐来抛闪

一帆风雨路三千

Ink painting of lotus flowers with leaves and a butterfly (no text or symbols)