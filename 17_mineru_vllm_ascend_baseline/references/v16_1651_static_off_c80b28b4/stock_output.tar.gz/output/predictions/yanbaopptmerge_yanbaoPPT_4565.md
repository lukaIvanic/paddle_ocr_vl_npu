Retell 1a

Jane: ... look tired ... ?

Kangkang: ... a headache.

Jane: ... sorry to ...?

Kangkang: ... watched ... last night

and ... bed very late.

Jane: Staying up late ...

health.

... go ...early

and … feel better …

Kangkang: ...must ... rest.

Illustration of three potted flowers with green leaves and pink flowers, no text or symbols present