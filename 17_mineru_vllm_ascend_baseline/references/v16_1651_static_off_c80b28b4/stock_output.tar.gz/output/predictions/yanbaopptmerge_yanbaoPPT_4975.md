Child blowing bubbles outdoors in a park-like setting (no text or symbols visible)

谁带着泡泡旅行呢？

Cartoon character riding a small vehicle with arms and legs, holding a thought bubble (no text or symbols)