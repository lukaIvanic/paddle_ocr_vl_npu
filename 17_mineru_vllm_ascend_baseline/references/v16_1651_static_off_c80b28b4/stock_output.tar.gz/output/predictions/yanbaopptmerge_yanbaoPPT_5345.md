情境导入

小朋友们正在游泳呢！我们根据这个图能列出几个加减法算式呢？

Illustration of children playing in a pool with lifebuys and floating rafts (no text or symbols)