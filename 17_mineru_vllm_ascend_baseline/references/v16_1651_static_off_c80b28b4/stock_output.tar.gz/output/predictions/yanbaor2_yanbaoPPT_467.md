中国的制造业生态系统还包括现代化的交通运输基础设施——公路、铁路和机场，高效连接中国工厂与全球市场。例如，新建的铁路现在能让中部城市郑州的制造商在16天内将商品送达欧洲的消费者，之前走海路运输则要38天之久。在中国境内，货物的平均交通流转速度比印度快 \(30 - 60\%\) 。图23说明了深圳制造业生态系统的种种优势。在这样的生态系统中，企业能够节约原型开发的时间和成本，利用庞大的供应商基础，将产品快速推向全球市场。

图23

深圳强大的制造业生态系统优势

| Category | Metric | Value |
| --- | --- | --- |
| Design and Prototype (Weekly) | 原型开发时间 (Week) | 10-15 |
| Design and Prototype (Weekly) | 原型开发成本 (KRW) | 100-200 |
| Design and Prototype (Weekly) | 原型开发时间 (Range) | 2-3 |
| Design and Prototype (Weekly) | 原型开发成本 (Range) | 30-50 |
| Scale Distribution | 两小时车程范围 | 1,000+ |
| Scale Distribution | 两小时车程范围 | 300+ |
| Scale Distribution | 两小时车程范围 | 2,000+ |
| Scale Distribution | 两小时车程范围 | 1,300 |
| Scale Distribution | 两小时车程范围 | 900万 |
| Market Ranking (Million Standard Boxes) | 全球港口排名 | 46 |
| Market Ranking (Million Standard Boxes) | 全球机场排名 | 5 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 46 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 34 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 32 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 18 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 17 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 18 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 17 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 17 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 17 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 17 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按药物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按药物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按药物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按药物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按药物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按药物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按药物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按药物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按照货物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按照货物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按照货物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按照货物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球 Airport排名::按货物吞吐量计 | 5 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 4 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::对货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::对货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::对货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全球机场排名::对货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐量计 | 5 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐量计 | 4 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::按货物吞吐计量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::对货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::对货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::对货物吞吐量计 | 2 |
| Market Ranking (Million Standard Boxes) | 全城机场排名::对货物吞吐量计 | 2 |

1 以低成本手机为例

2 化工，橡胶，矿物，金属，纺织

3 20英尺标准集装箱（测量船只载货量的单位）

资料来源：2014深圳统计年鉴；德鲁里集装箱航运市场；国际机场协会；文献检索；麦肯锡全球研究院分析

64

麦肯锡全球研究院

第四章 效率驱动型创新：生态系统优势