## Words in Modern and Older Indo-European Languages Equivalent to Modern English foot


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Old English fótModern English footModern German FuβModern Dutch voetModern Norwegian fotModern Danish fodModern Swedish fot</td><td style='text-align: center; word-wrap: break-word;'>Modern French piedModern Italian piedeModern Portuguese péModern Spanish pieSanskrit pātLatin pēsGreek peza</td></tr></table>