## Problems of Inconsistency

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_212_920_953.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1046_212_1737_952.jpg" alt="Image" width="34%" /></div>


## • Printed images don't look like displayed images

Slide Provided by David Clunie, Quintiles Intelligent Imaging