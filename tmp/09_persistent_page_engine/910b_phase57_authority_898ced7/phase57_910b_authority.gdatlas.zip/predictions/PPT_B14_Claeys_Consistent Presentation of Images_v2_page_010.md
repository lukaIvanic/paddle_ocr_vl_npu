## Monitor Characteristic Curve

<div style="text-align: center;"><img src="imgs/img_in_image_box_196_749_285_911.jpg" alt="Image" width="4%" /></div>


Ambient Light

<div style="text-align: center;"><img src="imgs/img_in_chart_box_534_344_1543_1143.jpg" alt="Image" width="50%" /></div>


Slide Provided by David Clunie, Quintiles Intelligent Imaging