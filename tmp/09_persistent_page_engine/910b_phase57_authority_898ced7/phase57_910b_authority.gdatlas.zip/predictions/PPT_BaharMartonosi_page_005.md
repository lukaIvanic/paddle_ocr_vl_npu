## TOP 10 POINTERS FOR A GOOD TALK

6. Use  $ \underline{\text{color}} $ to emphasize

7. Use illustrations to get across key concepts

May include limited animation

<div style="text-align: center;"><img src="imgs/img_in_image_box_1208_526_1794_798.jpg" alt="Image" width="29%" /></div>


8. Make eye contact

<div style="text-align: center;"><img src="imgs/img_in_image_box_804_952_1107_1043.jpg" alt="Image" width="15%" /></div>


9. Be ready to skip  $ \underline{\text{slides}} $ if time is short

10. Practice!!