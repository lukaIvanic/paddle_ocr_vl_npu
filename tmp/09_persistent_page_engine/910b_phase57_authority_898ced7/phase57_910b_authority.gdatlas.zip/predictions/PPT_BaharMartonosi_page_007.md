## A “TYPICAL” PROJECT TALK OUTLINE

## Results (2-6 slides)

Present key results and key insights. This is main body of the talk, but don't try to show ALL results.

Summary (1 slide)

○ Future Work (0-1 slides)

Backup Slides (0-3 slides)

3 Things to Remember!



Optionally have a few slides ready to answer expected questions.

<div style="text-align: center;"><img src="imgs/img_in_image_box_1779_1242_1909_1375.jpg" alt="Image" width="6%" /></div>
