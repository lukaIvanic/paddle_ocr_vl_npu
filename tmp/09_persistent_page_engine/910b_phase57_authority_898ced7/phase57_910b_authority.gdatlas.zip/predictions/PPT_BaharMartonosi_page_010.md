## THE BIGGER PICTURE: COMMUNICATION AND YOUR CAREER

Expressing yourself technically helps you make and use professional connections wisely

You are joining a long-term community...

Communicate your ideas to forge

mentoring and technical

relationships in the service of

professional goals

<div style="text-align: center;"><img src="imgs/img_in_image_box_1197_346_1891_962.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1775_1241_1913_1376.jpg" alt="Image" width="6%" /></div>
