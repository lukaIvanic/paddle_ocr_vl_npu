## Slope

- Slope = rise/run

-  $ \Delta y/\Delta x $

-  $ (y_2 - y_1)/(x_2 - x_1) $

- Order of points 1 and 2 not critical, but keeping them together is

- Points may lie in any quadrant: slope will work out

- Leibniz notation for derivative based on  $ \Delta y/\Delta x $; the derivative is written dy/dx

<div style="text-align: center;"><img src="imgs/img_in_image_box_1051_364_1947_1253.jpg" alt="Image" width="44%" /></div>
