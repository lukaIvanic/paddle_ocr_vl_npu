## Partial Derivatives

<div style="text-align: center;"><img src="imgs/img_in_chart_box_439_311_1282_1064.jpg" alt="Image" width="42%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1428_499_1568_897.jpg" alt="Image" width="7%" /></div>


• Functions of more than one variable

• Example:  $ C(x, y) = x^4 + y^3 + xy $