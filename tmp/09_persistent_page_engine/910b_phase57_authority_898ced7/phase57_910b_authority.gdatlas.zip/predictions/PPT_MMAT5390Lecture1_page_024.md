## What is a digital image?

## Mathematical definition of color image:

- A 2D (color) digital image is a 2D function defined on a 2D domain (usually rectangular domain):

 $$ f:=(f_{R},f_{G},f_{B}):\Omega\to\mathbb{R}^{3} $$ 

 $ f_{R}, f_{G}, f_{B} $ are the intensity/brightness/grey level corresponding to R, G and B respectively;

Combination of R, G, B forms the full spectrum of color!