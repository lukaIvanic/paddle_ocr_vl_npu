## REQUIREMENTS-1

Each group is required to present, with TWO options:

1. A short video summary in 1 min  $ \underline{\text{PLUS}} $
a classroom live presentation in 6-8 min;


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>1-min video by Mar 11</td><td style='text-align: center; word-wrap: break-word;'>Tutorial: 6-8 min classroom live presentation</td><td style='text-align: center; word-wrap: break-word;'>7-10 min tutorial discussion, Q&amp;A</td></tr></table>

2. A full video presentation in 5-7 min;


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>~6-min full video by Mar 11</td><td style='text-align: center; word-wrap: break-word;'>Tutorial: introduction and view video presentation</td><td style='text-align: center; word-wrap: break-word;'>7-10 min tutorial discussion, Q&amp;A</td></tr></table>

## ALL videos due on Mar 11, 2016;

ENGG1000 Presentation Specification