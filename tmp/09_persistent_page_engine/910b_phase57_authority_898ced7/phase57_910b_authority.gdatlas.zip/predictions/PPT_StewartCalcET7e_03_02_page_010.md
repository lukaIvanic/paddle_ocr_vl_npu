## Example 1

(a) If  $ f(x) = xe^x $, find  $ f'(x) $.

(b) Find the  $ n $th derivative,  $ f^{(n)}(x) $.

Solution:

(a) By the Product Rule, we have

 $$ \begin{aligned}f^{\prime}(x)&=\frac{d}{dx}\left(xe^{x}\right)&\\&=x\frac{d}{dx}\left(e^{x}\right)+e^{x}\frac{d}{dx}(x)\\ &\\&=xe^{x}+e^{x}\cdot1=(x+1)e^{x}\\ \end{aligned} $$ 