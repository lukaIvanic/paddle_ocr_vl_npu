Parallel processing of products on the computer is facilitated by a variant of (3) for computing  $ \mathbf{C} = \mathbf{AB} $, which is used by standard algorithms (such as in Lapack). In this method,  $ \mathbf{A} $ is used as given,  $ \mathbf{B} $ is taken in terms of its column vectors, and the product is computed columnwise; thus,

 $$ \mathbf{A}\mathbf{B}=\mathbf{A}[\mathbf{b}_{1}~\mathbf{b}_{2}~\ldots~\mathbf{b}_{p}]=[\mathbf{A}\mathbf{b}_{1}~\mathbf{A}\mathbf{b}_{2}~\ldots~\mathbf{A}\mathbf{b}_{p}]. $$ 

Columns of B are then assigned to different processors (individually or several to each processor), which simultaneously compute the columns of the product matrix  $ \mathbf{Ab}_{1} $,  $ \mathbf{Ab}_{2} $, etc.