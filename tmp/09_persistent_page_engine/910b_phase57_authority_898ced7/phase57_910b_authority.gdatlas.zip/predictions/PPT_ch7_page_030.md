If all the diagonal entries of a diagonal matrix S are equal, say, c, we call S a scalar matrix because multiplication of any square matrix A of the same size by S has the same effect as the multiplication by a scalar, that is,

 $$ \mathbf{A}\mathbf{S}=\mathbf{S}\mathbf{A}=c\mathbf{A}. $$ 

In particular, a scalar matrix, whose entries on the main diagonal are all 1, is called a unit matrix (or identity matrix) and is denoted by  $ I_{n} $ or simply by I. For I, formula (12) becomes

 $$ \mathbf{A}\mathbf{I}=\mathbf{I}\mathbf{A}=\mathbf{A}. $$ 