## Matrix Form of the Linear System (1)

From the definition of matrix multiplication we see that the  $ m $ equations of (1) may be written as a single vector equation

 $$  Ax=b $$ 

where the coefficient matrix  $ \mathbf{A} = [a_{jk}] $ is the  $ m \times n $ matrix

 $$ \mathbf{A}=\begin{bmatrix}a_{11}&a_{12}&\cdots&a_{1n}\\a_{21}&a_{22}&\cdots&a_{2n}\\\cdot&\cdot&\cdots&\cdot\\a_{m1}&a_{m2}&\cdots&a_{mn}\end{bmatrix},\quad and\quad\mathbf{x}=\begin{bmatrix}x_{1}\\\cdot\\\cdot\\\cdot\\x_{n}\end{bmatrix}\quad and\quad\mathbf{b}=\begin{bmatrix}b_{1}\\\vdots\\b_{m}\end{bmatrix} $$ 

are column vectors.