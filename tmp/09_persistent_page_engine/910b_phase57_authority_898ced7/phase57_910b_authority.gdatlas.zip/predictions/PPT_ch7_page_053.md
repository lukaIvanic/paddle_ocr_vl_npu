At the end of the Gauss elimination (before the back substitution), the row echelon form of the augmented matrix will be

<div style="text-align: center;"><img src="imgs/img_in_image_box_377_405_1286_1100.jpg" alt="Image" width="45%" /></div>


Here, and all entries in the blue triangle and blue rectangle are zero.