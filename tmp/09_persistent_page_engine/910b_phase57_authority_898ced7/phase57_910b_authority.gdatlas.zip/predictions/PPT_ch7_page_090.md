## Cramer's Rule for Linear Systems of Three Equations

 $$ a_{11}x_{1}+a_{12}x_{2}+a_{13}x_{3}=b_{1} $$ 

 $$ a_{21}x_{1}+a_{22}x_{2}+a_{23}x_{3}=b_{2} $$ 

 $$ a_{31}x_{1}+a_{32}x_{2}+a_{33}x_{3}=b_{3} $$ 

is

 $$ x_{1}=\frac{D_{1}}{D},\quad x_{2}=\frac{D_{2}}{D},\quad x_{3}=\frac{D_{3}}{D} $$ 

 $$ (D\neq0) $$ 

with the determinant D of the system given by (4) and

 $$ \begin{aligned}D_{1}&=\left|\begin{matrix}b_{1}&a_{12}&a_{13}\\ b_{2}&a_{22}&a_{23}\\ b_{3}&a_{32}&a_{33}\end{matrix}\right|,\quad D_{2}=\left|\begin{matrix}a_{11}&b_{1}&a_{13}\\ a_{21}&b_{2}&a_{23}\\ a_{31}&b_{3}&a_{33}\end{matrix}\right|,\quad D_{3}=\left|\begin{matrix}a_{11}&a_{12}&b_{1}\\ a_{21}&a_{22}&b_{2}\\ a_{31}&a_{32}&b_{3}\end{matrix}\right|.\end{aligned} $$ 

Note that  $ D_{1}, D_{2}, D_{3} $ are obtained by replacing Columns 1, 2, 3, respectively, by the column of the right sides of (5).