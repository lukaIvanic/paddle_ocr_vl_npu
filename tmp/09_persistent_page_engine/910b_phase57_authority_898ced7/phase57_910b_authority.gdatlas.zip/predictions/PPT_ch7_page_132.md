Vectors whose inner product is zero are called orthogonal. The length or  $ \mathbf{n}\mathbf{o}\mathbf{r}\mathbf{m} $ of a vector in V is defined by

 $$ \left\|\mathbf{a}\right\|=\sqrt{(\mathbf{a},\mathbf{a})}\quad(\geq0). $$ 

A vector of norm 1 is called a unit vector. From these axioms and from (2) one can derive the basic inequality

 $$ \left\| \mathbf{a},\mathbf{b} \right\|\leq \left\| \mathbf{a} \right\| \left\| \mathbf{b} \right\| $$ 

(Cauchy-Schwarz inequality)

From this follows

 $$ \left\| \mathbf{a}+\mathbf{b} \right\|\leq \left\| \mathbf{a} \right\|+ \left\| \mathbf{b} \right\| $$ 

(Triangle inequality).

A simple direct calculation gives

 $$ \left\|\mathbf{a}+\mathbf{b}\right\|^{2}+\left\|\mathbf{a}-\mathbf{b}\right\|^{2}=2\left(\left\|\mathbf{a}\right\|^{2}+\left\|\mathbf{b}\right\|^{2}\right) $$ 

(Parallelogram equality).