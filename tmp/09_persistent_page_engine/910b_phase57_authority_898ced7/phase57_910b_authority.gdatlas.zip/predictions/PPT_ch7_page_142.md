(continued 3)

The transpose  $ \mathbf{A}^\top $ of a matrix  $ \mathbf{A} = [a_{jk}] $ is  $ \mathbf{A}^\top = [a_{jk}] $; rows become columns and conversely (Sec. 7.2). Here,  $ \mathbf{A} $ need not be square. If it is and  $ \mathbf{A} = \mathbf{A}^\top $, then  $ \mathbf{A} $ is called symmetric; if  $ \mathbf{A} = -\mathbf{A}^\top $, it is called skew-symmetric.

For a product,  $ (\mathbf{A}\mathbf{B})^\top = \mathbf{B}^\top \mathbf{A}^\top $ (Sec. 7.2).

A main application of matrices concerns linear systems of equations

 $$  Ax=b $$ 

(m equations in n unknowns  $ x_1, \ldots, x_n $; A and b given).