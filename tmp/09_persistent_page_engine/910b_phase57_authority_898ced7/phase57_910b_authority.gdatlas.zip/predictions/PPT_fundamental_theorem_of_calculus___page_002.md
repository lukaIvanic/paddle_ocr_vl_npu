To estimate area A

under  $ y = 3x^{2} $ from

x = 2 to x = 4

<div style="text-align: center;"><img src="imgs/img_in_image_box_997_50_1654_455.jpg" alt="Image" width="32%" /></div>


we could split it into small rectangles:

With 4 rectangles,

the area  $ \approx 48.96 $ units $ ^{2} $

<div style="text-align: center;"><img src="imgs/img_in_image_box_1001_821_1666_1241.jpg" alt="Image" width="33%" /></div>
