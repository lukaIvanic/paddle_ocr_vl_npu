Generally, this is what we could do:

Area of 1 rectangle  $ \approx f(x) \times h $

<div style="text-align: center;"><img src="imgs/img_in_image_box_1098_143_1514_656.jpg" alt="Image" width="20%" /></div>


Area of all the rectangles $\approx \sum f(x) \times h$

Actual area under the curve =  $ \lim \sum_{h \to 0} f(x) \times h $

which is written as $\int f(x) \, dx$

(but evaluating this limit is incredibly complicated)