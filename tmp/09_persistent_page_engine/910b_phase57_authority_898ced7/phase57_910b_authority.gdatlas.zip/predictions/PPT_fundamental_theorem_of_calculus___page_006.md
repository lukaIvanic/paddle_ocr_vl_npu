After an lot of algebra, it would probably come to an expression similar to this:

 $$ \begin{array}{l} \text{Area } =\displaystyle {\lim_{\text{as } h \to 0}} 56 ( 1+2 h+4 h^{2}+8 h^{3}+ \dots)  \\ \qquad = 56 \text{ units}^2  \end{array} $$ 

Unfortunately, simplyfying the expression into something like the above is extremely difficult. (see pages 285 – 288 in my book)