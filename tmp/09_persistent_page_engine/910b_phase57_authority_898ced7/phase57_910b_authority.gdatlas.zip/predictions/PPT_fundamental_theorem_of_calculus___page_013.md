eg if $y = f(x) = 3x^{2}$ and $a = 2$ and $b = 4$

then Area A = \int_{2}^{4} 3x^{2} dx

 $$ \begin{array}{rl} &=\Bigg[ x^{3} \Bigg]_{2}^{4}\\&=\Bigg[ 4^{3} \Bigg] - \Bigg[ 2^{3} \Bigg]\\&=64 - 8\\ &= 56\ \text{units}^2 \end{array} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_894_482_1671_1080.jpg" alt="Image" width="38%" /></div>
