## HOMOGENEOUS LINEAR SYSTEMS

Example 1: Determine if the following homogeneous system has a nontrivial solution. Then describe the

solution set.

 $$ \begin{aligned}3x_{1}+5x_{2}-4x_{3}&=0\\-3x_{1}-2x_{2}+4x_{3}&=0\\6x_{1}+x_{2}-8x_{3}&=0\end{aligned} $$ 

Solution: Let A be the matrix of coefficients of the system and row reduce the augmented matrix  $ [A\ 0] $ to echelon form: