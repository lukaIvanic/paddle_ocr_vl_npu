## HOMOGENEOUS LINEAR SYSTEMS

 $$ \begin{bmatrix}{{{3}}}&{{{5}}}&{{{-4}}}&{{{0}}} \\{{{-3}}}&{{{-2}}}&{{{4}}}&{{{0}}} \\{{{6}}}&{{{1}}}&{{{-8}}}&{{{0}}}\end{bmatrix}\sim\begin{bmatrix}{{{3}}}&{{{5}}}&{{{-4}}}&{{{0}}} \\{{{0}}}&{{{3}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{-9}}}&{{{0}}}&{{{0}}}\end{bmatrix}\sim\begin{bmatrix}{{{3}}}&{{{5}}}&{{{-4}}}&{{{0}}} \\{{{0}}}&{{{3}}}&{{{0}}}&{{{0}}} \\{{{0}}}&{{{0}}}&{{{0}}}&{{{0}}}\end{bmatrix} $$ 

Since $x_{3}$ is a free variable, $Ax = 0$ has nontrivial solutions (one for each choice of $x_{3}$.)

Continue the row reduction of  $ [A\ 0] $ to reduced

echelon form:

 $$ \begin{bmatrix} {1}&{0}&{\displaystyle -\frac{4}{3}}&{0} \\ {0}&{1}&{0}&{0} \\ {0}&{0}&{0}&{0} \end{bmatrix} \quad \begin{aligned} x_{1}-\displaystyle \frac{4}{3}x_{3}&=0\\x_{2}&=0\\0&=0 \end{aligned} $$ 