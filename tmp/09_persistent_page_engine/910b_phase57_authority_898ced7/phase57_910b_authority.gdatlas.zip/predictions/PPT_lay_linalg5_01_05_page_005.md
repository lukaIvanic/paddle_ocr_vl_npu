## HOMOGENEOUS LINEAR SYSTEMS

Solve for the basic variables  $ x_{1} $ and  $ x_{2} $ to obtain  $ x_{1} = \frac{4}{3}x_{3} $,  $ x_{2} = 0 $, with  $ x_{3} $ free.

As a vector, the general solution of Ax = 0 has the form given below.

 $$ \mathrm{x}=\left[\begin{array}{l}x_{1}\\ x_{2}\\ x_{3}\end{array}\right]=\left[\begin{array}{c}\frac{4}{3}x_{3}\\ 0\\ x_{3}\end{array}\right]=x_{3}\left[\begin{array}{l}\frac{4}{3}\\ 0\\ 1\end{array}\right]=x_{3}\mathrm{v},\mathrm{where}\mathrm{v}=\left[\begin{array}{l}\frac{4}{3}\\ 0\\ 1\end{array}\right] $$ 