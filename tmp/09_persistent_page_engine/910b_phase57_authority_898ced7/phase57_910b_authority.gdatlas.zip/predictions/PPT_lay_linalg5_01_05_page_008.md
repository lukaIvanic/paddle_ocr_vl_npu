## SOLUTIONS OF NONHOMOGENEOUS SYSTEMS

When a nonhomogeneous linear system has many solutions, the general solution can be written in parametric vector form as one vector plus an arbitrary linear combination of vectors that satisfy the corresponding homogeneous system.

Example 3: Describe all solutions of Ax = b, where

 $$ \boldsymbol{A}=\left[\begin{array}{rrr}3&5&-4\\-3&-2&4\\6&1&-8\end{array}\right]\text{and}\mathbf{b}=\left[\begin{array}{r}7\\-1\\-4\end{array}\right]. $$ 