 $$ \begin{array}{rrrrr} x_{1}&-2x_{2}&+x_{3}&=0\\ &2x_{2}&-8x_{3}&=8\\ &-3x_{2}&+13x_{3}&=-9 \end{array} $$ 

 $$ \begin{bmatrix}{{{1}}}&{{{-2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{2}}}&{{{-8}}}&{{{8}}} \\{{{0}}}&{{{-3}}}&{{{13}}}&{{{-9}}}\end{bmatrix} $$ 

Changing the coefficient of  $ x_{2} $ from 2 to 1.

• The purpose of this step is to simplify the calculation in the next steps.

• To do it, we multiply the  $ 2^{nd} $ equation by  $ \frac{1}{2} $.

 $$ \begin{array}{rrrrr} x_{1}&-2x_{2}&+x_{3}&=0\\ &x_{2}&-4x_{3}&=4\\ &-3x_{2}&+13x_{3}&=-9 \end{array} $$ 

 $$ \begin{bmatrix}{{{1}}}&{{{-2}}}&{{{1}}}&{{{0}}} \\{{{0}}}&{{{1}}}&{{{-4}}}&{{{4}}} \\{{{0}}}&{{{-3}}}&{{{13}}}&{{{-9}}}\end{bmatrix} $$ 