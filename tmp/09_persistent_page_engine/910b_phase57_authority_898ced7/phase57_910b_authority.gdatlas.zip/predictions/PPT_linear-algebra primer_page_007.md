## Projection: Using Inner Products (I)

<div style="text-align: center;"><img src="imgs/img_in_image_box_506_340_1381_952.jpg" alt="Image" width="43%" /></div>


Projection of x along the direction  $ \mathbf{a}\left(\|\mathbf{a}\|=1\right) $.

 $$ \mathbf{p}=\mathbf{a}\left(\mathbf{a}^{\mathrm{T}}\mathbf{x}\right) $$ 

 $$ \left\| \mathbf{a} \right\|=a^T a=1 $$ 

Shivkumar Kalyanaraman