## Bases & Orthonormal Bases

Basis (or axes): frame of reference

<div style="text-align: center;"><img src="imgs/img_in_image_box_358_413_800_753.jpg" alt="Image" width="22%" /></div>


VS

<div style="text-align: center;"><img src="imgs/img_in_image_box_1241_344_1820_799.jpg" alt="Image" width="28%" /></div>


Basis: a space is totally defined by a set of vectors – any point is a linear combination of the basis

Ortho-Normal: orthogonal + normal

[Sneak peek]:

 $ \underline{\text{Orthogonal}} $: dot product is zero

Normal: magnitude is one ]

 $$ \begin{aligned}x&=\begin{bmatrix}1&0&0\end{bmatrix}^{T}\quad&x\cdot y&=0\\y&=\begin{bmatrix}0&1&0\end{bmatrix}^{T}\quad&x\cdot z&=0\\z&=\begin{bmatrix}0&0&1\end{bmatrix}^{T}\quad&y\cdot z&=0\end{aligned} $$ 