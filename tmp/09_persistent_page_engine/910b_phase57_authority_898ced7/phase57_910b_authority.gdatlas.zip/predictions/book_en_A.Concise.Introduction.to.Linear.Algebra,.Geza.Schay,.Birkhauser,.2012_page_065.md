Exercise 2.1.3.

 $$ \begin{aligned}2x_{1}+2x_{2}-3x_{3}&=0\\x_{1}+5x_{2}+2x_{3}&=1\end{aligned} $$ 

Exercise 2.1.4.

 $$ 2x_{1}+2x_{2}-3x_{3}=0 $$ 

In the next nine exercises use Gaussian elimination to find all solutions of the systems given by their augmented matrices.

Exercise 2.1.5.

 $$ \begin{bmatrix}1&0&-1\\ -2&3&-1\\ -6&6&0\end{bmatrix}\begin{array}{l}0\\ 0\\ 0\end{array} $$ 

Exercise 2.1.6.

 $$ \begin{bmatrix}{{{1}}}&{{{0}}}&{{{-1}}}&{{{1}}} \\{{{-2}}}&{{{3}}}&{{{-1}}}&{{{0}}} \\{{{-6}}}&{{{6}}}&{{{0}}}&{{{-2}}}\end{bmatrix} $$ 

Exercise 2.1.7.

 $$ \begin{bmatrix}1&0&-1\\ -2&3&-1\\ -6&6&0\end{bmatrix}\begin{bmatrix}1\\ 0\\ 0\end{bmatrix} $$ 

Exercise 2.1.8.

 $$ \left[ \begin{array}{rrrrr|r} 3&-6&-1&1&12\\-1&2&2&3&1\\6&-8&-3&-2&9 \end{array} \right] $$ 

Exercise 2.1.9.

 $$ \begin{bmatrix}1&4&9&2&0\\ 2&2&6&-3&0\\ 2&7&16&3&0\end{bmatrix} $$ 

Exercise 2.1.10.

 $$ \begin{bmatrix}2&4&1&7\\ 0&1&3&7\\ 3&3&-1&9\\ 1&2&3&11 \end{bmatrix} $$ 

Exercise 2.1.11.

 $$ \left[\begin{array}{r r r r r|r}{3}&{-6}&{-1}&{1}&{5}&{0}\\ {-1}&{2}&{2}&{3}&{3}&{0}\\ {4}&{-8}&{-3}&{-2}&{1}&{0}\end{array}\right] $$ 

 $$ \left[ \begin{array}{rrrr|r} 3&-6&-1&1&7\\-1&2&2&3&1\\4&-8&-3&-2&6 \end{array} \right] $$ 

Exercise 2.1.12.

Exercise 2.1.13.

 $$ \left[ \begin{array}{rrrr|r} 3&-6&-1&1&5\\-1&2&2&3&3\\6&-8&-3&-2&1 \end{array} \right] $$ 