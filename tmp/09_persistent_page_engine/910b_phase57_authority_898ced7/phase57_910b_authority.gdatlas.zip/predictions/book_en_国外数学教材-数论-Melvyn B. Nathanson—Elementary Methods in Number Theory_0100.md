Proof. This follows immediately from Theorem 3.3, since  $ |(\mathbf{Z}/p\mathbf{Z})^\times| = p - 1 $.  $ \Box $

The following table lists the primitive roots for the first six primes.


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>p</td><td style='text-align: center; word-wrap: break-word;'>$ \varphi(p-1) $</td><td style='text-align: center; word-wrap: break-word;'>primitive roots</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>2</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>5</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>2,3</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>7</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>3,5</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>11</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>2,6,7,8</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>13</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>2,6,7,11</td></tr></table>

Let p be a prime, and let g be a primitive root modulo p. If a is an integer not divisible by p, then there exists a unique integer k such that

 $$ a\equiv g^{k}\pmod{p} $$ 

and

 $$ k\in\{0,1,\ldots,p-2\}. $$ 

This integer k is called the index of a with respect to the primitive root g, and is denoted by

 $$ k=\operatorname{ind}_{g}(a). $$ 

If  $ k_1 $ and  $ k_2 $ are any integers such that  $ k_1 \leq k_2 $ and

 $$ a\equiv g^{k_{1}}\equiv g^{k_{2}}\pmod{p}, $$ 

then

 $$ g^{k_{2}-k_{1}}\equiv1\pmod{p}, $$ 

and so

 $$ k_{1}\equiv k_{2}\pmod{p-1}. $$ 

If $a \equiv g^{k} \pmod{p}$ and $b \equiv g^{\ell} \pmod{p}$, then $ab \equiv g^{k} g^{\ell} = g^{k + \ell} \pmod{p}$, and so

 $$ \operatorname{i n d}_{g}(a b)\equiv k+\ell\equiv\operatorname{i n d}_{g}(a)+\operatorname{i n d}_{g}(b)\pmod{p-1}. $$ 

The index map $\mathrm{ind}_{g}$ is also called the discrete logarithm to the base $g$ modulo $p$.

For example, 2 is a primitive root modulo 13. Here is a table of  $ \mathrm{ind}_{2}(a) $ for  $ a = 1, \ldots, 12 $:


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>ind_{2}(a)</td><td style='text-align: center; word-wrap: break-word;'>a</td><td style='text-align: center; word-wrap: break-word;'>ind_{2}(a)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>0</td><td style='text-align: center; word-wrap: break-word;'>7</td><td style='text-align: center; word-wrap: break-word;'>11</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>8</td><td style='text-align: center; word-wrap: break-word;'>3</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>9</td><td style='text-align: center; word-wrap: break-word;'>8</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>10</td><td style='text-align: center; word-wrap: break-word;'>10</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>5</td><td style='text-align: center; word-wrap: break-word;'>9</td><td style='text-align: center; word-wrap: break-word;'>11</td><td style='text-align: center; word-wrap: break-word;'>7</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>6</td><td style='text-align: center; word-wrap: break-word;'>5</td><td style='text-align: center; word-wrap: break-word;'>12</td><td style='text-align: center; word-wrap: break-word;'>6</td></tr></table>