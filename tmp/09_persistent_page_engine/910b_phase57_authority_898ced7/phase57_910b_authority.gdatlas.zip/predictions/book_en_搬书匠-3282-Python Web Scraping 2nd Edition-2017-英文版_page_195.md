The structure of the search results can be examined with your browser tools, as shown here:

<div style="text-align: center;"><img src="imgs/img_in_image_box_156_253_1345_933.jpg" alt="Image" width="79%" /></div>


Here, we see that the search results are structured as links whose parent element is a <h3> tag with class "r".

To scrape the search results, we will use a CSS selector, which was introduced in Chapter 2, Scraping the Data:

>>> from lxml.html import fromstring
>>> import requests
>>> html = requests.get('https://www.google.com/search?q=test')
>>> tree = fromstring(html.content)
>>> results = tree.cssselect('h3.r a')
>>> results
[ <Element a at 0x7f3d9affeaf8>,
<Element a at 0x7f3d9affe890>,
<Element a at 0x7f3d9affe8e8>,
<Element a at 0x7f3d9affeaa0>,
<Element a at 0x7f3d9bla9e68>,
<Element a at 0x7f3d9bla9c58>,
<Element a at 0x7f3d9bla9ec0>,
<Element a at 0x7f3d9bla9f18>,
<Element a at 0x7f3d9bla9f70>,
<Element a at 0x7f3d9bla9fc8>]