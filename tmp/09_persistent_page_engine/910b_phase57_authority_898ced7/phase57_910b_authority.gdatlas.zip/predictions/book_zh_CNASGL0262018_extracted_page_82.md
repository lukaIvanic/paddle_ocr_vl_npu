- EUT 与帧谱分析仪之间的链路 S 参数 0.724(m).. 损耗 2.8dB(d) 则

 $$ u_{ELT- 功分器 }=\frac{0.7\times0.099\times100}{\sqrt{2}\times11.5}=0.426dB $$ 

 $$ u_{ 功分器 - 衰减网络 }=\frac{0.099\times0.333\times100}{\sqrt{2}\times11.5}=0.203dB $$ 

 $$ u_{ 袁减网络 - 频谱仪 }=\frac{0.333\times0.091\times100}{\sqrt{2}\times11.5}=0.186\mathrm{d B} $$ 

 $$ u_{_{OUT-衰减网络}}=\frac{0.7\times0.333\times0.912\times0.912\times100}{\sqrt{2}\times11.5}=1.192dB $$ 

 $$ u_{ 功分器 - 频谱仪 }=\frac{0.099\times0.333\times0.794\times0.794\times100}{\sqrt{2}\times11.5}=0.128dB $$ 

 $$ u_{_{EUT- 频谱仪 }}=\frac{0.7\times0.091\times0.724\times0.724\times100}{\sqrt{2}\times11.5}=0.205dB $$ 

则  $ a\left(\theta\theta_{M}\right)=\sqrt{0.426^{2}+0.203^{2}+0.186^{2}+1.192^{2}+0.128^{2}+0.205^{2}}=1.3186dB $

##### 5.5.3.5 被测样供电电压变化引入的不确定度分量 $ w(i,t) $

在测试期间，实验室供电电压可控范围为0.1V，根据ETSI TR 100 028表F.1均值10%( $ p_{ij}/V $)

标准差 3%（p）

 $$ u(\delta P_{T})===\frac{0.1V\times\sqrt{(10\%/V)^{2}+(3\%/V)^{2}}}{\sqrt{3}\times23.0}=0.026\mathrm{d B} $$ 

5.5.3.6 时间周期变化引入的不确定度分量  $ u(\dot{\theta}_{0}) $

根据 ETSI TR 100 028 表 F.1，时间周期误差为  $ 2\%(d)(p)(n) $

 $$ u(\delta\mathbf{P}_{D})==\frac{2\%}{23.0}=0.087dB $$ 

#### 5.5.4 不确定度概算

<div style="text-align: center;">表5-10的导余散发射测量不确定度概算表</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>分量</td><td style='text-align: center; word-wrap: break-word;'>概率分布</td><td style='text-align: center; word-wrap: break-word;'>灵敏系数</td><td style='text-align: center; word-wrap: break-word;'>不确定度分量值（dB）</td></tr></table>