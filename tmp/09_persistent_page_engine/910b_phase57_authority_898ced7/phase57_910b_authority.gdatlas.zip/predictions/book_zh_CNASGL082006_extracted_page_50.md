 $$ P_{x}=\frac{w}{I}\quad w=\frac{n}{N}\times3.6\times10^{6} 瓦秒 $$ 

 $ P_{1} $——被测功率  $ W_{1} $

w——电度表累积测得电缆：

N——电度表每千瓦时盘转动数：

a——电度表的转数转：

——测量时间 S

## 3 方差与传播系数

 $$ u^{2}(P_{x})=\left(\frac{\partial f}{\partial w}\right)^{2}u^{2}(w)+\left(\frac{\partial f}{\partial t}\right)^{2}u^{2}(t)=c^{2}(w)u^{2}(w)+c^{2}(t)u^{2}(t) $$ 

 $$ c(w)=\frac{1}{t} $$ 

 $$ c(t)=-\frac{w}{t^{2}} $$ 

 $$ u^{2}(P_{x})=\frac{1}{t^{2}}u^{2}(w)+\frac{w^{2}}{t^{4}}u^{2}(t) $$ 

 $$ \left(\frac{u(P_{x})}{P_{x}}\right)^{2}=\frac{u^{2}(w)}{w^{2}}+\frac{u^{2}(t)}{t^{2}} $$ 

## 本不确定度分析以榨汁机为例

<div style="text-align: center;">表4-1</div>


## 4 标准不确定度—宽表

<div style="text-align: center;">标准不确定度一览表</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>标准不确定度量  $ u_i $</td><td style='text-align: center; word-wrap: break-word;'>不确定度来源</td><td style='text-align: center; word-wrap: break-word;'>标准不确定度值</td><td style='text-align: center; word-wrap: break-word;'>$ c_i = \tilde{c} / \tilde{c}x_i $</td><td style='text-align: center; word-wrap: break-word;'>$ |c_i| \times |u_i(x_i)| $</td><td style='text-align: center; word-wrap: break-word;'>自由度</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ u_1 $</td><td style='text-align: center; word-wrap: break-word;'>重复性误差</td><td style='text-align: center; word-wrap: break-word;'>0.2%</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>0.2%</td><td style='text-align: center; word-wrap: break-word;'>2</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ u_2 $</td><td style='text-align: center; word-wrap: break-word;'>表头示值误差</td><td style='text-align: center; word-wrap: break-word;'>0.29%</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>0.29%</td><td style='text-align: center; word-wrap: break-word;'>50</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>$ u_3 $</td><td style='text-align: center; word-wrap: break-word;'>电子移表误差</td><td style='text-align: center; word-wrap: break-word;'>0.02%</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>0.02%</td><td style='text-align: center; word-wrap: break-word;'>8</td></tr><tr><td colspan="6">$ u_4 $ ( $ P_i $) = 0.35%</td></tr></table>

 $$ \nu_{eff}=16 $$ 