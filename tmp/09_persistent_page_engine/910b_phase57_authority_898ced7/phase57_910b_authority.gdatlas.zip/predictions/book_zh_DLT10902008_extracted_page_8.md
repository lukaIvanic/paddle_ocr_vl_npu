4.1.3 可用系（AF）

 $$  AF=\frac{ 串联补偿装置的可用小时数 }{ 串联补偿装置的统计期间小时数 }\times100\%=\frac{AH}{PH}\times100\% $$ 

4.1.4 运行系数（SF）

 $$ \mathrm{SF}=\frac{ 串联补偿装置的运行小时数 }{ 串联补偿装置的统计期间小时数 }\times100\%=\frac{\mathrm{SH}}{\mathrm{PH}}\times100\% $$ 

4.1.5 平均无故障可用小时数（MTBF）

 $$ \mathrm{MTBF}=\frac{ 串联补偿装置的可用小时数 }{ 串联补偿装置的强迫停运的次数 }=\frac{\mathrm{AH}}{\mathrm{FOT}} $$ 

4.1.5 不可同系酸（沉W）

 $$ \mathrm{UF}=1-\mathrm{AF}=\frac{ 串联补偿装置的不可用小时数 }{ 串联补偿装置的统计期间小时数 }\times100\%=\frac{\mathrm{UH}}{\mathrm{PH}}\times100\% $$ 

4.2 对由两个及以上串联补偿装置组成的串联补偿系统，串联补偿系统的评价指标为串联等效可用系数（Series Equivalent Available Factor SEAF），其计算公式按式（7）进行统计。

 $$ \begin{aligned}SEAF=&\sum( 各串联补偿装置的额定补偿容量 \times 该串联补偿装置的可用时间 )\\& 该串联补偿系统的额定补偿容量 \times 统计期间 \\=&\sum\frac{(Q_{N}\times AH)}{Q_{N}\times PH}\times100\%\end{aligned} $$ 

## 5 填表要求

5.1 串联补偿装置基本情况表见表1.

5.2 非联补偿输黑基础事件表见表1.

5.3 本联补偿装置可应作自标汇总表记录3.

5.4 串联补偿装置防溢部件原图分类表见表九 7. 中车联补空装置部件分类参见附录8

<div style="text-align: center;">表1 串联补偿偏置基本情况表</div>


过廊日期：___年___月___日

均益单位：___


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td rowspan="5">串联补偿装置工程简况</td><td style='text-align: center; word-wrap: break-word;'>系统名称</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>串联补偿装置的类型</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>换运日期</td><td style='text-align: center; word-wrap: break-word;'>年 月 日</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>系统电压\nk/V</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>设备供货商</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td rowspan="5">串联补偿装置主要技术指标</td><td style='text-align: center; word-wrap: break-word;'>补偿度\n%</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>额定容量 $ Q_{{A}} $\nMvar/三相</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>额定容挑\nΩ/三相</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>额定电流\nkA</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>固定串联电容补偿装置的最大插埋电流 $ I_{{L}} $\nkA、10s</td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>