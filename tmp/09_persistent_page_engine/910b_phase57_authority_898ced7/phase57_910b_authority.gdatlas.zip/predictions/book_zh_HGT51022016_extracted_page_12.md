#### 5.4.3 操作

在 GB/T 2918 规定的标准状态下，测定试样的质量及表面积。在  $ 60^{\circ} $ 土 1 C 的温度下，将试样在表？规定的试验液中浸渍 8 h。然后用流动水冲洗大约 5 s，用于布擦干，放置在称量瓶中测定其质量。在焦糖水中浸渍过的试样不用水洗。

试验结果按公式（2）分期计算出各种试验满足使用的各2个试样在表面积不变的情况下的质量变化，取其平均值。

 $$  耐腐蚀性 =\frac{M_{2}-M_{1}}{A} $$ 

丈中：

 $ M_{1} $——浸渍前的质量的数值，单位为毫克（mg）；

 $ M_{1} $——玻璃前的质量的数值。单位为毫克（mg）。

A——试验片试验前的全部表面积的数值，单位为平方厘米（cm²）。

## 检验规则

### 6.1 检验分类与项目

1.1 产品检验分为出厂检验和型式检验，检验项目见表1.

<div style="text-align: center;">表8 出厂检验和型式检验项目</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="2">要求的条文和名称</td><td style='text-align: center; word-wrap: break-word;'>对应的试验方法条文</td><td style='text-align: center; word-wrap: break-word;'>出厂检验</td><td style='text-align: center; word-wrap: break-word;'>型式检验</td></tr><tr><td colspan="2">4.1 外观</td><td style='text-align: center; word-wrap: break-word;'>5.1 外观检查</td><td style='text-align: center; word-wrap: break-word;'>✓</td><td style='text-align: center; word-wrap: break-word;'>✓</td></tr><tr><td colspan="2">4.2 尺寸</td><td style='text-align: center; word-wrap: break-word;'>5.2 尺寸检查</td><td style='text-align: center; word-wrap: break-word;'>✓</td><td style='text-align: center; word-wrap: break-word;'>✓</td></tr><tr><td rowspan="4">4.3 性能</td><td style='text-align: center; word-wrap: break-word;'>拉伸强度</td><td style='text-align: center; word-wrap: break-word;'>5.3.2 拉伸强度试验</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>✓</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>维卡软化温度</td><td style='text-align: center; word-wrap: break-word;'>5.3.3 维卡软化温度试验</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>✓</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>线热收缩率</td><td style='text-align: center; word-wrap: break-word;'>5.3.4 线热收缩率试验</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>✓</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>化学性能(耐腐蚀性)</td><td style='text-align: center; word-wrap: break-word;'>5.4 化学性能(耐腐蚀性)试验</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>✓</td></tr></table>

4.1.2 出厂检验项目为外载质量（4.1）：尺寸及偏差（4.2）：轴样预批进行，每批随机检验2处。

6.1.3 型式检验项目为全部检验项目（4.1～4.3）。

有下列情况之一时，应进行整式检验：

(a) 新产品或老产品转厂生产的试制定型鉴定。

b）正式生产后，加结构、材料、工艺有较大改变，可能影响产品性能时。

正常生产时，定期或积累一定产量后，应用刚性进行一次检验，一般两年进行一次检验。

(3) 产品长期停产后，恢复生产时。

(3) 光厂检验结果与上次型式检验有较大差异时：

(3) 国家质量监督机构提出型式检验的要求时：

(6) 用户需出行型式检验的要求时。

### 6.2 组批规则及判定

#### 4.2.1 位置

以同一材料成分、相同工艺以及同一新生产出的制品为一级。