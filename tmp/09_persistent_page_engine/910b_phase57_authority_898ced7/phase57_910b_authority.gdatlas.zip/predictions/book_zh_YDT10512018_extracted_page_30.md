### C.3 本标准用电可靠性指标公式

市电不可用度指标关公式（C.1）

 $$  市电不可用度 =\frac{ 市电停电时间 }{ 统计期时间 }=1- 市电供电可靠率 $$ 

平均年停电时间指标见公式（C.2）。

 $$  平均年停电时间 = 市电不可用度 \times365\times24 $$ 

平均年停电次数指标见公式（C3）：

 $$  平均年停电次数 = 市电在一年统计期内平均停电次数 $$ 

### C.A 本标准存电可靠性指标取值

本标准取市中心市电可靠性指标平均值为一类市电可靠性指标。取市区+城镇市电可靠性指标平均值为二类市电可靠性指标，取农村市电可靠性指标平均值为三类市电可靠性指标。见表C3。

<div style="text-align: center;">表C.3 本标准用电可靠性指标取值</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>市电可靠性取值</td><td style='text-align: center; word-wrap: break-word;'>市中心（1）</td><td style='text-align: center; word-wrap: break-word;'>市区+城镇（2+3）</td><td style='text-align: center; word-wrap: break-word;'>农村（4）</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>市电供电可靠率（%）</td><td style='text-align: center; word-wrap: break-word;'>99.9615</td><td style='text-align: center; word-wrap: break-word;'>99.951</td><td style='text-align: center; word-wrap: break-word;'>99.855</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>市电不可用度</td><td style='text-align: center; word-wrap: break-word;'>$ 3.85 \times 10^{4} $</td><td style='text-align: center; word-wrap: break-word;'>$ 4.90 \times 10^{4} $</td><td style='text-align: center; word-wrap: break-word;'>$ 1.45 \times 10^{3} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>平均年停电时间（小时）</td><td style='text-align: center; word-wrap: break-word;'>3.37</td><td style='text-align: center; word-wrap: break-word;'>4.29</td><td style='text-align: center; word-wrap: break-word;'>12.70</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>平均年停电次数</td><td style='text-align: center; word-wrap: break-word;'>0.74</td><td style='text-align: center; word-wrap: break-word;'>1.12</td><td style='text-align: center; word-wrap: break-word;'>3.03</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>市电类别</td><td style='text-align: center; word-wrap: break-word;'>一类市电</td><td style='text-align: center; word-wrap: break-word;'>二类市电</td><td style='text-align: center; word-wrap: break-word;'>三类市电</td></tr></table>