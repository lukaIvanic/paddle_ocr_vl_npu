<div style="text-align: center;"><img src="imgs/img_in_image_box_0_0_1651_2243.jpg" alt="Image" width="99%" /></div>
