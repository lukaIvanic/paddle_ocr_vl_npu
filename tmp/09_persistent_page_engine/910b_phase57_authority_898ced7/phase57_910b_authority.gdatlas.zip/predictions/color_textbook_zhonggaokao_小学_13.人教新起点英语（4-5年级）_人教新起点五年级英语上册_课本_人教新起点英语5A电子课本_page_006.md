## Lesson 1

## A Listen and match

<div style="text-align: center;"><img src="imgs/img_in_image_box_214_297_417_541.jpg" alt="Image" width="12%" /></div>


Peter

<div style="text-align: center;"><img src="imgs/img_in_image_box_476_339_752_529.jpg" alt="Image" width="16%" /></div>


Helen

<div style="text-align: center;"><img src="imgs/img_in_image_box_901_312_1182_526.jpg" alt="Image" width="16%" /></div>


Tom

<div style="text-align: center;"><img src="imgs/img_in_image_box_1244_372_1361_539.jpg" alt="Image" width="7%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1378_299_1534_536.jpg" alt="Image" width="9%" /></div>


Mary

<div style="text-align: center;"><img src="imgs/img_in_image_box_165_681_465_911.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_533_674_748_920.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_897_679_1241_911.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1243_675_1560_907.jpg" alt="Image" width="19%" /></div>


## B Think and say

Let's talk about our classmates.

Lily is cute.

And she's friendly, too.

<div style="text-align: center;"><img src="imgs/img_in_image_box_426_1165_1294_1555.jpg" alt="Image" width="52%" /></div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>clever</td><td style='text-align: center; word-wrap: break-word;'>careless</td><td style='text-align: center; word-wrap: break-word;'>quiet</td><td style='text-align: center; word-wrap: break-word;'>friendly</td><td style='text-align: center; word-wrap: break-word;'>popular</td><td style='text-align: center; word-wrap: break-word;'>active</td><td style='text-align: center; word-wrap: break-word;'>polite</td><td style='text-align: center; word-wrap: break-word;'>cute</td><td style='text-align: center; word-wrap: break-word;'>helpful</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Lily</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>✓</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>✓</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

## Let's write

Lily is friendly and _____.

___ is ___ and ___.

 $ \underline{\text{is}} $  $ \underline{\text{and}} $