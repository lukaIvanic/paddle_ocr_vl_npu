### 3. Now read and tick

make

model ships

( )

make

model planes

( )

cute ()

clever

( )

helpful ()

polite ()

popular ()

active

( )

quiet

( )

careless

( )

## Let's play a guessing game

## Talk about our friends

<div style="text-align: center;"><img src="imgs/img_in_image_box_449_954_1243_1343.jpg" alt="Image" width="48%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_100_1375_1567_1874.jpg" alt="Image" width="88%" /></div>


## Let's write

What is Peter like?