### 3. Fill in the blanks

(1) Joe often answers questions in English class. He is ___.

(2) Joe is good at science. He is ___.

(3) Sometimes Joe is ___. He likes reading and thinking.

(4) He often says "Hello" and "Thank you" to everyone in the family. He is ___.

(5) He often helps Tom's family. He is _____.

## B Let's talk

<div style="text-align: center;"><img src="imgs/img_in_image_box_116_773_1597_1307.jpg" alt="Image" width="89%" /></div>


## Let's write

### Tom wants to introduce Joe to his classmates. Let's help him make a brief introduction

• What is Joe like?

• What is he good at?

• What does he usually do? ...

<div style="text-align: center;"><img src="imgs/img_in_image_box_164_1757_307_1954.jpg" alt="Image" width="8%" /></div>


This is Joe. He is ___