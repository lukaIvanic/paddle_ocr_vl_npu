## Let's Spell

## A Listen, point and repeat

<div style="text-align: center;"><img src="imgs/img_in_image_box_190_334_394_530.jpg" alt="Image" width="12%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_476_332_689_530.jpg" alt="Image" width="12%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_898_330_1126_537.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1180_357_1400_530.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_167_599_413_805.jpg" alt="Image" width="14%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_511_606_645_806.jpg" alt="Image" width="8%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_937_607_1094_814.jpg" alt="Image" width="9%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1170_621_1410_815.jpg" alt="Image" width="14%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_180_890_399_1010.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_497_889_721_1096.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_852_868_1107_1095.jpg" alt="Image" width="15%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1186_887_1394_1093.jpg" alt="Image" width="12%" /></div>


## B Listen, colour and repeat

1.  $ \underline{cl} $ ock

2.  $ \underline{bl} $ue

3.  $ \underline{cl} $ ass

4.

 $$ \frac{\mathrm{s l}}{\mathrm{f l}}\mathrm{O W} $$ 

5. $ \frac{f1}{sl}y $

6.  $ \underline{pl} $  $ \underline{cl} $ ay

7. $ \frac{sl}{pl} $ ant

8.  $ \underline{gl} $ ide

## Listen, write and say

Ms _____ is slim. She wears _____. Her gloves are _____.

## D Listen and repeat

My little blue plane

Is flying in the sky.

It flies very slowly,

But it climbs up high.

<div style="text-align: center;"><img src="imgs/img_in_image_box_945_1832_1412_2167.jpg" alt="Image" width="28%" /></div>
