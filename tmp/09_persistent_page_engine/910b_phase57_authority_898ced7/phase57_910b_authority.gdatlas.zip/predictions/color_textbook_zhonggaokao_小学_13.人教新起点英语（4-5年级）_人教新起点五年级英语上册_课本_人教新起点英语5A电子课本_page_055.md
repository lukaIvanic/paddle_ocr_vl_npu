## Let's Check

## A Listen and put the things into the right bag

<div style="text-align: center;"><img src="imgs/img_in_image_box_94_353_393_906.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_455_327_810_888.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_827_451_1179_990.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1261_375_1557_883.jpg" alt="Image" width="17%" /></div>


## B Let's play

Choose a picture and make a dialogue.

<div style="text-align: center;"><img src="imgs/img_in_image_box_97_1156_813_1586.jpg" alt="Image" width="43%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_841_1152_1570_1636.jpg" alt="Image" width="44%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_150_1628_1562_2125.jpg" alt="Image" width="85%" /></div>
