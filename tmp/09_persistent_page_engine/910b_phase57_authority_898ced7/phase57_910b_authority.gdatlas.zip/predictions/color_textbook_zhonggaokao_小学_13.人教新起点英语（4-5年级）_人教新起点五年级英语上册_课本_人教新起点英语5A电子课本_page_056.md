## © Read, choose and write

<div style="text-align: center;"><img src="imgs/img_in_image_box_110_236_305_548.jpg" alt="Image" width="11%" /></div>


Tomorrow is my first day back at school. I want to buy a new schoolbag. First my mum and I go to Xinxin Stationery Shop. I see a big orange bag there. It's 70 yuan. My mum likes it, but I don't like orange. I want a blue bag.

Lucy

Then we go to Headstart School Shop. There is a blue bag there. It's 110 yuan, but I only have 100 yuan.

Then we go to Kids Right Shop. There is a blue bag there. It's small, but it's 60 yuan. I buy it. I'm very happy.

Which bag does Lucy buy?

<div style="text-align: center;"><img src="imgs/img_in_image_box_212_794_514_1169.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_695_790_992_1170.jpg" alt="Image" width="17%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1157_798_1469_1169.jpg" alt="Image" width="18%" /></div>


## ⑨ Answer the questions and draw your bag

1. What colour is your school bag?

2. How much is it?

___.

3. Do you like it?



## Checkpoint


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>structures</td><td style='text-align: center; word-wrap: break-word;'>vocabulary</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>How much is it? It&#x27;s ...</td><td style='text-align: center; word-wrap: break-word;'>exercise book, pencil sharpener, a pair of scissors, pencil box, a box of crayons, please</td></tr></table>