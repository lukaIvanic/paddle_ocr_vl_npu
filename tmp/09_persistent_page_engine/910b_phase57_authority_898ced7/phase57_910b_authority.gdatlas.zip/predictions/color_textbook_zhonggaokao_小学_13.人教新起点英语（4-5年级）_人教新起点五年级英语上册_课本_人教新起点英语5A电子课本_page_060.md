## Lesson 1

## A Listen and match

<div style="text-align: center;"><img src="imgs/img_in_image_box_130_299_356_506.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_462_302_655_503.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_761_302_947_509.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1053_280_1222_508.jpg" alt="Image" width="10%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1327_312_1479_502.jpg" alt="Image" width="9%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_79_630_339_812.jpg" alt="Image" width="15%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_382_672_661_840.jpg" alt="Image" width="16%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_702_630_972_810.jpg" alt="Image" width="16%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1012_655_1275_827.jpg" alt="Image" width="15%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1330_625_1588_811.jpg" alt="Image" width="15%" /></div>


## B Let's talk

<div style="text-align: center;"><img src="imgs/img_in_image_box_289_1189_1134_1649.jpg" alt="Image" width="51%" /></div>


## Let's write

My favourite TV shows are _____.

My grandmother's favourite TV shows are _____.

My grandfather's favourite TV shows are ___.

My father's favourite TV shows are _____.

My mother's favourite TV shows are _____.