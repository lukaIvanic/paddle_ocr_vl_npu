## Lesson 3

## A Let's read

1. Read the letter from Worried. Do you have the same problem?

Dear Linda,

I always feel tired and sleepy. I sometimes sleep in class. I like my teachers and I like all my subjects, but I don't get good marks. At night I can't sleep, so I go on the computer or watch TV. It's not good. What should I do?

Dear Worried,



Worried

Many students have this problem. You are going to be OK. I have some advice for you. First, you should exercise every day. Play football or basketball with your classmates or do morning exercises. Next, you shouldn't play too much on the computer or watch too much TV. So turn off the TV and computer at 9 pm. Try to walk more and help your mum do some housework. Finally, you should go to bed before 9:30. Try these things. I think you'll soon feel better.



Linda

2. Linda writes a letter to Worried to tell him ___.

A. how to play computer games

B. how to feel better

C. how to make new friends

3. Fill in the chart.


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Worried&#x27;s problems</td><td style='text-align: center; word-wrap: break-word;'>Linda&#x27;s advice to Worried</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>1. He always feels ____ and ____.2. He doesn&#x27;t get good ____.3. He sometimes ____ in class.</td><td style='text-align: center; word-wrap: break-word;'>1. He should ____every day.2. He shouldn’t play too much on the ____or watch too much ____.3. He should ____ 9:30.</td></tr></table>