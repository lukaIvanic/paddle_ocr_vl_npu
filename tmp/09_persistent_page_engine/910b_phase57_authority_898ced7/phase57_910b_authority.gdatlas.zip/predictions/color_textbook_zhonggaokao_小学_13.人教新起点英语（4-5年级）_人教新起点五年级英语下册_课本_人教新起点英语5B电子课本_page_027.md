## Let's Check

## A Listen and tick

Children's Day

<div style="text-align: center;"><img src="imgs/img_in_image_box_508_322_599_408.jpg" alt="Image" width="5%" /></div>


Mother's Day

<div style="text-align: center;"><img src="imgs/img_in_image_box_1047_324_1377_405.jpg" alt="Image" width="19%" /></div>


New Year's Day

Teachers' Day

<div style="text-align: center;"><img src="imgs/img_in_image_box_1046_551_1424_632.jpg" alt="Image" width="22%" /></div>


National Day

<div style="text-align: center;"><img src="imgs/img_in_image_box_503_770_596_862.jpg" alt="Image" width="5%" /></div>


Mid-Autumn Festival

Spring Festival

<div style="text-align: center;"><img src="imgs/img_in_image_box_504_1010_599_1099.jpg" alt="Image" width="5%" /></div>


Tree Planting Day

<div style="text-align: center;"><img src="imgs/img_in_image_box_1046_1014_1355_1094.jpg" alt="Image" width="18%" /></div>


## B Read, match and underline the activities

Children’s Day

June 1st

It is the most important holiday for us. All our family get together and eat special food, like roast turkey. We also give each other presents. In Australia, Christmas is in the summer, and we often go to the beach!



Christmas Day

Dec 25th

This week we are going to have a very special day. I’m not going to go to school – it’s a holiday. I’m going to meet my friends in the park and we’re going to play many games. In the evening, I’m going to eat ice-cream.

