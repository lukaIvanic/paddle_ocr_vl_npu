## B Choose, think and say

<div style="text-align: center;"><img src="imgs/img_in_image_box_920_226_1536_363.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_760_385_1021_672.jpg" alt="Image" width="15%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1040_370_1280_676.jpg" alt="Image" width="14%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_185_855_665_1132.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_798_706_1107_831.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_717_842_1197_1171.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1228_699_1539_1177.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_169_1214_837_1540.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_877_1211_1539_1543.jpg" alt="Image" width="40%" /></div>


## Draw and write

What would you like to do on Children's Day?

<div style="text-align: center;"><img src="imgs/img_in_image_box_1108_1556_1537_1870.jpg" alt="Image" width="25%" /></div>
