## B Do a survey

Please interview your friends and find out what they would like to do on special days.

What's your favourite special day?

What would you like to do?

Would you like to make a phone call or send a message?

My favourite special day is Teachers' Day. It's coming soon.

I'd like to buy some flowers and make a card for my teacher.

I'd like to call her.

<div style="text-align: center;"><img src="imgs/img_in_image_box_638_878_986_1232.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1068_847_1430_1190.jpg" alt="Image" width="21%" /></div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>name</td><td style='text-align: center; word-wrap: break-word;'>Bill</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>special day</td><td style='text-align: center; word-wrap: break-word;'>Teachers&#x27; Day</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>things he/she would like to do</td><td style='text-align: center; word-wrap: break-word;'>buy some flowers make a card make a phone call</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>

## Let's write

<div style="text-align: center;"><img src="imgs/img_in_image_box_231_1732_473_1986.jpg" alt="Image" width="14%" /></div>


What would you like to do on Spring Festival?