## Revision 1

## Let's Review

## A Listen and number

<div style="text-align: center;"><img src="imgs/img_in_image_box_907_896_1447_1311.jpg" alt="Image" width="32%" /></div>


## B Let's play