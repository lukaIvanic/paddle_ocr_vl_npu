## Lesson 1

## A Look, listen and repeat

<div style="text-align: center;"><img src="imgs/img_in_image_box_99_339_1174_1079.jpg" alt="Image" width="65%" /></div>


## Shopping List

a knife

an eraser

a glue stick

a ruler

a schoolbag

books √

crayons √

pens

pencils

scissors

paper

## B Let's role-play

<div style="text-align: center;"><img src="imgs/img_in_image_box_112_1207_1475_1790.jpg" alt="Image" width="82%" /></div>


## Let's write

Do you have

Do you have

?Yes, we do.

? Sorry, we don't.