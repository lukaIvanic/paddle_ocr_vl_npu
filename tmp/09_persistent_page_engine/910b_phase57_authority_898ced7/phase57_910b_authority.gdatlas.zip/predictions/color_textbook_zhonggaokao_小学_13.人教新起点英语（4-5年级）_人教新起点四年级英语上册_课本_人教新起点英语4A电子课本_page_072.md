## Revision 2

## Let's Review

## A Look, listen and choose

<div style="text-align: center;"><img src="imgs/img_in_image_box_94_477_443_682.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_440_478_783_684.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_788_476_1128_688.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1131_477_1458_695.jpg" alt="Image" width="19%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_101_742_471_995.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_457_750_808_1005.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_805_756_1148_997.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1148_759_1456_1005.jpg" alt="Image" width="18%" /></div>


## B Choose and say

<div style="text-align: center;"><img src="imgs/img_in_image_box_252_1138_498_1456.jpg" alt="Image" width="14%" /></div>


This is Ann. She likes delicious food.

She is good at cooking.

She wants to be a cook in the future.

Name: Nancy

Favourite things: animals

and plants



<div style="text-align: center;"><img src="imgs/img_in_image_box_626_1484_739_1613.jpg" alt="Image" width="6%" /></div>


Good at: planting flowers

Wants to be: a farmer

Name: Ann

Favourite things: delicious food

Good at: cooking

Wants to be: a cook



<div style="text-align: center;"><img src="imgs/img_in_image_box_1253_1455_1363_1572.jpg" alt="Image" width="6%" /></div>


Name: Sam

<div style="text-align: center;"><img src="imgs/img_in_image_box_563_1827_678_1962.jpg" alt="Image" width="6%" /></div>


Favourite things: cars

Good at: driving bumper cars



Wants to be: a driver

Name:

Favourite things:

Good at:

Wants to be:

<div style="text-align: center;"><img src="imgs/img_in_image_box_1251_1823_1425_2001.jpg" alt="Image" width="10%" /></div>
