## Unit 5

## A Listen, point and repeat

<div style="text-align: center;"><img src="imgs/img_in_image_box_192_355_495_582.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_512_359_865_581.jpg" alt="Image" width="21%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_886_374_1480_576.jpg" alt="Image" width="35%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_185_688_467_1018.jpg" alt="Image" width="17%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_661_770_792_905.jpg" alt="Image" width="7%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_969_689_1463_1014.jpg" alt="Image" width="29%" /></div>


三年级下册

Unit 1

## A Listen, point and say

<div style="text-align: center;"><img src="imgs/img_in_image_box_190_1397_476_1550.jpg" alt="Image" width="17%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_635_1384_979_1574.jpg" alt="Image" width="20%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_196_1684_484_1943.jpg" alt="Image" width="17%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_663_1672_981_1943.jpg" alt="Image" width="19%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1081_1371_1444_1947.jpg" alt="Image" width="21%" /></div>
