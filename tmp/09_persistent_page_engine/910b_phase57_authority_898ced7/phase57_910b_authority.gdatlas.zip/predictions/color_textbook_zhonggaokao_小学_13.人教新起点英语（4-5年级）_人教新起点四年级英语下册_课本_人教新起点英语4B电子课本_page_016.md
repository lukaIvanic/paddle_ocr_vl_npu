<div style="text-align: center;"><img src="imgs/img_in_image_box_149_123_1502_645.jpg" alt="Image" width="81%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_151_664_835_1067.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_146_1219_825_1631.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_850_666_1503_1626.jpg" alt="Image" width="39%" /></div>


## B Draw the route

<div style="text-align: center;"><img src="imgs/img_in_image_box_178_1755_1486_2166.jpg" alt="Image" width="79%" /></div>
