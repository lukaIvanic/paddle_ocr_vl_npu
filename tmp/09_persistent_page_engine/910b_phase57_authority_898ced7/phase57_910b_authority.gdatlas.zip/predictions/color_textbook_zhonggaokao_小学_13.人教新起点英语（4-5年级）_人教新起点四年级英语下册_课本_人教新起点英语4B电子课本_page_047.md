## Lesson 3

## Read and write

This is my family's hobby book. I like collecting stamps. I have over 200 stamps. I also like skateboarding. I think it is very cool. My mother likes drawing. She is really good at it. My father likes fishing. He often goes fishing but never catches any fish. My cat likes eating fish. She often goes with my father, but she never gets any fish!



<div style="text-align: center;"><img src="imgs/img_in_image_box_1159_264_1354_461.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_100_886_914_1230.jpg" alt="Image" width="49%" /></div>


## B Read again and write

Bob likes _____.

His mother likes _____.

His father likes _____.

His cat likes _____.

I like _____.

My ___.