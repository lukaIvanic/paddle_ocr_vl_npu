## Let's Spell

## A Listen, point and repeat

<div style="text-align: center;"><img src="imgs/img_in_image_box_159_340_393_591.jpg" alt="Image" width="14%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_547_314_765_590.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_889_330_1105_584.jpg" alt="Image" width="13%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1244_330_1440_586.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_214_691_346_879.jpg" alt="Image" width="7%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_555_643_712_872.jpg" alt="Image" width="9%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_879_592_1075_870.jpg" alt="Image" width="11%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1211_604_1471_869.jpg" alt="Image" width="15%" /></div>


### B Read aloud. Then listen and check

king

wing

going

strong

wrong

## C Listen and write

<div style="text-align: center;"><img src="imgs/img_in_image_box_655_1136_737_1214.jpg" alt="Image" width="4%" /></div>


1. I like _____ _____ .

<div style="text-align: center;"><img src="imgs/img_in_image_box_893_1126_1195_1361.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_184_1386_532_1552.jpg" alt="Image" width="21%" /></div>


2. The bird has _____ _____.

3. _____ is easier than _____.

Fly!

<div style="text-align: center;"><img src="imgs/img_in_image_box_1022_1508_1423_1682.jpg" alt="Image" width="24%" /></div>


## D Listen and repeat

My mother likes singing,

Singing happy songs.

My father likes reading,

Reading books all day long.

But I like running

And playing ping-pong!

<div style="text-align: center;"><img src="imgs/img_in_image_box_857_1760_1460_2156.jpg" alt="Image" width="36%" /></div>
