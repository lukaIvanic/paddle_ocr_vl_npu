<div style="text-align: center;"><img src="imgs/img_in_image_box_181_124_412_196.jpg" alt="Image" width="13%" /></div>


# ⚖️🌧

often (adv) 经常

oil (n) 油，油画颜料

· car oil

cooking oil

OK/O.K./okay (exclaim) 好，不错，可以

old (adj) 旧的，老的

omelette (n) 煎蛋

on (prep & adv) 在...之上，作用中

once (adv) 一次，曾经

only once

one (pron, det & num) 一，任何人

onion (n) 洋葱

only (adv & adj) 只，仅仅，唯一的

• I only wanted to help.

· the only one

open (adj & v) 开著的，开放的，打开，公开

opera (n) 歌剧

opposite (prep) 在...对面

orange (adj & n) 橙色的，橘子

or (conj) 或者，还是

other (det) 别的，其他的

our (pron) 我们的

ours (pron) 我们的

ourselves (pron) 我们自己

out (adv) 在外，出现

outdoor (adj) 户外的，屋外的

outdoors (adv) 在户外，在野外

outside (prep & adv) 在...外，在外面

over (prep & adv) 在...的上方，结束

over 60 people (prep)

• to travel all over the world (adv)

own (adj) 自己的，特有的

paint(v & n) 油漆，绘画

• They cook their own meals.

pack(v) 包装，捆扎，塞满

• pack a suitcase

pair (n) 双，对，副

page(n) 页

## P

• a pair of shoes

part (n) 部份，零件，角色

paper (n & adj) 纸，文件，纸做的

pardon (v & n) 原谅，赦免

· Pardon?

park (n & v) 公园，停车，停车场，置于

the best part of the day

• You pass the station on the left.

party(n) 政党，聚会

parent(n) 父母，父母亲

pain(n) 痛苦，疼痛，辛苦

pass (v) 经过，通过，传递

• to pass a driving test

pay for (phr v) 偿还，付款

path(n) 路线，轨道，路程，小路，小径

passport(n) 护照

passenger(n) 乘客，旅客

past (prep) 经过，晚于

pay(v) 支付，付清，报偿

pasta(n) 生面团，意大利通心粉

pencil (n) 铅笔

people(n) 民族，人，人们

pence (n pl) 便士

pen(n) 钢笔

pepper(n) 胡椒粉

per (prep) 每，每一

pen-friend (n) 笔友

perhaps (adv) 也许，可能

person (n) 人

pet(n) 宠物

petrol(n) 汽油

petrol station (n) 加油站

pharmacy(n) 药房，配药学

phone (v & n) 打电话，电话

photo(graph) (n) 照片

photography (n) 摄影术

piano (n) 钢琴

KET 高频词汇表

<div style="text-align: center;"><img src="imgs/img_in_image_box_162_2062_1462_2175.jpg" alt="Image" width="78%" /></div>
