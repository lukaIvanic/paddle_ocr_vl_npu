## KET 口语 Part 1 演示

## place of origin/school 来自哪里/学校

Where do you come from?

What do you study?

Do you like your studies?

Do you study English at school?

Do you like your school?

What is your favourite subject?

Why do you like it?



information about self 个人信息

Where do you go at the weekend?

Who do you like spending time with?

## KET 口语 Part 1 演示

tell me something about... 即兴问答

Where did you go last weekend?

Tell me something about your future job

Tell me something about your free time

<div style="text-align: center;"><img src="imgs/img_in_image_box_1263_973_2230_1224.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;">PART 1</div>
