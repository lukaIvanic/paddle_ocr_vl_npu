## 第四课 口语部分Part 2详解下

轻松搞定 KET口语25分

## 内容提要

KET 口语part 2 问题卡怎么看

KET 口语part 2 重点句型

KET 口语 part 2 信息卡、问题卡综合训练

KET 口语 part 2 专项训练

<div style="text-align: center;"><img src="imgs/img_in_image_box_1306_98_2307_696.jpg" alt="Image" width="42%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_61_922_1032_1594.jpg" alt="Image" width="41%" /></div>


## KET口语 part 2 考试技巧

Give clear answers

Only use the information in the booklet

Can't get higher marks for adding extra information

KET口语 part 2 重点句型

问名字：What's the name of the show?

问日期：When's the show?

问时间：What time does the show start?

问地址：Where's the show?