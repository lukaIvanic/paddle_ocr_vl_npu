<div style="text-align: center;"><img src="imgs/img_in_image_box_489_167_558_227.jpg" alt="Image" width="5%" /></div>


## 互动学习

## 重点讲解·吃透教材

## 认读和书写：Mm 和 Nn 并掌握其基本读音

<div style="text-align: center;"><img src="imgs/img_in_image_box_238_341_462_431.jpg" alt="Image" width="16%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_505_342_730_432.jpg" alt="Image" width="16%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_236_451_462_542.jpg" alt="Image" width="16%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_504_451_731_543.jpg" alt="Image" width="17%" /></div>


## 指点迷津·提升能力

英语字母分为大写字母和小写字母，都写在四线三格中。大写字母占一二两格，小写字母大部分都在四线三格的第二格中。书写时要注意笔顺。

字母 M 的发音是浊辅音 /m/, 双唇轻合，舌面平放，气流通过鼻腔，振动声带发音。



字母 N 的发音是浊辅音 /n/，唇齿微开，舌前端抵上门齿，软腭下垂，气流通过鼻腔，振动声带发音。

## 小试牛刀

<div style="text-align: center;"><img src="imgs/img_in_image_box_500_682_547_740.jpg" alt="Image" width="3%" /></div>


## Read and colour（认读下面单词，并为你会读的单词下面的笑脸涂色）


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>milk</td><td style='text-align: center; word-wrap: break-word;'>man</td><td style='text-align: center; word-wrap: break-word;'>night</td><td style='text-align: center; word-wrap: break-word;'>nice</td><td style='text-align: center; word-wrap: break-word;'>mum</td></tr><tr><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_421_866_477_922.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_524_866_583_922.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_631_867_688_921.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_737_867_794_921.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_844_866_899_921.jpg" alt="Image"" /></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>mother</td><td style='text-align: center; word-wrap: break-word;'>noodles</td><td style='text-align: center; word-wrap: break-word;'>my</td><td style='text-align: center; word-wrap: break-word;'>me</td><td style='text-align: center; word-wrap: break-word;'>net</td></tr><tr><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_420_993_477_1047.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_525_992_583_1048.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_631_992_688_1048.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_737_992_794_1048.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_844_992_900_1048.jpg" alt="Image"" /></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>name</td><td style='text-align: center; word-wrap: break-word;'>new</td><td style='text-align: center; word-wrap: break-word;'>nose</td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_746_1066_789_1096.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'>Mrs</td></tr><tr><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_418_1119_479_1175.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_524_1119_585_1175.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_631_1118_690_1175.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_737_1118_796_1175.jpg" alt="Image"" /></td><td style='text-align: center; word-wrap: break-word;'><img src="imgs/img_in_image_box_842_1117_901_1175.jpg" alt="Image"" /></td></tr></table>

<div style="text-align: center;"><img src="imgs/img_in_image_box_498_1204_549_1263.jpg" alt="Image" width="3%" /></div>


## 单元复习

## 一、 能力要求

能综合运用本单元所学的词汇和句型，能对儿童乐园中常见的游乐设施进行描述。

## 二、 方法指导

1. 有关 can 的特殊疑问句的问答

(1) —What can you do? 你会做什么？—I can sing. 我会唱歌。（回答的句型：I can+动词原形）

(2) —What can you see? 你能看见什么？—I can see a slide. 我能看见一个滑梯。（回答的句型：I can see+名词）

（3）—What can you hear？你能听见什么？—I can hear a bus. 我能听见一辆公交车。（回答的句型：I can hear+名词）

(4)—What can you draw? 你会画什么？—I can draw a flower. 我会画一朵花。(回答的句