<div style="text-align: center;"><img src="imgs/img_in_image_box_514_145_563_206.jpg" alt="Image" width="3%" /></div>


## 词汇清单


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>单词</td><td style='text-align: center; word-wrap: break-word;'>音标</td><td style='text-align: center; word-wrap: break-word;'>词性</td><td style='text-align: center; word-wrap: break-word;'>词义</td><td style='text-align: center; word-wrap: break-word;'>运用</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>beautiful</td><td style='text-align: center; word-wrap: break-word;'>/ˈbjuːtɪfl/</td><td style='text-align: center; word-wrap: break-word;'>adj.</td><td style='text-align: center; word-wrap: break-word;'>美丽的</td><td style='text-align: center; word-wrap: break-word;'>What a beautiful flower! 多美的一朵花啊! Linda has a beautiful doll. 琳达有一个漂亮的洋娃娃。</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>rainbow</td><td style='text-align: center; word-wrap: break-word;'>/ˈreɪnbəʊ/</td><td style='text-align: center; word-wrap: break-word;'>n.</td><td style='text-align: center; word-wrap: break-word;'>彩虹</td><td style='text-align: center; word-wrap: break-word;'>There is a rainbow in the sky. 天空中挂着一道彩虹。 Do you like the rainbow? 你喜欢那道彩虹吗?</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>shine</td><td style='text-align: center; word-wrap: break-word;'>/ʃaɪn/</td><td style='text-align: center; word-wrap: break-word;'>v.</td><td style='text-align: center; word-wrap: break-word;'>照耀;闪耀</td><td style='text-align: center; word-wrap: break-word;'>The sun shines through the window. 阳光透过窗户照耀进来。 It&#x27;s a beautiful morning and the sun is shining. 这是个迷人的早晨,阳光照耀。</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>outside</td><td style='text-align: center; word-wrap: break-word;'>/aʊtˈsaɪd/</td><td style='text-align: center; word-wrap: break-word;'>adv. &amp; prep.</td><td style='text-align: center; word-wrap: break-word;'>在外面</td><td style='text-align: center; word-wrap: break-word;'>I can hear the dog barking outside. 我能听到外面的狗叫声。 Paul puts on the coat and walks outside. 保罗穿上大衣走了出去。</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>window</td><td style='text-align: center; word-wrap: break-word;'>/ˈwɪndəʊ/</td><td style='text-align: center; word-wrap: break-word;'>n.</td><td style='text-align: center; word-wrap: break-word;'>窗户;橱窗</td><td style='text-align: center; word-wrap: break-word;'>It&#x27;s cold outside. Can you close the window for me, please? 外面很冷。你能为我关窗吗? I do like the beautiful dress in the window. 我很喜欢橱窗里那条漂亮的连衣裙。</td></tr></table>

<div style="text-align: center;"><img src="imgs/img_in_image_box_501_1190_574_1250.jpg" alt="Image" width="5%" /></div>


## 互动学习

## 重点讲解·吃透教材

## see 和 look 的区别

see 通常指看的客观结果，即“看见”，后面可以直接跟看见的东西。如：

I can see the colourful rainbow in the sky.

我能看见色彩缤纷的彩虹挂在天空。

look 通常表示主动地、有意识地“看”，侧重于看的行为，后面不能直接跟东西。如：

Look! There is a colourful rainbow in the sky.

看！天上挂着一道色彩缤纷的彩虹。

Look! The rabbit is eating the carrot.

看！这只兔子正在吃胡萝卜。

## 指点迷津·提升能力

watch，read的用法：

watch 强调观赏，多用在看电视、比赛或展览的时候。如：

It's raining outside. Let's watch TV at home.

外面下雨了。我们在家看电视吧。

read 强调阅读一类的“看”，后接纸张类阅读物，如书、报纸、杂志、小说、地图等。如：

I like reading fairy tales.

我喜欢读童话故事。