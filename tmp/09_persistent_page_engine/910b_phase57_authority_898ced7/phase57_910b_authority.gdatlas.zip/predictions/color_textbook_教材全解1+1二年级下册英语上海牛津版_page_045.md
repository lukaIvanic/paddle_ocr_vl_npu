<div style="text-align: center;"><img src="imgs/img_in_image_box_488_145_559_206.jpg" alt="Image" width="5%" /></div>


## 互动学习

## 重点讲解·吃透教材

## 字母 h 在单词中的发音

辅音字母 h 在单词里发声门摩擦音 /h/ 的音，发音时，气流经过声门摩擦，由口腔而出，声带不振动。/h/ 是清辅音。这个音只出现在字首、字中位置。

## 指点迷津·提升能力

字母 h 的发音规律：

①一般情况下读作/h/，如：

house /haus/(房子)

②在元音 o 之前，往往不发音，如：

honest /'ɒnɪst/（诚实的）

③在字母 r, g 或字母组合 ex之后，h 不发音，如：rhyme /raɪm/（押韵）

<div style="text-align: center;"><img src="imgs/img_in_image_box_499_534_548_593.jpg" alt="Image" width="3%" /></div>


## 小试牛刀

Look and read（认读下面单词，并为你会读的单词下面的笑脸涂色。）


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>hat</td><td style='text-align: center; word-wrap: break-word;'>horse</td><td style='text-align: center; word-wrap: break-word;'>happy</td><td style='text-align: center; word-wrap: break-word;'>hop</td><td style='text-align: center; word-wrap: break-word;'>hot</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>house</td><td style='text-align: center; word-wrap: break-word;'>have</td><td style='text-align: center; word-wrap: break-word;'>has</td><td style='text-align: center; word-wrap: break-word;'>he</td><td style='text-align: center; word-wrap: break-word;'>hamburger</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>hi</td><td style='text-align: center; word-wrap: break-word;'>hello</td><td style='text-align: center; word-wrap: break-word;'>his</td><td style='text-align: center; word-wrap: break-word;'>honey</td><td style='text-align: center; word-wrap: break-word;'>how</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td><td style='text-align: center; word-wrap: break-word;'>😊</td></tr></table>

<div style="text-align: center;"><img src="imgs/img_in_image_box_498_980_548_1039.jpg" alt="Image" width="3%" /></div>


## 单元复习

## 能力要求

综合运用本单元所学的词汇和句型，对喜欢的食物进行描述和交流。

## 方法指导

一、Introduction 介绍自己喜欢的食物

I. 英语中通常使用“I like eating...”句型来介绍自己喜欢的食物。注意区分食物的单复数。回答用“I like eating+食物名词”来表达，注意食物名词如果是可数名词，必须用复数。

2. 描述食物味道的形容词有 “delicious, tasty, yummy, yukky” 等，同学们要注意积累哦。

二、Asking 询问他人喜欢的食物

what 表示“什么”，问对方喜欢吃/喝什么，我们可以问：

What do you like eating? =What do you like to eat? 你喜欢吃什么?

What do you like drinking? =What do you like to drink? 你喜欢喝什么?

What's your favourite food? 你最喜欢的食物是什么?

## 交际实例

（在森林里，熊猫先生开的食品店里来了两位客人。）

Mr Panda: Hello, who are you?

Little Rabbit: I'm Little Rabbit. I'm small and white. My ears are long. My eyes are red.

Mr Panda: What do you like eating?