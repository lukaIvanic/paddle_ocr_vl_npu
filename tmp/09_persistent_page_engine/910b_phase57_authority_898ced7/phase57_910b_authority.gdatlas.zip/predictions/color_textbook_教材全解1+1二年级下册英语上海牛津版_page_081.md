have...意为“我有……”。如果主语是第三人称单数，则have要变为第三人称单数形式has。

2. Summer is hot. 夏天很热。

Spring/Summer/Autumn/Winter is...可以用来形容四个季节不同的气候特征。

## 交际实例

（李欣和澳大利亚的小朋友 Lisa 在视频聊天。）

Li Xin: It's summer. Summer is hot.

Lisa: It's winter now in Australia (澳大利亚).

Lisa: No, winter is hot.

Li Xin: Is winter cold there?

Li Xin: What do you have for winter?

Lisa: I have a T-shirt. I have shorts.

Li Xin: What do you have for summer?

Lisa: I have a sweater. I have trousers.

Li Xin: Wow, so cool. I want to go to Australia.

Lisa: Welcome to Australia!

## 拓宽视野

<div style="text-align: center;"><img src="imgs/img_in_image_box_499_704_548_762.jpg" alt="Image" width="3%" /></div>


我们在本单元学习了一些有关服装的单词，除了 trousers，sweater，shirt，coat 外，下面的有关服装的单词你认识吗？来读一读，学一学吧！

uniform 校服

pants 长裤 jeans 牛仔裤 pajamas 睡衣

jacket 夹克衫

swimsuit 泳衣 underwear 内衣裤 socks 袜子

<div style="text-align: center;"><img src="imgs/img_in_image_box_490_929_559_984.jpg" alt="Image" width="5%" /></div>


## 家长帮一帮

请按照下表所列内容与具体要求，复习本单元重点知识，不积跬步，无以至千里，小朋友加油哦！


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="2">项目与要求</td><td style='text-align: center; word-wrap: break-word;'>内容</td><td style='text-align: center; word-wrap: break-word;'>复习方式</td></tr><tr><td rowspan="2">词汇</td><td style='text-align: center; word-wrap: break-word;'>三会（听说读）</td><td style='text-align: center; word-wrap: break-word;'>trousers(长裤),sweater(毛衣),shirt(衬衫),coat(外套)</td><td style='text-align: center; word-wrap: break-word;'>★熟读熟记\n★学会运用</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>二会（听说）</td><td style='text-align: center; word-wrap: break-word;'>listen(听),woof(狗叫声),too(也),school(学校),together(在一起),ring(铃响),time(时间)</td><td style='text-align: center; word-wrap: break-word;'>★指读</td></tr><tr><td colspan="2">句子（听说读）</td><td style='text-align: center; word-wrap: break-word;'>Summer is hot. What do you have for...? I have...</td><td style='text-align: center; word-wrap: break-word;'>★大声朗读\n★熟读熟记\n★学会运用</td></tr><tr><td colspan="2">口语（听说）</td><td style='text-align: center; word-wrap: break-word;'>Time for class. /I&#x27;m sorry. /That&#x27;s all right.</td><td style='text-align: center; word-wrap: break-word;'>★指读\n★对话</td></tr><tr><td colspan="2">语音（听读）</td><td style='text-align: center; word-wrap: break-word;'>字母1、r的发音(见教材P37)</td><td style='text-align: center; word-wrap: break-word;'>★大声朗读\n★熟读熟记</td></tr></table>