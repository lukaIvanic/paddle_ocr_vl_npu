"Who are you?" said Lucie. "Have you seen my pocket-handkins?"

The little person made a bob-curtesy—"Oh, yes, if you please'm; my name is Mrs. Tiggy-winkle; oh, yes if you please'm, I'm an excellent clear-starcher!" And she took something out of a clothes-basket, and spread it on the ironing-blanket.

"What's that thing?" said Lucie—"that's not my pocket-handkin?"

"Oh no, if you please'm;

that's a little scarlet waist-coat belonging to Cock Robin!"







<div style="text-align: center;"><img src="imgs/img_in_image_box_84_273_441_663.jpg" alt="Image" width="34%" /></div>


And she ironed it and folded it, and put it on one side.

<div style="text-align: center;"><img src="imgs/img_in_image_box_532_861_868_1225.jpg" alt="Image" width="32%" /></div>
