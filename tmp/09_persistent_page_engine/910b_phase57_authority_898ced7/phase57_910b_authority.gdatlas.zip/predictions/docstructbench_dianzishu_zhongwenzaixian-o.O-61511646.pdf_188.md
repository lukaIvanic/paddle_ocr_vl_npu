## 安妮如愿得到泡泡袖裙子

安妮在没来绿山墙农舍之前就非常渴望拥有一条属于自己的泡泡袖裙子。圣诞节来临，马修终于圆了她的梦。赶快拿起你的彩笔，为安妮画出这条她梦寐以求的新裙子吧！

<div style="text-align: center;"><img src="imgs/img_in_image_box_191_641_951_1388.jpg" alt="Image" width="66%" /></div>
