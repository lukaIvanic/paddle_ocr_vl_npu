### 1. 基础单价

基础单价是计算工程单价的基础，包括人工预算单价，材料预算价格，电、风、水预算价格，施工机械使用费，砂石料单价，混凝土材料单价。

（1）人工预算单价。是指支付给从事建筑及安装工程施工的生产工人的各项费用。包括生产工人的基本工资和辅助工资。

1）基本工资，由技能工资和岗位工资构成。

技能工资是根据不同技术岗位对劳动技能的要求和职工实际具备的劳动技能水平及工作实绩，经考试、考核合格确定的工资。

岗位工资是根据职工所在岗位的责任、技能要求、劳动强度和劳动条件的差别所确定的工资。

2）辅助工资，是在基本工资之外，以其他形式支付给职工的工资性收入。包括：①根据国家有关规定属于工资性质的各种津贴，主要包括地区津贴、施工津贴和加班津贴等；②生产工人年有效施工天数以外非作业天数的工资，包括职工学习、培训期间的工资，调动工作、探亲和休假期间的工资，因气候影响的停工工资，女工哺乳时间的工资，病假在6个月以内的工资及产、婚、丧假期的工资。

本书仅列出了一般地区人工预算单价计算标准见表11-1。

<div style="text-align: center;">表11-1</div>


<div style="text-align: center;">一般地区人工预算单价计算标准</div>


单位：元/工时


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>序 号</td><td style='text-align: center; word-wrap: break-word;'>定 额 人 等 级</td><td style='text-align: center; word-wrap: break-word;'>一 般 地 区</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>高级熟练工</td><td style='text-align: center; word-wrap: break-word;'>10.26</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>熟练工</td><td style='text-align: center; word-wrap: break-word;'>7.61</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>半熟练工</td><td style='text-align: center; word-wrap: break-word;'>5.95</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>普工</td><td style='text-align: center; word-wrap: break-word;'>4.90</td></tr></table>

（2）材料预算价格。材料预算价格是指购买地运到工地分仓库（或堆放场地）的出库价格。材料预算价格一般包括材料原价、运杂费、运输保险费、采购及保管费4项，个别材料若规定另计包装费的另行计算。

1）材料原价。除电及火工产品外，材料原价按工程所在地区就近的大物资供应公司、材料交易中心的市场成交价或设计选定的生产厂家的出厂价计算。有时也可以工程所在地建设工程造价管理部门公布的信息价计算。电及火工产品执行国家定价。包装费一般包含在材料原价中。若材料原价中未包括包装费用，而在运输和保管过程中必须包装的材料，则应另计包装费，按照包装材料的品种、规格、包装费用和正常的折旧摊销费，包装费按工程所在地实际资料和有关规定计算。

2）运杂费。指材料由交货地点运至工地分仓库（或相当于工地分仓库的堆放场地）所发生的各种运载车辆的运费、调车费、装卸费和其他杂费等费用。一般分铁路、公路、水路几种方式计算其运杂费。

3）运输保险费。指材料在运输过程中发生的保险费，按工程所在省、自治区、直辖市或中国人民保险公司的有关规定计算。

 $$  运输保险费 = 材料原价 \times 材料运输保险费率 $$ 