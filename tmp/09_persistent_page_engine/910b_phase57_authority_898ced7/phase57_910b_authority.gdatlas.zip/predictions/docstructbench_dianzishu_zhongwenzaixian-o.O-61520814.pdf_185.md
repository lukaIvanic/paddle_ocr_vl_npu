54.3%；长度在1000m及以上的侵蚀沟道数量14.70万条，占总数的22.0%，面积8.56万km $ ^{2} $，占总面积的45.7%。西北黄土高原区侵蚀沟道数量、长度与面积见表6-3-2。

<div style="text-align: center;">表6-3-2</div>


<div style="text-align: center;">西北黄土高原区侵蚀沟道数量、长度与面积</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td rowspan="2">侵蚀沟道级别 $ ^{{①}} $</td><td colspan="3">沟道数量/万条</td><td colspan="3">沟道长度/万 km</td><td colspan="3">沟道面积/万  $ km^{{2}} $</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>丘陵沟壑区</td><td style='text-align: center; word-wrap: break-word;'>高原沟壑区</td><td style='text-align: center; word-wrap: break-word;'>合计</td><td style='text-align: center; word-wrap: break-word;'>丘陵沟壑区</td><td style='text-align: center; word-wrap: break-word;'>高原沟壑区</td><td style='text-align: center; word-wrap: break-word;'>合计</td><td style='text-align: center; word-wrap: break-word;'>丘陵沟壑区</td><td style='text-align: center; word-wrap: break-word;'>高原沟壑区</td><td style='text-align: center; word-wrap: break-word;'>合计</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>合计</td><td style='text-align: center; word-wrap: break-word;'>55.64</td><td style='text-align: center; word-wrap: break-word;'>11.03</td><td style='text-align: center; word-wrap: break-word;'>66.67</td><td style='text-align: center; word-wrap: break-word;'>47.1</td><td style='text-align: center; word-wrap: break-word;'>9.23</td><td style='text-align: center; word-wrap: break-word;'>56.33</td><td style='text-align: center; word-wrap: break-word;'>15.67</td><td style='text-align: center; word-wrap: break-word;'>3.05</td><td style='text-align: center; word-wrap: break-word;'>18.72</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>500（含） ~ 1000m</td><td style='text-align: center; word-wrap: break-word;'>43.31</td><td style='text-align: center; word-wrap: break-word;'>8.66</td><td style='text-align: center; word-wrap: break-word;'>51.97</td><td style='text-align: center; word-wrap: break-word;'>29.76</td><td style='text-align: center; word-wrap: break-word;'>5.97</td><td style='text-align: center; word-wrap: break-word;'>35.73</td><td style='text-align: center; word-wrap: break-word;'>8.43</td><td style='text-align: center; word-wrap: break-word;'>1.73</td><td style='text-align: center; word-wrap: break-word;'>10.16</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>1000m 及以上</td><td style='text-align: center; word-wrap: break-word;'>12.33</td><td style='text-align: center; word-wrap: break-word;'>2.37</td><td style='text-align: center; word-wrap: break-word;'>14.70</td><td style='text-align: center; word-wrap: break-word;'>17.34</td><td style='text-align: center; word-wrap: break-word;'>3.26</td><td style='text-align: center; word-wrap: break-word;'>20.6</td><td style='text-align: center; word-wrap: break-word;'>7.24</td><td style='text-align: center; word-wrap: break-word;'>1.32</td><td style='text-align: center; word-wrap: break-word;'>8.56</td></tr></table>

①侵蚀沟道级别用侵蚀沟道的长度表示。

在西北黄土高原区中，甘肃省侵蚀沟道数量最多，占区域侵蚀沟道总数量的40.3%；其次为陕西省，占21.1%；侵蚀沟道数量最少的为宁夏回族自治区，占2.51%。侵蚀沟道面积与数量基本一致，甘肃省和陕西省面积较大，占区域侵蚀沟道总面积的比例分别达到28.9%和23.9%；宁夏回族自治区、河南省及内蒙古自治区侵蚀沟道面积较小，分别占5.3%、6.2%、7.5%。西北黄土高原区各省（自治区）侵蚀沟道数量与面积见附表A32，各省（自治区）侵蚀沟道面积占全区沟道面积比例见图6-3-1。

<div style="text-align: center;"><img src="imgs/img_in_chart_box_242_1222_714_1650.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">图6-3-1 西北黄土高原区各省（自治区）侵蚀沟道面积占全区沟道面积比例</div>


按西北黄土高原区侵蚀类型统计，高原沟壑区侵蚀沟道共11.03万条，沟道面积3.05万km²；丘陵沟壑区侵蚀沟道共55.64万条，沟道面积15.67万km²。高原沟壑区侵蚀沟道数量占侵蚀沟道总数的16.5%，丘陵沟壑区占83.5%。

高原沟壑区侵蚀沟道主要分布于甘肃省东部、陕西省延安南部和渭河以北、山西省南部等地区，平均沟道纵比为20.42%，沟道沟壑密度1.25km/km $ ^{2} $。丘陵沟壑区依据地形地貌差异分为5个副区。其中，第一、第二副区主要分布于陕西省北部、山西省西北部和内蒙古自治区南部，平均沟道纵比分别为19.93%、14.06%，沟壑密度分别为3.4～7.6km/km $ ^{2} $、3.0～5.0km/km $ ^{2} $；第三、第四副区主要分布于青海省东部、甘肃省中部、河南省西部，平均沟道纵

