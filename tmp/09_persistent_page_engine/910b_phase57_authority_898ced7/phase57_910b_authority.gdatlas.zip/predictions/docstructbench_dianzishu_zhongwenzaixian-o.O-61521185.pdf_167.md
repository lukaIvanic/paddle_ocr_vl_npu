# ★ 葱油面

<div style="text-align: center;"><img src="imgs/img_in_image_box_761_288_1096_617.jpg" alt="Image" width="25%" /></div>


## 材料成分

主料：香葱500g，大葱500g，紫葱头500g，切面（细）5kg；

辅料：水300g，油菜500g，食用油500g；

调料：酱油1kg。

<div style="text-align: center;"><img src="imgs/img_in_image_box_840_736_1181_962.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;">原材料图</div>


## 制作过程

香葱切段，大葱、葱头切丝，油菜切开备用；葱油制作：锅内放油烧至三成热，将香葱、大葱、葱头入锅小火熬制20分钟后加酱油、水，开锅10分钟盛出；锅中煮面条的同时放一个小油菜，煮熟后浇上葱油、撒上香葱粒即可（原料按35碗计算）。

## 工艺技巧

面条要细；熬油温度不宜太高。

## 品质特点

<div style="text-align: center;"><img src="imgs/img_in_image_box_841_1087_1181_1317.jpg" alt="Image" width="25%" /></div>


柔韧爽滑，葱香可口。

<div style="text-align: center;">半成品图</div>


## 王广勇 提供