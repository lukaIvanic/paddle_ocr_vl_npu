续表


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>名 称</td><td style='text-align: center; word-wrap: break-word;'>说 明</td><td style='text-align: center; word-wrap: break-word;'>操 作 方 法</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>键盘锁</td><td style='text-align: center; word-wrap: break-word;'>当无需使用按键或旋钮时，开启键盘锁可锁定按键或旋钮以防误操作。如果经销商设置了键盘锁备份，终端将自动保存关机前按键或旋钮是否锁定的状态</td><td style='text-align: center; word-wrap: break-word;'>按“键盘锁”快捷键开启或关闭键盘锁</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>自定义单音发码</td><td style='text-align: center; word-wrap: break-word;'>自定义单音发码是您可以自定义设置终端发射的音频，用于进行报警或通知目标终端</td><td style='text-align: center; word-wrap: break-word;'>按下“自定义单音发码”快捷键，终端对当前联系人持续发射自定义的音频，松开该快捷键停止发射</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>漫游</td><td style='text-align: center; word-wrap: break-word;'>(1) 常规模式。漫游是终端工作在多基站 IP 网络互联系统时，可以通过基站的信号强度自动选择可用的基站，确保在任意站点正通信。\n(2) 集群模式。漫游是终端发生位置变更，移动到非归属网络或基站时，检测到信号即可发起登记</td><td style='text-align: center; word-wrap: break-word;'>(1) 常规模式。按“漫游”快捷键开启或关闭漫游。\n(2) 集群模式。由经销商开启</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>脱网</td><td style='text-align: center; word-wrap: break-word;'>脱网是如遇中转台故障或超出中转台的覆盖范围时，终端可以转换至直通模式进行通信</td><td style='text-align: center; word-wrap: break-word;'>按“脱网”快捷键在直通模式和中转模式之间切换</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>超时</td><td style='text-align: center; word-wrap: break-word;'>超时禁发是个呼或组呼时按住</td><td style='text-align: center; word-wrap: break-word;'>默认开启</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>信道繁忙锁定</td><td style='text-align: center; word-wrap: break-word;'>信道繁忙锁定是当其他终端占用当前信道时，按住“PTT”键，终端将发出“嘟”音，提示无法发射。若当前信道空闲时，按住“PTT”键可以进行发射</td><td style='text-align: center; word-wrap: break-word;'>默认开启</td></tr></table>

## （三） 切换音频方式

终端的音频类型包括麦克风和扬声器。在使用麦克风和扬声器的过程中，若终端成功外接音频附件后，可以根据需要切换音频方式。具体说明和操作方法见表6-7-8。

<div style="text-align: center;">表6-7-8</div>


<div style="text-align: center;">切换音频方式的具体说明和操作方法</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>音频方式</td><td style='text-align: center; word-wrap: break-word;'>具体说明</td><td style='text-align: center; word-wrap: break-word;'>操作方法</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>跟随 PTT</td><td style='text-align: center; word-wrap: break-word;'>使用终端自身的“PTT”键进行语音发射则启用内部麦克风，使用外接的音频附件进行语音发射则启用外部麦克风</td><td rowspan="4">按“麦克风设置切换”快捷键，快速切换麦克风的音频方式。\n按“喇叭设置切换”快捷键，快速切换扬声器的音频方式</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>仅本机</td><td style='text-align: center; word-wrap: break-word;'>仅使用终端自身的麦克风和扬声器</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>仅外设</td><td style='text-align: center; word-wrap: break-word;'>仅使用终端外接音频附件的麦克风和扬声器，如耳机、扬声器话筒</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>外设优先</td><td style='text-align: center; word-wrap: break-word;'>终端外接音频附件则使用外部麦克风和扬声器，无外接音频附件时才使用终端自身的麦克风和扬声器</td></tr></table>

## （四） 常规功能

常规功能分为数字功能和模拟功能见表6-7-9和表6-7-10。