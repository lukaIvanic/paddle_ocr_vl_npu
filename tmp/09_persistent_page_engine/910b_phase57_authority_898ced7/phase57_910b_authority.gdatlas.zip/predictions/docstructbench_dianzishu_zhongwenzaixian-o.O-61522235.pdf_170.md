<div style="text-align: center;"><img src="imgs/img_in_image_box_224_228_709_589.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">(a) 初始状态</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_724_227_1211_591.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">（b）最终状态</div>


<div style="text-align: center;">图3 水松生长情况对比</div>


#### 3.3.2 美人蕉植株高度和开花情况

美人蕉植株高度及开花数见表7。实验发现美人蕉最终高度不能肥组<施苗木种植基质<br>施花木专用基质组，3组重复平均分别为90.7～119.3cm、118.7～150.3cm、112.7～163cm，可见苗木种植基质与花木专用基质的肥力较为显著，能明显促进美人蕉的生长。但从整体性来说，使用苗木种植基质组的美人蕉长势更为均匀，高度范围相差最小。这可能是由于施用的基质肥力越高，植株间的竞争越强，长势越好的植株越容易吸收土壤中的基质，使其生长更为旺盛，从而拉开植株间的差距。美人蕉开花数比较如图4所示，生长情况对比如图5所示。

<div style="text-align: center;">表7</div>


<div style="text-align: center;">美人蕉植株高度及开花数</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td rowspan="2" colspan="2">参 数</td><td colspan="3">美 人 蕉</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>不施肥</td><td style='text-align: center; word-wrap: break-word;'>施苗木种植基质</td><td style='text-align: center; word-wrap: break-word;'>施花木专用基质</td></tr><tr><td rowspan="4">高度/cm</td><td style='text-align: center; word-wrap: break-word;'>第一组</td><td style='text-align: center; word-wrap: break-word;'>105~126</td><td style='text-align: center; word-wrap: break-word;'>120~146</td><td style='text-align: center; word-wrap: break-word;'>112~160</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>第二组</td><td style='text-align: center; word-wrap: break-word;'>62~101</td><td style='text-align: center; word-wrap: break-word;'>112~150</td><td style='text-align: center; word-wrap: break-word;'>116~167</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>第三组</td><td style='text-align: center; word-wrap: break-word;'>105~131</td><td style='text-align: center; word-wrap: break-word;'>124~155</td><td style='text-align: center; word-wrap: break-word;'>110~162</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>平均</td><td style='text-align: center; word-wrap: break-word;'>90.7~119.3</td><td style='text-align: center; word-wrap: break-word;'>118.7~150.3</td><td style='text-align: center; word-wrap: break-word;'>112.7~163</td></tr><tr><td rowspan="4">开花数/(朵/株)</td><td style='text-align: center; word-wrap: break-word;'>第一组</td><td style='text-align: center; word-wrap: break-word;'>19</td><td style='text-align: center; word-wrap: break-word;'>20</td><td style='text-align: center; word-wrap: break-word;'>23</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>第二组</td><td style='text-align: center; word-wrap: break-word;'>19</td><td style='text-align: center; word-wrap: break-word;'>23</td><td style='text-align: center; word-wrap: break-word;'>26</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>第三组</td><td style='text-align: center; word-wrap: break-word;'>17</td><td style='text-align: center; word-wrap: break-word;'>23</td><td style='text-align: center; word-wrap: break-word;'>27</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>平均</td><td style='text-align: center; word-wrap: break-word;'>18</td><td style='text-align: center; word-wrap: break-word;'>22</td><td style='text-align: center; word-wrap: break-word;'>25</td></tr></table>

经测量发现美人蕉最终开花数不能肥组<施苗木种植基质组<施花木专用基质组，3组重复平均分别为18朵/株、22朵/株、25朵/株，可见苗木种植基质与花木专用基质都能提高美人蕉的开花数，尤其是施用花木专用基质，能使美人蕉充分展示作为园林植物的花卉观赏价值。