<div style="text-align: center;"><img src="imgs/img_in_image_box_171_261_305_338.jpg" alt="Image" width="11%" /></div>


从原有棋子出发，向“日”字形的对角线交点处下一子叫

“飞”，也叫“小飞”。

图2–116 相对于图中原有的白棋一子来说，无论白方在A、B、C、D、E、F、G、H这些字母代表的位置上任意一处行棋，都可以称其为飞。

<div style="text-align: center;"><img src="imgs/img_in_image_box_606_449_1004_716.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">图2-116</div>


图2-117 相对于白方原有的一子来说，白 $ \Delta $是飞。反过来，相对于白方 $ \Delta $一子，白原有的一子也叫作飞。

飞的形式里还有“大飞”。它是指在原有棋子呈“目”字形的对角线交点处行棋。

图2-118 白△就叫白棋原有一子的大飞。同样，假若白方今后在A、B、C、D、E、F、G任何一处行棋，都叫大飞。

<div style="text-align: center;"><img src="imgs/img_in_image_box_175_1140_573_1463.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">图2-117</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_606_1141_1003_1461.jpg" alt="Image" width="33%" /></div>


<div style="text-align: center;">图2-118</div>
