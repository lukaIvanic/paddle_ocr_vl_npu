⑤原卟啉标准液。

a. 原卟啉标准贮备液（50 mg/L）：称取 5 mg 原卟啉，加 4 ml 无水乙醇使之溶解，以 1.5 N HCl 稀释至 100 ml。

b. 原卟啉标准中间液（1.0 mg/L）：取 2 ml 原卟啉贮备液，以乙酸乙酯与乙酸（4:1）混合液稀释到 100 ml。

c. 原卟啉标准应用液（0.1 mg/L）：取 1 ml 原卟啉中间液，以乙酸乙酯与乙酸（4:1）混合液稀释到 10 ml。

## （4） 实验步骤：（表4）

<div style="text-align: center;">表4 红细胞内游离原卟啉测定实验步骤</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>试剂</td><td style='text-align: center; word-wrap: break-word;'>样品管</td><td style='text-align: center; word-wrap: break-word;'>空白管</td><td style='text-align: center; word-wrap: break-word;'>标准管</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>肝素（ml）</td><td style='text-align: center; word-wrap: break-word;'>0.10</td><td style='text-align: center; word-wrap: break-word;'>0.10</td><td style='text-align: center; word-wrap: break-word;'>0.10</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>全血（ml）</td><td style='text-align: center; word-wrap: break-word;'>0.02</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>水（ml）</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>0.02</td><td style='text-align: center; word-wrap: break-word;'>0.02</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>5%硅藻土悬浊液（ml）</td><td style='text-align: center; word-wrap: break-word;'>0.15</td><td style='text-align: center; word-wrap: break-word;'>0.15</td><td style='text-align: center; word-wrap: break-word;'>0.15</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>原卟啉标准应用液（ml）</td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>0.5</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>乙酸乙酯与乙酸（4:1）混合液（ml）</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>3.5</td></tr></table>

注：按上表依次加入各种试剂，在加入乙酸乙酯与乙酸混合液前，用混旋器混合已加入的混合液，然后边混合边加入乙酸乙酯与乙酸混合液。

离心 15 min，将各管上清液分别倒入 10 ml 比色管中，每管加 4 ml 0.5N 盐酸，振摇 5 min 静止使之分层，将上层溶剂抽出弃去，测定盐酸液的荧光强度（30 min 内比色）。

（5）荧光测量：

①若使用日立 MPF-4 型荧光分光光度计测定条件为激发波长为 403 nm，狭缝 10 nm；发射波长为 605 nm，狭缝为 5 nm，液槽为 1 cm 厚石英槽。

②若使用国产930型荧光光度计测试，条件为激发滤光片420，荧光滤片550，灵敏度 $ 1\times500 $，滴度开关开至最大，液槽为1cm厚石英槽，检出灵敏度为 $ 0.01\ g/ml $。在不同量原卟啉（0 g，0.01 g，0.03 g，0.05 g，0.07 g，0.1 g）呈线性关系。

（6）计算：

 $$  血中原卟啉含量（g/L 全血）=\frac{样品荧光强度空白荧光强度}{标准管荧光强度空白荧光强度}\times 标准管原卟啉含量（g）\times $$ 

 $$ \begin{array}{r}100\\ \hline  样品取样量（ml）\end{array}\times10 $$ 