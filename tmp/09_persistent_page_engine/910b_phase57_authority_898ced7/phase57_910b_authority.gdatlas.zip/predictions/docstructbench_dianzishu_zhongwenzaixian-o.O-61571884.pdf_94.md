<div style="text-align: center;"><img src="imgs/img_in_image_box_180_99_647_469.jpg" alt="Image" width="32%" /></div>


<div style="text-align: center;">图 6-19 绘制辅助线和点</div>


在顶视图中以刚刚绘制的水平线为直径，捕捉其两个端点绘制一个椭圆，如图6-20所示。

<div style="text-align: center;"><img src="imgs/img_in_image_box_190_747_630_1149.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">图6-20 绘制椭圆</div>


### 3. 绘制曲线

在左视图中捕捉点和椭圆的四分点，参考头盔背景图绘制头盔两侧的两条曲线，并适当调整使其光滑，如图6-21所示。

<div style="text-align: center;"><img src="imgs/img_in_image_box_186_1509_634_1859.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;">图 6-21 绘制两侧曲线</div>


### 4. 双轨扫掠

执行“建立曲面”工具箱中的“双轨扫掠”命令，以点和椭圆为路径，以两条曲线为断面曲线，在打开的“双轨扫掠选项”对话框中，直接单击“确定”，完成头盔主体曲面的创建，如图6-22所示。

<div style="text-align: center;"><img src="imgs/img_in_image_box_739_447_1274_741.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;">图6-22 双轨扫掠</div>


### 5. 绘制前部侧面轮廓线

执行“控制点曲线”命令，参考背景图，在左视图中绘制头盔侧面轮廓线，如图6-23所示。

<div style="text-align: center;"><img src="imgs/img_in_image_box_742_1101_1272_1527.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;">图6-23 绘制前部侧面轮廓线</div>


### 6. 分割前部曲面

执行左侧工具条上的“分割”命令，选择头盔曲面作为“要分割的物件”，选择刚绘制的曲线作为“切割用物件”，进行曲面分割，分割后的效果如图6-24所示。此时可通过执