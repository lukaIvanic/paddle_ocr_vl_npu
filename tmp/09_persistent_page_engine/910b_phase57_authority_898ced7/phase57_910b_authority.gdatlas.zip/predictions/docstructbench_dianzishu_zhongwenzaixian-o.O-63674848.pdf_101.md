<div style="text-align: center;"><img src="imgs/img_in_image_box_184_230_1122_689.jpg" alt="Image" width="72%" /></div>


<div style="text-align: center;">图4–20 2015年商标专用权质押贷款网络</div>


运用 Gephi 软件对网络结构图的相关指标进行统计，整理得出 2014 年商标权质押贷款网络特征统计，如表 4-9 所示。

<div style="text-align: center;">表4-9 2014年商标权质押贷款网络特征统计</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>指标</td><td style='text-align: center; word-wrap: break-word;'>最大值</td><td style='text-align: center; word-wrap: break-word;'>最小值</td><td style='text-align: center; word-wrap: break-word;'>平均值</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>点度中心性</td><td style='text-align: center; word-wrap: break-word;'>17</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1.18</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>加权度</td><td style='text-align: center; word-wrap: break-word;'>17</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1.196</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>接近中心性</td><td style='text-align: center; word-wrap: break-word;'>1.94118</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>1.18373</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>中介中心性</td><td style='text-align: center; word-wrap: break-word;'>136</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>0.48795</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>特征向量中心性</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>0.00607</td><td style='text-align: center; word-wrap: break-word;'>0.01879</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>网络密度</td><td colspan="3">0.001</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>网络直径</td><td colspan="3">2</td></tr></table>

从表4-9中可以看出，该网络的密度为0.001，一个完备的网络图密度为1，该网络不具有完备性，说明商标专用权质押贷款中出质人之间没有连接的关系，只是出质人和质权人会有连接的关系。而网络直径为2，也就是说任意两个节点之间的最大距离为2，说明该网络的稳定性还是很好的，如果出现网络故障时，能够很容易地找到出现故障的节点。该网络加权度的最大值为17，说明在整个网络中质权人最多与17个出质人发生了合作关系，而平均值为1.196，最小值为1，说明大部分的质权人与出质