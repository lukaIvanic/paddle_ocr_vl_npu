05 添加色阶 添加“色阶”图层，设置色阶参数，增强画面对比度。

06 盖印图层 按下快捷键 Ctrl+Shift+Alt+E，盖印可见图层。



<div style="text-align: center;"><img src="imgs/img_in_image_box_132_282_513_952.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_509_392_727_690.jpg" alt="Image" width="14%" /></div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td colspan="2">图层</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>☑ 类型</td><td style='text-align: center; word-wrap: break-word;'>☑</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>正常</td><td style='text-align: center; word-wrap: break-word;'>☑ 不透明度：100%</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>锁定：</td><td style='text-align: center; word-wrap: break-word;'>☑ 填充：100%</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>色阶</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>选取颜色</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>#82</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>#82</td></tr></table>

<div style="text-align: center;"><img src="imgs/img_in_image_box_755_281_1322_952.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_133_993_725_1897.jpg" alt="Image" width="39%" /></div>


07 二次构图复制“盖印”图层，将复制的图层名称修改为“二次构图”。单击工具箱中的“矩形选框工具”按钮，在裙子底部绘制选区，按下快捷键Ctrl+H将选区内的图像进行变形，使裙子更长。变形完成后，按下快捷键Ctrl+Enter确定，继续按下快捷键Ctrl+D取消选区。

<div style="text-align: center;"><img src="imgs/img_in_image_box_761_1314_1282_1571.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_761_1595_1354_1904.jpg" alt="Image" width="39%" /></div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>P类型</td><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>T</td><td style='text-align: center; word-wrap: break-word;'>口</td><td style='text-align: center; word-wrap: break-word;'>☒</td><td style='text-align: center; word-wrap: break-word;'>☑</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>正常</td><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>不透明度</td><td style='text-align: center; word-wrap: break-word;'>100%</td><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>☑</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>锁定：☑</td><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>填充</td><td style='text-align: center; word-wrap: break-word;'>100%</td><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>☑</td></tr><tr><td colspan="7">二大档图</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>☑</td><td colspan="6">基印</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>层</td><td colspan="5">基印</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>☑</td><td style='text-align: center; word-wrap: break-word;'>fr</td><td style='text-align: center; word-wrap: break-word;'>层</td><td colspan="4">基印</td></tr></table>