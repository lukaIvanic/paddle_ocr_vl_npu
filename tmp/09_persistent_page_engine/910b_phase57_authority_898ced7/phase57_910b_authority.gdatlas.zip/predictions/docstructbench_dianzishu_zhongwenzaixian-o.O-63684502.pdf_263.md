开发一个投资回报率（ROI）评估指标来评价当前的部署阶段是不是具有价值（在政府部门，ROI只是一个逻辑概念，ROI可能是对公众的更好的服务，而不必是一个财务的ROI）。

表5-1列出了评估分析能力的各项内容，表5-2列出了最佳实践分析的视角。

<div style="text-align: center;">表5-1 评估数据分析能力</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>能力\n（自高而低）</td><td style='text-align: center; word-wrap: break-word;'>信息管理</td><td style='text-align: center; word-wrap: break-word;'>分析技术和工具</td><td style='text-align: center; word-wrap: break-word;'>面向数据的文化</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>刚有热情</td><td style='text-align: center; word-wrap: break-word;'>怎样管理特殊数据</td><td style='text-align: center; word-wrap: break-word;'>使用电子表格和标准化的报告</td><td style='text-align: center; word-wrap: break-word;'>分析是不是战略的组成部分</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>专业化</td><td style='text-align: center; word-wrap: break-word;'>业务线有集中的数据管理</td><td style='text-align: center; word-wrap: break-word;'>使用预测分析的工具和技术</td><td style='text-align: center; word-wrap: break-word;'>被业务线的业务绩效评价所驱动</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>协作化</td><td style='text-align: center; word-wrap: break-word;'>企业应用集成在进行</td><td style='text-align: center; word-wrap: break-word;'>使用计分卡\n使用仪表盘\n实施了数据仓库和 BI</td><td style='text-align: center; word-wrap: break-word;'>被企业范围的关注所驱动</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>重大变革</td><td style='text-align: center; word-wrap: break-word;'>集成化的、简化的信息平台</td><td style='text-align: center; word-wrap: break-word;'>强大的数据分析工具和能力的集合</td><td style='text-align: center; word-wrap: break-word;'>分析驱动的组织</td></tr></table>

<div style="text-align: center;">表5-2 数据分析的好经验</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>内容</td><td style='text-align: center; word-wrap: break-word;'>细节</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>主数据的单一视图</td><td style='text-align: center; word-wrap: break-word;'>标杆企业在生成企业级的主数据模型方面有哪些好的做法？如何建立统一的客户、产品、资产、资金、组织、人员、渠道等主数据的视图？如何支撑大数据分析</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>业务流程管理</td><td style='text-align: center; word-wrap: break-word;'>标杆企业如何通过业务流程水线和业务流程管理来实现业务数据的采集、分析和改进</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>信息管理</td><td style='text-align: center; word-wrap: break-word;'>标杆企业如何管理企业在各个环节产生的关键信息？如何利用历史系统中的数据？如何获取与客户沟通中有价值的信息</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>整合和简化信息集成和数据分析</td><td style='text-align: center; word-wrap: break-word;'>标杆企业如何整合和简化集成和分析的环境？如何整合新的数据分析的技术</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>整合和优化基础设施平台</td><td style='text-align: center; word-wrap: break-word;'>标杆企业如何整合和优化信息化基础设施？如何实现不同平台之间的信息共享？如何保护历史基础设施投资</td></tr></table>

#### 5.1.3 大数据应用架构规划和设计

大数据应用架构规划和设计阶段，要以业务价值为基础、以数据分析战略为驱动、以灵活性和扩展性为原则，设计一个将来的大数据技术应用架构。主要关注点如下。