<div style="text-align: center;"><img src="imgs/img_in_image_box_188_221_746_606.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;">图3-11 拖长字幕和照片的时间到5秒</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_852_235_1245_604.jpg" alt="Image" width="26%" /></div>


<div style="text-align: center;">图3-12 用快捷方式为照片添加转场“交叉叠化”</div>


⑦ 选中视频 2 轨，用同样的方法给字幕文件的开头和结尾都添加转场“交叉叠化”，如图 3-13 所示。

<div style="text-align: center;"><img src="imgs/img_in_image_box_184_779_709_1158.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;">图3-13 用快捷方式为字幕添加转场“交叉叠化”</div>


## 触类旁通

观察转场“交叉叠化”前的红色标记，这是其他转场特效都没有的。因为在制作过程中，“交叉叠化”是非常常用的一个转场，所以软件附加了快捷键 Ctrl+D 给它，以方便制作。在实际使用时，如果想把其他转场设为默认转场，可以用快捷键实现，也可以右击相应的转场，选择“设为默认转场”命令即可。

⑧ 拖动照片“2.jpg”到视频1轨，与轨

道上的照片“1.jpg”无缝衔接，拖长时间到15秒；选择“字幕—新建字幕—基于模板”命令，在打开的“模板”窗口中选择字幕设计器预设下的“常规—小女孩—小女孩（标题）”命令，如图3-14和图3-15所示。

<div style="text-align: center;"><img src="imgs/img_in_image_box_220_1401_774_1783.jpg" alt="Image" width="36%" /></div>


<div style="text-align: center;">图3-14 拖动照片素材并放长</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_845_1397_1287_1777.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">图3-15 选择字幕模板</div>


⑨ 更改模板文字，并删除条纹底图，然后在工具栏中选择矩形工具；在字幕上绘制矩形长条，修改填充颜色为白色，透明度为60%，如图3-16和图3-17所示。