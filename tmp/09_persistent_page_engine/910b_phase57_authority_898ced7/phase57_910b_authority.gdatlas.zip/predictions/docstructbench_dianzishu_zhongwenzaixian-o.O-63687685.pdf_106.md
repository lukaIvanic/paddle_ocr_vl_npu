## 避免凌乱的曲线图

在用曲线图做趋势比较时，若有超过3个以上数据系列，极易出现曲线之间相互交叉、乱成一团麻的情况，很难清楚地观察各个系列的变化趋势（图3-29）。

在这种情况下，可以使用一种叫作平板图（Panel chart）的图表处理方法。

如图3-30所示，将各条曲线分开来绘制，彼此并不交叉影响，显得很清晰。但它们仍在一个图表中，共用一个纵坐标轴，便于观察趋势和比较大小。这种处理方法适用于多系列曲线图，系列之间量纲相同，数量级相差不是太大的情况。

其实现技巧，只是将原来的数据源进行图中所示的“错行”组织，做出的曲线图自然也就错开了。独立的格子通过设置网格线间隔实现，上面的公司名称签使用文本框或辅助系列来完成。具体做法这里不再细述，读者可参见范例文件中的步骤。

<div style="text-align: center;"><img src="imgs/img_in_image_box_498_655_1344_961.jpg" alt="Image" width="58%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_934_656_1339_953.jpg" alt="Image" width="27%" /></div>


<div style="text-align: center;">图3-29 线条纠缠在一起显得异常凌乱，不便于阅读分析</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_498_1105_1344_1436.jpg" alt="Image" width="58%" /></div>


<div style="text-align: center;">图3-30 将多系列的曲线图做成彼此分离的平板图，避免了曲线的交叉凌乱</div>
