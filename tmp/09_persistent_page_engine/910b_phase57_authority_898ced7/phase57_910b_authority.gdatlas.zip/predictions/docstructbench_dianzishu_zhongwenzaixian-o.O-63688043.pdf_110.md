参照上述方法，请同学们进行一次生涯人物访谈。要求每个同学都参与，并各自形成报告，全班同学在班内举行一次专业发展方向的宣讲会，总结所学专业可从事的职业有哪些，对感兴趣职业的了解是什么。

## 2 ）“试穿你的职业”。

众所周知，在买衣服的时候都要先试试才能知道衣服是不是合适，同样的，找工作也是这样的。自己现在想做的工作不一定将来会去做，也不一定真的适合自己。那么，同学们怎样才能试穿自己的工作呢？可以参加实习等。假如现在要去一个公司进行实地见习，你将会怎样安排自己的实习？

下面给大家一个实习需要准备的范例表（见表3-3），供大家做参考。

<div style="text-align: center;">表3-3 范例表</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>参访机构：</td><td style='text-align: center; word-wrap: break-word;'>日期：</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>参访项目：</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>参访心得：</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>实习机构：</td><td style='text-align: center; word-wrap: break-word;'>日期：</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>实习项目：</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>实习心得：</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>打工机构：</td><td style='text-align: center; word-wrap: break-word;'>日期：</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>打开项目：</td><td style='text-align: center; word-wrap: break-word;'></td></tr><tr><td style='text-align: center; word-wrap: break-word;'>打工心得：</td><td style='text-align: center; word-wrap: break-word;'></td></tr></table>