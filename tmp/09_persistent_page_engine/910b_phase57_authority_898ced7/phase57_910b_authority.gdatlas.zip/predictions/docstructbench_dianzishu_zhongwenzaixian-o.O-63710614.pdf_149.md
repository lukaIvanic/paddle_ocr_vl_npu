1973年夏，江苏如皋出土了唐代早期的水密九舱木船1艘，船长17.32米，最宽处1.6米，船桅残存仅1米多，在船舱的木板缝中还发现了3枚铜钱“开元通宝”。据考，此船为唐代如皋南部古横江成陆前沉没，埋入土中已1000余年，现陈列于南京博物院（图5-11）。唐代水密隔舱技术的出现，使中国传统古船的强度和抗沉性产生了革命性的变化，水密舱壁是中国对世界造船技术的重要贡献之一。马可·波罗在其游记中叙及：“若干最大船舶有内舱至十三所，互以厚板隔之，其用在防海险。如船身触

<div style="text-align: center;"><img src="imgs/img_in_image_box_663_204_1211_603.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;">图5-10《唐船图》中的台湾船</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_660_712_1216_864.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;">图5-11 1973年江苏如皋出土的唐代沉船</div>


礁触饿鲸而海水透人之事，其事常见……至是水由破处浸入，流入船舱。水手发现船舱破处，立将浸水舱中货物徙于邻舱。盖诸舱之壁嵌隔甚坚，水不能透。然后修理破处，复将徙出货物运回舱中 $ ^{[1]} $。1974年泉州湾后诸出土的南宋海船，共分13个舱，舱隔板厚10～12厘米，隔板与船壳用扁铁和钩钉连接、桐油灰腻密。1982年在泉州法石还发现另一艘南宋海船，也设置了类似的水密隔舱，可见水密隔舱技术到宋朝已经十分成熟并普遍设置了（图5-12、5-13）。

<div style="text-align: center;"><img src="imgs/img_in_image_box_227_1279_746_1586.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;">图5-12 泉州后诸港宋船出土情况（现存于泉州海外交通史博物馆） （资料来源：《泉州古港史》）</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_769_1273_1188_1600.jpg" alt="Image" width="30%" /></div>


<div style="text-align: center;">图5-13 泉州宋代海船复原图（资料来源：《中国古船图说》）</div>
