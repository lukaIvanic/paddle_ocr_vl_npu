North American limit switches are also available in an enclosed basic version. These switches are designated by the catalog number 3SE03-EB. Enclosed basic switches are preconfigured with a plunger actuator, booted plunger, roller lever, booted roller lever, roller plunger, or a booted roller plunger.

<div style="text-align: center;"><img src="imgs/img_in_image_box_631_405_1523_894.jpg" alt="Image" width="52%" /></div>
