## ETIOLOGY

Injury to a peripheral nerve can occur by means of several mechanisms: stretching, compression (i.e., sustained compression or blunt trauma), friction, inflammation, or laceration. The clinical results of stretching or compression of the nerve vary depending on whether the insult has a rapid onset or is the result of a gradual change. A sudden insult does not allow for any adaptive change in the connective tissue of the nerve and is more likely to cause acute disruption of the nerve's blood supply or connective tissue. Conversely, the nerve can adapt amazingly well to a slow increase in tensile or compressive forces, such as that brought on by a growing osteophyte. $ ^{12} $ A classification of peripheral nerve injuries is presented in Table 25.1- $ ^{13-16} $

## Mechanisms of Peripheral Nerve Injury

Stretching

• Compression

Friction

<div style="text-align: center;">TABLE 25-1</div>


Inflammation

Laceration

Compression of the nerve can be caused by external sources or by swelling (e.g., inflammation) with a concomitant increase in pressure in a rigid compartment (e.g., carpal tunnel syndrome [CTS] compressing the median nerve at the wrist or anterior compartment [exertional] syndrome of the leg compressing the deep fibular [peroneal] nerve).$^{[17]}$ A nerve can be directly compressed,

<div style="text-align: center;">Classification of Nerve Injuries $ ^{13-16} $</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>TYPE</td><td style='text-align: center; word-wrap: break-word;'>FUNCTION</td><td rowspan="2">Pathological Basis</td><td rowspan="2">Possible Causes</td><td rowspan="2">Prognosis</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Seddon&#x27;s Classification</td><td style='text-align: center; word-wrap: break-word;'>Sunderland&#x27;s Classification</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Neurapraxia</td><td style='text-align: center; word-wrap: break-word;'>Type 1:\n• Focal conduction block\n• Primarily motor function and proprioception are affected\n• Some sensation and sympathetic function possibly present</td><td style='text-align: center; word-wrap: break-word;'>• Local myelin injury, primarily larger fibers\n• Axonal continuity\n• No Wallerian degeneration</td><td style='text-align: center; word-wrap: break-word;'>• Electrolyte imbalances\n• Deformation of myelin sheaths\n• Ischemia caused by compression or traction</td><td style='text-align: center; word-wrap: break-word;'>• Recovery within minutes, hours, or days if lesion was caused by anoxia or ionic imbalances\n• Mechanical compression or stretch may recover in weeks to months</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Axonotmesis</td><td style='text-align: center; word-wrap: break-word;'>Type 2:\n• Loss of nerve conduction at injury site and distally</td><td style='text-align: center; word-wrap: break-word;'>• Disruption of axonal continuity with Wallerian degeneration\n• Connective tissue elements of the nerve remain intact</td><td style='text-align: center; word-wrap: break-word;'>• Compression</td><td style='text-align: center; word-wrap: break-word;'>• Axonal regeneration required for recovery\n• The length of time for regeneration will depend on the distance of the injury from the end of the nerve\n• Good prognosis</td></tr><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>Type 3:\n• Loss of nerve conduction at injury site and distally</td><td style='text-align: center; word-wrap: break-word;'>• Loss of axonal continuity and endoneurial tubes\n• Perineurium and epineurium preserved</td><td style='text-align: center; word-wrap: break-word;'>• Compression</td><td style='text-align: center; word-wrap: break-word;'>• Disruption of endoneurial tubes, hemorrhage, and edema, producing scarring\n• Axonal misdirection possible\n• Poor prognosis\n• Surgery possibly required</td></tr><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>Type 4:\n• Loss of nerve conduction at injury site and distally</td><td style='text-align: center; word-wrap: break-word;'>• Damage to endoneurium and perineurium\n• Epineurium remains intact</td><td style='text-align: center; word-wrap: break-word;'>• Compression</td><td style='text-align: center; word-wrap: break-word;'>• Intraneural scarring and axonal misdirection\n• Poor prognosis\n• Surgery required</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Neurotmesis</td><td style='text-align: center; word-wrap: break-word;'>Type 5:\n• Loss of nerve conduction at injury site and distally</td><td style='text-align: center; word-wrap: break-word;'>• Severance of entire nerve</td><td style='text-align: center; word-wrap: break-word;'>• Compression\n• Traction\n• Laceration</td><td style='text-align: center; word-wrap: break-word;'>• Surgical resection and repair only means of recovery; full recovery unlikely\n• Factors that affect extent of recovery: nerve injured, level at which nerve is damaged, extent of injury, time elapsed since injury, patient&#x27;s age</td></tr></table>

Modified from Dumitru D: Electrodiagnostic medicine, Philadelphia, 1995, Hanley & Belfus.