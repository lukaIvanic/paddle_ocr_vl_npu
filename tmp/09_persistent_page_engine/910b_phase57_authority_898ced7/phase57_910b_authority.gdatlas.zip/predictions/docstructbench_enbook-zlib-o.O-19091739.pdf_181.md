Model We are asked to find the magnetic field due to a simple current distribution, so this example is a typical problem for which the Biot–Savart law is appropriate. We must find the field contribution from a small element of current and then integrate over the current distribution from $\theta_{i}$ to $\theta_{p}$, as shown in Figure 29.3b.

Analyse Let's start by considering a length element  $ d\bar{s} $ located at distance r from P. The direction of the magnetic field at point P due to the current in this element is out of the page because  $ \langle\bar{d}\times\bar{s}\rangle $ is out of the page. In fact, because all the current elements  $ 1d\bar{s} $ lie in the plane of the page, they all produce a magnetic field directed out of the page at point P. Therefore, the direction of the magnetic field at point P is out of the page and we need only find the magnitude of the field. We place the origin at O and let point P be along the positive axis, with  $ \bar{k} $ being a unit vector pointing out of the page.

From the geometry in Figure 29.3a, we can see that the angle between the vectors  $ d \ \mathbf{s} $ and  $ \mathbf{r} $ is  $ \left(\frac{\pi}{2} - \theta\right) $ radians.

 $$ d\mathbf{\bar{s}}\times\mathbf{\hat{r}}=|d\mathbf{\bar{s}}\times\mathbf{\hat{r}}|\mathbf{\hat{k}}=\left[d x\sin\left(\frac{\pi}{2}-\theta\right)\right]\mathbf{\hat{k}}=(d x\cos\theta)\mathbf{\hat{k}} $$ 

Evaluate the cross product in the Biot-Savart law:

Substitute into Equation 29.1:

 $$ d\overrightarrow{\mathbf{B}}=(d B)\hat{\mathbf{k}}={\frac{\mu_{0}I}{4\pi}}{\frac{d x\cos\theta}{r^{2}}}\hat{\mathbf{k}} $$ 

<div style="text-align: center;"><img src="imgs/img_in_image_box_1217_176_1514_464.jpg" alt="Image" width="17%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1217_534_1513_807.jpg" alt="Image" width="17%" /></div>


From the geometry in Figure 29.3a, express $r$ in terms of $\theta$:

(Example 29.1) (a) A thin, straight wire carrying a current $I$ (b) The angles $\theta_{1}$ and $\theta_{2}$ are used for determining the net field.

 $$ r=\frac{a}{\cos\theta} $$ 

Notice that  $ \tan \theta = -x/a $ from the right triangle in Figure 29.3a (the negative sign is necessary because  $ d\vec{s} $ is located at a negative value of  $ x $) and solve for  $ x $:

 $$ x=-a\tan\theta $$ 

 $$ dx=-a\sec^{2}\theta\,d\theta=-\frac{a\,d\theta}{\cos^{2}\theta} $$ 

Find the differential dx:

Substitute Equations (2) and (3) into the magnitude of the field from Equation (1):

 $$ dB=-\frac{\mu_{0}I}{4\pi}\left(\frac{a\,d\theta}{\cos^{2}\theta}\right)\left(\frac{\cos^{2}\theta}{a^{2}}\right)\cos\theta=-\frac{\mu_{0}I}{4\pi a}\cos\theta\,d\theta $$ 

Integrate Equation (4) over all length elements on the wire, where the subtending angles range from  $ \theta_1 $ to  $ \theta_2 $ as defined in Figure 29.3b:

 $$ B=-\frac{\mu_{_{0}}I}{4\pi a}\int_{\theta_{1}}^{\theta_{2}}\cos\theta d\theta=\frac{\mu_{_{0}}I}{4\pi a}(\sin\theta_{_{1}}-\sin\theta_{_{2}}) $$ 

Check the dimensions, noting that the quantity in brackets is dimensionless:

 $$ [\mathbf{M}\mathbf{Q}^{-1}\mathbf{T}^{-1}]=[\mathbf{M}\mathbf{L}\mathbf{Q}^{-2}][\mathbf{Q}\mathbf{T}^{-1}]/[\mathbf{L}]=[\mathbf{M}\mathbf{Q}^{-1}\mathbf{T}^{-1}]\circledast $$ 

(B) Find an expression for the field at a point near a very long current-carrying wire.

## Solution

We can use Equation 29.4 to find the magnetic field of any straight current-carrying wire if we know the geometry and hence the angles  $ \theta_1 $ and  $ \theta_2 $. If the wire in Figure 29.3b becomes infinitely long, we see that  $ \theta_1 = \pi/2 $ and  $ \theta_2 = -\pi/2 $ for