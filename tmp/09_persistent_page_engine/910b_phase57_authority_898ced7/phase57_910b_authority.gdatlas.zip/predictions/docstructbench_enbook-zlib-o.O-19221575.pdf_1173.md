Gotu kola, kava kava, St. John's wort, valerian may increase CNS depression. FOOD: None known. LAB VAL: UEs. May decrease total free thyroxine (T₃) serum levels. May increase serum cholesterol, triglycerides, ALT, AST, WBC, GGT. May produce false-positive pregnancy test result.

## AVAILABILITY (Rx)

Tablets: 25 mg, 50 mg, 100 mg, 200 mg, 300 mg, 400 mg.

Tablets, Extended-Release: 50 mg, 150 mg, 200 mg, 300 mg, 400 mg.

## ADMINISTRATION/HANDLING PO

## INDICATIONS/ROUTES/DOSAGE

• Give immediate-release tablets without regard to food. • Do not break, crush, dissolve, or divide extended-release tablets.

• Extended-release tablets should be given without regard to food or with a light meal in evening.

Note: • When restarting pts who have been off QUIetapiine for less than 1 wk, titration is not required and maintenance dose can be reinstituted. • When restarting pts who have been off QUIetapiine for longer than 1 wk, follow initial titration schedule. • When discontinuing, gradual tapering recommended to avoid withdrawal symptoms and minimize risk of relapse.

## Schizophrenia

PO. (Immediate-Release): ADULTS, ELDERY. Initially, 25 mg twice daily, then increase in 25–50 mg increments divides between 4 times/day. 500–100 mg between the third day (mean 500–100 mg) in 2–3 divided doses by the fourth day. Further adjustments of 25–50 mg twice daily may be made at intervals of 2 days or longer. Maintenance: 150–75 mg/day (adults); 50–200 mg/day (elderly). (Extended-Release): Initially, 300 mg/day may increase at intervals as short as 10 mg/day. (Immediate-Release): 20–80 mg/day (elderly). (Immediate-Release): Children 13 YRS and OLDer. Initially, 25 mg twice daily may end on day 1, 50 mg twice daily on day 2, then increase by 100 mg/day to target dose of 400 mg twice daily on day 5. May further increase to 800 mg/day in increments of 100 mg or less daily. Range: 400–800 mg/day. Maximum: 800 mg. Total dose in 3 divides: 10 mg/day. Minimum: 50 mg/day. Maximum: 50 mg once daily on day 1, 100 mg on day 2, until 400 mg once daily is reached on day 5. Range: 400–800 mg/day. Maximum: 800 mg/day.



## Mania in Bipolar Disorder

PO: (Immediate-Release): ADULTS, ELDERY. Initially, 50 mg twice daily for 1 day. May increase in increments of 100 mg once a day. Followed by 100 mg once a day. May further increase in increments of 200 mg/day to 800 mg/day on day 6. Range: 400–800 mg/day. (Extended-Release): Initially, 500 mg on day 1 in the evening; 600 mg on day 2 and adjust between 400–600 mg/day to 900 mg on day 2 and 300 mg/day. Followed by 100 mg once a day. A OLDERY: 25 mg twice daily for 10 years, 50 mg twice daily on day 2, then increase by 100 mg once a day. Followed on day 4, 50 mg once a day up to 600 mg/day on day 5. May increase up to 600 mg/day on day 6. Extend the Release: 30 mg on day 100 mg once a day, 200 mg once a day, 100 mg once a day, 400 mg once a day is reached on day 4; 1 total; 400–600 mg once daily.

## Depression in Bipolar Disorder

PO: (Immediate-Release): ADULTS, ELDERLY: Initially, 50 mg/day on day 1, increase to 100 mg/day on day 2, then increase by 100 mg/day up to target dose of 300 mg/day. (Extended-Release): Initially, 50 mg on day 1 in the evening, 100 mg on day 2, 200 mg on day 3, 300 mg on day 4 and thereafter.

## Adjunctive Therapy in MDD

PO: ADULTS, ELDERLY: (Extended-Release): Initially, 50 mg on days 1 and 2; then 150 mg on days 3 and 4; then 150–300 mg/day thereafter.