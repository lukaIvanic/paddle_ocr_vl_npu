## Top 10 Best Seller Books

## [PDF] Where the Crawdads Sing

<div style="text-align: center;"><img src="imgs/img_in_image_box_117_335_262_557.jpg" alt="Image" width="8%" /></div>


SOON TO BE A MAJOR MOTION PICTURE—The #1 New York Times bestselling worldwide sensation with more than 12 million copies sold, hailed by The New York Times Book Review as “a painfully beautiful first novel that is at once a murder mystery, a coming-of-age narrative and a celebration of nature.” For years, … Read More…

## [PDF] The Summer I Turned Pretty

<div style="text-align: center;"><img src="imgs/img_in_image_box_123_722_257_927.jpg" alt="Image" width="8%" /></div>


Now a streaming series in Summer 2022! Belly has an unforgettable summer in this stunning start to the Summer I Turned Pretty series from the New York Times bestselling author of To All the Boys I've Loved Before, Jenny Han. Some summers are just destined to be pretty. Belly measures her life in ... Read More...

## [PDF] The Inn on Harmony Island

<div style="text-align: center;"><img src="imgs/img_in_image_box_116_1093_263_1312.jpg" alt="Image" width="8%" /></div>


“I’ve binged it in a day, I love these characters, I love their dynamics, I love the mysteriousness of their background and everything in between. I’ve fallen hard for these characters!” --Reviewer “Each time I assumed the book would be predictable, a twist popped up and ... Read More...

## [PDF] It's Not Summer Without You

<div style="text-align: center;"><img src="imgs/img_in_image_box_116_1466_263_1692.jpg" alt="Image" width="8%" /></div>


Soon to be a streaming series in Summer 2022! Belly finds out what comes after falling in love in this follow-up to The Summer I Turned Pretty from the New York Times bestselling author of To All the Boys I've Loved Before (now a major motion picture!), Jenny Han. It used to be that Belly counted the... Read More...

## [PDF] It Ends with Us

<div style="text-align: center;"><img src="imgs/img_in_image_box_120_1853_262_2068.jpg" alt="Image" width="8%" /></div>


In this “brave and heartbreaking novel that digs its claws into you and doesn’t let go, long after you’ve finished it” (Anna Todd, New York Times bestselling author) from the #1 New York Times bestselling author of All Your Perfects , a workaholic with a too-good-to-be-true romance can’t stop th... Read More...