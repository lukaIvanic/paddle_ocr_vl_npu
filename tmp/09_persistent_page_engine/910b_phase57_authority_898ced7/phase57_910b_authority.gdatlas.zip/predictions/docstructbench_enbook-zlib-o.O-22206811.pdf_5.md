## [PDF] No Safe Place

<div style="text-align: center;"><img src="imgs/img_in_image_box_116_191_262_406.jpg" alt="Image" width="8%" /></div>


There's nothing more dangerous than a familiar face... As funeral mourners stand in silence at Ragmullin cemetery, a deafening cry cuts through the air. Lying crumpled at the bottom of an open grave is the bloodied body of a young woman, and Detective Lottie Parker is called in to investi... Read More...

## [PDF] Portrait of an Unknown Woman

<div style="text-align: center;"><img src="imgs/img_in_image_box_122_574_258_787.jpg" alt="Image" width="8%" /></div>


In a spellbinding new masterpiece by #1 New York Times bestselling author Daniel Silva, Gabriel Allon undertakes a high-stakes search for the greatest art forger who ever lived Legendary spy and art restorer Gabriel Allon has at long last severed ties with Israeli intelligence and settled quietly in... Read More...

## [PDF] The 6:20 Man

<div style="text-align: center;"><img src="imgs/img_in_image_box_117_948_262_1167.jpg" alt="Image" width="8%" /></div>


A cryptic murder pulls a former soldier turned financial analyst deep into the corruption and menace that prowl beneath the opulent world of finance, in this #1 New York Times bestselling thriller from David Baldacci. Every day without fail, Travis Devine puts on a cheap suit, grabs his faux-leather... Read More...

## [PDF] It Ends with Us

<div style="text-align: center;"><img src="imgs/img_in_image_box_120_1331_262_1545.jpg" alt="Image" width="8%" /></div>


In this “brave and heartbreaking novel that digs its claws into you and doesn’t let go, long after you’ve finished it” (Anna Todd, New York Times bestselling author) from the #1 New York Times bestselling author of All Your Perfects, a workaholic with a too-good-to-be-true romance can’t stop th... Read More...

## [PDF] Thunder Bay

<div style="text-align: center;"><img src="imgs/img_in_image_box_119_1703_261_1916.jpg" alt="Image" width="8%" /></div>


Stoirm Island's secrets are worth killing for in this immersive, unrelenting thriller for readers of All the Missing Girls and Neon Prey —"this crime novel has it all" (Publishers Weekly, starred review). When reporter Rebecca Connolly gets a tip that suspected murderer Roddie Drummond ... Read More...