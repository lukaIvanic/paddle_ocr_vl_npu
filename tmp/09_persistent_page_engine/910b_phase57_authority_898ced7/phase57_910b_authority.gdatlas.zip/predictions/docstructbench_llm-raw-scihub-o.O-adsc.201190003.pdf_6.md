337 Synthesis of Azomethines from  $ \alpha $-Oxocarboxylates, Amines and Aryl Bromides via One-Pot Three-Component Decarboxylative Coupling

Adv. Synth. Catal. 2011, 353, 337–342

<div style="text-align: center;"><img src="imgs/img_in_image_box_95_383_131_421.jpg" alt="Image" width="2%" /></div>


Felix Rudolphi, Bingrui Song, Lukas J. Gooßen

343 Enantioselective Organocatalytic Synthesis of Oxazolidine Derivatives through a One-Pot Cascade Reaction

Adv. Synth. Catal. 2011, 353, 343–348

Zhichao Jin, Huicai Huang, Wenjun Li, Xiaoyan Luo, Xinmiao Liang, Jinxing Ye $ ^{*} $



<div style="text-align: center;"><img src="imgs/img_in_image_box_95_668_131_703.jpg" alt="Image" width="2%" /></div>


## FULL PAPERS

349 Bicyclic Cyclopentenones via the Combination of an Iridium-Catalyzed Allylic Substitution with a Diastereoselective Intramolecular Pauson-Khand Reaction

Adv. Synth. Catal. 2011, 353, 349–370

<div style="text-align: center;"><img src="imgs/img_in_image_box_97_1104_131_1140.jpg" alt="Image" width="2%" /></div>


☐ Andreas Farwick, Jens U. Engelhart, Olena Tverskoy, Carolin Welter, Quendolin A. Umlauf (née Stang), Frank Rominger, William J. Kerr,* Günter Helmchen*

371 One-Pot Synthesis of Spirooxindole Derivatives Catalyzed by Lipase in the Presence of Water

Adv. Synth. Catal. 2011, 353, 371–375

<div style="text-align: center;"><img src="imgs/img_in_image_box_95_1537_131_1575.jpg" alt="Image" width="2%" /></div>


She-Jie Chai, Yi-Feng Lai, Jiang-Cheng Xu, Hui Zheng, Qing Zhu, Peng-Fei Zhang $ ^{*} $

376 Highly Enantio- and Diastereoselective Synthesis of  $ \gamma $-Amino Alcohols from  $ \alpha,\beta $-Unsaturated Imines through a One-Pot  $ \beta $-Boration/Reduction/Oxidation Sequence

Adv. Synth. Catal. 2011, 353, 376–384

<div style="text-align: center;"><img src="imgs/img_in_image_box_96_1829_130_1866.jpg" alt="Image" width="2%" /></div>


Cristina Solé, Andrew Whiting,* Henrik Gulyás,* Elena Fernández*