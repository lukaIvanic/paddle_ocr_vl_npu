<div style="text-align: center;"><img src="imgs/img_in_chart_box_125_216_660_717.jpg" alt="Image" width="39%" /></div>


<div style="text-align: center;">Fig. 1. Percent body fat in males and females. Percent fat was estimated from seven skinfolds using the Jackson and Pollock (1978, 1980) and Siri (1961) equations. SED, LOF, HIF as in Table 1.  $ ^{b}P < 0.01 $ vs. LOF females.  $ ^{i}P < 0.001 $ vs. SED females or SED males, respectively.</div>


<div style="text-align: center;">Maximal Oxygen Consumption Of The Fat Free Mass</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_126_1003_658_1445.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;">Fig. 2. Maximal oxygen consumption (VO $ _{2} $max) of the fat free mass (FFM). VO $ _{2} $max in ml/min per kg of FFM in males and females of the various activity groups. SED, LOF, and HIF as in Table 1.  $ ^{1}P < 0.001 $ vs. SED females.</div>


more resilience to fat loss in females than in males and/or larger differences in caloric expenditure between LOF and SED males than between LOF and SED females. The physical activities in which the LOF females

reported participating were apparently sufficient to result in aerobic conditioning compared to that in SED females, but were not sufficient to result in significant decreases in percent body fat compared to that in SED females. This is similar to observations in animals, where female rats allowed spontaneous exercise lost less weight and body fat than males in spite of more negative exercise related energy balance in the females (Cortright et al., 1997). Although fat oxidation contributes more to exercise energy expenditure in females than in males (Blaak, 2001), catecholamine-induced lipolysis is lower in females than in males and the resting rate of fat oxidation adjusted for FFM is lower in females than in males (Ballor and Keesey, 1991). Thus, in minimally active (LOF) females, with limited contribution of physical activity to total energy expenditure, fat mobilization and oxidation are likely to be limited and fat storage favored. In addition, the intensity of the activities in which LOF females engaged, although sufficient to alleviate leg muscle limitations to treadmill exercise, was insufficient to induce a significant negative energy balance, either because of their low frequency, intensity and duration, and/or due to simultaneous increases in energy intake. The heavy LOF females may not be able to comfortably sustain exercise of sufficiently high intensity to impinge on their body weight. In addition, because of their low V $ _{0} $ or V $ _{2} $ at the same time received level of exertion or %VO $ _{2} $max, the absolute intensity of work and the caloric expenditure will be lower in females than in males. Only females reporting participation in three or more exercise sessions per week had significantly lower body fat than SED females. In these HIF females aerobic power was higher than in SED females both because of higher oxygen consumption capacity of their FFM and because of a lower percent body fat. Thus, in females sufficient to prevent or exercise fat and overweight (Suzuki et al., 1998, Indeed, longitudinal studies showed that changes in aerobic fitness and fitness with low-intensity training were inversely related to the initial values of these variables: the least fit showing the greatest improvement in aerobic fitness, the obese showing the least reduction in body fat (Campaigna, 1990).

In males, the physical activities in which they reported participation were insufficient