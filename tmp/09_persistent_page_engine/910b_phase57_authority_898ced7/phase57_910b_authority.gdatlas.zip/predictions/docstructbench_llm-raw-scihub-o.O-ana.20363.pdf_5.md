usually have partial myelitis and characteristically have asymmetric clinical findings with predominantly sensory symptoms. Spinal MRI lesions usually extend over less than two spinal segments. As in the other subtypes of CIS, abnormal brain MRI results is the most robust factor to predict conversion, followed by the presence of OBs. $ ^{25,28,29} $ Notably, none of our 20 patients with myelitis and normal baseline MRI results has experienced development of a second attack or a new T2 lesion in the 1-year MRI after a mean follow-up of 44 months (data not shown).

CISs classically refer to ON, brainstem syndromes, or spinal cord syndromes. Less common initial episodes suggestive of central nervous system demyelination such as hemispheric or clinically polyregional syndromes have not been specifically studied. In our cohort, only 30 patients (9.4%) had an initial attack different from classical CISs: 12 patients (3.8%) had a polyregional syndrome, 6 had a hemispheric syndrome (1.9%), and 12 (3.8%) had a neurological syndrome of undetermined topography. In our cohort of patients, there are insufficient numbers in this subgroup of patients to draw useful conclusions. A consensus definition of what is multifocal or polyregional needs to be achieved, and a greater number of patients with such characteristics should be studied.

The apparent discrepancy between natural history studies that claimed that ON has a better outcome and the prospective cohort on CISs and clinical trials that do not show differences in outcomes among different topographies may be explained by our observational study, which demonstrates that, overall, patients with ON may have a better outcome because, as a group, they have more chances for normal baseline MRI results than patients with other CISs. Differential diagnosis in patients with subacute visual loss is comprehensible, and other causes that mimic inflammatory-demyelinating ON are difficult to identify. Nevertheless, if a patient with ON has abnormal baseline MRI results, his or her prognosis does not differ from that of other patients with different CISs. MRI at baseline, not CIS topography, appears to be the crucial issue at MS presentation.

## References

1. Confavreux C, Vukusic S, Adeleine P. Early clinical predictors and progression of irreversible disability in multiple sclerosis: an amnestic process. Brain 2003;126:770–782.

2. Weinshenker BG, Bass GP, Rice J, et al. The natural history of multiple sclerosis: a geographically based study. I. Clinical course and disability. Brain 1989;112:133–146.

3. Weinshenker BG. Natural History of Multiple Sclerosis. Ann Neurol 1994;36:S6–S11.

4. Runmarker B, Andersen O. Prognostic factors in multiple sclerosis incidence cohort with twenty-five years of follow-up. Brain 1993;116:117–134.

5. Brex PA, Ciccarelli O, Jonathon I, et al. A longitudinal study of abnormalities on MRI and disability from multiple sclerosis. N Engl J Med 2002;346:158–164.

6. Morrissey SP, Miller DH, Kendall BE, et al. The significance of brain magnetic resonance imaging abnormalities at presentation with clinically isolated syndromes suggestive of multiple sclerosis. A 5-year follow-up study. Brain 1993;116:135-146.

7. O'Riordan JI, Thompson AJ, Kingsley DPE, et al. The prognostic value of brain MRI in clinically isolated syndromes of the CNS: a 10 year follow-up. Brain 1998;121:495–503.

8. Jacobs LD, Beck RW, Simon JH, et al. Intramuscular interferon-beta-1a therapy initiated during a first demyelinating event in multiple sclerosis. N Engl J Med 2000;343:898–904.

9. Comi G, Filippi M, Barkhof F, et al. Effect of early interferon treatment on conversion to definite multiple sclerosis: a randomized study. Lancet 2001;357:1576–1582.

10. Tintoré M, Rovira A, Rio J, et al. Optic neuritis brainstem syndromes and myelitis: early conversion to multiple sclerosis. Med Clin (Barc) 1999;112:693–694.

11. Tintoré M, Rovira A, Rio J, et al. New diagnostic criteria for multiple sclerosis: application in first demyelinating episode. Neurology 2003;60:27–30.

12. Frohman EM, Goodin DS, Calabresi PA, et al. The utility of MRI in suspected MS. Report of the therapeutics and technology assessment subcommittee of the American Academy of Neurology. Neurology 2003;61:602–611.

13. McDonald WI, Compston A, Edan G, et al. Recommended diagnostic criteria for multiple sclerosis: guidelines from the international panel on the diagnosis of multiple sclerosis. Ann Neurol 2001;50:121–127.

14. Andersson M, Alvarez-Cermeño J, Bernardi G, et al. Cerebrospinal fluid in the diagnosis of multiple sclerosis: a consensus report. J Neurol Neurosurg Psychiatry 1994;57:897–902.

15. Barkhof F, Filippi M, Miller DH, et al. Comparison of MRI criteria at first presentation to predict conversion to clinically definite multiple sclerosis. Brain 1997;120:2059–2069.

16. Poser CM, Paty DW, Scheinberg L, et al. New diagnostic criteria for multiple sclerosis: guidelines for research proposals. Ann Neurol 1983;13:227–231.

17. Tintoré M, Rovira A, Martínez MJ, et al. Isolated demyelinating syndromes: comparison of different MRI criteria to predict conversion to clinically definite multiple sclerosis. Am J Neuroradiol 2000;21:702–706.

18. Beck RW, Cleary PA, Anderson MM Jr, et al. A randomized, controlled trial of corticosteroids in the treatment of acute optic neuritis. The Optic Neuritis Study Group. N Engl J Med 1992;27:581–588.

19. Rio J, Nos C, Rovira A, et al. The development of multiple sclerosis following an isolated episode of optic neuritis. Magnetic resonance study. Med Clin (Barc) 1997;109:370–372.

21. Miller DH, Ormerod IEC, McDonald WI, et al. The early risk of multiple sclerosis after optic neuritis. J Neurol Neurosurg Psychiatry 1988;51:1569–1571.

22. Söderström M, Ya-Ping J, Hillert J, Link H. Optic neuritis. Prognosis for multiple sclerosis from MRI, CSF and HLA findings. Neurology 1998;50:708–714.

23. Jacobs LD, Kaba SE, Miller CM, et al. Correlation of clinical, MRI and CSF findings in optic neuritis. Ann Neurol 1997;41:392–398.