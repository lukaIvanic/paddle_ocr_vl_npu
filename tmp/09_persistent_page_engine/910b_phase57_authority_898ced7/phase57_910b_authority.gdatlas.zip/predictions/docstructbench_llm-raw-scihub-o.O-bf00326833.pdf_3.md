<div style="text-align: center;"><img src="imgs/img_in_chart_box_141_147_826_586.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_845_135_1533_598.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_135_616_826_1101.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;">Fig. 3. Thirty bolus profiles in a three-dimensional presentation</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_132_1119_818_1605.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_124_1635_800_1999.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_849_622_1532_1098.jpg" alt="Image" width="41%" /></div>


<div style="text-align: center;">Fig. 2a–e. Bolus profiles from rat ureter during low diuresis. Two seconds of recording time were evaluated reading every other frame. From the total of 30 profiles (Fig. 3), a selection of 7 is shown in the figure. Digitized grey levels (y-axis) are plotted against points or pixels in the ureter (x-axis) beginning with the proximal ureter at x = 0. The high luminance readings all along the ureter in a and e indicate the absence of dye before and after a bolus transit. Notice the collection of low grey levels moving from the left (b) to the right part of the curve (d) representing an urine bolus travelling from the proximal to the distal ureter. (Magnification 16x, 1 mm = 18 points or pixels)</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_853_1423_1517_1818.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;">Fig. 4. Time-distance diagram of bolus profiles. X-axis: time in seconds (30 frames = 2 sec); y-axis: length along ureter in pixels, beginning in the upper ureter (0) down to the lower third (180). The black shaded curve shows the position and length of the bolus at any given point of time. The upper slope indicates the velocity of the trailing end of the bolus (determined by the contraction ring); the lower slope indicates the velocity of the leading end of the bolus. In this example both velocities are almost identical.</div>
