chemical reaction on the sides of electrode, resulting in corrosion. It was concluded that pulse direct current field might reduce some of disadvantages mentioned above. However, the use of appending pulse direct current electric field in MBR has not been reported in the literature to date. In order to stabilize membrane flux and slow down membrane fouling, a new style MBR with the ability to control membrane fouling was built, in order to investigate the influence of pulse direct-current field on membrane flux in the presence of appending pulse direct-current field.

## 2 Experimental Setup and Sewage Properties

### 2.1 Experimental Setup

The reactor was made of plastic with dimensions of  $ 40 \times 30 \times 42 $ cm. The effective volume was 40.5 L. The reactor was partitioned into two compartments by a clapboard, with one compartment twice the size of the other. A tubular aerator was fitted at the top of the pool level so that aerobic and anoxic biofilms could be formed in the upper and lower parts, respectively. The hollow fiber membrane assembly was fitted in the other pool. A small perforated pipe aerator was fitted under the membrane assembly. The clapboard height was lower than the waterline to ensure water flowed from the bigger compartment into the smaller, so that membrane fouling could be alleviated. The bioreactor is shown in Fig. 1.

The polypropylene hollow fibrous membrane assembly was purchased from Zheda Kaihua Technical Co. Ltd. The inner and outer diameters of the membrane are 0.32 and 0.47 mm, respectively. The area of the membrane assembly was 4 m $ ^{2} $. The length and height of the membrane were 24 cm and 22.5 cm, respectively.

Activated sludge was taken from Wuhan Shahu Sewage Treatment Plant. The initial incubation concentration was 4.5 g/L. The MBR began to operate formally after the active sludge was cultured for 7 days. No sludge was discharged during experiments under normal conditions.

<div style="text-align: center;"><img src="imgs/img_in_image_box_116_1450_747_1910.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;">Figure 1. Schematic of the new style membrane bioreactor after applying the appending direct pulse current field.</div>


Hydraulic retention time was set to 8 h. The effluent was pumped under an operating pressure of  $ \Delta P = 0.1 $ MPa. The initial effluent flow was 36.7 L/m $ ^{2} $h.

The electrode was made of stainless steel with many small, evenly distributed holes. The distance between the electrode plates was 5 cm. The membrane assembly and the electrode plates were bound together. The adjustable power regulator ST-DRPS1000F was purchased from Hangzhou Supertech Electronic Technology Corp. Ltd. (Hangzhou, China).

XHPLC-28MR Programmable logical control was obtained from Changzhou Xionghua Automation Equipment Co. Ltd. (Changzhou, China).

### 2.2 Sewage Properties

Sewage water was taken from a septic tank at residential building No. 2 situated in the northern part of a university in Wuhan, China. The water quality is shown in Tab. 1.

<div style="text-align: center;">Table 1. Water quality in the experiments.</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>$ \text{COD}_{cr} $(mg/L)</td><td style='text-align: center; word-wrap: break-word;'>pH</td><td style='text-align: center; word-wrap: break-word;'>Turbidity(NTU)</td><td style='text-align: center; word-wrap: break-word;'>SS(mg/L)</td><td style='text-align: center; word-wrap: break-word;'>$ \zeta $-potential(mV)</td><td style='text-align: center; word-wrap: break-word;'>Water Temperature( $ ^{\circ} $C)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>310-740</td><td style='text-align: center; word-wrap: break-word;'>5-8</td><td style='text-align: center; word-wrap: break-word;'>100-500</td><td style='text-align: center; word-wrap: break-word;'>400-800</td><td style='text-align: center; word-wrap: break-word;'>-18.4--22.6</td><td style='text-align: center; word-wrap: break-word;'>15-25</td></tr></table>

## 3 Results and Discussion

### 3.1 Influence of Pulse Direct Current Electric Field on Membrane Flux in the MBR

In order to research the effect of the pulse direct current field on membrane flux, the change in membrane flux was measured at three different electric fields: 20 V/cm steady direct current field, 20 V/cm electric field with 10 s pulse duration, 30 min pulse interval, and no appending electric field. These were controlled respectively in the MBR. The results are shown in Fig. 2. It can be seen from Fig. 2 that the average membrane flux in pulsed direct current field varies between the values for membrane flux in continuous direct current field and no electric field, under the same electric field strength.

The membrane flux in Fig. 2, curve (c) drops continuously with time during the complete operation. This could be caused by the continuous sedimentation of minute particles on the membrane surface, which clogged pores of the membrane.

The membrane flux in Fig. 2, curve (a) becomes stable after a transit reduction with an increase of operation time under 20 V/cm appending steady electric field strength. Its average membrane flux was the highest of all experiments carried out.

It can be seen from Fig. 2, curve (b) that the membrane flux increases immediately after the application of an electric pulse. The rate of reduction of the average membrane flux is lower than that found with no electric field. This suggests that the application of pulsed electric field in MBRs is an effective method for resisting the deposition of particles on the membrane surface, cleaning the filter cake, and reducing membrane