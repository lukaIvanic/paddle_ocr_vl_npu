own. Typical of the results are those afforded by B3LYP/6-3L + G* methods; these indicate an equilibrium geometry which, like that of H$\underline{C}=\underline{S}-\mathrm{HCl}$,$^{[9]}$ is a bent planar one with the HF axis directed toward the S atom and subtending a C$\underline{S}$--H angle close to $90^{\circ}$, as shown in Figure 6. Such a

<div style="text-align: center;"><img src="imgs/img_in_image_box_276_401_653_625.jpg" alt="Image" width="22%" /></div>


<div style="text-align: center;">Figure 6. Molecular model of the H₂CS⁺HF complex optimized with the B3LYP/6-31 + G* theoretical model.</div>


structure and its dimensions tally with those deduced in the earlier theoretical studies. $ ^{[29,30]} $ The vibrational properties computed for the present model, together with the corresponding properties computed on a similar basis for the free subunits  $ H_{C-S} $ and HF, the experimental results both for the normal and perdeuterated forms of D and for the complex  $ H_{C-S} \cdots HCl $, are given as Supporting Information.

Where comparisons can be made, there is good agreement between the theoretical and experimental wavenumbers. Both the direction and magnitude of the wavenumber shifts found experimentally to be induced by complexation are reproduced by the calculations. For example, the experimental (HF) shift of  $ -435.3 \, \text{cm}^{-1} $ is matched theoretically by a shift of  $ -437.9 \, \text{cm}^{-1} $. Small blue shifts of the fundamentals that could be observed for the  $ H_cC=S $ subunit are also anticipated satisfactorily by the calculations. Low intensity in terms of IR absorption, masking by more intense absorptions of other species, and wavenumbers falling below the minimum threshold of the present measurements are then explanations sufficient to account for the fundamentals of  $ H_cC=S\cdots HF $ and  $ D_cC=S\cdots DF $ that escaped detection. Despite these omissions, though, we have little doubt that D has thus been identified correctly.

The matrix photochemistry of methyl thiofluoroformate, FC(O)SCH₃, follows closely the precedents set by the corresponding thiochloroformate, ClC(O)SCH₃, [9] The various reaction channels have been charted by characterization of the photoproducts by their IR spectra and by monitoring the behavior of the IR absorptions as a function of photolysis time. The conclusions have been endorsed by studying the effects of perdeuteration of the parent compound and carrying out quantum chemical calculations on the putative products.

## Conclusions

The photolytic interconversion of the two rotamers of FC(O)SCH₃ is the first process observed on broadband UV-visible irradiation of the matrix-isolated molecule, behavior made familiar by analogous studies of other sulfenyl carbonyl compounds, for example, CIC(O)SCH₃,⁹ FC(O)SCH₃,¹² FC(O)SCH₃,⁹ and CIC(O)SBr,¹³] The unambiguous identification of IR absorptions due to the less stable anti rotamer allows us to conclude that the vapor is composed of approximately 98% of the syn form and 2% of the anti form at ambient temperatures, in good agreement with the forecasts of quantum chemical calculations. Both forms of FC(O)SCH₃ then photodecompose. The main reaction channel involves the elimination of CO with the formation of the hitherto elusive sulfenyl fluoride CH₃SF, thus emulating similar photochemical processes starting from CIC(O)SCH₃,⁹ FC(O)SCH₃,⁹ FC(O)SBr,¹⁴ and CIC(O)SBr,¹³]



In a final step, continued UV-visible irradiation brings about a automeric change in  $ CH_{2}SF $ with detachment of a hydrogen atom from the methyl group to form HF and thioformaldehyde,  $ H_{2}C=S $, which together form the complex  $ H_{2}C=S\cdots HF $.

Scheme 2 summarizes these photochemical events. In addition, there are secondary reactions involving, for example, the elimination of OCS, together presumably with  $ CH_{3}F $ although this could not be detected, as well as the formation of loosely bound CO complexes.

<div style="text-align: center;"><img src="imgs/img_in_image_box_851_989_1516_1685.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;">Scheme 2. Outline of the photochemical reactions of  $ \mathrm{FC(O)SCH_{3}} $ isolated in a solid Ar matrix.</div>


## Experimental and Computational Procedures

(ECO)SCH, was prepared by reaction of CCO(SCH) with TE (both from Aldie) a ambient temperature $ ^{[1]} $ and subsequently purified by repeated rap-to-trap condensation under vacuum. The purity of the compound was checked by reference to the IR spectrum of the vapor and to the  $ {}^{1} $H,  $ {}^{1} $N NMR spectra of the liquid $ ^{[2]} $. The perdeuterated compound CCO(SCH), was prepared for the first time by the corresponding reaction of the liquid with the corresponding compound CCO(SCH), and the reaction rate of the compound to the  $ ^{1} $H,  $ ^{1} $N NMR spectrum.