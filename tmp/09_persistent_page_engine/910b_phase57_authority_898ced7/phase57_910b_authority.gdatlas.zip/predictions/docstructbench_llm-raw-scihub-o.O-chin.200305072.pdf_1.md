Polycarboxylic acids and esters

P 0253

05-072

Michael Addition of Nitroalkanes to Dimethyl Citraconate, with DBU as Base: An Unexpected, One-Pot Synthesis of Polyfunctionalized Carbonyl Derivatives.



— I he direct formation of keto diesters (III) from nitroalkanes and dimetnyl citracbonate proceeds via an isomerization of the double bond of (II) followed by Michael addition of the anion derived from (I) and a Nef-type conversion. The expected adducts (IV) are not observed. — (BALLINI*, R.; BARBONI, L.; BOSICA, G.; FIORINI, D.; GIL, M. V.; Synlett 2002, 10, 1706-1708; Dip. Sci. Chim., Univ. Camerino, I-62032 Camerino, Macerata, Italy; Eng.) — Mais

<div style="text-align: center;"><img src="imgs/img_in_image_box_278_383_884_753.jpg" alt="Image" width="52%" /></div>
