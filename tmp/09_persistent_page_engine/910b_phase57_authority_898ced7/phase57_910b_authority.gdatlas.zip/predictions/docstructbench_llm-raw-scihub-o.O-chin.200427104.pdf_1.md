Pyrrole derivatives

R 0120

27–104

Anti-HIV-1 Activity of Pyrryl Aryl Sulfone (PAS) Derivatives: Synthesis and SAR Studies of Novel Esters and Amides at the Position 2 of the Pyrrole Nucleus.—

Of all tested compounds, compound (IVa) shows the highest antiviral activity.—

(SILVESTR)*, R.; ARTICO, M.; LA REGINA, G.; DE MARTINO, G.; LA COLLA, M.; LODDO, R.; COLLA*, P.; Farmaco 59 (2004) 3, 201–210; Dip. Stud. Farm., Univ. La Sapienza, I-00185 Roma, Italy; Eng.)—C. Oppel



<div style="text-align: center;"><img src="imgs/img_in_image_box_291_345_865_708.jpg" alt="Image" width="49%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_291_733_769_872.jpg" alt="Image" width="41%" /></div>
