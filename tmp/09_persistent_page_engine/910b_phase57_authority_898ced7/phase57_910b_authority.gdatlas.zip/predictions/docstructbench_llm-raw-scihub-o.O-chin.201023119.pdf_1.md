Imidazole derivatives

R 0190

23-119

DOI: 10.1002/chin.201023119

Stereoselective Synthesis of 5-Substituted Pyrrolo[1,2-c]imidazol-3-ones: Access to Annulated Chiral Imidazol(in)ium Salts. The title compounds are available in a 2-step procedure via diastereoselective or enantioselective lithiation. Followed by a POCl-induced salt formation, precatalysts of type (XII) can be prepared. (MetALLINOS*, C.; XU, S.; Org. Lett. 12 (2010) 1, 76-79; Dep. Chem., Brock Univ., St. Catharines, Ont. 23A 3A1, Can., Eng.)—R. Simon

<div style="text-align: center;"><img src="imgs/img_in_image_box_116_391_847_523.jpg" alt="Image" width="63%" /></div>


A): sBuLi, TMEDA, Et_{2}O, -78°C, [2 h] B): -78 -> +25°C, [16 h]

<div style="text-align: center;"><img src="imgs/img_in_image_box_116_594_1041_758.jpg" alt="Image" width="79%" /></div>


C): iPrLi, (-)-sporteine, Me-O-tBu, -78°C, [2 h]

<div style="text-align: center;"><img src="imgs/img_in_image_box_115_820_949_990.jpg" alt="Image" width="71%" /></div>
