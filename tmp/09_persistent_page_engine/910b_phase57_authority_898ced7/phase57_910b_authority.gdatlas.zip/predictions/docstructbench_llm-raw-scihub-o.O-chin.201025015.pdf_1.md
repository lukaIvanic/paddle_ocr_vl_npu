Germanium

I 4700

25-015

DOI: 10.1002/chin.201025015

Mixed Cations and Structural Complexity in (Eu₁, Ca₁)InGe₂ and (Eu₁, Ca₁)InGe₂. The First Two Members of the Homologous Series

A₂₀₋₃₁In₂₀Ge₂ (n, m, 1, 2, …, 20; A: Ca, Sr, Ba, Eu, or Yb).

B₁₂₋₃₂In₂₀Ge₂(n), (n, m, 1, 2, …, 20; A: Ca, Sr, Ba, Cu, or Yb). (III), and

E₁₀₀Ca₂Ca₂InGe₂ (IV) are synthesized from the elements in a molten metal flux

(960 °C, 20 h). The compounds are characterized by single crystal XRD, magnetic

susceptibility measurements, and TB-LMTO band structure calculations. (I and II) crystal

utilized in the space group C2/m with Z = 2, and (III) and (IV) in the space group Pmna with a 4-

(4-0) and a 4-0. The潭角位子具有对称性，并且在空间位置上的位置

(1000) and a nearly square planar environment. (A)

T.S.-T.O.BASH, P.H. BEBOVE, S. Inorg. Chem. 49 (2010) 4, 1773-1783; Dep. Chem. Biochem., Univ. Del., Newark, DE 19716, USA; Eng.

W. P. Westerford