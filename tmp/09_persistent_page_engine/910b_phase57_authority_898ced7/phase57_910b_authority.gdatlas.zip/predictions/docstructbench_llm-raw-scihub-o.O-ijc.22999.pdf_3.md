<div style="text-align: center;"><img src="imgs/img_in_chart_box_343_201_969_513.jpg" alt="Image" width="36%" /></div>


<div style="text-align: center;">b</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_982_237_1293_538.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_347_571_888_953.jpg" alt="Image" width="31%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_929_565_1355_951.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;">e</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_358_989_1148_1298.jpg" alt="Image" width="46%" /></div>


<div style="text-align: center;">FIGURE 1—Combination of VEGFR and PDGFR tyrosine kinase inhibitors inhibits B16 melanoma tumor growth in vivo. (a) Subconfluent cultures of PAE/PDGFRβ cells were stimulated and conditioned media from B16/명초 or B16/PDGF-BB cells for 1 hr on ice (left panels). (b) Inhibits B16 cells were calculated as the value at 2°C with the conditioned medium on increasing amounts of PDGF-BB (right panels). (c) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cell line of the cells (right panels). (d) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (e) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (f) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (g) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (h) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (i) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (j) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (k) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (l) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (m) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (n) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (o) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (p) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (q) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (r) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (s) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (t) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (u) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (v) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (w) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (x) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (y) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (z) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (y) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (z) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (y) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (z) Inhibits PDGFRβ phosphorylation levels on the value by PDGFRβ and phosphorylation of the cells (right panels). (y</div>


## Results

## In vitro characterization of a B16F10 melanoma clone which produces PDGF-BB

A B16 melanoma cell line producing PDGF-BB (B16/PDGF-BB) was previously established. $ ^{[26]} $ This cell line was used to isolate a clone with robust PDGF-BB production that was selected for further experiments. As shown in Figure 1a (left panels), conditioned medium from the selected B16/PDGF-BB, but not a study transformed clone (B16/mock), induced stress. PDGFR $ \beta $ phosphorylation porcing aortic endothelial cells transfected with the PDGFR $ \beta $ (PAE/PDGFR $ \beta $), indicating production of a large amount of PDGF-BB. The amount of PDGF-BB released into the conditioned medium was estimated by incubating PAE/PDGFR $ \beta $ cells with either conditioned medium or increasing amounts of PDGF-BB. After 2 days, the B16/PDGF-BB cells had released an amount of PDGF into the medium that was in excess of 0.5 ng/ml PDGF-BB (Fig. 1a, right panels). It should be noted that PDGF-BB sticks to both cells and plastic, so this amount is likely to represent underestimation of the production of PDGF-BB.

