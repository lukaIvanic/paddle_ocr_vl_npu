<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_152_230_817_934.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;">(c)</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_849_220_1517_939.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;">(d)</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_153_979_816_1684.jpg" alt="Image" width="40%" /></div>


Estimating mean G(r) as ratio of means as in Baddeley et al. (1993) and using the variance estimator for ratio estimators

<div style="text-align: center;"><img src="imgs/img_in_chart_box_852_1018_1516_1682.jpg" alt="Image" width="40%" /></div>


<div style="text-align: center;">Fig. 5. Summary statistics (continuous curves) with envelopes (dotted) for rotenone1, given in the same order as in Fig. 3 for untreated 1.</div>


## Mean G-curves

intervals are so narrow that they are nearly indistinguishable from the mean curve. Therefore the plot is omitted.

leads to the mean curves and confidence bands shown in Fig. 11. Figure 12 shows that the assumption of a linear relation between numerator and denominator in the reduced sample estimator  $ \hat{G}_{0} $ is realistic. The EM algorithm yielded overall mean and variances from the ratio estimators. Figure 13 also shows the overall sample mean with confidence bands estimated from the sample variance.

