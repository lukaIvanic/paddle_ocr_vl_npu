<div style="text-align: center;"><img src="imgs/img_in_chart_box_397_194_1122_533.jpg" alt="Image" width="43%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_396_539_1127_907.jpg" alt="Image" width="44%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_389_935_1277_1427.jpg" alt="Image" width="53%" /></div>


<div style="text-align: center;">Fig. 1. Detection of the binding between the two partners of a specific complex. (A) High-mass MALDI mass spectrum of the bPrP and an antibody, IES, against bPrP without cross-linking. (B) Detection of the [1E5=bPrP] and [1E5=2bPrP] complexes after cross-linking. (C) Sensorgram of binding and dissociation between the immobilized ligand, IES, and the analyte, bPrP. The beginning of the sensorgram shows the level of response from the surface with only IES, the middle section shows the binding of bPrP with the surface during the injection, and the last section corresponds to the dissociation of the complex.</div>


[1E5•bPrP] and [1E5•2bPrP] complexes are still present, albeit in a much lower quantity. In the reference experiment (Fig. 4A), if one assumes that the peaks from the two complexes represent 100% of the intensity of the signal, the two peaks corresponding to the complexes with bPrP in the cases of peptides [140–160] and [145–165] represent only 36 and 42%, respectively, of the total intensity of all three peaks. This suggests that these peptides effectively compete with bPrP for binding with the antibody.

The characterization of the binding between 1E5 and the three selected peptides, two of which are assumed to be competing, was performed with a different procedure using SPR. A modified protocol (similar to the one described earlier for MS) was developed and tested. Rather than the antibody, the antigen was immobilized and the antibody, after mixing with the peptides, was flowed across the surface. The binding response was followed on the sensorgram (Fig. 4E). In all cases, binding between the surface and components of the mixture of antibody with or without peptide was detected. The upper curve shows the response of the binding between the mixture of 1E5 and peptide [145–165] and the surface with the antigen bPrP. The responses corresponding to 1E5 alone and the mixture of 1E5 with the noncompeting peptide are relatively close; the RU values after the injection (RU_final) are 460 and 470, respectively, so the binding is quite similar in those

