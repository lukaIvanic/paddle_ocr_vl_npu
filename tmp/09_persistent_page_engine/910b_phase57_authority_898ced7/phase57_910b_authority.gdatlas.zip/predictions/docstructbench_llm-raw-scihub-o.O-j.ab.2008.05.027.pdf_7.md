<div style="text-align: center;">A</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_251_196_680_567.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;">B</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_266_595_687_956.jpg" alt="Image" width="25%" /></div>


<div style="text-align: center;">Fig. 4. Estimation of CTB bound per well. (A) Western blots of known amounts of CTB (ng) were scanned and analyzed for blot density (pixels). Blot density versus CTB (ng) were scanned and analyzed for blot density versus CTB (nm). Blot density versus CTB (nm) were screened and analyzed for the amount of CTB bound to cells were then calculated from Western blots (using the equation from the panel A inset) and compared with fluorescence data from gangliosome analysis of epithelia exposed to the same amounts of CTB. This equation was therefore used to estimate amount of CTB bound to epithelia (from the number of cells) and the amount of CTB (from the number of cells) of the first triplicate experiments. Error bars in panel A represent 1 standard deviation of triplicate experiments. RFU, relative fluorescence units.</div>


parisons are warranted using more sensitive Western blot substrates, but under the conditions used here, the gangliosome method compared favorably in terms of sensitivity toward CTB concentrations introduced to Caco-2 cells. However, the greater strength of the gangliosome method lies in the ability to determine the relative degree of CTB binding simultaneously in 96 wells with high reproducibility and with comparatively minimal processing and time to results. In addition, this approach permits visualization of bound CTB under a fluorescence microscope.

### Detection of CTB in cocultures with V. cholerae and Caco-2 cells

As part of our efforts to develop a cell culture model of V. cholerae infection, we required methods for assaying the relative amounts of CTB being produced by V. cholerae when incubated with human epithelial cells and the relative amounts bound to the latter in the same system. We previously reported on a gangliosome-based microtiter plate assay for the quantification of CTB expressed in cell culture medium supernatants [35]. The method reported here allows for detection and quantification of the relative amounts of the CTB subunit of CT bound to epithelial cells. Due to safety and regulatory considerations, the method was optimized using just the CTB subunit as an analyte. However, it would anticipate improved performance with CT given that  $ G_{M1} $ has been reported to have a 100-fold increased avidity for the whole toxin versus CTB [13]. We incubated Caco-2 cells with various dilutions of V. cholerae grown in a KFED supplemented with 10% heat-inactivated FBS for 3 to 5 h. AKFD medium was developed

<div style="text-align: center;">A</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_904_186_1519_442.jpg" alt="Image" width="37%" /></div>


<div style="text-align: center;">B</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_918_462_1492_944.jpg" alt="Image" width="34%" /></div>


<div style="text-align: center;">Fig. 5. Detection of CTB in cocultures of V. cholerae and epithelial cells. (A) Fluorescence images of Caco-2 monolayers postincubation (5 h) either with a 1:1000 concentration of 100 μM</div>


specifically for V. cholerae growth and CT production, and it contains a higher salt concentration than does AKI medium [61]. After washing away the V. cholerae, we treated the Caco-2 cells with gangliosomes (BEGs) and viewed them under a fluorescence microscope (Fig. 5A) before lysing and measuring fluorescence in a microtiter plate reader (Fig. 5B). We also estimated the amount of CTB bound to each well by Western blot and correlated that estimate with the fluorescence for that well.

We found that BEGs were well suited to detecting V. cholerae-secreted CTB bound on the outside of epithelial cells. The background fluorescence was minimal, and we were able to clearly detect a difference between cells incubated with V. cholerae and those incubated with V. cholerae in the same amount of time (Fig. 5A). Furthermore, we were able to quantify the relative degree of CTB binding to the outside of the Caco-2 cells and to track the change in surface-bound CTB throughout the course of the culture (Fig. 5B). As we expected, the amount of CTB bound to the epithelial cells increased over time as the cholera cell density increased (as determined by visual inspection under an ordinary fluorescence microscope). The 1:1000 dilution of V. cholerae did not make enough to be detected when bound to Caco-2 cells after 3 h, whereas the Caco-2 cells incubated with 10-fold more V. cholerae exhibited CTB binding that correlated to nearly 1 ng/well (Fig. 5B). Both cultures increased in bound CTB levels after 5 h. Although we have observed this phenomenon consistently in pure cultures of V. cholerae, this is the first time it was recorded in cocultures of epithelial cells. This result was encouraging given that one of our goals is to develop a culture-based model of V. cholerae colonization of epithelial cells.