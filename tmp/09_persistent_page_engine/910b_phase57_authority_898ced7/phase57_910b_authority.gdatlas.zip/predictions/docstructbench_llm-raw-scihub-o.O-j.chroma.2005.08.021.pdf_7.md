<div style="text-align: center;"><img src="imgs/img_in_chart_box_148_181_792_691.jpg" alt="Image" width="38%" /></div>


<div style="text-align: center;">Fig. 4. The BET adsorption/desorption isotherms of C.I. Pigment Blue 15:4 and C.I. Pigment Red 122.</div>


ent levels of interaction, with associated energies, take place for the adsorption and the desorption processes.

The isotherms in Fig. 4 indicate that both pigments are quite strongly coherent as there is little low-pressure hysteresis. This suggests that the pigment crystals are sufficiently well packed to prevent significant amounts of nitrogen entering into any void spaces. C.I. Pigment Blue 15:4 gives more high pressure hysteresis than that provided by C.I. Pigment Red 122. This implies that the phthalocyanine pigment (C.I. Pigment Blue 15:4) has better ordered character within the sample than does the quinacridone (C.I. Pigment Red 122).

The computer software associated with the ASAP 2000 System carries out the calculations that are needed to determine the BET surface area of the pigment sample. The results obtained are summarised in Table 5.

As these results show, the C.I. Pigment Blue 15:4 sample has a slightly larger surface area than that possessed by the C.I. Pigment Red 122 sample.

#### 3.4. Inverse gas chromatography studies

In preliminary experiments, the influence of pigment loading, on the support material as a “concentration” series, was evaluated to ensure that, in the investigations described here, complete coverage of the support material was a reality, within experimental error. In this way, it was possible to ensure that the observations made in experiments were not influenced by the amount of coverage and that no “naked” zones of support material were present to cause complications in the behaviour observed [35].

<div style="text-align: center;">Table 5</div>


<div style="text-align: center;">The results of the BET analyses</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'></td><td style='text-align: center; word-wrap: break-word;'>C.I. Pigment Blue 15:4</td><td style='text-align: center; word-wrap: break-word;'>C.I. Pigment Red 122</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>BET surface area ( $ m^{{2}}/g $)</td><td style='text-align: center; word-wrap: break-word;'>65.18  $ \pm $ 0.25</td><td style='text-align: center; word-wrap: break-word;'>56.97  $ \pm $ 0.15</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Correlation coefficient</td><td style='text-align: center; word-wrap: break-word;'>1.00</td><td style='text-align: center; word-wrap: break-word;'>1.00</td></tr></table>

######## 3.4.1. Evaluation of C.I. Pigment Red 122 and of C.I

### Pigment Blue 15.4

Determination of the dispersive component of the surface free energy of C.I. Pigment Red 122 and of C.I. Pigment Blue 15.4. The Fowkes approach was used to determine the dispersive component of the surface free energy over a range of temperatures. For each temperature of study, the calculated values of RT In Vg were plotted against  $ a(\gamma)_{1}^{0.5} $. These details are shown in Fig. 5a–e for C.I. Pigment Red 122 and Fig. 8a–e for C.I. Pigment Blue 15.4. Data obtained from studies of polar probes are included in these graphs. These data are discussed later in this paper.

Although the Fowkes data analytical approach has a relatively simple background, the results can be relatively easily rationalised within the objectives of the study undertaken. The data so derived are interpreted on the basis of the Fowkes model and used within the limitations of the model, bearing in mind the potential complexity of the systems being investigated. Thus, a good correlation coefficient was obtained from each of the linear fits, denoted as  $ R^{2} $ in each of the plots. The slope of the linear fit, obtained for each n-alkane plot, gives the dispersive component of the surface free energy,  $ \gamma_{s}^{d} $, at that temperature. To determine the relationship between these two parameters, the values shown in Table 6 for C.I. Pigment Red 122.

Table 6 shows that the dispersive component of the surface free energy decreases as the temperature increases. This follows a logical trend as the weaker the dispersive interaction, the easier it would be to remove the molecules from the surface.

However, there was significant variation in the values of the dispersive component of the surface energy as the temperature increased. Further experimental work is necessary to understand the reason for such variation, although owing to the high quality of experimental consistency, it is felt that the variation is indicative of the changing nature of the pigment (steric, chemical) as a function of temperature.

Determination of the specific component of the surface free energy of C.I. Pigment Red 122 and of C.I. Pigment Blue 15.4. The behaviour of a range of polar probes was used to determine the specific component of the surface free energy. The acidic probes that were studied were trichloromethane (TCM) and dichloromethane (DCM). A single basic probe, tetrahydrofuran (THF), was studied in the same way. The amphoteric probes included acetone, diethyl ether and ethyl acetate.

As for the $n$-alkanes, values of $RT \ln V_g$ were calculated for each of the polar probes that were studied. Plots of these values of $RT \ln V_g$ against $a(Y_i^d)^0.5$ are included in Fig. 5a–e, at the relevant temperature. The specific component of the surface free energy,

<div style="text-align: center;">Values of $\gamma_{s}^{d}$ with increasing temperature for C.I. Pigment Red 122</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Temperature (°C)</td><td style='text-align: center; word-wrap: break-word;'>$ \gamma_{s}^{d} $ (mJ/m $ ^{2} $)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>80</td><td style='text-align: center; word-wrap: break-word;'>49.72</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>90</td><td style='text-align: center; word-wrap: break-word;'>46.72</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>100</td><td style='text-align: center; word-wrap: break-word;'>42.62</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>110</td><td style='text-align: center; word-wrap: break-word;'>34.09</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>120</td><td style='text-align: center; word-wrap: break-word;'>32.46</td></tr></table>