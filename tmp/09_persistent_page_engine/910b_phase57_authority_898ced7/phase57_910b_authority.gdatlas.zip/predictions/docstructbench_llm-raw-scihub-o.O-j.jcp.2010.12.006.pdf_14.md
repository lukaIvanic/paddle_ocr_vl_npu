<div style="text-align: center;"><img src="imgs/img_in_image_box_197_158_732_687.jpg" alt="Image" width="35%" /></div>


<div style="text-align: center;">(a)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_762_162_1297_690.jpg" alt="Image" width="35%" /></div>


<div style="text-align: center;">(b)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_194_742_739_1280.jpg" alt="Image" width="36%" /></div>


<div style="text-align: center;">(c)</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_760_749_1304_1288.jpg" alt="Image" width="35%" /></div>


<div style="text-align: center;">(d)</div>


<div style="text-align: center;">Fig. 4. The dispersion contours with stepsizes  $ \Delta t = 0.01 $,  $ \Delta = 0.1 $ for Maxwell's equations (46) from (a) exact dispersion; (b) boxscheme; (c) symplectic method and (d) Yee's method. The constant contour values are  $ \omega \in [2,4,6,\ldots,24] $.</div>


 $$ \varphi=\tan^{-1}\left(\frac{(v_{g})_{y}}{(v_{g})_{x}}\right),\quad|v_{g}|=\sqrt{(v_{g})_{x}^{2}+(v_{g})_{y}^{2}} $$ 

Substituting into (48) the vectors  $ \kappa $ and  $ v_g $ in polar coordinates (44), and let  $ a = |\kappa|\Delta $, this yields the propagation angle  $ \varphi $ and the propagation speed  $ |v_g| $ in terms of  $ a $ and  $ \theta $.

For example,  $ \phi $ for the boxscheme is given by

 $$ \varphi=\tan^{-1}\left(\frac{\sin\left(\frac{1}{2}\sin(\theta)a\right)\cos^{3}\left(\frac{1}{2}\cos(\theta)a\right)}{\cos^{3}\left(\frac{1}{2}\sin(\theta)a\right)\sin\left(\frac{1}{2}\cos(\theta)a\right)}\right). $$ 

Taking the Taylor expansion of this expression with respect to a = 0 yields,

 $$ \varphi\approx\theta-\frac{1}{12}\operatorname{s i n}(4\theta)a^{2}+O(a^{3}). $$ 

Similarly, the Taylor expansion of  $ |v_g| $ at a = 0 yields,

 $$ |v_{g}|\approx1+\left(\frac{1}{16}\cos(4\theta)-\frac{r^{2}}{4}+\frac{3}{16}\right)a^{2}+O(a^{4}), $$ 