fixed-target spectrometer with excellent vertexing and particle identification. Most of the FOCUS experiment and analysis techniques have been described previously [3,17–19,21]. Our analysis cuts were chosen to give reasonably uniform acceptance over the five kinematic decay variables, while maintaining a strong rejection of backgrounds. To suppress background from the re-interaction of particles in the target region which can mimic a decay vertex, we required that the charm secondary vertex was located at least three standard deviations outside of all solid material including our target and target microstrip system. We will refer to this as the "out-of-material" cut.

To isolate the $D^+ \rightarrow \phi \mu^+ \nu$ topology, we required that candidate muon, pion, and kaon tracks appeared in a secondary vertex with a confidence level exceeding 1%. The muon track, when extrapolated to the shielded muon arrays, was required to match muon hits with a confidence level exceeding 5%. The kaon was required to have a $C_{\text{erenkov}}$ light pattern more consistent with that of a kaon than that of a pion by 1 unit of log likelihood [19]. To further reduce non-charm background we required that our primary vertex consisted of at least two charged tracks. To further reduce muon misidentification, a muon candidate was allowed to have at most one missing hit in the 6 planes comprising our inner muon system and an energy exceeding 10 GeV. In order to suppress muons from pions and kaons decaying within our apparatus, we required that each muon candidate had a confidence level exceeding 1% to the hypothesis that it had a consistent trajectory through our two analysis magnets.

Non-charm and random combinatorial backgrounds were reduced by requiring both a detachment between the vertex containing the  $ K-K^{+}\mu^{+} $ and the primary production vertex of at least 5 standard deviations.

Possible background from  $ D^+ \to K^-K^+\pi^+ $, where a pion is misidentified as a muon, was reduced by treating the muon as a pion and requiring the reconstructed  $ K K\pi $ mass be less than  $ 1.8\,GeV/c^2 $. The  $ m_K^+K^- $ distribution for our  $ D_s^+ \to K^+K^-\mu^+\nu $ candidates is shown in Fig. 2.

It was important to test the fidelity of the simulation with respect to reproducing the resolution of those kinematic variables which depend on the neutrino momentum. To do this, we studied fully-reconstructed  $ D^0 \to K^{-}\pi^+\pi^+\pi^- $ decays where, as a test, one

<div style="text-align: center;"><img src="imgs/img_in_chart_box_785_238_1390_667.jpg" alt="Image" width="39%" /></div>


<div style="text-align: center;">Fig. 2. The $m_k^+k_-$ mass distribution for events satisfying our signal selection cuts. The solid histogram is our data. The dashed histogram is distribution for the ccbar background Monte Carlo. The ccbar background Monte Carlo is normalized to the same number of events in the sideband region $1.040 < m_k^+k_-$ < 1.14 GeV/c^2$.</div>


of the pions was reconstructed using our line-off-flight technique. We then compared its reconstructed momentum to its original, magnetic reconstruction in order to obtain an “observed” resolution function that was well matched by our simulation.

### 3. Fitting technique

The $r_v$ and $r_2$ form factors were fit to the probability density function described by four fitted kinematic variables ($q^2$, $\cos\theta_v$, $\cos\theta_t$, and $\chi$) for decays in the mass range $1.010 < m_{K^+K^-} < 1.030~\mathrm{GeV}/c^2$ using the squared amplitude described by Eq. (1).

The fit which determines the $r_v$ and $r_2$ form factor ratios minimizes the sum of $w = -2\ln I$ where $I$ is the normalized decay squared amplitude at each

We use a variant of the continuous fitting technique developed by the E691 Collaboration [20] for fitting decay squared amplitudes where several of the kinematic variables have very poor resolution such as the four variables that rely on reconstructed neutrino kinematics.