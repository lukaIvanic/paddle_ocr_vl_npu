For consistency, the time derivative of the constraints of (10) must vanish and hence they must have vanishing Poisson bracket with H. Using the fundamental Poisson brackets

 $$ \left[U(x),\varPi^{U}(y)\right]=\delta(x-y), $$ 

etc., we find that the primary constraints of (10) imply the secondary constraints

 $$ \begin{array}{r}{(\Sigma,\Sigma_{i})=\bigl(-\partial_{k}\varPi_{k}^{V},\varepsilon^{i j k}\partial_{j}\bigl(\varPi_{k}^{B}-m V_{k}\bigr)-\mu^{2}B_{i}\bigr).}\end{array} $$ 

 $ \mathrm{If}~\mu^2=0 $ (the Cremmer–Sheck model Lagrangian [1]), the constraints of (14) would become reducible as then  $ \partial_t\Sigma_i=0 $ and only the transverse portions of  $ \Sigma_i $ are constraints. Furthermore, with  $ \mu^2\neq0 $, the requirement  $ \Sigma_i=0 $ leads to a tertiary constraint

 $$ T_{k}\equiv\mu^{2}\varPi_{k}^{B}=0 $$ 

with $\Sigma_{i}$ and $T_{k}$ constituting second class constraints as

 $$ \left[T_{k}(x),\varSigma_{i}(y)\right]=\mu^{4}\delta_{i k}\delta(x-y). $$ 

All other constraints are first class and no further constraints need to be imposed for consistency. There are consequently five first class constraints ( $ \Phi^U $,  $ \Phi_k^A $ and  $ \Sigma $) and six second class constraints ( $ \Sigma_i $ and  $ T_k $). The constraints  $ \Phi^U $ and  $ \Sigma $ correspond to the usual gauge transformations  $ \delta W_0 = \partial_0 \Omega $,  $ \delta W_i = \partial_i \Omega $, associated with a gauge field  $ W_\mu $, while  $ \Phi_k^A $ is associated with the fact that in (12)  $ A_k $ acts merely as a Lagrange multiplier (i.e., it is not dynamical) and hence its value is completely arbitrary. Suitable gauge conditions associated with the first class constraints are

 $$ \left(\gamma^{U},\gamma_{k}^{A},\gamma^{V}\right)=\left(U,A_{k},\partial_{k}V_{k}\right)=0. $$ 

From (10), (14), (15) and (17) it is evident that the only dynamical degrees of freedom are

 $$ V_{i}^{T}\equiv\left(\delta_{i j}-\partial_{i}\partial_{j}/\partial^{2}\right)V_{j}. $$ 

We can verify this directly by explicitly eliminating the non-physical degrees of freedom in (4). First, one decomposes  $ V_{k} $,  $ A_{k} $ and  $ B_{k} $ into transverse (T) and longitudinal (L) parts where

 $$ \nabla\times\mathbf{V}^{L}\equiv0\equiv\nabla\cdot\mathbf{V}^{T}, $$ 

etc., (4) now becomes

 $$ \begin{aligned}2L=&\left(\dot{\mathbf{B}}^{L}\right)^{2}-\left(\nabla\cdot\mathbf{B}^{L}\right)^{2}+\left[\dot{\mathbf{B}}^{T}-\nabla\times\mathbf{A}^{T}\right]^{2}+\left(\dot{\mathbf{V}}^{T}\right)^{2}-\left(\nabla\times\mathbf{V}^{T}\right)^{2}+\left[\dot{\mathbf{V}}^{L}-\nabla U\right]^{2}\\&+2m\left[\mathbf{V}^{T}\cdot\left(\nabla\times\mathbf{A}^{T}\right)+\mathbf{B}^{L}\cdot\dot{\mathbf{V}}^{L}+\mathbf{B}^{T}\cdot\dot{\mathbf{V}}^{T}-\mathbf{B}^{L}\cdot\nabla U\right]+2\mu^{2}\left[\mathbf{A}^{T}\cdot\mathbf{B}^{T}+\mathbf{A}^{L}\cdot\mathbf{B}^{L}\right].\end{aligned} $$ 

The equations of motion for  $ \mathbf{A}^L $ and  $ U $, respectively, imply that

 $$ \mathbf{B}^{L}=0=\dot{\mathbf{V}}^{L}-\nabla U, $$ 

reducing (20) to

 $$ 2L=\left(\mathbf{\dot{V}}^{T}\right)^{2}-\left(\mathbf{\nabla}\times\mathbf{V}^{T}\right)^{2}+\left[\mathbf{\dot{B}}^{T}-\mathbf{\nabla}\times\mathbf{A}^{T}\right]^{2}+2m\mathbf{V}^{T}\cdot\left(\mathbf{\nabla}\times\mathbf{A}^{T}\right)+2m\mathbf{B}^{T}\cdot\dot{\mathbf{V}}^{T}+2\mu^{2}\mathbf{A}^{T}\cdot\mathbf{B}^{T}. $$ 

Since

 $$ \mathbf{A}^{T}\cdot\mathbf{B}^{T}=-\big(\nabla\times\mathbf{A}^{T}\big)\cdot\big(\nabla^{2}\big)^{-1}\big(\nabla\times\mathbf{B}^{T}\big), $$ 

we can eliminate  $ \nabla \times A^T $ from (22) to obtain

 $$ \nabla\times\mathbf{A}^{T}=\dot{\mathbf{B}}^{T}-m\mathbf{V}^{T}+\mu^{2}\big(\nabla^{2}\big)^{-1}\big(\nabla\times\mathbf{B}^{T}\big). $$ 