<div style="text-align: center;"><img src="imgs/img_in_chart_box_364_189_662_478.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_683_190_987_476.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_1004_192_1309_476.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;">Fig. 5. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-D-Trp imprinted ODMAAN-533. [(Ac-D-Trp)/(ODMA) = 0.17,  $ K_{S,app} = 5.5 \times 10^{3} \, \text{mol}^{-1} \, \text{dm}^{-3} $].</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_362_582_661_869.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_685_582_989_869.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_1007_584_1310_867.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;">Fig. 6. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-L-Trp imprinted ODMAAN-533. [(Ac-L-Trp)/(ODMA) = 0.17,  $ K_{s,app} = 5.5 \times 10^{3} \, \text{mol}^{-1} \, \text{dm}^{-3} $].</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_353_971_662_1267.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_680_971_994_1266.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_1017_972_1318_1268.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;">Fig. 7. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-D-Trp imprinted ODMAAN-533. [(Ac-D-Trp)/(ODMA) = 0.21,  $ K_{s,app} = 1.20 \times 10^{4} mol^{-1} dm^{3} $].</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_357_1376_664_1665.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_681_1374_993_1663.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_1007_1373_1316_1662.jpg" alt="Image" width="18%" /></div>


<div style="text-align: center;">Fig. 8. Adsorption isotherms of Ac-Trp's and adsorption selectivity of the Ac-L-Trp imprinted ODMAAN-533. [(Ac-L-Trp)/(ODMA) = 0.21,  $ K_{S,app} = 1.16 \times 10^{4} \, \text{mol}^{-1} \, \text{dm}^{-3} $].</div>


 $$ \Delta\theta=f[\mathrm{Ac-D-Trp}]_{\mathrm{m}}=f k_{\mathrm{A,app}}[\mathrm{Ac-D-Trp}] $$ 

and those for the L-isomer can be represented by the following equation:

 $$ \begin{aligned}\Delta\theta&=f[\mathrm{Ac-L-Trp}]_{\mathrm{m}}\\&=f\left\{Pe_{\mathrm{A,app}}[\mathrm{Ac-L-Trp}]+\frac{K_{\mathrm{S,app}}[\mathrm{Site}]_{0}[\mathrm{Ac-L-Trp}]}{1+K_{\mathrm{S,app}}[\mathrm{Ac-L-Trp}]}\right\}\end{aligned} $$ 

The apparent affinity constant between Ac-i-Trp and the formed chiral recognition site, which was constructed by the presence of i-isomer during the molecular imprinting process, was determined by the following procedure: the difference in the shift ( $ \Delta\theta $)s, between that for Ac-i-Trp, which was adsorbed not only on the chiral recognition site toward i-isomer but also on the non-specific region, and that for Ac-j-Trp, which was non-specifically adsorbed, was