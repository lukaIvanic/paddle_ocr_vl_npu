<div style="text-align: center;"><img src="imgs/img_in_image_box_253_192_648_357.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;">Fig. 1. Real structure consisting of three thin layers: silver (for electric contact), metal-free phthalocyanine and palladium fabricated on an alundum substrate.</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_1024_189_1337_356.jpg" alt="Image" width="18%" /></div>


The main goal of this paper is to investigate the electric resistance of a layered phthalocyanine and palladium (Pc + Pd) structure under the influence of various hydrogen concentrations in nitrogen and air. We show that during the

<div style="text-align: center;">Fig. 2. A scheme of resistance measurements in the two-point method. Changes in resistance were monitored by an automatic data acquisition unit Agilent 34970A for various hydrogen concentrations in nitrogen or in air.</div>


interaction of hydrogen with bilayer structures metal-free phthalocyanine and palladium there occurs a strong change in the resistance of these structures. This would correspond to an acousto-electric effect in the SAW sensor system

<div style="text-align: center;"><img src="imgs/img_in_chart_box_333_704_1292_1311.jpg" alt="Image" width="58%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_332_1355_1295_1956.jpg" alt="Image" width="58%" /></div>


<div style="text-align: center;">Fig. 3. Changes in the resistance of structures with two different thicknesses of metal-free phthalocyanine (55 nm circle – left axis, and 80 nm triangle – right axis) interaction in nitrogen, (a) at lower hydrogen concentrations 0.5–2.5% and (b) at higher concentrations 2.5–4%.</div>
