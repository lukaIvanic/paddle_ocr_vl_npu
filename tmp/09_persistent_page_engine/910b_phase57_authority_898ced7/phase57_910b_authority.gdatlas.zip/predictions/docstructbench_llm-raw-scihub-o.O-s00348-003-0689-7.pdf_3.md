<div style="text-align: center;"><img src="imgs/img_in_image_box_126_134_1033_264.jpg" alt="Image" width="54%" /></div>


<div style="text-align: center;">Fig. 2. Diagram of trigger system for rotor-laser synchronization</div>


<div style="text-align: center;">Table 1. Example solution for rotor-laser synchronization</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Rotor</td><td style='text-align: center; word-wrap: break-word;'>Laser flash lamps</td><td style='text-align: center; word-wrap: break-word;'>Rotor frequency/flash lamp rate</td><td style='text-align: center; word-wrap: break-word;'>Camera and q-switch</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>1,041 RPM~17.35 Hz</td><td style='text-align: center; word-wrap: break-word;'>9.914 Hz</td><td style='text-align: center; word-wrap: break-word;'>m/n=7/4</td><td style='text-align: center; word-wrap: break-word;'>2.479 Hz</td></tr></table>

constant rotor frequency, a very accurate and stable phase shift could be achieved.

## 3 

## Flow seeding

Di-ethyl-hexyl-sebacat (DEHS) atomized by Laskin nozzle particle generators was used to seed the flow. The particles were pumped through a distribution rake mounted in the settling chamber of the wind tunnel. The rake was remotely traversed to guide the homogeneous seed stream to the region of interest. The DEHS droplets generated and distributed by this arrangement have a mean diameter below 1  $ \mu $m as confirmed by previous tests. The rake and the resulting particle distribution during testing can be seen in Fig. 3. Although seed particles are visible inside the tip vortex, the seeding density is noticeably lower than in the remainder of the flow field. This can be explained by the reduced air density inside the core and centrifugal forces that affect the particle distribution (for a more detailed discussion of particle behaviour, see e.g. Grant 1994).

## 4 

## Cameras and light sheet traverses

The PIV system consisted of five digital cameras and three double-pulse Nd:YAG lasers (2×320 mJ each). The output beams from the laser systems were combined to produce an intense light sheet that was approximately 1.5 m wide and 7 mm thick. The resulting sheet was oriented at an angle of  $ 30.6^{\circ} $ with respect to the axis of the wind tunnel (Fig. 4). Cameras, lasers and light sheet optics were mounted on a traversing system (the common support system of the DNW-LLE). In this set-up, the distance between the cameras and the light sheet could be kept constant during all PIV measurements. Therefore, a pixel-to-length re-calibration and camera alignment (which usually has to be performed after each change in the set-up) could be avoided. Additional traverses were mounted to the tower of the common support (Fig. 4) in order to move the cameras parallel to the light sheet in an up and down direction (along the z axis). The common support itself allows for positioning the camera view along three axes (Fig. 5), two lateral axes (x and y) and one rotation angle.

<div style="text-align: center;"><img src="imgs/img_in_image_box_128_1226_529_1640.jpg" alt="Image" width="24%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_537_1227_998_1642.jpg" alt="Image" width="27%" /></div>


<div style="text-align: center;">Fig. 3. The distribution of seed particles in the settling chamber and in the test section</div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_127_1713_602_2046.jpg" alt="Image" width="28%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_image_box_611_1733_1004_2051.jpg" alt="Image" width="23%" /></div>


<div style="text-align: center;">Fig. 4. PIV cameras and viewing direction (flow from above)</div>
