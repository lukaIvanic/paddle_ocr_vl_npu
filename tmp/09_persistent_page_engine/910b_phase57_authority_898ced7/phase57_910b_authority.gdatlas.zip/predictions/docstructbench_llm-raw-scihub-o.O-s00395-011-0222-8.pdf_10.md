<div style="text-align: center;"><img src="imgs/img_in_chart_box_315_160_808_663.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_848_162_1335_658.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_335_670_810_1197.jpg" alt="Image" width="28%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_853_667_1336_1195.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_315_1205_809_1670.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">Fig. 5 Effect of Akt overexpression (AOE) on aging-induced change in insulin receptor  $ \beta $ (panel a), DKI phosphorylation (panel b), Akt phosphorylation (panel c) and Thr $ ^{208} $ (panel d). GSK3 $ \beta $ phosphorylation (pGSK3 $ \beta $-to-GSK3 $ \beta $ ratio, panel e), and PTEN phosphorylation (pPTEN-to-PTEN ratio, panel f).</div>


<div style="text-align: center;"><img src="imgs/img_in_chart_box_847_1206_1332_1670.jpg" alt="Image" width="29%" /></div>


<div style="text-align: center;">Insets: representative gel blots depicting expression and phosphorylation of these proteins using specific antibodies.  $ \alpha $-Tubulin was used as the loading control. Mean  $ \pm $ SEM, n=5–7 mice per group,  $ *p<0.05 $ versus WT-young group,  $ \#p<0.05 $ versus WT-old group</div>


an index for lysosomal activity [11, 33], was determined in young or aged WT and Akt transgenic mice. Our data failed to revealed altered  $ \beta $-glucuronidase activity in response to aging. Akt overactivation, or both. In addition, the levels of the two autophagy-related lysosomal proteins, cathepsin B and LAMP1, were examined [17, 22]. Neither

