<div style="text-align: center;"><img src="imgs/img_in_image_box_75_155_1594_852.jpg" alt="Image" width="90%" /></div>


# A Miniature Marvel of Monsters, Mayhem and Miscellany

Steve Brown

<div style="text-align: center;"><img src="imgs/img_in_image_box_68_1000_1079_1220.jpg" alt="Image" width="60%" /></div>


The Orc Inn,

with reserved

parking for

important chariots

(When Steve Brown showed up at GenCon XII, he wanted to enter his fantastic “underground orc castle” in the figure painting contest sponsored by TSR Periodicals. It didn't qualify for any category, but we couldn't ignore it! Steve got a special award, The Dragon got some photographs of his work, and Steve talked into a tape recorder for a while to provide this “guided tour” for TD's readers.)

Welcome, ladies and gentlemen, to this special guided tour of the secret underground castle of the orcs. Please stay with the group at all times, and don't touch anything if you want to leave with the same number of fingers you came with.

Now we're just inside the main gate, where we can see a party of sentry orcs preparing to scout the area for unaccompanied humans and other creatures. The orcs fancy themselves a very cultured group and want to keep the riff-raff humans, elves and dwarves out of the area.



The best in orc lodging is available at the inn, and the prices are right. According to the sign, it's 4 cp a night for a bed, 6 cp for a pot-luck dinner, 2 cp for housekeeping, but there's a limit of five to a bed.

The guard dog at the gate seems to be giving a passer-by a little trouble, but all he can do is growl as long as he's chained to the wall. Near the gate is a party of scavengers coming back with more wood for construction inside the castle.

Now we're passing the parking-lot area, which contains two of the orcs' more impressive chariots: The big, bad Lord's chariot and the "living chariot" of the Wizard, with eyes that glow!

Weapons, weapons everywhere in the guard room

<div style="text-align: center;"><img src="imgs/img_in_image_box_600_1631_1605_1936.jpg" alt="Image" width="59%" /></div>


Follow me past the loading-dock area into the guard room. As we enter, you can see on the left the commander's office, his desk, recruiting posters, and bulletin board. The commander's bedroom is upstairs.

The guard room also serves as an armory, where all the orcs' weapons are kept in case of a combat alert. The soldiers have a fireman's pole to slide down so they can answer an alert in less time than it takes to eat a hobbit. The armory is full of captured weapons, everything from crossbows to dwarven hammers, which are prizes from past conquests.

