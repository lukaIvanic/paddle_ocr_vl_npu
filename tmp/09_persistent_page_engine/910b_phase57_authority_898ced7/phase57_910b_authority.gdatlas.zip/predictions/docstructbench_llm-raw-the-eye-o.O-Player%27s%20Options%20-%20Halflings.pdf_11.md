<div style="text-align: center;">TABLE 5: WEAPONS</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Weapon</td><td style='text-align: center; word-wrap: break-word;'>Cost</td><td style='text-align: center; word-wrap: break-word;'>Dmg (S)</td><td style='text-align: center; word-wrap: break-word;'>Dmg (M)</td><td style='text-align: center; word-wrap: break-word;'>Critical</td><td style='text-align: center; word-wrap: break-word;'>Range</td><td style='text-align: center; word-wrap: break-word;'>Weight</td><td style='text-align: center; word-wrap: break-word;'>Type</td><td style='text-align: center; word-wrap: break-word;'>Special</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Slingshot, Halfling</td><td style='text-align: center; word-wrap: break-word;'>15 gp</td><td style='text-align: center; word-wrap: break-word;'>1d4</td><td style='text-align: center; word-wrap: break-word;'>1d6</td><td style='text-align: center; word-wrap: break-word;'>19-20/x2</td><td style='text-align: center; word-wrap: break-word;'>75 ft.</td><td style='text-align: center; word-wrap: break-word;'>1 lb.</td><td style='text-align: center; word-wrap: break-word;'>B</td><td style='text-align: center; word-wrap: break-word;'>-</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Bullets, Slingshot (10)</td><td style='text-align: center; word-wrap: break-word;'>1 sp</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>5 lbs.</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Sling-staff, Halfling</td><td style='text-align: center; word-wrap: break-word;'>25 gp</td><td style='text-align: center; word-wrap: break-word;'>2d3/1d6</td><td style='text-align: center; word-wrap: break-word;'>2d4/1d8</td><td style='text-align: center; word-wrap: break-word;'>19-20/x2</td><td style='text-align: center; word-wrap: break-word;'>50 ft.</td><td style='text-align: center; word-wrap: break-word;'>2 lbs.</td><td style='text-align: center; word-wrap: break-word;'>B/B</td><td style='text-align: center; word-wrap: break-word;'>-</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Bullets, Sling-staff (10)</td><td style='text-align: center; word-wrap: break-word;'>1sp</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>5 lbs.</td><td style='text-align: center; word-wrap: break-word;'>-</td><td style='text-align: center; word-wrap: break-word;'>-</td></tr></table>

<div style="text-align: center;">TABLE 6: MUNDANE GEAR</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Item</td><td style='text-align: center; word-wrap: break-word;'>Cost</td><td style='text-align: center; word-wrap: break-word;'>Weight</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Halfling Blueberry Ale\n(sold by pint bottle, 1-gallon keg, and 5-gallon keg)</td><td style='text-align: center; word-wrap: break-word;'>7 cp/5 sp/2 gp</td><td style='text-align: center; word-wrap: break-word;'>-</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Halfling Cloak</td><td style='text-align: center; word-wrap: break-word;'>25 gp (50 gp)</td><td style='text-align: center; word-wrap: break-word;'>2 lbs. (3 lbs.)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Halfling Pouch Belt</td><td style='text-align: center; word-wrap: break-word;'>10 gp (15 gp)</td><td style='text-align: center; word-wrap: break-word;'>1 lb. (1 1/2 lbs.)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Halfling Tobacco</td><td style='text-align: center; word-wrap: break-word;'>7 sp</td><td style='text-align: center; word-wrap: break-word;'>1 lb.</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Halfling Tri-flute</td><td style='text-align: center; word-wrap: break-word;'>9 gp</td><td style='text-align: center; word-wrap: break-word;'>-</td></tr></table>

allows a traveler to walk or ride in the rain or snow without getting soaked to the bone. Wearers of these cloaks benefit from condition similar to that provided by endure elements, though it only protects from cold brought on specifically due to exposure to rain and/or snow.

Occasionally, halflings may make these cloaks for the “big folk”. For anyone larger than a halfling, use the cost and weight in parenthesis.

Halffling Pouch Belt: The halfling pouch belt is a sturdy but supple leather belt with six leather pouches sewn to it. Each pouch closes via a brass button, and each can hold about as much as a standard halfling-sized belt pouch. The organization the pouches afford means items may be retrieved quickly. One item per round may be accessed as a swift action. Accessing any other items from the pouches – or placing them in the pouches – takes a normal move action.

Occasionally, halflings may make these belts for the "big folk". For anyone larger than a halfling, use the cost

<div style="text-align: center;"><img src="imgs/img_in_image_box_146_1521_510_2041.jpg" alt="Image" width="21%" /></div>


and weight in parenthesis.

Halfling Tobacco: Also known as pipeweed, halfling leaf or sometimes just leaf, halfling tobacco has been perfected over many decades to be very mild, very sweet and slow burning.

Halfling Tri-Flute:

The halfling tri-flute may be a variant or descendant of the aulos or pan-pipe, or it may be a unique creation altogether. It consists of three short wooden flutes, each of varying lengths, connected with leather bands. There are four fingerholes on the longest pipe, three on the shortest and none on the middle pipe. A single mouthpiece connects to all three pipes.









<div style="text-align: center;"><img src="imgs/img_in_image_box_867_1302_1543_2031.jpg" alt="Image" width="39%" /></div>
