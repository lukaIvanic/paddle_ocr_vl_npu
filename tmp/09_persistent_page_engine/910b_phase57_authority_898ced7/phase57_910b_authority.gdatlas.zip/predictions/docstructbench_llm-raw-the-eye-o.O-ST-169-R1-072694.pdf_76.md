## Result Parameter Details

## Peripheral Control Status

The SMPC outputs the peripheral control status to the status register (SR) when the SMPC control mode is used. The status register (SR) is a register that can be read without regard for the INTBACK command. However, when the register is read when the INTBACK command is not in use, all bits except the RESB bit will be undefined.

<div style="text-align: center;"><img src="imgs/img_in_image_box_147_526_1405_1402.jpg" alt="Image" width="74%" /></div>


<div style="text-align: center;">Figure 3.13 Peripheral Control Status</div>
