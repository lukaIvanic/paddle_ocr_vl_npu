
<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Constant</td><td style='text-align: center; word-wrap: break-word;'>Value</td><td style='text-align: center; word-wrap: break-word;'>Meaning</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>kAlertStdAlertOKButton</td><td style='text-align: center; word-wrap: break-word;'>1</td><td style='text-align: center; word-wrap: break-word;'>The OK push button. The default text for this push button is “OK”.</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>kAlertStdAlertCancelButton</td><td style='text-align: center; word-wrap: break-word;'>2</td><td style='text-align: center; word-wrap: break-word;'>The Cancel push button (optional). The default text for this push button is “Cancel”.</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>kAlertStdAlertOtherButton</td><td style='text-align: center; word-wrap: break-word;'>3</td><td style='text-align: center; word-wrap: break-word;'>A third push button (optional). The default text for this push button is “Don’t Save”.</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>kAlertStdAlertHelpButton</td><td style='text-align: center; word-wrap: break-word;'>4</td><td style='text-align: center; word-wrap: break-word;'>The Help push button (optional).</td></tr></table>

## Creating Dialog Boxes

Dialog boxes may be created in one of two ways:

Using the function GetNewDialog, which takes descriptive information about the dialog from dialog ('DLOG') and extended dialog ('dIGx') resources. The resource ID of the 'DLOG' and 'dIGx' resources must be the same, and is passed in the first parameter of this function.

Using NewDialog, NewColorDialog, or NewFeaturesDialog, which take descriptive information passed in the parameters of those functions.

## Historical Note

The extended dialog resource and the NewFeaturesDialog function were introduced with OS 8 and the Appearance Manager. NewFeaturesDialog should be used to create Appearance-compliant dialogs. Unlike NewDialog and NewColorDialog, it has a flags parameter containing the same flags you would set in an extended dialog resource.

If NULL is specified as the second parameter in the GetNewDialog call, GetNewDialog itself creates a non-relocatable block for the dialog structure. Passing NULL is appropriate for modal and movable modal dialog boxes because you should dispose of the dialog box, and hence the associated dialog structure, when the user dismisses the dialog. However, in order to avoid heap fragmentation effects, you should ordinarily allocate your own memory for modeless dialog box dialog structures (just as you would for a window structure) and specify the pointer to that memory block in the second parameter of the GetNewDialog call.

Regardless of which method is used to create the dialog, a dialog structure and a window structure will be created, and a pointer to the dialog structure will be returned to the calling function.

## The Dialog Structure

The dialog structure created by the GetNewDialog call is defined by the data type DiaIogRecord:

struct DialogRecord
{
    WindowRecord window; // Dialog's window record.
    Handle items; // Item list resource.
    TEHARide textId; // Current editable text item.
    SNT16 editField; // Editable text item number minus 1.
    SNT16 editOpen; // (Used internally.)
    SNT16 aDefItem; // Default push button item number.
};
typedef struct DialogRecord DialogRecord;
typedef DialogRecord *DialogPeek;

Note that the dialog structure includes a window structure field. The Dialog Manager sets the windowKind field of this window structure to kDialogWindowKind.