## 六、 附录

## 市场行情

截至2023年2月24日，上证综指年初至今累计上涨5.76%，汽车（申万）指数累计上涨10.85%；沪深300指数上涨4.89%；创业板指数上涨3.50%；深证成指上涨7.00%。

<div style="text-align: center;">表8：汽车与A股综合指数行情回顾</div>



<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>证券代码</td><td style='text-align: center; word-wrap: break-word;'>证券简称</td><td style='text-align: center; word-wrap: break-word;'>收盘价\n(2023-2-24)</td><td style='text-align: center; word-wrap: break-word;'>5日涨跌幅（%）</td><td style='text-align: center; word-wrap: break-word;'>20日涨跌幅\n(%)</td><td style='text-align: center; word-wrap: break-word;'>年初至今涨跌幅\n(%)</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>801880.SI</td><td style='text-align: center; word-wrap: break-word;'>汽车(申万)</td><td style='text-align: center; word-wrap: break-word;'>5,922.84</td><td style='text-align: center; word-wrap: break-word;'>0.70</td><td style='text-align: center; word-wrap: break-word;'>4.83</td><td style='text-align: center; word-wrap: break-word;'>10.85</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>000001.SH</td><td style='text-align: center; word-wrap: break-word;'>上证综指</td><td style='text-align: center; word-wrap: break-word;'>3,267.16</td><td style='text-align: center; word-wrap: break-word;'>0.56</td><td style='text-align: center; word-wrap: break-word;'>0.83</td><td style='text-align: center; word-wrap: break-word;'>5.76</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>000300.SH</td><td style='text-align: center; word-wrap: break-word;'>沪深 300</td><td style='text-align: center; word-wrap: break-word;'>4,061.05</td><td style='text-align: center; word-wrap: break-word;'>-0.79</td><td style='text-align: center; word-wrap: break-word;'>-2.28</td><td style='text-align: center; word-wrap: break-word;'>4.89</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>399006.SZ</td><td style='text-align: center; word-wrap: break-word;'>创业板指</td><td style='text-align: center; word-wrap: break-word;'>2,428.94</td><td style='text-align: center; word-wrap: break-word;'>-3.33</td><td style='text-align: center; word-wrap: break-word;'>-5.54</td><td style='text-align: center; word-wrap: break-word;'>3.50</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>399001.SZ</td><td style='text-align: center; word-wrap: break-word;'>深证成指</td><td style='text-align: center; word-wrap: break-word;'>11,787.45</td><td style='text-align: center; word-wrap: break-word;'>-1.01</td><td style='text-align: center; word-wrap: break-word;'>-1.06</td><td style='text-align: center; word-wrap: break-word;'>7.00</td></tr></table>

资料来源：wind，中国银河证券研究院

## 行业重要政策发布及新闻

#### 1、 关于支持新能源商品汽车铁路运输 服务新能源汽车产业发展的意见 2023.01.30

积极鼓励铁路运输企业开展新能源商品汽车铁路运输业务，对纳入工业和信息化部《道路机动车辆生产企业及产品公告》范围（出口新能源商品汽车产品不受此限制），采用锂离子电池驱动的插电式混合动力或纯电动新能源商品汽车，依据《铁路安全管理条例》《铁路危险货物运输安全监督管理规定》《危险货物品名表》（GB 12268）等法律法规和有关标准，铁路运输新能源商品汽车不按危险货物管理，由承托双方按照本通知要求办理运输。办理新能源商品汽车国际铁路联运，应当符合铁路合作组织《国际铁路货物联运协定》附件第2号《危险货物运送规则》等有关规定。

资料来源： $ \underline{\text{http://www.caam.org.cn/chn/9/cate_95/con_5236654.html}} $

#### 2、 关于组织开展公共领域车辆全面电动化先行区试点工作的通知 2023.01.30

按照需求牵引、政策引导、因地制宜、联动融合的原则，在完善公共领域车辆全面电动化支撑体系，促进新能源汽车推广、基础设施建设、新技术新模式应用、政策标准法规完善等方面积极创新、先行先试，探索形成一批可复制可推广的经验和模式，为新能源汽车全面市场化拓展和绿色低碳交通运输体系建设发挥示范带动作用。

资料来源： $ \underline{\text{http://www.caam.org.cn/chn/9/cate_95/con_5236695.html}} $

#### 3、 发改委：巩固新能源汽车等优势产业领先地位2023.02.16

2月16日，国家发展和改革委员会在《求是》杂志发布文章《努力推动经济实现质的有效提升和量的合理增长》。文章提出，深入实施产业基础再造工程，支持专精特新企业发展，推动制造业高端化、智能化、绿色化发展。巩固新能源汽车等优势产业领先地位，壮大人工智能、生物制造、绿色低碳等战略性新兴产业。

资料来源： $ \underline{\text{http://www.caam.org.cn/chn/9/cate_95/con_5236724.html}} $