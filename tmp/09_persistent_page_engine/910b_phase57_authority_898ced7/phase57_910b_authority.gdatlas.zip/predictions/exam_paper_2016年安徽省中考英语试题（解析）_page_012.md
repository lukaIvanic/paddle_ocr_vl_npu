72.B

73\.A

74\.B

## 【解析】

试题分析：这篇短文主要介绍了马可波罗历经三年半的时间到达中国。在中国居住了17年之久，在回家后把在中国的经历著成了一本书。

71.C 推理判断题。根据短文 But it was very hard for people from Europe to visit China then. After three and a half years, the Polos reached China on 1275. 可知当时马可波罗的旅行是艰苦的，故选 C。

72 B 细节理解题。根据短文 filter three and a half years, the Polos reached China on 1275 可知马可波罗一家在1275年到达中国，故选B。

73.A 细节理解题。根据 While he was there, Marco Polo worked for Kublai Khan, the emperor (皇帝) of China. 可知他为中国的皇帝效力，故选 A。

74.B 归纳理解题。根据短文主要描述了马可波罗到中国旅行的经历，故选 B。学科网考点：故事类短文阅读。

## B

Robots seem to be getting cleverer and cleverer. Here are four examples.


<table border=1 style='margin: auto; word-wrap: break-word;'><tr><td style='text-align: center; word-wrap: break-word;'>Budgee<img src="imgs/img_in_image_box_613_1262_710_1383.jpg" alt="Image"" />\n·He was created by Five Elements Robotics.·With two wheels and a little basket, he can carry things for you while you&#x27;re at the shops.</td><td style='text-align: center; word-wrap: break-word;'>Paro<img src="imgs/img_in_image_box_1178_1272_1305_1414.jpg" alt="Image"" />\n·He was made by Takanori Shibata.·He is used on patients in hospitals.·He can learn a name and even show feelings such as surprise, happiness and sadness.</td></tr><tr><td style='text-align: center; word-wrap: break-word;'>Rover<img src="imgs/img_in_image_box_587_1656_715_1774.jpg" alt="Image"" />\n·He was created by a team at Sydney University.·He is used to make cows move together from a field to a diary（牛奶场）.</td><td style='text-align: center; word-wrap: break-word;'>Simon<img src="imgs/img_in_image_box_1184_1676_1305_1810.jpg" alt="Image"" />\n·He was developed by the Georgia Institute of Technology.·He can clean up offices.·In tests, he could tell whether someone was paying attention to him or not.</td></tr></table>

75. Which robot can help you when you are shopping?