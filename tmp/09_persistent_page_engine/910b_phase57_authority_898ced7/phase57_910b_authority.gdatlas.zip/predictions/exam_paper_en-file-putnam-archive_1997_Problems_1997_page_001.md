# The 58th William Lowell Putnam Mathematical Competition Saturday, December 6, 1997

A-1 A rectangle, HOMF, has sides HO = 11 and OM = 5. A triangle ABC has H as the intersection of the altitudes, O the center of the circumscribed circle, M the midpoint of BC, and F the foot of the altitude from A. What is the length of BC?

A–2 Players 1, 2, 3, ..., n are seated around a table, and each has a single penny. Player 1 passes a penny to player 2, who then passes two pennies to player 3. Player 3 then passes one penny to Player 4, who passes two pennies to Player 5, and so on, players alternately passing one penny or two to the next player who still has some pennies. A player who runs out of pennies drops out of the game and leaves the table. Find an infinite set of numbers n for which some player ends up with all n pennies.

## A–3 Evaluate

 $$ \begin{aligned}\int_{0}^{\infty}\left(x-\frac{x^{3}}{2}+\frac{x^{5}}{2\cdot4}-\frac{x^{7}}{2\cdot4\cdot6}+\cdots\right)\\\left(1+\frac{x^{2}}{2^{2}}+\frac{x^{4}}{2^{2}\cdot4^{2}}+\frac{x^{6}}{2^{2}\cdot4^{2}\cdot6^{2}}+\cdots\right)dx.\end{aligned} $$ 

A-4 Let $G$ be a group with identity $e$ and $\phi: G \to G$ a function such that

 $$ \phi(g_{1})\phi(g_{2})\phi(g_{3})=\phi(h_{1})\phi(h_{2})\phi(h_{3}) $$ 

whenever $g_{1}g_{2}g_{3}=e=h_{1}h_{2}h_{3}$. Prove that there exists an element $a\in G$ such that $\psi(x)=a\phi(x)$ is a homomorphism (i.e. $\psi(xy)=\psi(x)\psi(y)$ for all $x,y\in G$).

A–5 Let $N_{n}$ denote the number of ordered $n$-tuples of positive integers $(a_{1},a_{2},\ldots,a_{n})$ such that $1/a_{1}+1/a_{2}+\ldots+1/a_{n}=1$. Determine whether $N_{10}$ is even or odd.

A–6 For a positive integer n and any real number c, define  $ x_k $ recursively by  $ x_0 = 0 $,  $ x_1 = 1 $, and for  $ k \geq 0 $,

 $$ x_{k+2}=\frac{c x_{k+1}-(n-k)x_{k}}{k+1}. $$ 

Fix $n$ and then take $c$ to be the largest value for which $x_{n+1} = 0$. Find $x_{k}$ in terms of $n$ and $k$, $1 \leq k \leq n$.

B-1 Let $\{x\}$ denote the distance between the real number $x$ and the nearest integer. For each positive integer $n$, evaluate



 $$ F_{n}=\sum_{m=1}^{6n-1}\min(\{\frac{m}{6n}\},\{\frac{m}{3n}\}). $$ 

(Here  $ \min(a,b) $ denotes the minimum of a and b.)

B-2 Let f be a twice-differentiable real-valued function satisfying

 $$ f(x)+f^{\prime \prime}(x)=-xg(x)f^{\prime}(x), $$ 

where  $ g(x) \geq 0 $ for all real x. Prove that  $ |f(x)| $ is bounded.

B-3 For each positive integer $n$, write the sum $\sum_{m=1}^{n}1/m$ in the form $p_n/q_n$, where $p_n$ and $q_n$ are relatively prime positive integers. Determine all $n$ such that 5 does not divide $q_n$.

B-4 Let  $ a_{m,n} $ denote the coefficient of  $ x^n $ in the expansion of  $ (1 + x + x^2)^m $. Prove that for all [integers]  $ k \geq 0 $,

 $$ 0\leq\sum_{i=0}^{\lfloor\frac{2k}{3}\rfloor}(-1)^{i}a_{k-i,i}\leq1. $$ 

B-5 Prove that for  $ n \geq 2 $,

 $$ \overbrace{2^{2^{\cdots^{2}}}}^{n terms}\equiv\overbrace{2^{2^{\cdots^{2}}}}^{n-1 terms} $$ 

B-6 The dissection of the 3-4-5 triangle shown below (into four congruent right triangles similar to the original) has diameter 5/2. Find the least diameter of a dissection of this triangle into four parts. (The diameter of a dissection is the least upper bound of the distances between pairs of points belonging to the same part.)